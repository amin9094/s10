"""Bounded synthetic integration exercise; never a live-market attestation.

Uses genuine engine fixture plans and production inbox/paper/backup code.
No external API, Telegram dispatch or broker execution is involved.
"""
import argparse,json,os,sys,tempfile,time
from decimal import Decimal as D
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:sys.path.insert(0,str(ROOT))


def exercise(*,cycles=2):
    from tests.test_v9_market_pending_accounts import setup
    from core.storage.engine import DatabaseEngine
    from repositories.v2.live_signal_inbox import LiveSignalInbox,STRATEGIES
    from repositories.v2.strategy_paper import StrategyPaperRepository
    from repositories.v2.common import content_hash
    from modules.signal_execution import build_market
    from scripts.strategy_restore_exercise import exercise as restore
    fixtures={k:setup(k) for k in STRATEGIES};started=time.monotonic();states={};count=0
    with tempfile.TemporaryDirectory(prefix='sentinel-synthetic-soak-') as folder:
        db=DatabaseEngine(database_url='',sqlite_path=Path(folder)/'exercise.sqlite3');db.ensure_schema()
        inbox=LiveSignalInbox(db);repo=StrategyPaperRepository(db);clock=[1.]
        try:
            with patch('repositories.v2.strategy_paper.time.time',lambda:clock[0]):
                for cycle in range(cycles):
                    for engine,(context,plan,base) in fixtures.items():
                        now=context.cutoff_ms+cycle*1000;clock[0]=now/1000
                        quantum=D(plan.get('tick_size',plan.get('calculation_quantum')))
                        # Both sides must still be outside the whole entry zone.
                        q={**base,'id':f'{cycle}-{engine}-start','epoch':f'cycle-{cycle}',
                           'bid':str(D(base['bid'])+quantum),'ask':str(D(base['ask'])+quantum),
                           'event_ms':now,'received_ms':now}
                        pending=inbox.stage(f'{cycle}-{engine}','native',plan,content_hash(plan),profile_id=context.parameters.profile_id)
                        inbox.update(pending,'PENDING',pending['payload']);pending=inbox.get(pending['id'])
                        market=build_market(plan,pending['id'],q,now)
                        immediate=inbox.stage(f'{cycle}-{engine}-market','native',market,content_hash(market),profile_id=context.parameters.profile_id)
                        inbox.update(immediate,'PENDING',immediate['payload']);immediate=inbox.get(immediate['id'])
                        for row in (pending,immediate):
                            enrollment=repo.enroll(row,q);trade_id=enrollment['trade_id']
                            # Editorial cancellation must never stop the experiment.
                            inbox.terminate(row['id'],'CANCELLED','SYNTHETIC_EDITORIAL_DECISION')
                            ticks=[]
                            prices=[plan['entry'],plan['tp1'],plan['stop']]
                            for n,price in enumerate(prices,1):
                                ticks.append({**q,'id':q['id']+f'-{n}','bid':price,'ask':price,'event_ms':now+n*100,'received_ms':now+n*100})
                            if cycle%2:ticks[0]['epoch']='interrupted-source'
                            repo.tick_batch(trade_id,ticks);state=repo.trade(trade_id)['state'];states[state]=states.get(state,0)+1;count+=1
                recovery=restore(db)
                with db.transaction(read_only=True) as c:accounts=c.execute('SELECT COUNT(*) AS n FROM s9_strategy_paper_runs WHERE active=1').fetchone()['n']
        finally:db.close()
    return {'scope':'SYNTHETIC_OFFLINE_INTEGRATION_NOT_LIVE_OR_LONG_DURATION_CERTIFICATION','cycles':cycles,
            'trades':count,'accounts':accounts,'states':states,'elapsed_seconds':round(time.monotonic()-started,3),
            'all_editorial_cancelled':True,'restore':recovery,'external_network_used':False}


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--cycles',type=int,default=2);parser.add_argument('--output',required=True);args=parser.parse_args()
    if not 1<=args.cycles<=100:raise ValueError('EXERCISE_CYCLES_OUT_OF_BOUNDS')
    report=exercise(cycles=args.cycles);Path(args.output).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(report))


if __name__=='__main__':
    code=1
    try:main();code=0
    finally:sys.stdout.flush();sys.stderr.flush();os._exit(code)
