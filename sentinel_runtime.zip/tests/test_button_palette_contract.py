from __future__ import annotations

import importlib
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from telegram_test_stub import install

install()


def _factory():
    module = importlib.import_module("ui.button_factory")
    return module.InlineKeyboardButton, module.state_button


def test_final_user_palette_uses_real_native_styles():
    button, _ = _factory()

    vip = button("💎 خرید اشتراک VIP", callback_data="u_vip")
    education = button("🎓 آموزش", callback_data="u_edu")
    market = button("💹 بازار و خبر", callback_data="nav_user:markets")
    calculator = button("🧮 ماشین حساب", callback_data="u_calc")
    trading = button("📡 مرکز معاملاتی", callback_data="nav_user:trade", style="primary")
    account = button("👤 حساب‌های من", callback_data="u_account", style="primary")
    admin = button("🛠 مرکز مدیریت", callback_data="admin_home", style="primary")
    cancel = button("✖️ لغو عملیات جاری", callback_data="cancel_current")
    back = button("↩️ بازگشت", callback_data="home")

    assert vip.style == "success"
    assert education.style is None
    assert market.style is None
    assert calculator.style is None
    assert getattr(trading, "style", None) == "primary"
    assert getattr(account, "style", None) is None
    assert getattr(admin, "style", None) is None
    assert cancel.style == "danger"
    assert back.style is None


def test_admin_state_controls_keep_green_and_red():
    _, state_button = _factory()

    enabled = state_button("کنترل امنیت", True, callback_data="security_toggle")
    disabled = state_button("کنترل امنیت", False, callback_data="security_toggle")

    assert enabled.style == "success"
    assert disabled.style == "danger"
