"""Telegram handler packages extracted from the legacy bot entrypoint."""
