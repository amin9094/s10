from __future__ import annotations

import base64
import json
import os
import sqlite3
import threading
from contextlib import closing
from datetime import date, datetime
from decimal import Decimal
from pathlib import Path
from typing import Any

from telegram.ext import BasePersistence, PersistenceInput

from core.async_runtime import run_blocking

_TAG = "__sentinel_type__"


def _encode(value: Any) -> Any:
    if value is None or isinstance(value, (bool, int, float, str)):
        return value
    if isinstance(value, datetime):
        return {_TAG: "datetime", "value": value.isoformat()}
    if isinstance(value, date):
        return {_TAG: "date", "value": value.isoformat()}
    if isinstance(value, Decimal):
        return {_TAG: "decimal", "value": str(value)}
    if isinstance(value, bytes):
        return {_TAG: "bytes", "value": base64.b64encode(value).decode("ascii")}
    if isinstance(value, Path):
        return {_TAG: "path", "value": str(value)}
    if isinstance(value, tuple):
        return {_TAG: "tuple", "items": [_encode(item) for item in value]}
    if isinstance(value, set):
        return {_TAG: "set", "items": [_encode(item) for item in sorted(value, key=repr)]}
    if isinstance(value, list):
        return [_encode(item) for item in value]
    if isinstance(value, dict):
        return {_TAG: "dict", "items": [[_encode(key), _encode(item)] for key, item in value.items()]}
    # Conversation state values are normally integers/strings. Refuse unknown
    # executable objects instead of silently pickling them.
    raise TypeError(f"Unsupported persistence value: {type(value).__name__}")


def _decode(value: Any) -> Any:
    if isinstance(value, list):
        return [_decode(item) for item in value]
    if not isinstance(value, dict) or _TAG not in value:
        return value
    kind = value.get(_TAG)
    if kind == "datetime":
        return datetime.fromisoformat(str(value["value"]))
    if kind == "date":
        return date.fromisoformat(str(value["value"]))
    if kind == "decimal":
        return Decimal(str(value["value"]))
    if kind == "bytes":
        return base64.b64decode(str(value["value"]))
    if kind == "path":
        return Path(str(value["value"]))
    if kind == "tuple":
        return tuple(_decode(item) for item in value.get("items", []))
    if kind == "set":
        return set(_decode(item) for item in value.get("items", []))
    if kind == "dict":
        return {_decode(key): _decode(item) for key, item in value.get("items", [])}
    raise ValueError(f"Unknown persistence type tag: {kind!r}")


def _dumps(value: Any) -> str:
    return json.dumps(_encode(value), ensure_ascii=False, separators=(",", ":"), allow_nan=False)


def _loads(payload: str) -> Any:
    return _decode(json.loads(payload))


class SafeSQLitePersistence(BasePersistence[dict[str, Any], dict[str, Any], dict[str, Any]]):
    """Safe, queryable PTB persistence without Python pickle deserialization.

    The database is WAL-backed and updates are atomic. Only a small explicit
    JSON type vocabulary is accepted, so a tampered state file cannot execute
    arbitrary Python code during startup.
    """

    def __init__(self, filepath: str | Path, *, update_interval: float = 15) -> None:
        super().__init__(
            store_data=PersistenceInput(bot_data=True, chat_data=True, user_data=True, callback_data=False),
            update_interval=update_interval,
        )
        self.path = Path(filepath)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._initialize()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.path, timeout=30, isolation_level=None)
        try:
            connection.row_factory = sqlite3.Row
            connection.execute("PRAGMA journal_mode=WAL")
            connection.execute("PRAGMA synchronous=NORMAL")
            connection.execute("PRAGMA busy_timeout=30000")
            return connection
        except BaseException:
            connection.close()
            raise

    def _initialize(self) -> None:
        if self.path.exists() and (self.path.is_symlink() or not self.path.is_file()):
            raise RuntimeError("PERSISTENCE_FILE must be a regular file and not a symbolic link")
        with closing(self._connect()) as connection:
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS state (
                    scope TEXT NOT NULL,
                    entity_id TEXT NOT NULL,
                    payload TEXT NOT NULL,
                    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY(scope, entity_id)
                );
                CREATE TABLE IF NOT EXISTS conversations (
                    name TEXT NOT NULL,
                    conversation_key TEXT NOT NULL,
                    state_payload TEXT NOT NULL,
                    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY(name, conversation_key)
                );
                CREATE INDEX IF NOT EXISTS idx_conversations_name ON conversations(name);
                """
            )
        try:
            os.chmod(self.path, 0o600)
            os.chmod(self.path.parent, 0o700)
        except OSError:
            pass

    def _read_scope(self, scope: str) -> dict[int, dict[str, Any]]:
        with self._lock, closing(self._connect()) as connection:
            rows = connection.execute("SELECT entity_id, payload FROM state WHERE scope = ?", (scope,)).fetchall()
        result: dict[int, dict[str, Any]] = {}
        for row in rows:
            value = _loads(str(row["payload"]))
            if not isinstance(value, dict):
                raise ValueError(f"Persisted {scope} data must be a dictionary")
            result[int(row["entity_id"])] = value
        return result

    def _upsert(self, scope: str, entity_id: str, data: Any) -> None:
        payload = _dumps(data)
        with self._lock, closing(self._connect()) as connection:
            connection.execute(
                """
                INSERT INTO state(scope, entity_id, payload, updated_at)
                VALUES(?, ?, ?, CURRENT_TIMESTAMP)
                ON CONFLICT(scope, entity_id) DO UPDATE SET
                    payload = excluded.payload,
                    updated_at = CURRENT_TIMESTAMP
                """,
                (scope, entity_id, payload),
            )

    def _read_bot_sync(self) -> dict[str, Any]:
        with self._lock, closing(self._connect()) as connection:
            row = connection.execute(
                "SELECT payload FROM state WHERE scope = 'bot' AND entity_id = 'singleton'"
            ).fetchone()
        if row is None:
            return {}
        value = _loads(str(row["payload"]))
        if not isinstance(value, dict):
            raise ValueError("Persisted bot data must be a dictionary")
        return value

    def _get_conversations_sync(self, name: str) -> dict[tuple[int | str, ...], object]:
        with self._lock, closing(self._connect()) as connection:
            rows = connection.execute(
                "SELECT conversation_key, state_payload FROM conversations WHERE name = ? AND updated_at >= datetime('now', ?)",
                (name, f"-{max(60, min(86400, int(os.getenv('BOT_SESSION_TIMEOUT_SECONDS', '1800'))))} seconds")
            ).fetchall()
        result: dict[tuple[int | str, ...], object] = {}
        for row in rows:
            key = _loads(str(row["conversation_key"]))
            if not isinstance(key, tuple):
                raise ValueError("Persisted conversation key must be a tuple")
            result[key] = _loads(str(row["state_payload"]))
        return result

    def _update_conversation_sync(self, name: str, key: tuple[int | str, ...], new_state: object | None) -> None:
        encoded_key = _dumps(tuple(key))
        with self._lock, closing(self._connect()) as connection:
            if new_state is None:
                connection.execute(
                    "DELETE FROM conversations WHERE name = ? AND conversation_key = ?", (name, encoded_key)
                )
            else:
                connection.execute(
                    """
                    INSERT INTO conversations(name, conversation_key, state_payload, updated_at)
                    VALUES(?, ?, ?, CURRENT_TIMESTAMP)
                    ON CONFLICT(name, conversation_key) DO UPDATE SET
                        state_payload = excluded.state_payload,
                        updated_at = CURRENT_TIMESTAMP
                    """,
                    (name, encoded_key, _dumps(new_state)),
                )

    def _delete_sync(self, scope: str, entity_id: str) -> None:
        with self._lock, closing(self._connect()) as connection:
            connection.execute("DELETE FROM state WHERE scope = ? AND entity_id = ?", (scope, entity_id))

    def _flush_sync(self) -> None:
        with self._lock, closing(self._connect()) as connection:
            connection.execute("PRAGMA wal_checkpoint(PASSIVE)")

    async def get_user_data(self) -> dict[int, dict[str, Any]]:
        return await run_blocking(self._read_scope, "user", timeout=10)

    async def get_chat_data(self) -> dict[int, dict[str, Any]]:
        return await run_blocking(self._read_scope, "chat", timeout=10)

    async def get_bot_data(self) -> dict[str, Any]:
        return await run_blocking(self._read_bot_sync, timeout=10)

    async def get_callback_data(self) -> None:
        return None

    async def get_conversations(self, name: str) -> dict[tuple[int | str, ...], object]:
        return await run_blocking(self._get_conversations_sync, name, timeout=10)

    async def update_user_data(self, user_id: int, data: dict[str, Any]) -> None:
        await run_blocking(self._upsert, "user", str(user_id), data, timeout=10)

    async def update_chat_data(self, chat_id: int, data: dict[str, Any]) -> None:
        await run_blocking(self._upsert, "chat", str(chat_id), data, timeout=10)

    async def update_bot_data(self, data: dict[str, Any]) -> None:
        await run_blocking(self._upsert, "bot", "singleton", data, timeout=10)

    async def update_callback_data(self, data: object) -> None:
        return None

    async def update_conversation(self, name: str, key: tuple[int | str, ...], new_state: object | None) -> None:
        await run_blocking(self._update_conversation_sync, name, key, new_state, timeout=10)

    async def drop_user_data(self, user_id: int) -> None:
        await run_blocking(self._delete_sync, "user", str(user_id), timeout=10)

    async def drop_chat_data(self, chat_id: int) -> None:
        await run_blocking(self._delete_sync, "chat", str(chat_id), timeout=10)

    async def refresh_user_data(self, user_id: int, user_data: dict[str, Any]) -> None:
        return None

    async def refresh_chat_data(self, chat_id: int, chat_data: dict[str, Any]) -> None:
        return None

    async def refresh_bot_data(self, bot_data: dict[str, Any]) -> None:
        return None

    async def flush(self) -> None:
        await run_blocking(self._flush_sync, timeout=10)


class SafePostgresPersistence(BasePersistence[dict[str, Any], dict[str, Any], dict[str, Any]]):
    """Shared safe PTB persistence for webhook/multi-instance deployments.

    Payloads use the same explicit JSON codec as :class:`SafeSQLitePersistence`;
    no Python object deserialization is performed. Blocking psycopg operations
    are moved to a worker thread so Telegram's event loop remains responsive.
    """

    def __init__(self, dsn: str, *, update_interval: float = 15) -> None:
        super().__init__(
            store_data=PersistenceInput(bot_data=True, chat_data=True, user_data=True, callback_data=False),
            update_interval=update_interval,
        )
        if not str(dsn).startswith(("postgresql://", "postgres://")):
            raise ValueError("PostgreSQL persistence requires a postgresql:// DSN")
        self.dsn = str(dsn)
        try:
            from psycopg_pool import ConnectionPool
        except ImportError as exc:  # pragma: no cover - dependency is validated in release builds.
            raise RuntimeError("psycopg-pool is required for PostgreSQL persistence") from exc
        from core.postgres_runtime import connection_kwargs, normalize_database_url, pool_policy
        self.dsn = normalize_database_url(self.dsn)
        self._pool = ConnectionPool(
            conninfo=self.dsn,
            **pool_policy(legacy_max='POSTGRES_PERSISTENCE_POOL_MAX'),
            kwargs=connection_kwargs(autocommit=True, application_name='sentinel-telegram'),
            open=True,
        )
        try:
            self._initialize()
        except BaseException:
            self._pool.close()
            raise

    def _connect(self) -> Any:
        return self._pool.connection()

    def _initialize(self) -> None:
        with self._connect() as connection, connection.cursor() as cursor:
            cursor.execute(
                """
                CREATE TABLE IF NOT EXISTS telegram_state (
                    scope TEXT NOT NULL,
                    entity_id TEXT NOT NULL,
                    payload JSONB NOT NULL,
                    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                    PRIMARY KEY(scope, entity_id)
                )
                """
            )
            cursor.execute(
                """
                CREATE TABLE IF NOT EXISTS telegram_conversations (
                    name TEXT NOT NULL,
                    conversation_key TEXT NOT NULL,
                    state_payload JSONB NOT NULL,
                    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                    PRIMARY KEY(name, conversation_key)
                )
                """
            )
            cursor.execute(
                "CREATE INDEX IF NOT EXISTS idx_telegram_conversations_name ON telegram_conversations(name)"
            )

    def _read_scope_sync(self, scope: str) -> dict[int, dict[str, Any]]:
        with self._connect() as connection, connection.cursor() as cursor:
            cursor.execute("SELECT entity_id, payload FROM telegram_state WHERE scope = %s", (scope,))
            rows = cursor.fetchall()
        result: dict[int, dict[str, Any]] = {}
        for entity_id, raw in rows:
            value = _loads(raw if isinstance(raw, str) else json.dumps(raw, ensure_ascii=False))
            if not isinstance(value, dict):
                raise ValueError(f"Persisted {scope} data must be a dictionary")
            result[int(entity_id)] = value
        return result

    def _read_bot_sync(self) -> dict[str, Any]:
        with self._connect() as connection, connection.cursor() as cursor:
            cursor.execute(
                "SELECT payload FROM telegram_state WHERE scope = 'bot' AND entity_id = 'singleton'"
            )
            row = cursor.fetchone()
        if row is None:
            return {}
        raw = row[0]
        value = _loads(raw if isinstance(raw, str) else json.dumps(raw, ensure_ascii=False))
        if not isinstance(value, dict):
            raise ValueError("Persisted bot data must be a dictionary")
        return value

    def _upsert_sync(self, scope: str, entity_id: str, data: Any) -> None:
        payload = _dumps(data)
        with self._connect() as connection, connection.cursor() as cursor:
            cursor.execute(
                """
                INSERT INTO telegram_state(scope, entity_id, payload, updated_at)
                VALUES(%s, %s, %s::jsonb, NOW())
                ON CONFLICT(scope, entity_id) DO UPDATE SET
                    payload = EXCLUDED.payload,
                    updated_at = NOW()
                """,
                (scope, entity_id, payload),
            )

    def _get_conversations_sync(self, name: str) -> dict[tuple[int | str, ...], object]:
        with self._connect() as connection, connection.cursor() as cursor:
            cursor.execute(
                "SELECT conversation_key, state_payload FROM telegram_conversations WHERE name = %s AND updated_at >= NOW() - (%s * INTERVAL '1 second')",
                (name, max(60, min(86400, int(os.getenv('BOT_SESSION_TIMEOUT_SECONDS', '1800')))))
            )
            rows = cursor.fetchall()
        result: dict[tuple[int | str, ...], object] = {}
        for raw_key, raw_state in rows:
            key = _loads(str(raw_key))
            if not isinstance(key, tuple):
                raise ValueError("Persisted conversation key must be a tuple")
            state_payload = raw_state if isinstance(raw_state, str) else json.dumps(raw_state, ensure_ascii=False)
            result[key] = _loads(state_payload)
        return result

    def _update_conversation_sync(
        self,
        name: str,
        key: tuple[int | str, ...],
        new_state: object | None,
    ) -> None:
        encoded_key = _dumps(tuple(key))
        with self._connect() as connection, connection.cursor() as cursor:
            if new_state is None:
                cursor.execute(
                    "DELETE FROM telegram_conversations WHERE name = %s AND conversation_key = %s",
                    (name, encoded_key),
                )
                return
            cursor.execute(
                """
                INSERT INTO telegram_conversations(name, conversation_key, state_payload, updated_at)
                VALUES(%s, %s, %s::jsonb, NOW())
                ON CONFLICT(name, conversation_key) DO UPDATE SET
                    state_payload = EXCLUDED.state_payload,
                    updated_at = NOW()
                """,
                (name, encoded_key, _dumps(new_state)),
            )

    def _delete_sync(self, scope: str, entity_id: str) -> None:
        with self._connect() as connection, connection.cursor() as cursor:
            cursor.execute(
                "DELETE FROM telegram_state WHERE scope = %s AND entity_id = %s",
                (scope, entity_id),
            )

    async def get_user_data(self) -> dict[int, dict[str, Any]]:
        return await run_blocking(self._read_scope_sync, "user")

    async def get_chat_data(self) -> dict[int, dict[str, Any]]:
        return await run_blocking(self._read_scope_sync, "chat")

    async def get_bot_data(self) -> dict[str, Any]:
        return await run_blocking(self._read_bot_sync)

    async def get_callback_data(self) -> None:
        return None

    async def get_conversations(self, name: str) -> dict[tuple[int | str, ...], object]:
        return await run_blocking(self._get_conversations_sync, name)

    async def update_user_data(self, user_id: int, data: dict[str, Any]) -> None:
        await run_blocking(self._upsert_sync, "user", str(user_id), data)

    async def update_chat_data(self, chat_id: int, data: dict[str, Any]) -> None:
        await run_blocking(self._upsert_sync, "chat", str(chat_id), data)

    async def update_bot_data(self, data: dict[str, Any]) -> None:
        await run_blocking(self._upsert_sync, "bot", "singleton", data)

    async def update_callback_data(self, data: object) -> None:
        return None

    async def update_conversation(self, name: str, key: tuple[int | str, ...], new_state: object | None) -> None:
        await run_blocking(self._update_conversation_sync, name, key, new_state)

    async def drop_user_data(self, user_id: int) -> None:
        await run_blocking(self._delete_sync, "user", str(user_id))

    async def drop_chat_data(self, chat_id: int) -> None:
        await run_blocking(self._delete_sync, "chat", str(chat_id))

    async def refresh_user_data(self, user_id: int, user_data: dict[str, Any]) -> None:
        return None

    async def refresh_chat_data(self, chat_id: int, chat_data: dict[str, Any]) -> None:
        return None

    async def refresh_bot_data(self, bot_data: dict[str, Any]) -> None:
        return None

    async def flush(self) -> None:
        return None

    def close(self) -> None:
        self._pool.close()
