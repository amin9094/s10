from __future__ import annotations

import logging
import os
import threading
import time
from collections import OrderedDict
from typing import Any

_LOCK = threading.RLock()
_INSTALLED = False


class DuplicateNoiseFilter(logging.Filter):
    """Rate-limit repetitive INFO/DEBUG records without ever hiding warnings/errors."""

    def __init__(self, *, window_seconds: float = 30.0, max_keys: int = 2000) -> None:
        super().__init__()
        self.window_seconds = max(1.0, float(window_seconds))
        self.max_keys = max(100, int(max_keys))
        self._seen: OrderedDict[str, float] = OrderedDict()

    def filter(self, record: logging.LogRecord) -> bool:
        if record.levelno >= logging.WARNING:
            return True
        try:
            message = record.getMessage()
        except Exception:
            return True
        key = f"{record.name}|{record.levelno}|{message[:500]}"
        now = time.monotonic()
        with _LOCK:
            previous = self._seen.get(key)
            self._seen[key] = now
            self._seen.move_to_end(key)
            while len(self._seen) > self.max_keys:
                self._seen.popitem(last=False)
        return previous is None or now - previous >= self.window_seconds


def install_smart_logging() -> bool:
    global _INSTALLED
    if _INSTALLED:
        return False
    enabled = str(os.getenv("SMART_LOGGING_ENABLED", "true")).strip().lower() not in {"0", "false", "no", "off"}
    if not enabled:
        return False
    window = float(os.getenv("SMART_LOGGING_DEDUPE_SECONDS", "30") or 30)
    filter_instance = DuplicateNoiseFilter(window_seconds=window)
    root = logging.getLogger()
    for handler in root.handlers:
        handler.addFilter(filter_instance)
    _INSTALLED = True
    return True
