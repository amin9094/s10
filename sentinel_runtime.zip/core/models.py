from __future__ import annotations

from typing import Any, NotRequired, TypedDict


class UserRecord(TypedDict, total=False):
    id: int
    username: str
    first_name: str
    last_name: str
    language_code: str
    created_at: str
    updated_at: str
    last_seen_at: str


class VipOrderRecord(TypedDict, total=False):
    order_id: str
    user_id: str | int
    plan_id: str
    plan_name: str
    payment_method: str
    status: str
    price: int
    usdt_amount: str
    network: str
    transaction_hash: str
    verification_status: str
    verification_provider: str
    verification_reason: str
    received_amount: str
    confirmations: int
    quote_expires_at: str
    created_at: str
    updated_at: str
    approved_at: str
    approved_by: str | int


class SignalRecord(TypedDict, total=False):
    id: int
    symbol: str
    side: str
    status: str
    entry: float | str
    stop: float | str
    targets: list[float | str]
    cycle_id: int
    created_at: str
    updated_at: str
    result_updated_at: str
    source: str
    provider: str
    market_timestamp: str
    stale: bool
    delayed: bool
    fallback: bool
    confidence: float


class TicketRecord(TypedDict, total=False):
    id: int
    user_id: str | int
    status: str
    priority: str
    category: str
    assigned_admin: str | int
    subject: str
    created_at: str
    updated_at: str
    closed_at: str


class MarketQuoteRecord(TypedDict):
    symbol: str
    price: float
    provider: str
    fetched_at: str
    market_timestamp: str
    age_seconds: float
    stale: bool
    delayed: bool
    fallback: bool
    confidence: float
    metadata: NotRequired[dict[str, Any]]
