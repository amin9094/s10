from __future__ import annotations

import asyncio
from threading import RLock
from weakref import WeakKeyDictionary


class LoopLocalLock:
    """Return one asyncio.Lock per running event loop.

    Module-level asyncio primitives bind to the first event loop that waits on
    them.  Test runners, recovery tools, and embedded deployments may create
    more than one loop in the same process, so sharing a primitive can deadlock
    a later loop.  This wrapper keeps production single-flight semantics while
    remaining safe across loop restarts.
    """

    def __init__(self) -> None:
        self._guard = RLock()
        self._instances: WeakKeyDictionary[asyncio.AbstractEventLoop, asyncio.Lock] = WeakKeyDictionary()

    def __call__(self) -> asyncio.Lock:
        loop = asyncio.get_running_loop()
        with self._guard:
            lock = self._instances.get(loop)
            if lock is None:
                lock = asyncio.Lock()
                self._instances[loop] = lock
            return lock


class LoopLocalSemaphore:
    """Return one bounded asyncio.Semaphore per running event loop."""

    def __init__(self, value: int) -> None:
        self._value = max(1, int(value))
        self._guard = RLock()
        self._instances: WeakKeyDictionary[asyncio.AbstractEventLoop, asyncio.Semaphore] = WeakKeyDictionary()

    def __call__(self) -> asyncio.Semaphore:
        loop = asyncio.get_running_loop()
        with self._guard:
            semaphore = self._instances.get(loop)
            if semaphore is None:
                semaphore = asyncio.Semaphore(self._value)
                self._instances[loop] = semaphore
            return semaphore
