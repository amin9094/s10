from __future__ import annotations

import hashlib
import json
import logging
import os
import time
from threading import RLock
from typing import Any

from config import SETTINGS
from core.runtime_topology import replica_count

logger = logging.getLogger(__name__)
_LOCK = RLock()
_LOCAL: dict[str, float] = {}
_REDIS: Any = None
_DISABLED_UNTIL = 0.0


def _client() -> Any:
    global _REDIS, _DISABLED_UNTIL
    if not SETTINGS.redis_url or time.monotonic() < _DISABLED_UNTIL:
        return None
    if _REDIS is not None:
        return _REDIS
    try:
        import redis
        timeout = max(0.2, float(os.getenv("REDIS_SOCKET_TIMEOUT_SECONDS", "1.5") or 1.5))
        _REDIS = redis.Redis.from_url(
            SETTINGS.redis_url,
            decode_responses=True,
            socket_connect_timeout=timeout,
            socket_timeout=timeout,
            health_check_interval=30,
            max_connections=max(2, int(os.getenv("REDIS_MAX_CONNECTIONS", "30") or 30)),
            retry_on_timeout=True,
        )
        _REDIS.ping()
        return _REDIS
    except Exception as exc:
        _REDIS = None
        _DISABLED_UNTIL = time.monotonic() + 60
        logger.warning("Redis initData replay guard unavailable: %s", exc.__class__.__name__)
        return None


def _production_fail_closed() -> bool:
    production = bool(os.getenv("RAILWAY_PROJECT_ID") or os.getenv("RAILWAY_ENVIRONMENT")) or str(
        os.getenv("SENTINEL_ENV") or os.getenv("ENVIRONMENT") or ""
    ).lower() in {"prod", "production"}
    required = str(os.getenv("REQUIRE_REDIS_FOR_PRODUCTION", "true")).lower() not in {"0", "false", "no", "off"}
    override = str(os.getenv("ALLOW_LOCAL_RATE_LIMIT", "false")).lower() in {"1", "true", "yes", "on"}
    replicas = replica_count()
    return production and replicas > 1 and required and not override


def consume(fingerprint: str, *, client_hash: str, ttl_seconds: int = 900) -> bool:
    """Atomically consume one signed Telegram initData fingerprint."""
    digest = hashlib.sha256(str(fingerprint).encode("utf-8")).hexdigest()
    key = f"sentinel:initdata:{digest}"
    ttl = max(60, min(172800, int(ttl_seconds)))
    value = json.dumps({"client": str(client_hash)[:32], "at": int(time.time())}, separators=(",", ":"))
    client = _client()
    if client is not None:
        try:
            return bool(client.set(key, value, nx=True, ex=ttl))
        except Exception as exc:
            logger.warning("Redis initData replay guard failed: %s", exc.__class__.__name__)
    if _production_fail_closed():
        return False
    now = time.monotonic()
    with _LOCK:
        for stale, expiry in list(_LOCAL.items()):
            if expiry <= now:
                _LOCAL.pop(stale, None)
        if key in _LOCAL:
            return False
        _LOCAL[key] = now + ttl
        return True


def reset_for_tests() -> None:
    global _REDIS, _DISABLED_UNTIL
    with _LOCK:
        _LOCAL.clear()
    _REDIS = None
    _DISABLED_UNTIL = 0.0
