from __future__ import annotations

import asyncio
import functools
import os
import queue
import threading
import time
import weakref
from contextlib import contextmanager
from contextvars import ContextVar
from collections.abc import Callable
from concurrent.futures import Executor, Future
from typing import Any, TypeVar

T = TypeVar("T")
_MAX_BLOCKING = max(2, min(64, int(os.getenv("BLOCKING_IO_MAX_CONCURRENCY", "16") or 16)))
_DEFAULT_TIMEOUT = max(1.0, min(120.0, float(os.getenv("BLOCKING_IO_TIMEOUT_SECONDS", "20") or 20)))
_ACQUIRE_TIMEOUT = max(0.1, min(30.0, float(os.getenv("BLOCKING_IO_ACQUIRE_TIMEOUT_SECONDS", "3") or 3)))
_SEMAPHORE: asyncio.Semaphore | None = None
_SEMAPHORE_LOOP: asyncio.AbstractEventLoop | None = None
_SEMAPHORES: weakref.WeakKeyDictionary = weakref.WeakKeyDictionary()
_SEMAPHORES_LOCK = threading.Lock()
_LANE=ContextVar('sentinel_blocking_lane',default='default')
_INTERACTIVE_SEMAPHORES=weakref.WeakKeyDictionary()
_INTERACTIVE_CAPACITY=max(1,min(4,int(os.getenv('INTERACTIVE_IO_MAX_CONCURRENCY','2') or 2)))
_INTERACTIVE_EXECUTOR=None


@contextmanager
def blocking_lane(lane):
    if lane not in {'default','interactive'}:raise ValueError('BLOCKING_LANE_INVALID')
    token=_LANE.set(lane)
    try:yield
    finally:_LANE.reset(token)


class BlockingCapacityExhausted(TimeoutError):
    """The shared executor has no admission slot; callers may wait boundedly."""


class _DaemonExecutor(Executor):
    """Small bounded daemon worker pool.

    ``ThreadPoolExecutor`` registers non-daemon workers with CPython's global
    executor shutdown hook. A dependency stuck in an uninterruptible blocking
    call can therefore keep a Railway deploy/restart alive after the bot has
    completed its own shutdown. Sentinel already bounds outstanding blocking
    work with an asyncio semaphore, so a compact daemon pool is sufficient and
    lets the process exit even when the OS/library cannot cancel a worker.
    """

    def __init__(self, max_workers: int):
        self._max_workers = max(1, int(max_workers))
        self._queue: queue.Queue[tuple[Future[Any], Callable[[], Any]] | None] = queue.Queue(maxsize=self._max_workers)
        self._slots = threading.BoundedSemaphore(self._max_workers)
        self._pending: dict[Future[Any], float] = {}
        self._running: dict[Future[Any], float] = {}
        self._lock = threading.Lock()
        self._shutdown = False
        self._threads: list[threading.Thread] = []
        for index in range(self._max_workers):
            thread = threading.Thread(
                target=self._worker,
                name=f"sentinel-blocking-{index + 1}",
                daemon=True,
            )
            thread.start()
            self._threads.append(thread)

    def _worker(self) -> None:
        while True:
            try:
                item = self._queue.get(timeout=0.1)
            except queue.Empty:
                if self._shutdown:
                    return
                continue
            try:
                if item is None:
                    return
                future, call = item
                if not future.set_running_or_notify_cancel():
                    continue
                with self._lock:
                    self._running[future] = time.monotonic()
                try:
                    result = call()
                except BaseException as exc:
                    future.set_exception(exc)
                else:
                    future.set_result(result)
                finally:
                    with self._lock:
                        self._running.pop(future, None)
            finally:
                self._queue.task_done()

    def _finished(self, future: Future[Any]) -> None:
        with self._lock:
            self._pending.pop(future, None)
        self._slots.release()

    def submit(self, fn: Callable[..., T], /, *args: Any, **kwargs: Any) -> Future[T]:
        with self._lock:
            if self._shutdown:
                raise RuntimeError("blocking executor has been shut down")
            if not self._slots.acquire(blocking=False):
                raise BlockingCapacityExhausted("blocking I/O capacity exhausted")
            future: Future[T] = Future()
            self._pending[future] = time.monotonic()
            try:
                self._queue.put_nowait((future, functools.partial(fn, *args, **kwargs)))
            except queue.Full as exc:
                self._pending.pop(future, None)
                self._slots.release()
                raise BlockingCapacityExhausted("blocking I/O queue full") from exc
            future.add_done_callback(self._finished)
            return future

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            oldest = min(self._pending.values(), default=time.monotonic())
            return {"capacity": self._max_workers, "outstanding": len(self._pending),
                    "active": len(self._running), "queue_depth": self._queue.qsize(),
                    "oldest_seconds": max(0.0, time.monotonic() - oldest)}

    def shutdown(self, wait: bool = True, *, cancel_futures: bool = False) -> None:
        # Never insert blocking sentinels into a full bounded queue. Idle workers
        # observe shutdown on their bounded poll; running work keeps its slot.
        with self._lock:
            self._shutdown = True
            threads = list(self._threads)
        if cancel_futures:
            while True:
                try:
                    item = self._queue.get_nowait()
                except queue.Empty:
                    break
                try:
                    if item is not None:
                        item[0].cancel()
                finally:
                    self._queue.task_done()
        if wait:
            for thread in threads:
                thread.join()

    def join_bounded(self, timeout: float) -> bool:
        deadline = time.monotonic() + max(0.0, float(timeout))
        for thread in list(self._threads):
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                break
            thread.join(remaining)
        return not any(thread.is_alive() for thread in self._threads)


_EXECUTOR: _DaemonExecutor | None = None
_EXECUTOR_LOCK = threading.Lock()


def _executor() -> _DaemonExecutor:
    global _EXECUTOR
    if _EXECUTOR is not None:
        return _EXECUTOR
    with _EXECUTOR_LOCK:
        if _EXECUTOR is None:
            _EXECUTOR = _DaemonExecutor(_MAX_BLOCKING)
        return _EXECUTOR


def _interactive_executor():
    global _INTERACTIVE_EXECUTOR
    with _EXECUTOR_LOCK:
        if _INTERACTIVE_EXECUTOR is None:
            _INTERACTIVE_EXECUTOR=_DaemonExecutor(_INTERACTIVE_CAPACITY)
        return _INTERACTIVE_EXECUTOR
def shutdown_blocking_executor(*, wait_seconds: float = 0.5) -> bool:
    """Stop accepting new blocking work without letting stuck workers block exit.

    Returns ``True`` when every daemon worker exited inside the bounded grace
    period. ``False`` is safe: remaining workers are daemon threads and cannot
    keep the Railway process alive during restart/deploy.
    """
    global _EXECUTOR,_INTERACTIVE_EXECUTOR
    with _EXECUTOR_LOCK:
        executors=[e for e in (_EXECUTOR,_INTERACTIVE_EXECUTOR) if e is not None]
        _EXECUTOR=_INTERACTIVE_EXECUTOR=None
    for executor in executors:executor.shutdown(wait=False,cancel_futures=True)
    deadline=time.monotonic()+max(0,wait_seconds)
    results=[executor.join_bounded(max(0,deadline-time.monotonic())) for executor in executors]
    return all(results)


def _semaphore() -> asyncio.Semaphore:
    global _SEMAPHORE, _SEMAPHORE_LOOP
    loop = asyncio.get_running_loop()
    interactive=_LANE.get()=='interactive'
    collection=_INTERACTIVE_SEMAPHORES if interactive else _SEMAPHORES
    with _SEMAPHORES_LOCK:
        for closed in [candidate for candidate in collection if candidate.is_closed()]:
            collection.pop(closed, None)
        limit = collection.get(loop)
        if limit is None:
            limit = asyncio.Semaphore(_INTERACTIVE_CAPACITY if interactive else _MAX_BLOCKING)
            collection[loop] = limit
        if not interactive:_SEMAPHORE, _SEMAPHORE_LOOP = limit, loop  # Compatibility for extensions.
        return limit


def blocking_executor_snapshot() -> dict[str, Any]:
    executor = _EXECUTOR
    result=executor.snapshot() if executor is not None else {"capacity": _MAX_BLOCKING, "outstanding": 0, "active": 0, "queue_depth": 0, "oldest_seconds": 0}
    result['interactive']=_INTERACTIVE_EXECUTOR.snapshot() if _INTERACTIVE_EXECUTOR else {'capacity':_INTERACTIVE_CAPACITY,'outstanding':0,'active':0,'queue_depth':0,'oldest_seconds':0}
    return result


def _release_permit(limit: asyncio.Semaphore, loop: asyncio.AbstractEventLoop) -> None:
    if loop.is_closed():
        return
    loop.call_soon_threadsafe(limit.release)


async def run_blocking(
    function: Callable[..., T],
    /,
    *args: Any,
    timeout: float | None = None,
    acquire_timeout: float | None = None,
    **kwargs: Any,
) -> T:
    """Run synchronous I/O outside the event loop with bounded admission.

    A Python thread cannot be force-cancelled safely. If the caller times out or
    is cancelled, the concurrency permit remains held until the underlying call
    actually exits. The daemon pool additionally guarantees a permanently stuck
    native call cannot prevent process shutdown.
    """
    limit = _semaphore()
    effective_timeout = _DEFAULT_TIMEOUT if timeout is None else max(0.1, float(timeout))
    effective_acquire = _ACQUIRE_TIMEOUT if acquire_timeout is None else max(0.1, float(acquire_timeout))

    try:
        await asyncio.wait_for(limit.acquire(), timeout=effective_acquire)
    except TimeoutError as exc:
        raise TimeoutError("blocking I/O capacity exhausted") from exc

    loop = asyncio.get_running_loop()
    try:
        deadline = time.monotonic() + effective_acquire
        while True:
            try:
                pool=_interactive_executor() if _LANE.get()=='interactive' else _executor()
                concurrent_future = pool.submit(function, *args, **kwargs)
                break
            except BlockingCapacityExhausted:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise
                await asyncio.sleep(min(0.025, remaining))
        future = asyncio.wrap_future(concurrent_future, loop=loop)
    except BaseException:
        limit.release()
        raise
    release_deferred = False
    try:
        return await asyncio.wait_for(asyncio.shield(future), timeout=effective_timeout)
    except (TimeoutError, asyncio.CancelledError):
        release_deferred = True
        concurrent_future.add_done_callback(lambda _future: _release_permit(limit, loop))
        raise
    finally:
        if not release_deferred:
            limit.release()
