"""Additive SENTINEL 9 market evidence schema, shared by both database dialects."""


def market_table_names():
    """One schema-derived allow-list for backup, restore and future additions."""
    return tuple(statement.split()[5] for statement in MARKET_DDL
                 if statement.startswith('CREATE TABLE IF NOT EXISTS s9_'))

MARKET_DDL = (
    """CREATE TABLE IF NOT EXISTS s9_strategy_paths (
       id TEXT PRIMARY KEY,engine TEXT NOT NULL,active INTEGER NOT NULL CHECK(active IN (0,1)),
       revision INTEGER NOT NULL CHECK(revision>0),created_ms BIGINT NOT NULL,payload TEXT NOT NULL)""",
    "CREATE UNIQUE INDEX IF NOT EXISTS s9_path_one_active ON s9_strategy_paths(engine) WHERE active=1",
    """CREATE TABLE IF NOT EXISTS s9_strategy_switches (
       engine TEXT PRIMARY KEY,enabled INTEGER NOT NULL CHECK(enabled IN (0,1)),revision INTEGER NOT NULL CHECK(revision>0),payload TEXT NOT NULL)""",
    """CREATE TABLE IF NOT EXISTS s9_scan_observations (
       id TEXT PRIMARY KEY,symbol TEXT NOT NULL,timeframe TEXT NOT NULL,at_ms BIGINT NOT NULL,payload TEXT NOT NULL)""",
    "CREATE INDEX IF NOT EXISTS s9_scan_observations_time ON s9_scan_observations(at_ms,id)",
    """CREATE TABLE IF NOT EXISTS s9_shadow_comparisons (
       id TEXT PRIMARY KEY,at_ms BIGINT NOT NULL,active_profile TEXT NOT NULL,shadow_profile TEXT NOT NULL,payload TEXT NOT NULL)""",
    "CREATE INDEX IF NOT EXISTS s9_shadow_comparisons_time ON s9_shadow_comparisons(at_ms,id)",
    """CREATE TABLE IF NOT EXISTS s9_desk_queue_views (
       id TEXT PRIMARY KEY,admin_id TEXT NOT NULL,filter_hash TEXT NOT NULL,
       created_ms BIGINT NOT NULL,expires_ms BIGINT NOT NULL)""",
    """CREATE TABLE IF NOT EXISTS s9_desk_queue_members (
       view_id TEXT NOT NULL,rank INTEGER NOT NULL,signal_id TEXT NOT NULL,
       captured_state TEXT NOT NULL,distance_r TEXT,PRIMARY KEY(view_id,rank),
       FOREIGN KEY(view_id) REFERENCES s9_desk_queue_views(id) ON DELETE CASCADE)""",
    """CREATE TABLE IF NOT EXISTS s9_research_cases (
       id TEXT PRIMARY KEY,symbol TEXT NOT NULL,timeframe TEXT NOT NULL,created_ms BIGINT NOT NULL,payload TEXT NOT NULL)""",
    "CREATE INDEX IF NOT EXISTS s9_research_cases_page ON s9_research_cases(created_ms DESC,id DESC)",
    """CREATE TABLE IF NOT EXISTS s9_research_links (
       source_key TEXT PRIMARY KEY,case_id TEXT NOT NULL,FOREIGN KEY(case_id) REFERENCES s9_research_cases(id))""",
    """CREATE TABLE IF NOT EXISTS s9_research_jobs (
       id TEXT PRIMARY KEY,case_id TEXT NOT NULL,owner TEXT NOT NULL,state TEXT NOT NULL,created_ms BIGINT NOT NULL,payload TEXT NOT NULL)""",
    """CREATE TABLE IF NOT EXISTS s9_export_jobs (
       id TEXT PRIMARY KEY,owner TEXT NOT NULL,state TEXT NOT NULL,created_ms BIGINT NOT NULL,
       expires_ms BIGINT NOT NULL,payload TEXT NOT NULL)""",
    "CREATE INDEX IF NOT EXISTS s9_export_jobs_owner ON s9_export_jobs(owner,created_ms DESC)",
    """CREATE TABLE IF NOT EXISTS s9_signal_timeline (
       id TEXT PRIMARY KEY,signal_id TEXT NOT NULL,kind TEXT NOT NULL,at_ms BIGINT NOT NULL,payload TEXT NOT NULL)""",
    "CREATE INDEX IF NOT EXISTS s9_signal_timeline_page ON s9_signal_timeline(signal_id,at_ms,id)",
    """CREATE TABLE IF NOT EXISTS s9_custom_presets (
       id TEXT PRIMARY KEY,name TEXT NOT NULL,created_ms BIGINT NOT NULL,payload TEXT NOT NULL)""",
    "CREATE INDEX IF NOT EXISTS s9_custom_presets_page ON s9_custom_presets(created_ms DESC,id DESC)",
    """CREATE TABLE IF NOT EXISTS s9_quote_archive_sessions (
       provider TEXT NOT NULL,symbol TEXT NOT NULL,epoch TEXT NOT NULL,next_ordinal BIGINT NOT NULL,
       PRIMARY KEY(provider,symbol,epoch))""",
    """CREATE TABLE IF NOT EXISTS s9_quote_archive (
       provider TEXT NOT NULL,symbol TEXT NOT NULL,epoch TEXT NOT NULL,ordinal BIGINT NOT NULL,sequence BIGINT NOT NULL,
       source_id TEXT NOT NULL,event_ms BIGINT NOT NULL,received_ms BIGINT NOT NULL,digest TEXT NOT NULL,payload TEXT NOT NULL,
       PRIMARY KEY(provider,symbol,epoch,ordinal),UNIQUE(provider,symbol,epoch,source_id))""",
    "CREATE INDEX IF NOT EXISTS s9_quote_archive_cursor ON s9_quote_archive(provider,symbol,epoch,source_id)",
    "CREATE INDEX IF NOT EXISTS s9_quote_archive_retention ON s9_quote_archive(received_ms)",
    """CREATE TABLE IF NOT EXISTS s9_iran_equity_analyses (
       id TEXT PRIMARY KEY, ins_code TEXT NOT NULL, symbol TEXT NOT NULL, timeframe TEXT NOT NULL,
       state TEXT NOT NULL, created_ms BIGINT NOT NULL, payload TEXT NOT NULL)""",
    "CREATE INDEX IF NOT EXISTS s9_iran_analysis_desk ON s9_iran_equity_analyses(timeframe,created_ms DESC,id DESC)",
    """CREATE TABLE IF NOT EXISTS s9_desk_notifications (
       admin_id TEXT PRIMARY KEY, interval_minutes INTEGER NOT NULL, due_ms BIGINT NOT NULL,
       revision INTEGER NOT NULL DEFAULT 1, payload TEXT NOT NULL)""",
    """CREATE TABLE IF NOT EXISTS s9_candle_revisions (
       id TEXT PRIMARY KEY, symbol TEXT NOT NULL, provider TEXT NOT NULL, timeframe TEXT NOT NULL,
       start_ms BIGINT NOT NULL, state TEXT NOT NULL, observed_ms BIGINT NOT NULL, payload TEXT NOT NULL)""",
    "CREATE INDEX IF NOT EXISTS s9_candle_revisions_family ON s9_candle_revisions(symbol,provider,timeframe,state)",
    """CREATE TABLE IF NOT EXISTS s9_signal_inbox (
       id TEXT PRIMARY KEY, market TEXT NOT NULL, engine TEXT NOT NULL, state TEXT NOT NULL,
       created_ms BIGINT NOT NULL, revision INTEGER NOT NULL DEFAULT 1, payload TEXT NOT NULL)""",
    "CREATE INDEX IF NOT EXISTS s9_inbox_folder ON s9_signal_inbox(market,engine,created_ms DESC)",
    """CREATE TABLE IF NOT EXISTS s9_signal_reads (
       signal_id TEXT NOT NULL, admin_id TEXT NOT NULL, read_ms BIGINT NOT NULL,
       PRIMARY KEY(signal_id,admin_id))""",
    """CREATE TABLE IF NOT EXISTS s9_strategy_paper_runs (
       id TEXT PRIMARY KEY, engine TEXT NOT NULL, active INTEGER NOT NULL, revision INTEGER NOT NULL DEFAULT 1,
       created_ms BIGINT NOT NULL, payload TEXT NOT NULL)""",
    "CREATE UNIQUE INDEX IF NOT EXISTS s9_paper_one_active ON s9_strategy_paper_runs(engine) WHERE active=1",
    """CREATE TABLE IF NOT EXISTS s9_strategy_paper_trades (
       id TEXT PRIMARY KEY, run_id TEXT NOT NULL, signal_id TEXT NOT NULL UNIQUE, state TEXT NOT NULL,
       revision INTEGER NOT NULL DEFAULT 1, created_ms BIGINT NOT NULL, payload TEXT NOT NULL,
       FOREIGN KEY(run_id) REFERENCES s9_strategy_paper_runs(id))""",
    """CREATE TABLE IF NOT EXISTS s9_paper_statistics (
       run_id TEXT NOT NULL, bucket TEXT NOT NULL, payload TEXT NOT NULL,
       PRIMARY KEY(run_id,bucket), FOREIGN KEY(run_id) REFERENCES s9_strategy_paper_runs(id))""",

    "CREATE INDEX IF NOT EXISTS s9_paper_run_signal ON s9_strategy_paper_trades(run_id,signal_id)",
    "CREATE INDEX IF NOT EXISTS s9_paper_run_page ON s9_strategy_paper_trades(run_id,created_ms DESC,id DESC)",
    "CREATE INDEX IF NOT EXISTS s9_paper_open ON s9_strategy_paper_trades(state,created_ms)",
    """CREATE TABLE IF NOT EXISTS s9_provider_budget (
       id TEXT PRIMARY KEY, payload TEXT NOT NULL)""",
    """CREATE TABLE IF NOT EXISTS s9_preparations (
       id TEXT PRIMARY KEY, state TEXT NOT NULL, prepared_ms BIGINT NOT NULL, payload TEXT NOT NULL)""",
    """CREATE TABLE IF NOT EXISTS s9_deliveries (
       id TEXT PRIMARY KEY, setup_id TEXT NOT NULL, plan_version INTEGER NOT NULL, event_id TEXT NOT NULL,
       audience TEXT NOT NULL, target_id TEXT NOT NULL, content_hash TEXT NOT NULL, state TEXT NOT NULL,
       attempts INTEGER NOT NULL DEFAULT 0, ready_ms BIGINT NOT NULL, payload TEXT NOT NULL,
       UNIQUE(setup_id,plan_version,event_id,audience,target_id))""",
    "CREATE INDEX IF NOT EXISTS s9_deliveries_ready ON s9_deliveries(state,ready_ms)",
    """CREATE TABLE IF NOT EXISTS s9_admin_review_outbox (
       id TEXT PRIMARY KEY, review_id TEXT NOT NULL, admin_id TEXT NOT NULL, status TEXT NOT NULL,
       attempts INTEGER NOT NULL DEFAULT 0, updated_ms BIGINT NOT NULL, payload TEXT NOT NULL,
       UNIQUE(review_id,admin_id))""",
    """CREATE TABLE IF NOT EXISTS s9_strategy_reviews (
       id TEXT PRIMARY KEY, engine TEXT NOT NULL, symbol TEXT NOT NULL, timeframe TEXT NOT NULL,
       state TEXT NOT NULL, created_ms BIGINT NOT NULL, payload TEXT NOT NULL)""",
    "CREATE INDEX IF NOT EXISTS s9_reviews_family ON s9_strategy_reviews(engine,symbol,timeframe,created_ms DESC)",
    """CREATE TABLE IF NOT EXISTS s9_candles (
       symbol TEXT NOT NULL, provider TEXT NOT NULL, timeframe TEXT NOT NULL, start_ms BIGINT NOT NULL,
       end_ms BIGINT NOT NULL, payload TEXT NOT NULL, PRIMARY KEY(symbol,provider,timeframe,start_ms))""",
    "CREATE INDEX IF NOT EXISTS s9_candles_range ON s9_candles(symbol,provider,timeframe,start_ms DESC)",
    "CREATE INDEX IF NOT EXISTS s9_candles_retention ON s9_candles(end_ms)",
    """CREATE TABLE IF NOT EXISTS s9_setups (
       id TEXT PRIMARY KEY, thesis_key TEXT NOT NULL, engine TEXT NOT NULL, symbol TEXT NOT NULL,
       timeframe TEXT NOT NULL, plan_version INTEGER NOT NULL, state_version INTEGER NOT NULL,
       phase TEXT NOT NULL, proposed_ms BIGINT NOT NULL, payload TEXT NOT NULL,
       UNIQUE(engine,symbol,timeframe,thesis_key))""",
    """CREATE TABLE IF NOT EXISTS s9_setup_events (
       id TEXT PRIMARY KEY, setup_id TEXT NOT NULL, event_type TEXT NOT NULL, event_ms BIGINT NOT NULL,
       payload TEXT NOT NULL, FOREIGN KEY(setup_id) REFERENCES s9_setups(id))""",
    "CREATE INDEX IF NOT EXISTS s9_events_setup ON s9_setup_events(setup_id,event_ms)",
    """CREATE TABLE IF NOT EXISTS s9_approvals (
       id TEXT PRIMARY KEY, setup_id TEXT NOT NULL, plan_version INTEGER NOT NULL, event_id TEXT NOT NULL,
       audience TEXT NOT NULL, actor TEXT NOT NULL, approved_ms BIGINT NOT NULL, content_hash TEXT NOT NULL,
       FOREIGN KEY(setup_id) REFERENCES s9_setups(id), UNIQUE(setup_id,plan_version,event_id,audience))""",
    """CREATE TABLE IF NOT EXISTS s9_signal_workspace (
       signal_id TEXT PRIMARY KEY,revision INTEGER NOT NULL,payload TEXT NOT NULL,
       FOREIGN KEY(signal_id) REFERENCES s9_signal_inbox(id))""",
    """CREATE TABLE IF NOT EXISTS s9_case_reviews (
       case_id TEXT NOT NULL,admin_id TEXT NOT NULL,revision INTEGER NOT NULL,payload TEXT NOT NULL,
       PRIMARY KEY(case_id,admin_id),FOREIGN KEY(case_id) REFERENCES s9_research_cases(id))""",
    """CREATE TABLE IF NOT EXISTS s9_paper_equity (
       run_id TEXT NOT NULL,at_ms BIGINT NOT NULL,complete INTEGER NOT NULL,payload TEXT NOT NULL,
       PRIMARY KEY(run_id,at_ms),FOREIGN KEY(run_id) REFERENCES s9_strategy_paper_runs(id))""",
    """CREATE TABLE IF NOT EXISTS s9_poster_presets (
       id TEXT PRIMARY KEY,name TEXT NOT NULL,created_ms BIGINT NOT NULL,payload TEXT NOT NULL)""",
    """CREATE TABLE IF NOT EXISTS s9_poster_assets (
       id TEXT PRIMARY KEY,payload TEXT NOT NULL)""",
    """CREATE TABLE IF NOT EXISTS s9_original_indicator_inputs (
       id TEXT PRIMARY KEY,symbol TEXT NOT NULL,timeframe TEXT NOT NULL,available_ms BIGINT NOT NULL,payload TEXT NOT NULL)""",
    "CREATE INDEX IF NOT EXISTS s9_original_indicator_source ON s9_original_indicator_inputs(symbol,timeframe,available_ms DESC)",
    """CREATE TABLE IF NOT EXISTS s9_research_protocols (
       id TEXT PRIMARY KEY,owner TEXT NOT NULL,created_ms BIGINT NOT NULL,payload TEXT NOT NULL)""",
)
