from __future__ import annotations

import asyncio
import time
import os
import threading
import logging
from collections.abc import Awaitable
from typing import Any

from telegram import Update
from telegram.ext import BaseUpdateProcessor

from core.async_runtime import run_blocking
from core.logging_context import reset_correlation_id, set_correlation_id
from core.observability import increment, gauge, record_error


logger = logging.getLogger(__name__)


class KeyedUpdateProcessor(BaseUpdateProcessor):
    """Process unrelated users concurrently while preserving per-user ordering.

    ConversationHandler state and financial workflows remain serialized for the
    same Telegram user/chat, but slow requests from one user no longer block
    every other user.
    """

    def __init__(self, max_concurrent_updates: int = 8) -> None:
        super().__init__(max(1, int(max_concurrent_updates)))
        self._locks: dict[str, tuple[asyncio.Lock, float]] = {}
        self._lock_users: dict[str, int] = {}
        self._guard = asyncio.Lock()
        self.processing_timeout = max(1.0, min(300.0, float(os.getenv("TELEGRAM_UPDATE_TIMEOUT_SECONDS", "90"))))
        self.lock_timeout = max(0.1, min(30.0, float(os.getenv("TELEGRAM_USER_WAIT_SECONDS", "5"))))
        self._activity_lock = threading.Lock()
        self._active: dict[int, float] = {}
        self.last_completed_at = 0.0

    def is_healthy(self) -> bool:
        with self._activity_lock:
            oldest = min(self._active.values(), default=time.monotonic())
        # No updates is normal. Only an actually stuck task is unhealthy.
        return time.monotonic() - oldest < self.processing_timeout + self.lock_timeout + 30

    def delivery_probe(self) -> dict[str, Any]:
        with self._activity_lock:
            active = len(self._active)
            completed = self.last_completed_at
        # Diagnostic gauges may describe leased/retry work or an earlier poll.
        # The runtime watchdog must observe actual in-flight work; its caller
        # adds the current PTB queue depth. No filesystem/metrics read belongs
        # in this independent liveness probe.
        return {'pending': active,
                'completed': completed, 'processor_healthy': self.is_healthy()}

    @staticmethod
    def _key(update: object) -> str:
        if isinstance(update, Update):
            if update.effective_user is not None:
                return f"user:{update.effective_user.id}"
            if update.effective_chat is not None:
                return f"chat:{update.effective_chat.id}"
            return f"update:{update.update_id}"
        return "global"

    async def initialize(self) -> None:
        return None

    async def shutdown(self) -> None:
        async with self._guard:
            self._locks.clear()
            self._lock_users.clear()

    async def _lock_for(self, key: str) -> asyncio.Lock:
        now = time.monotonic()
        async with self._guard:
            row = self._locks.get(key)
            if row is None:
                lock = asyncio.Lock()
                self._locks[key] = (lock, now)
            else:
                lock = row[0]
                self._locks[key] = (lock, now)
            self._lock_users[key] = self._lock_users.get(key, 0) + 1
            return lock

    async def _forget_lock(self, key: str, lock: asyncio.Lock) -> None:
        async with self._guard:
            remaining = self._lock_users.get(key, 1) - 1
            if remaining > 0:
                self._lock_users[key] = remaining
            else:
                self._lock_users.pop(key, None)
                if self._locks.get(key, (None,))[0] is lock:
                    self._locks.pop(key, None)

    async def _busy_reply(self, update: object) -> None:
        if not isinstance(update, Update):
            return
        try:
            async with asyncio.timeout(2):
                if update.callback_query:
                    await update.callback_query.answer("درخواست قبلی طول کشیده است؛ چند لحظه دیگر دوباره تلاش کنید.", show_alert=False)
                elif update.effective_message:
                    await update.effective_message.reply_text("پردازش موقتاً طول کشیده است؛ لطفاً دوباره /start را بزنید.")
        except Exception as exc:
            logger.info("Busy notification unavailable: %s", type(exc).__name__)

    async def do_process_update(self, update: object, coroutine: Awaitable[Any]) -> None:
        gauge("telegram_last_update_timestamp", time.time())
        key = self._key(update)
        lock = await self._lock_for(key)
        update_id = getattr(update, "update_id", "unknown")
        token = set_correlation_id(f"telegram:{update_id}:{key}")
        acquired = False
        started = False
        task_key = id(coroutine)
        with self._activity_lock:
            self._active[task_key] = time.monotonic()
        try:
            try:
                await asyncio.wait_for(lock.acquire(), self.lock_timeout)
                acquired = True
            except TimeoutError:
                increment("telegram_user_queue_timeout_total")
                await self._busy_reply(update)
                if isinstance(update, Update):
                    from core.telegram_update_store import mark_failed
                    await run_blocking(mark_failed, update.update_id, "USER_QUEUE_TIMEOUT", timeout=5)
                return
            async with asyncio.timeout(self.processing_timeout):
                if isinstance(update, Update):
                    from core.telegram_update_outcome import clear_update_failure
                    clear_update_failure(update.update_id)
                try:
                    started = True
                    await coroutine
                except Exception as exc:
                    if isinstance(update, Update):
                        from core.telegram_update_store import mark_failed
                        status = await run_blocking(mark_failed, update.update_id, exc.__class__.__name__, timeout=5)
                        increment(f"telegram_updates_{status}_total")
                    raise
                else:
                    if isinstance(update, Update):
                        from core.telegram_update_outcome import consume_update_failure
                        failure = consume_update_failure(update.update_id)
                        if failure:
                            from core.telegram_update_store import mark_failed
                            status = await run_blocking(mark_failed, update.update_id, failure, timeout=5)
                            increment(f"telegram_updates_{status}_total")
                        else:
                            from core.telegram_update_store import mark_done
                            await run_blocking(mark_done, update.update_id, timeout=5)
                            increment("telegram_updates_processed_total")
        except TimeoutError as exc:
            record_error("telegram_update_timeout", exc)
            increment("telegram_update_timeout_total")
            logger.exception("Telegram update timed out: update_id=%s", update_id)
            await self._busy_reply(update)
            if isinstance(update, Update):
                from core.telegram_update_store import mark_failed
                await run_blocking(mark_failed, update.update_id, "PROCESSING_TIMEOUT", timeout=5)
        finally:
            if acquired:
                lock.release()
            await self._forget_lock(key, lock)
            if not started and hasattr(coroutine, "close"):
                coroutine.close()
            with self._activity_lock:
                self._active.pop(task_key, None)
                self.last_completed_at = time.monotonic()
            gauge('telegram_last_completed_timestamp', time.time())
            gauge('telegram_active_updates', len(self._active))
            if isinstance(update, Update):
                from core.telegram_update_outcome import clear_update_failure
                clear_update_failure(update.update_id)
            reset_correlation_id(token)
