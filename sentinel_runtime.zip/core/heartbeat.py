from __future__ import annotations

import json
import os
import tempfile
from datetime import UTC, datetime
from pathlib import Path
from typing import Any


def write_heartbeat(path: Path, *, status: str = "running", details: dict[str, Any] | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "status": status,
        "timestamp": datetime.now(UTC).isoformat(),
        "pid": os.getpid(),
        **(details or {}),
    }
    fd, temp_name = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, ensure_ascii=False, allow_nan=False)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp_name, path)
        try:
            os.chmod(path, 0o600)
        except OSError:
            pass
    finally:
        if os.path.exists(temp_name):
            os.unlink(temp_name)


def read_heartbeat(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        data = json.load(handle)
    if not isinstance(data, dict):
        raise ValueError("heartbeat root is not an object")
    return data


def heartbeat_age_seconds(path: Path, now: datetime | None = None) -> float:
    data = read_heartbeat(path)
    raw = str(data.get("timestamp") or "")
    stamp = datetime.fromisoformat(raw.replace("Z", "+00:00"))
    if stamp.tzinfo is None:
        stamp = stamp.replace(tzinfo=UTC)
    current = (now or datetime.now(UTC)).astimezone(UTC)
    age = (current - stamp.astimezone(UTC)).total_seconds()
    # A far-future timestamp can otherwise keep a dead container healthy
    # indefinitely. Allow only a small amount of normal clock skew.
    if age < -60:
        raise ValueError("heartbeat timestamp is too far in the future")
    return max(0.0, age)


def process_is_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True
