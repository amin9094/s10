from __future__ import annotations

import asyncio
import json
import gzip
import logging
import mimetypes
import os
import secrets
import threading
import time
import tempfile
from collections import defaultdict, deque
from collections.abc import Awaitable, Callable
from datetime import UTC, datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import unquote, urlsplit

logger = logging.getLogger(__name__)

_LOCK = threading.RLock()
_COUNTERS: dict[str, int] = defaultdict(int)
_GAUGES: dict[str, float] = {}
_JOB_STATUS: dict[str, dict[str, Any]] = {}
_RECENT_ERRORS: deque[dict[str, Any]] = deque(maxlen=100)
_STARTED_AT = time.time()
_SERVER: ThreadingHTTPServer | None = None
_THREAD: threading.Thread | None = None
_METRICS_FILE: Path | None = None
_HEARTBEAT_FILE: Path | None = None
_HEARTBEAT_MAX_AGE = 120
_METRICS_TOKEN: str | None = None
_ALLOW_UNAUTHENTICATED_METRICS = True
_READINESS_CHECKS: dict[str, Callable[[], bool]] = {}
_READINESS_STATES: dict[str, bool] = {}
_WEBAPP_ROOT = (Path(__file__).resolve().parents[1] / "webapp").resolve()


def _now() -> str:
    return datetime.now(UTC).isoformat()


def configure(metrics_file: Path, heartbeat_file: Path, heartbeat_max_age: int) -> None:
    global _METRICS_FILE, _HEARTBEAT_FILE, _HEARTBEAT_MAX_AGE, _METRICS_TOKEN
    _METRICS_FILE = metrics_file
    _HEARTBEAT_FILE = heartbeat_file
    _HEARTBEAT_MAX_AGE = max(30, int(heartbeat_max_age))
    _METRICS_TOKEN = os.getenv("METRICS_TOKEN", "").strip() or None
    metrics_file.parent.mkdir(parents=True, exist_ok=True)
    try:
        raw = json.loads(metrics_file.read_text(encoding="utf-8")) if metrics_file.exists() else {}
    except (OSError, ValueError):
        raw = {}
    with _LOCK:
        for key, value in raw.get("counters", {}).items():
            try:
                _COUNTERS[str(key)] = int(value)
            except (TypeError, ValueError):
                continue


def increment(name: str, amount: int = 1) -> None:
    with _LOCK:
        _COUNTERS[str(name)] += int(amount)


def gauge(name: str, value: float) -> None:
    with _LOCK:
        _GAUGES[str(name)] = float(value)


def record_error(component: str, error: BaseException | str) -> None:
    if isinstance(error, BaseException):
        from core.telemetry import capture_exception

        capture_exception(error, component=component)
    with _LOCK:
        _COUNTERS["errors_total"] += 1
        _COUNTERS[f"errors_{component}_total"] += 1
        _RECENT_ERRORS.append(
            {
                "component": str(component),
                "error": str(error)[:500],
                "type": error.__class__.__name__ if isinstance(error, BaseException) else "Error",
                "created_at": _now(),
            }
        )


def job_started(name: str) -> float:
    started = time.monotonic()
    with _LOCK:
        state = _JOB_STATUS.setdefault(str(name), {})
        state.update({"status": "running", "started_at": _now()})
        state["attempt"] = int(state.get("attempt", 0) or 0) + 1
        _COUNTERS[f"job_{name}_runs_total"] += 1
    return started


def job_finished(name: str, started: float, *, error: BaseException | None = None) -> None:
    duration = max(0.0, time.monotonic() - started)
    now = _now()
    with _LOCK:
        state = _JOB_STATUS.setdefault(str(name), {})
        consecutive = int(state.get("consecutive_failures", 0) or 0)
        if error:
            consecutive += 1
            state.update(
                {
                    "status": "failed" if consecutive >= 2 else "degraded",
                    "finished_at": now,
                    "last_failure_at": now,
                    "duration_seconds": round(duration, 4),
                    "last_error": str(error)[:500],
                    "last_error_type": error.__class__.__name__,
                    "consecutive_failures": consecutive,
                }
            )
            _COUNTERS[f"job_{name}_failures_total"] += 1
        else:
            state.update(
                {
                    "status": "ok",
                    "finished_at": now,
                    "last_success_at": now,
                    "duration_seconds": round(duration, 4),
                    "last_error": "",
                    "last_error_type": "",
                    "consecutive_failures": 0,
                }
            )
        _GAUGES[f"job_{name}_last_duration_seconds"] = duration
    if error:
        record_error(f"job_{name}", error)


def _transient_job_error(error: BaseException) -> bool:
    if isinstance(error, (asyncio.TimeoutError, TimeoutError, ConnectionError, OSError)):
        return True
    name = error.__class__.__name__.lower()
    return any(token in name for token in (
        "timeout", "network", "connect", "temporary", "retryafter",
        "pooltimeout", "readerror", "writeerror", "redis", "operationalerror",
        "serverdisconnected", "remoteprotocol",
    ))


def observed_job(name: str, callback: Callable[..., Awaitable[Any]]) -> Callable[..., Awaitable[Any]]:
    async def wrapped(*args: Any, **kwargs: Any) -> Any:
        started = job_started(name)
        retries = max(0, min(2, int(os.getenv("JOB_TRANSIENT_RETRIES", "1") or 1)))
        retry_delay = max(0.05, min(5.0, float(os.getenv("JOB_RETRY_DELAY_SECONDS", "0.35") or 0.35)))
        timeout = max(1.0, min(3600.0, float(os.getenv("JOB_MAX_RUNTIME_SECONDS", "600"))))
        attempt = 0
        while True:
            try:
                async with asyncio.timeout(timeout):
                    result = await callback(*args, **kwargs)
                job_finished(name, started)
                return result
            except asyncio.CancelledError:
                job_finished(name, started, error=RuntimeError("job cancelled during shutdown or lease loss"))
                raise
            except Exception as exc:
                if attempt < retries and _transient_job_error(exc):
                    attempt += 1
                    with _LOCK:
                        state = _JOB_STATUS.setdefault(str(name), {})
                        state.update({
                            "status": "retrying",
                            "retry_attempt": attempt,
                            "last_error": str(exc)[:500],
                            "last_error_type": exc.__class__.__name__,
                        })
                        _COUNTERS[f"job_{name}_retries_total"] += 1
                    await asyncio.sleep(retry_delay * attempt)
                    continue
                job_finished(name, started, error=exc)
                raise

    wrapped.__name__ = getattr(callback, "__name__", f"observed_{name}")
    wrapped.__doc__ = callback.__doc__
    return wrapped


def _heartbeat_healthy() -> bool:
    if not _HEARTBEAT_FILE or not _HEARTBEAT_FILE.exists():
        return False
    try:
        raw = json.loads(_HEARTBEAT_FILE.read_text(encoding="utf-8"))
        timestamp = datetime.fromisoformat(str(raw.get("updated_at") or raw.get("timestamp")).replace("Z", "+00:00"))
        if timestamp.tzinfo is None:
            timestamp = timestamp.replace(tzinfo=UTC)
        age = (datetime.now(UTC) - timestamp.astimezone(UTC)).total_seconds()
        return raw.get("status") == "running" and -60 <= age <= _HEARTBEAT_MAX_AGE
    except (OSError, ValueError, TypeError):
        return False


def snapshot() -> dict[str, Any]:
    # A slow mounted heartbeat file must never hold the process-wide metrics
    # lock used by Telegram update processing and scheduler instrumentation.
    healthy = _heartbeat_healthy()
    with _LOCK:
        return {
            "status": "ok" if healthy else "degraded",
            "started_at": datetime.fromtimestamp(_STARTED_AT, UTC).isoformat(),
            "uptime_seconds": int(time.time() - _STARTED_AT),
            "counters": dict(_COUNTERS),
            "gauges": dict(_GAUGES),
            "jobs": json.loads(json.dumps(_JOB_STATUS, default=str)),
            "recent_errors": list(_RECENT_ERRORS),
            "heartbeat_healthy": healthy,
        }


def public_health_snapshot() -> dict[str, Any]:
    """Return a minimal health payload safe for an unauthenticated endpoint."""
    healthy = _heartbeat_healthy()
    return {
        "status": "ok" if healthy else "degraded",
        "started_at": datetime.fromtimestamp(_STARTED_AT, UTC).isoformat(),
        "uptime_seconds": int(time.time() - _STARTED_AT),
        "heartbeat_healthy": healthy,
    }



def register_readiness_check(name: str, callback: Callable[[], bool]) -> None:
    _READINESS_CHECKS[str(name)] = callback


def set_readiness_state(name: str, healthy: bool) -> None:
    with _LOCK:
        _READINESS_STATES[str(name)] = bool(healthy)
        if healthy:
            _GAUGES[f"{name}_last_success_timestamp"] = time.time()


def liveness_snapshot() -> dict[str, Any]:
    return {
        "status": "ok",
        "started_at": datetime.fromtimestamp(_STARTED_AT, UTC).isoformat(),
        "uptime_seconds": int(time.time() - _STARTED_AT),
    }


def readiness_snapshot() -> dict[str, Any]:
    with _LOCK:
        states = dict(_READINESS_STATES)
    checks: dict[str, bool] = {"heartbeat": _heartbeat_healthy(), **states}
    for name, callback in list(_READINESS_CHECKS.items()):
        try:
            checks[name] = bool(callback())
        except Exception:
            logger.exception("Readiness check failed: %s", name)
            checks[name] = False
    ready = all(checks.values())
    return {
        "status": "ok" if ready else "degraded",
        "ready": ready,
        "checks": checks,
        "uptime_seconds": int(time.time() - _STARTED_AT),
    }

def _metrics_authorized(handler: BaseHTTPRequestHandler) -> bool:
    if _ALLOW_UNAUTHENTICATED_METRICS and not _METRICS_TOKEN:
        return True
    if not _METRICS_TOKEN:
        return False
    supplied = str(handler.headers.get("Authorization") or "")
    prefix = "Bearer "
    return supplied.startswith(prefix) and secrets.compare_digest(
        supplied[len(prefix):].strip(),
        _METRICS_TOKEN,
    )


def persist() -> None:
    if not _METRICS_FILE:
        return
    payload = snapshot()
    temp_name = None
    try:
        fd, temp_name = tempfile.mkstemp(prefix=f".{_METRICS_FILE.name}.", suffix=".tmp", dir=_METRICS_FILE.parent)
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, ensure_ascii=False, indent=2, allow_nan=False)
        os.replace(temp_name, _METRICS_FILE)
    except OSError:
        logger.exception("Could not persist metrics snapshot")
    finally:
        if temp_name is not None:
            try:
                os.unlink(temp_name)
            except FileNotFoundError:
                pass


def prometheus_text() -> str:
    rows = ["# HELP sentinel_uptime_seconds Bot process uptime", "# TYPE sentinel_uptime_seconds gauge"]
    rows.append(f"sentinel_uptime_seconds {int(time.time() - _STARTED_AT)}")
    with _LOCK:
        for key, counter_value in sorted(_COUNTERS.items()):
            safe = "".join(ch if ch.isalnum() or ch == "_" else "_" for ch in key)
            rows.append(f"sentinel_{safe} {int(counter_value)}")
        for key, gauge_value in sorted(_GAUGES.items()):
            safe = "".join(ch if ch.isalnum() or ch == "_" else "_" for ch in key)
            rows.append(f"sentinel_{safe} {float(gauge_value)}")
    rows.append(f"sentinel_heartbeat_healthy {1 if _heartbeat_healthy() else 0}")
    return "\n".join(rows) + "\n"


class _Handler(BaseHTTPRequestHandler):
    server_version = "SENTINELWeb/2.0"

    @staticmethod
    def _static_file(request_path: str) -> Path | None:
        if not _WEBAPP_ROOT.is_dir():
            return None
        clean = unquote(request_path).lstrip("/")
        # Support both the canonical root URL and the legacy /app/ URL.
        # Relative assets requested from /app/ are mapped back to webapp/.
        if clean in {"app", "app/"}:
            clean = "index.html"
        elif clean.startswith("app/"):
            clean = clean[4:] or "index.html"
        elif not clean:
            clean = "index.html"
        candidate = (_WEBAPP_ROOT / clean).resolve()
        try:
            candidate.relative_to(_WEBAPP_ROOT)
        except ValueError:
            return None
        if candidate.is_file():
            return candidate
        # Single-page-app fallback for clean routes only.
        if "." not in Path(clean).name:
            index_file = _WEBAPP_ROOT / "index.html"
            return index_file if index_file.is_file() else None
        return None

    def do_GET(self) -> None:  # noqa: N802
        parsed_url = urlsplit(self.path)
        path = parsed_url.path
        content_type = "application/json; charset=utf-8"
        cache_control = "no-store"
        content_security_policy = None
        if path in {"/health", "/healthz", "/livez"}:
            payload = liveness_snapshot()
            status = 200
            body = json.dumps(payload, ensure_ascii=False, default=str).encode()
        elif path in {"/ready", "/readyz"}:
            payload = readiness_snapshot()
            status = 200 if payload["ready"] else 503
            body = json.dumps(payload, ensure_ascii=False, default=str).encode()
        elif path == "/metrics" and _metrics_authorized(self):
            status = 200
            body = prometheus_text().encode()
            content_type = "text/plain; version=0.0.4; charset=utf-8"
        elif path == "/metrics":
            status, body = 403, b"forbidden"
            content_type = "text/plain; charset=utf-8"
        else:
            static_file = self._static_file(path)
            if static_file is None:
                status, body = 404, b"not found"
                content_type = "text/plain; charset=utf-8"
            else:
                try:
                    body = static_file.read_bytes()
                    status = 200
                    guessed, _ = mimetypes.guess_type(static_file.name)
                    content_type = guessed or "application/octet-stream"
                    if content_type.startswith("text/") or content_type in {"application/javascript", "application/json"}:
                        content_type += "; charset=utf-8"
                    cache_control = "no-cache" if static_file.name == "index.html" else "public, max-age=86400"
                    content_security_policy = (
                        "default-src 'self'; "
                        "script-src 'self' https://telegram.org; "
                        "style-src 'self' 'unsafe-inline'; "
                        "img-src 'self' data: https:; "
                        "media-src 'self' blob:; "
                        "connect-src 'self'; "
                        "worker-src 'self'; manifest-src 'self'; "
                        "frame-ancestors https://web.telegram.org https://*.telegram.org; "
                        "base-uri 'none'; form-action 'self'"
                    )
                except OSError:
                    logger.exception("Could not read Mini App asset: %s", static_file)
                    status, body = 500, b"asset unavailable"
                    content_type = "text/plain; charset=utf-8"
        content_encoding = ""
        accept_encoding = str(self.headers.get("Accept-Encoding") or "").lower()
        compressible = content_type.startswith("text/") or content_type.startswith("application/json") or content_type.startswith("application/javascript")
        if "gzip" in accept_encoding and compressible and len(body) >= 1024:
            body = gzip.compress(body, compresslevel=6)
            content_encoding = "gzip"
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Cache-Control", cache_control)
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
        if content_encoding:
            self.send_header("Content-Encoding", content_encoding)
            self.send_header("Vary", "Accept-Encoding")
        if content_security_policy:
            self.send_header("Content-Security-Policy", content_security_policy)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self) -> None:  # noqa: N802
        # Unversioned Mini App mutation endpoints were permanently removed in
        # v8.0. The production API lives exclusively under /api/v1 in FastAPI.
        self.send_error(404)

    def log_message(self, format: str, *args: Any) -> None:  # noqa: A002
        logger.debug("health-http: " + format, *args)


def start_health_server(host: str, port: int) -> None:
    """Start the unified FastAPI Mini App/API/health server in a daemon thread."""
    global _ALLOW_UNAUTHENTICATED_METRICS
    if not port:
        return
    normalized_host = str(host or "").strip().lower()
    _ALLOW_UNAUTHENTICATED_METRICS = normalized_host in {"127.0.0.1", "::1", "localhost"}
    if not _ALLOW_UNAUTHENTICATED_METRICS and not _METRICS_TOKEN:
        logger.warning("Public /metrics is disabled until METRICS_TOKEN is configured")
    from core.miniapp_server import start

    start(host, int(port))


def stop_health_server() -> None:
    from core.miniapp_server import stop

    stop()
    persist()
