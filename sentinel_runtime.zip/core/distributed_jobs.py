from __future__ import annotations

import asyncio
import inspect
import logging
import os
import time
import secrets
import threading
from weakref import WeakKeyDictionary
from collections.abc import Awaitable, Callable
from typing import Any

from config import SETTINGS
from core.runtime_topology import replica_count
from core.async_runtime import run_blocking

logger = logging.getLogger(__name__)
_LOCAL_LOCK = threading.RLock()
_LOCAL_RUNNING: set[str] = set()
_REDIS: Any = None
_REDIS_CLIENTS: WeakKeyDictionary = WeakKeyDictionary()
_REDIS_GUARDS: WeakKeyDictionary = WeakKeyDictionary()
_REDIS_DISABLED_UNTIL = 0.0
_RELEASE_SCRIPT = """
if redis.call('get', KEYS[1]) == ARGV[1] then
  return redis.call('del', KEYS[1])
end
return 0
"""
_RENEW_SCRIPT = """
if redis.call('get', KEYS[1]) == ARGV[1] then
  return redis.call('expire', KEYS[1], ARGV[2])
end
return 0
"""


def _replica_count() -> int:
    try:
        return replica_count()
    except (TypeError, ValueError):
        return 1


def _acquire_postgres_lease(name: str) -> tuple[str, Any | None]:
    """Acquire a session advisory lock used only when Redis is unavailable.

    Returns ``("acquired", connection)``, ``("busy", None)`` or
    ``("unavailable", None)``. A dedicated connection is intentional here:
    PostgreSQL session advisory locks must remain attached to one session for
    the whole async job lifetime. The fallback is used only during Redis loss.
    """
    if not SETTINGS.database_url:
        return "unavailable", None
    connection = None
    try:
        import psycopg

        dsn = str(SETTINGS.database_url).replace("postgres://", "postgresql://", 1)
        connection = psycopg.connect(dsn, autocommit=True, connect_timeout=3)
        connection.execute("SET statement_timeout = 5000")
        connection.execute("SET lock_timeout = 2000")
        row = connection.execute(
            "SELECT pg_try_advisory_lock(hashtextextended(%s, 0))",
            (f"sentinel-job:{name}",),
        ).fetchone()
        if row and bool(row[0]):
            return "acquired", connection
        connection.close()
        return "busy", None
    except Exception as exc:
        if connection is not None:
            connection.close()
        logger.error("PostgreSQL distributed job fallback unavailable for %s: %s", name, exc.__class__.__name__)
        return "unavailable", None


def _release_postgres_lease(name: str, connection: Any) -> None:
    try:
        connection.execute(
            "SELECT pg_advisory_unlock(hashtextextended(%s, 0))",
            (f"sentinel-job:{name}",),
        )
    finally:
        connection.close()


async def _acquire_postgres_lease_async(name: str):
    """Transfer ownership only if the async caller is still waiting.

    Cancelling run_blocking cannot stop its worker. Without this hand-off a
    late successful connection would retain a session lock with no owner.
    """
    guard = threading.Lock()
    # Both values deliberately live in one guarded hand-off record.  Without
    # the explicit value type, static analysis infers ``bool | None`` from the
    # initializer and can hide an accidental close() on the cancellation flag.
    pending: dict[str, Any] = {'cancelled': False, 'connection': None}

    def acquire():
        status, connection = _acquire_postgres_lease(name)
        with guard:
            cancelled = pending['cancelled']
            if not cancelled:
                pending['connection'] = connection
        if cancelled and connection is not None:
            connection.close()
        return status

    try:
        status = await run_blocking(acquire, timeout=12, acquire_timeout=2)
        with guard:
            connection, pending['connection'] = pending['connection'], None
        return status, connection
    except BaseException:
        with guard:
            pending['cancelled'] = True
            connection, pending['connection'] = pending['connection'], None
        if connection is not None:
            # Closing psycopg releases the session lock without another query.
            connection.close()
        raise


async def _redis_client() -> Any:
    loop = asyncio.get_running_loop()
    with _LOCAL_LOCK:
        guard = _REDIS_GUARDS.setdefault(loop, asyncio.Lock())
    async with guard:
        return await _redis_client_locked(loop)


async def _redis_client_locked(loop) -> Any:
    global _REDIS, _REDIS_DISABLED_UNTIL
    if not SETTINGS.redis_url or time.monotonic() < _REDIS_DISABLED_UNTIL:
        return None
    if loop in _REDIS_CLIENTS:
        return _REDIS_CLIENTS[loop]
    candidate = None
    try:
        import redis.asyncio as redis

        timeout = max(0.2, float(os.getenv("REDIS_SOCKET_TIMEOUT_SECONDS", "2") or 2))
        candidate = redis.Redis.from_url(
            SETTINGS.redis_url,
            decode_responses=True,
            socket_connect_timeout=timeout,
            socket_timeout=timeout,
            health_check_interval=30,
            max_connections=max(2, int(os.getenv("REDIS_MAX_CONNECTIONS", "30") or 30)),
            retry_on_timeout=True,
        )
        await candidate.ping()
        _REDIS = candidate
        _REDIS_CLIENTS[loop] = candidate
        return candidate
    except Exception as exc:
        _REDIS = None
        _REDIS_DISABLED_UNTIL = time.monotonic() + max(5, int(os.getenv("REDIS_CIRCUIT_OPEN_SECONDS", "30") or 30))
        logger.error("Redis distributed job coordinator unavailable: %s", exc.__class__.__name__)
        return None
    finally:
        if candidate is not None and _REDIS_CLIENTS.get(loop) is not candidate:
            try:
                async with asyncio.timeout(3):
                    await candidate.aclose()
            except Exception:
                logger.exception("Could not close unsuccessful job coordinator client")


def distributed_job(
    name: str,
    callback: Callable[..., Awaitable[Any]],
    *,
    lease_seconds: int = 300,
) -> Callable[..., Awaitable[Any]]:
    """Run a recurring job once across replicas with layered coordination.

    Redis is preferred. During a Redis outage PostgreSQL session advisory locks
    preserve exactly-once execution across replicas. A local lock is used only
    for a confirmed single-replica deployment. Multi-replica mode fails closed
    if neither shared coordinator is available.
    """

    async def wrapped(*args: Any, **kwargs: Any) -> Any:
        key = f"sentinel:job-lock:{name}"
        token = secrets.token_urlsafe(24)
        client = await _redis_client()
        acquired_redis = False
        acquired_local = False
        postgres_lease: Any | None = None
        renew_task: asyncio.Task[Any] | None = None
        shared_busy = False
        redis_unavailable = False

        if SETTINGS.redis_url and client is not None:
            try:
                acquired_redis = bool(await client.set(key, token, nx=True, ex=max(30, int(lease_seconds))))
            except Exception as exc:
                logger.error("Could not acquire Redis distributed job lock %s: %s", name, exc.__class__.__name__)
                redis_unavailable = True
            else:
                if not acquired_redis:
                    shared_busy = True
        elif SETTINGS.redis_url:
            redis_unavailable = True

        if shared_busy:
            return None

        if acquired_redis:
            async def renew_loop() -> bool:
                interval = max(10, int(lease_seconds) // 3)
                while True:
                    await asyncio.sleep(interval)
                    try:
                        renewed = await client.eval(
                            _RENEW_SCRIPT, 1, key, token, max(30, int(lease_seconds))
                        )
                        if not renewed:
                            logger.error("Lost distributed job lease for %s", name)
                            return False
                    except asyncio.CancelledError:
                        raise
                    except Exception:
                        logger.exception("Could not renew distributed job lock %s", name)
                        return False

            renew_task = asyncio.create_task(renew_loop(), name=f"job-lease:{name}")
        else:
            # Redis absent or temporarily unavailable: PostgreSQL is the shared
            # coordinator of last resort for multi-replica safety.
            if SETTINGS.database_url:
                status, postgres_lease = await _acquire_postgres_lease_async(name)
                if status == "busy":
                    return None
                if status != "acquired":
                    postgres_lease = None
            if postgres_lease is None:
                if _replica_count() > 1:
                    logger.warning(
                        "Skipping distributed job %s: no shared coordinator is available for %s replicas",
                        name,
                        _replica_count(),
                    )
                    return None
                with _LOCAL_LOCK:
                    if name in _LOCAL_RUNNING:
                        return None
                    _LOCAL_RUNNING.add(name)
                    acquired_local = True
                if redis_unavailable:
                    logger.warning("Running job %s under single-replica local fallback while Redis is unavailable", name)

        callback_task = None
        try:
            result = callback(*args, **kwargs)
            if not inspect.isawaitable(result):
                return result
            callback_task = asyncio.ensure_future(result)
            if renew_task is None:
                return await callback_task
            done, _ = await asyncio.wait({callback_task, renew_task}, return_when=asyncio.FIRST_COMPLETED)
            if renew_task in done and not callback_task.done():
                callback_task.cancel()
                try:
                    await callback_task
                except asyncio.CancelledError:
                    pass
                raise RuntimeError(f"Distributed job lease lost: {name}")
            return await callback_task
        finally:
            # Cancellation of asyncio.wait does not cancel its children. Keep
            # the lease until the callback has stopped; otherwise another
            # replica can execute the same economic job concurrently.
            if callback_task is not None and not callback_task.done():
                callback_task.cancel()
                try:
                    await callback_task
                except asyncio.CancelledError:
                    pass
                except Exception:
                    logger.exception("Job failed while cancelling: %s", name)
            if renew_task is not None:
                renew_task.cancel()
                try:
                    await renew_task
                except asyncio.CancelledError:
                    pass
            if acquired_redis and client is not None:
                try:
                    await client.eval(_RELEASE_SCRIPT, 1, key, token)
                except Exception:
                    logger.exception("Could not release distributed job lock %s", name)
            if postgres_lease is not None:
                try:
                    await run_blocking(_release_postgres_lease, name, postgres_lease, timeout=5)
                except Exception:
                    logger.exception("Could not release PostgreSQL distributed job lock %s", name)
            if acquired_local:
                with _LOCAL_LOCK:
                    _LOCAL_RUNNING.discard(name)

    wrapped.__name__ = getattr(callback, "__name__", f"distributed_{name}")
    wrapped.__doc__ = callback.__doc__
    return wrapped


async def close_distributed_jobs() -> None:
    global _REDIS, _REDIS_DISABLED_UNTIL
    loop = asyncio.get_running_loop()
    with _LOCAL_LOCK:
        client = _REDIS_CLIENTS.pop(loop, None)
    if _REDIS is client:
        _REDIS = None
    _REDIS_DISABLED_UNTIL = 0.0
    if client is not None:
        async with asyncio.timeout(3):
            await client.aclose()
