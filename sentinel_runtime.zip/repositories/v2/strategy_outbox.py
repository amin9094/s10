"""Durable per-admin research notices. Uncertain Telegram delivery is not retried."""

from __future__ import annotations

import time
from hashlib import sha256

from core.storage.engine import normalized_engine
from repositories.v2.common import json_dump, json_load


class StrategyOutboxRepository:
    def __init__(self, engine=None):
        self.engine = engine or normalized_engine()

    def enqueue(self, review_ids, admin_ids):
        now = int(time.time() * 1000)
        with self.engine.transaction() as cursor:
            for review_id in review_ids:
                review = cursor.execute("SELECT payload FROM s9_strategy_reviews WHERE id=?", (review_id,)).fetchone()
                if not review:
                    continue
                for admin_id in admin_ids:
                    key = sha256(f"{review_id}:{int(admin_id)}".encode()).hexdigest()[:32]
                    cursor.execute("""INSERT INTO s9_admin_review_outbox(id,review_id,admin_id,status,attempts,updated_ms,payload)
                                   VALUES(?,?,?,'PENDING',0,?,?) ON CONFLICT(review_id,admin_id) DO NOTHING""",
                                   (key, review_id, str(int(admin_id)), now, json_dump({"review": json_load(review["payload"])})))

    def claim(self, limit=2):
        from uuid import uuid4
        found = []
        with self.engine.transaction() as cursor:
            old=cursor.execute("SELECT id,payload FROM s9_admin_review_outbox WHERE status='SENDING' LIMIT 200").fetchall()
            for row in old:
                payload=json_load(row['payload'])
                if payload.get('claimed_ms') is not None and int(time.time()*1000)-payload['claimed_ms']<600000:continue
                payload.update(detail='WORKER_LEASE_EXPIRED',claim_token=None)
                cursor.execute("UPDATE s9_admin_review_outbox SET status='UNCERTAIN',payload=? WHERE id=? AND status='SENDING' AND payload=?",(json_dump(payload),row['id'],row['payload']))
            rows = cursor.execute("SELECT * FROM s9_admin_review_outbox WHERE status='PENDING' AND attempts<3 AND updated_ms<=? ORDER BY updated_ms,id LIMIT ?",
                                  (int(time.time() * 1000), max(1, min(10, int(limit))))).fetchall()
            for row in rows:
                payload=json_load(row['payload']);payload.update(claim_token=uuid4().hex,claimed_ms=int(time.time()*1000),delivery_started_ms=None)
                cursor.execute("UPDATE s9_admin_review_outbox SET status='SENDING',attempts=attempts+1,updated_ms=?,payload=? WHERE id=? AND status='PENDING'",
                               (int(time.time() * 1000), json_dump(payload), row["id"]))
                if cursor.rowcount:
                    found.append({**row, "payload": payload})
        return found

    def finish(self, key, status, *, message_id=None, retry_seconds=0, detail='', verification=None,claim_token=None):
        if status not in {"SENT", "PENDING", "FAILED", "UNCERTAIN", "REVOKED"}:
            raise ValueError("STRATEGY_OUTBOX_STATE_INVALID")
        with self.engine.transaction() as cursor:
            row = cursor.execute("SELECT payload,attempts FROM s9_admin_review_outbox WHERE id=? AND status='SENDING'", (key,)).fetchone()
            if not row:
                raise ValueError("STRATEGY_OUTBOX_CLAIM_MISSING")
            payload = json_load(row["payload"])
            if claim_token is not None and payload.get('claim_token')!=claim_token:raise ValueError('DELIVERY_LEASE_CHANGED')
            if detail:payload['detail']=detail
            if verification is not None:payload['verification']=verification
            if message_id is not None:
                payload["telegram_message_id"] = int(message_id)
            if status == "PENDING" and row["attempts"] >= 3:
                status = "FAILED"
            ready_ms = int(time.time() * 1000) + (max(0, min(3600, float(retry_seconds))) * 1000 if status == "PENDING" else 0)
            cursor.execute("UPDATE s9_admin_review_outbox SET status=?,updated_ms=?,payload=? WHERE id=? AND status='SENDING' AND payload=?",
                           (status, int(ready_ms), json_dump(payload), key, row['payload']))
            if cursor.rowcount!=1:raise ValueError('DELIVERY_LEASE_CHANGED')

    def start(self,key,claim_token):
        with self.engine.transaction() as cursor:
            row=cursor.execute("SELECT payload FROM s9_admin_review_outbox WHERE id=? AND status='SENDING'",(key,)).fetchone()
            payload=json_load(row['payload']) if row else {}
            if not claim_token or payload.get('claim_token')!=claim_token:raise ValueError('DELIVERY_LEASE_CHANGED')
            if int(time.time()*1000)-int(payload.get('claimed_ms',0))>=600000:raise ValueError('DELIVERY_LEASE_EXPIRED')
            payload['delivery_started_ms']=int(time.time()*1000)
            cursor.execute("UPDATE s9_admin_review_outbox SET payload=? WHERE id=? AND payload=?",(json_dump(payload),key,row['payload']))
            if cursor.rowcount!=1:raise ValueError('DELIVERY_LEASE_CHANGED')
