"""Read-only matched-cohort comparisons and current risk, without auto selection."""
from decimal import Decimal as D
import time
from modules.signal_execution import account_key
from repositories.v2.common import json_load
from repositories.v2.paper_statistics import contribution,combine
from repositories.v2.strategy_paper import StrategyPaperRepository


def comparison(repo,strategy,*,from_ms=None,to_ms=None,symbol=None,timeframe=None,profile_id=None):
    runs=[repo.active(account_key(strategy,m)) for m in ('PENDING','MARKET')]
    end=int(time.time()*1000) if to_ms is None else to_ms
    start=max(r['created_ms'] for r in runs) if from_ms is None else from_ms
    if type(start) is not int or type(end) is not int or not 0<=start<=end<=int(time.time()*1000):raise ValueError('PAPER_PERIOD_INVALID')
    if timeframe not in {None,'5m','1h'}:raise ValueError('PAPER_FILTER_INVALID')
    if symbol:
        from modules.automated_market_scope import require_global_symbol
        require_global_symbol(symbol)
    if profile_id is not None and (not isinstance(profile_id,str) or len(profile_id)>160):raise ValueError('PAPER_FILTER_INVALID')
    result=[]
    with repo.engine.transaction(read_only=True,repeatable_read=True) as c:
        for run in runs:
            summary=combine({},{});cursor=(start,'');by_profile={}
            def field(*keys):
                if repo.engine.dialect.name=='postgres':return 'CAST(payload AS JSONB)'+''.join("->'"+k+"'" for k in keys[:-1])+"->>'"+keys[-1]+"'"
                return "json_extract(payload,'$."+'.'.join(keys)+"')"
            conditions=[];extra=[]
            for value,keys in ((symbol,('plan','symbol')),(timeframe,('plan','timeframe')),(profile_id,('profile_id',))):
                if value is not None:conditions.append(field(*keys)+'=?');extra.append(value)
            condition=' AND '+' AND '.join(conditions) if conditions else ''
            while True:
                query='SELECT id,created_ms,payload FROM s9_strategy_paper_trades WHERE run_id=? AND created_ms>=? AND created_ms<=? AND (created_ms>? OR (created_ms=? AND id>?))'+condition+' ORDER BY created_ms,id LIMIT 200'  # nosec B608 -- field paths are fixed above; every filter value is bound
                rows=c.execute(query,(run['id'],start,end,cursor[0],cursor[0],cursor[1],*extra)).fetchall()
                for row in rows:
                    p=json_load(row['payload']);plan=p['plan']
                    v=contribution(p);summary=combine(summary,v)
                    profile=p.get('profile_id') or 'unclassified';by_profile[profile]=combine(by_profile.get(profile),v)
                if len(rows)<200:break
                cursor=(rows[-1]['created_ms'],rows[-1]['id'])
            balance=peak=drawdown=D(0)
            closed_expr='COALESCE(CAST('+field('closed_ms')+' AS BIGINT),created_ms)';closed_cursor=(-1,'')
            while True:
                query='SELECT id,payload,'+closed_expr+" AS closed_ms FROM s9_strategy_paper_trades WHERE run_id=? AND created_ms>=? AND created_ms<=? AND state='CLOSED' "+condition+' AND ('+closed_expr+'>? OR ('+closed_expr+'=? AND id>?)) ORDER BY '+closed_expr+',id LIMIT 200'  # nosec B608 -- fixed dialect JSON path, bound filters and cursor
                closed_rows=c.execute(query,(run['id'],start,end,*extra,closed_cursor[0],closed_cursor[0],closed_cursor[1])).fetchall()
                for closed in closed_rows:
                    balance+=D(json_load(closed['payload'])['realized_usd']);peak=max(peak,balance);drawdown=max(drawdown,peak-balance)
                if len(closed_rows)<200:break
                closed_cursor=(closed_rows[-1]['closed_ms'],closed_rows[-1]['id'])
            summary.update(win_rate=summary['wins']/summary['closed']*100 if summary['closed'] else None,
                average_r=str(D(summary['r_sum'])/summary['closed']) if summary['closed'] else None,
                average_wait_ms=str(D(summary['wait_ms_sum'])/summary['wait_count']) if summary['wait_count'] else None,
                closed_trade_drawdown_usd=str(drawdown),drawdown_model='CLOSED_TRADE_COHORT_CURVE_NOT_INTRATRADE_EQUITY',
                profile_ids=sorted(by_profile),profiles=[{'profile_id':k,**v} for k,v in sorted(by_profile.items())])
            summary.update(sample_size=summary['closed'],costs_complete=summary['costs_unknown']==0,
                net_realized_usd=summary['realized_usd'] if summary['costs_unknown']==0 else None,
                net_average_r=summary['average_r'] if summary['costs_unknown']==0 else None,
                net_win_rate=summary['win_rate'] if summary['costs_unknown']==0 else None)
            result.append({'execution_mode':run['payload'].get('execution_mode','PENDING'),'run_id':run['id'],'stats':summary})
    return {'strategy':strategy,'from_ms':start,'to_ms':end,'symbol':symbol,'timeframe':timeframe,'profile_id':profile_id,
        'cohort':'SIGNALS_CREATED_IN_SHARED_PERIOD_OUTCOMES_AS_OF_NOW','accounts':result,
        'automatic_selection':False,'same_profile_filter':profile_id is not None}


def exposure(repo):
    """Sum loss-at-original-stop, including unresolved exposure; never suppress tests."""
    groups={};total=D(0);cursor=(-1,'')
    with repo.engine.transaction(read_only=True) as c:
        while True:
            rows=c.execute("""SELECT t.id,t.created_ms,t.run_id,t.state,t.payload,r.engine FROM s9_strategy_paper_trades t
                JOIN s9_strategy_paper_runs r ON r.id=t.run_id WHERE r.active=1 AND t.state IN ('OPEN','NEEDS_REVIEW')
                AND (t.created_ms>? OR (t.created_ms=? AND t.id>?)) ORDER BY t.created_ms,t.id LIMIT 200""",
                (cursor[0],cursor[0],cursor[1])).fetchall()
            for row in rows:
                p=json_load(row['payload'])
                if p.get('entered_ms') is None:continue
                plan=p['plan'];key=(row['engine'],plan['symbol'],plan['direction'])
                g=groups.setdefault(key,{'account':key[0],'symbol':key[1],'direction':key[2],'positions':0,'unresolved':0,'risk_usd':'0'})
                risk=D(p['risk_usd'])*D(p['remaining']);total+=risk;g['positions']+=1
                g['unresolved']+=int(row['state']=='NEEDS_REVIEW');g['risk_usd']=str(D(g['risk_usd'])+risk)
            if len(rows)<200:break
            cursor=(rows[-1]['created_ms'],rows[-1]['id'])
    return {'loss_at_original_stop_usd':str(total),'groups':list(groups.values()),'cap_enabled':False,
        'model':'VIRTUAL_RISK_SUM_NOT_BROKER_MARGIN_OR_STATISTICAL_CORRELATION','all_valid_signals_preserved':True}
