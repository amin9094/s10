"""Durable published-book evidence, not reconstruction of unobserved prices."""
from dataclasses import asdict
from core.storage.engine import normalized_engine
from repositories.v2.common import json_dump,json_load,content_hash
from modules.ordered_quotes import OrderedQuote
from modules.canonical_market import Quote


class QuoteArchive:
    def __init__(self,engine=None):self.engine=engine or normalized_engine()

    def append(self,frames):
        grouped={}
        for n,frame in enumerate(frames):
            if n>=5000:raise ValueError('QUOTE_ARCHIVE_BATCH_TOO_LARGE')
            q=frame.quote;grouped.setdefault((q.provider,q.symbol,frame.epoch),[]).append(frame)
        with self.engine.transaction() as c:
            for scope,group in sorted(grouped.items()):
                c.execute('INSERT INTO s9_quote_archive_sessions(provider,symbol,epoch,next_ordinal) VALUES(?,?,?,0) ON CONFLICT DO NOTHING',scope)
                query=('SELECT next_ordinal FROM s9_quote_archive_sessions WHERE provider=? AND symbol=? AND epoch=? FOR UPDATE' if self.engine.dialect.name=='postgres' else 'SELECT next_ordinal FROM s9_quote_archive_sessions WHERE provider=? AND symbol=? AND epoch=?')
                ordinal=c.execute(query,scope).fetchone()['next_ordinal']
                identifiers=list(dict.fromkeys(f.quote.source_id for f in group));known={}
                for offset in range(0,len(identifiers),500):
                    chunk=identifiers[offset:offset+500]
                    rows=c.execute('SELECT source_id,digest FROM s9_quote_archive WHERE provider=? AND symbol=? AND epoch=? AND source_id IN ('+','.join('?' for _ in chunk)+')',(*scope,*chunk)).fetchall()  # nosec B608 -- fixed query and bound placeholders
                    known.update((r['source_id'],r['digest']) for r in rows)
                pending=[]
                for frame in group:
                    q=frame.quote;p={**asdict(frame),'quote':q.as_dict()};digest=content_hash(p)
                    if q.source_id in known:
                        if known[q.source_id]!=digest:raise ValueError('DURABLE_QUOTE_REWRITE_REJECTED')
                        continue
                    pending.append((*scope,ordinal,frame.sequence,q.source_id,q.event_ms,q.received_ms,digest,json_dump(p)))
                    known[q.source_id]=digest;ordinal+=1
                if pending:
                    c.executemany('INSERT INTO s9_quote_archive(provider,symbol,epoch,ordinal,sequence,source_id,event_ms,received_ms,digest,payload) VALUES(?,?,?,?,?,?,?,?,?,?)',pending)
                    c.execute('UPDATE s9_quote_archive_sessions SET next_ordinal=? WHERE provider=? AND symbol=? AND epoch=?',(ordinal,*scope))

    def replay(self,provider,symbol,epoch,after_id,*,limit=2001):
        with self.engine.transaction(read_only=True) as c:
            anchor=c.execute('SELECT ordinal FROM s9_quote_archive WHERE provider=? AND symbol=? AND epoch=? AND source_id=?',
                (provider,symbol,epoch,after_id)).fetchone()
            if not anchor:return []
            rows=c.execute('''SELECT payload,digest FROM s9_quote_archive WHERE provider=? AND symbol=? AND epoch=?
                AND ordinal>=? ORDER BY ordinal LIMIT ?''',(provider,symbol,epoch,anchor['ordinal'],max(1,min(2001,limit)))).fetchall()
        result=[]
        for row in rows:
            p=json_load(row['payload'])
            if content_hash(p)!=row['digest']:raise ValueError('DURABLE_QUOTE_HASH_MISMATCH')
            p['quote']['quality_flags']=tuple(p['quote'].get('quality_flags',()))
            p['quote']=Quote(**p['quote']);frame=OrderedQuote(**p)
            if result:
                last=result[-1]
                if frame.snapshot or frame.previous_sequence!=last.sequence or frame.quote.received_ms<last.quote.received_ms:
                    raise ValueError('DURABLE_QUOTE_CONTINUITY_GAP')
            result.append(frame)
        return result

    def prune(self,before_ms,*,batch=1000):
        # An old cursor subsequently falls back to NEEDS_REVIEW, never a fabricated fill.
        with self.engine.transaction() as c:
            rows=c.execute('SELECT provider,symbol,epoch,ordinal FROM s9_quote_archive WHERE received_ms<? ORDER BY received_ms LIMIT ?',
                (before_ms,max(1,min(5000,batch)))).fetchall()
            for r in rows:c.execute('DELETE FROM s9_quote_archive WHERE provider=? AND symbol=? AND epoch=? AND ordinal=?',tuple(r[k] for k in ('provider','symbol','epoch','ordinal')))
        return len(rows)
