"""Exact incremental paper statistics; the journal remains authoritative.

A single bounded-page backfill initializes each old run. Subsequent writes update
only the all-run and profile buckets in the same transaction as the trade.
"""
from decimal import Decimal as D
from repositories.v2.common import json_dump,json_load

VERSION=3
MONEY=('realized_usd','unrealized_usd','gross_profit','gross_loss','open_risk_usd','r_sum','price_r_sum','gross_r_sum','wait_ms_sum','manual_realized_usd','gross_realized_usd','costs_usd','mfe_r_sum','mae_r_sum')
COUNTS=('total_signals','closed','wins','unresolved_positions','entered','never_entered','manual_signals','wait_count','costs_unknown','strategy_only_closed','strategy_only_wins','excursion_count')


def contribution(p):
    state=p['state'];entered=p.get('entered_ms') is not None
    closed=state=='CLOSED';unresolved=state in {'NEEDS_REVIEW','RESET_ARCHIVED'} and entered
    realized=D(p.get('realized_usd','0'));risk=D(p.get('risk_usd','0'))
    budget=D(p.get('risk_budget_usd',str(risk)));gross=D(p.get('gross_realized_usd',str(realized)))
    manual=any(str(e.get('type','')).startswith('ADMIN_') for e in p.get('events',[]))
    excursion=p.get('excursions') or {};has_excursion=closed and bool(excursion)
    return {**{k:0 for k in COUNTS},**{k:'0' for k in MONEY},'total_signals':1,
        'closed':int(closed),'wins':int(closed and realized>0),'strategy_only_closed':int(closed and not manual),'strategy_only_wins':int(closed and not manual and realized>0),'unresolved_positions':int(unresolved),
        'entered':int(entered),'never_entered':int(not entered),'manual_signals':int(manual),
        'realized_usd':str(realized),'unrealized_usd':p.get('unrealized_usd','0') if state=='OPEN' else '0',
        'gross_profit':str(max(D(0),realized)) if closed else '0',
        'gross_loss':str(min(D(0),realized)) if closed else '0',
        'open_risk_usd':str(risk*D(p.get('remaining','0'))) if state=='OPEN' or unresolved else '0',
        'r_sum':str(realized/budget) if closed and budget>0 else '0',
        'price_r_sum':str(gross/risk) if closed and risk>0 else '0',
        'gross_r_sum':str(gross/budget) if closed and budget>0 else '0',
        'mfe_r_sum':excursion.get('mfe_r','0') if has_excursion else '0',
        'mae_r_sum':excursion.get('mae_r','0') if has_excursion else '0','excursion_count':int(has_excursion),
        'manual_realized_usd':str(realized) if manual else '0','gross_realized_usd':p.get('gross_realized_usd',str(realized)),'costs_usd':p.get('costs_usd','0'),'costs_unknown':int(entered and not p.get('fees_included',False)),
        'wait_count':int(entered),'wait_ms_sum':str(max(0,p['entered_ms']-p.get('armed_ms',p['entered_ms']))) if entered else '0',
        'counts':{state:1}}


def combine(a,b,sign=1):
    a=dict(a or {});a['counts']=dict(a.get('counts',{}));a['statistics_version']=VERSION
    for k in MONEY:a[k]=str(D(a.get(k,'0'))+sign*D(b.get(k,'0')))
    for k in COUNTS:a[k]=a.get(k,0)+sign*b.get(k,0)
    for k,v in b.get('counts',{}).items():
        a['counts'][k]=a['counts'].get(k,0)+sign*v
        if not a['counts'][k]:del a['counts'][k]
    return a


def _bucket(p):return 'profile:'+str(p.get('profile_id') or 'unclassified')


def _buckets(p):
    from repositories.v2.live_signal_inbox import market_for
    plan=p['plan']
    dimensions={'engine':plan['engine'],'execution_mode':p.get('execution_mode','PENDING'),
                'market':market_for(plan['symbol']),'symbol':plan['symbol'],'timeframe':plan['timeframe'],
                'profile_id':p.get('profile_id') or 'unclassified'}
    return {_bucket(p),'dimension:'+json_dump(dimensions)}


def ready(c,run_id):
    row=c.execute('SELECT payload FROM s9_paper_statistics WHERE run_id=? AND bucket=?',(run_id,'all')).fetchone()
    return bool(row and json_load(row['payload']).get('statistics_version')==VERSION)


def ensure(c,run_id):
    if ready(c,run_id):return
    c.execute('DELETE FROM s9_paper_statistics WHERE run_id=?',(run_id,))
    buckets={'all':combine({}, {})};after=(-1,'')
    while True:
        rows=c.execute('''SELECT id,created_ms,payload FROM s9_strategy_paper_trades WHERE run_id=?
            AND (created_ms>? OR (created_ms=? AND id>?)) ORDER BY created_ms,id LIMIT 200''',
            (run_id,after[0],after[0],after[1])).fetchall()
        for r in rows:
            p=json_load(r['payload']);v=contribution(p)
            for key in {'all'}|_buckets(p):buckets[key]=combine(buckets.get(key),v)
        if len(rows)<200:break
        after=(rows[-1]['created_ms'],rows[-1]['id'])
    for key,p in buckets.items():
        c.execute('INSERT INTO s9_paper_statistics(run_id,bucket,payload) VALUES(?,?,?) ON CONFLICT DO NOTHING',(run_id,key,json_dump(p)))


def changed(c,run_id,old,new):
    # Called AFTER the authoritative trade write. A missing cache is rebuilt
    # from the already-updated journal, so the current delta must not be added twice.
    if not ready(c,run_id):
        ensure(c,run_id);return
    old_keys=_buckets(old) if old else set();new_keys=_buckets(new) if new else set()
    keys={'all'}|old_keys|new_keys
    for key in keys:
        r=c.execute('SELECT payload FROM s9_paper_statistics WHERE run_id=? AND bucket=?',(run_id,key)).fetchone()
        value=json_load(r['payload']) if r else combine({}, {})
        if old and (key=='all' or key in old_keys):value=combine(value,contribution(old),-1)
        if new and (key=='all' or key in new_keys):value=combine(value,contribution(new))
        c.execute('''INSERT INTO s9_paper_statistics(run_id,bucket,payload) VALUES(?,?,?)
            ON CONFLICT(run_id,bucket) DO UPDATE SET payload=excluded.payload''',(run_id,key,json_dump(value)))


def read(c,run_id,*,initialize=True,profile_after=''):
    if initialize:ensure(c,run_id)
    rows=c.execute("SELECT bucket,payload FROM s9_paper_statistics WHERE run_id=? AND bucket='all'",(run_id,)).fetchall()
    rows+=c.execute("SELECT bucket,payload FROM s9_paper_statistics WHERE run_id=? AND bucket LIKE 'profile:%' AND bucket>? ORDER BY bucket LIMIT 100",(run_id,profile_after)).fetchall()
    return {r['bucket']:json_load(r['payload']) for r in rows}


def breakdown(c,run_id,*,after=''):
    rows=c.execute("SELECT bucket,payload FROM s9_paper_statistics WHERE run_id=? AND bucket LIKE 'dimension:%' AND bucket>? ORDER BY bucket LIMIT 50",(run_id,after)).fetchall()
    items=[]
    for row in rows:
        p=json_load(row['payload']);closed=p['closed'];n=p['excursion_count']
        items.append({'dimensions':json_load(row['bucket'][10:]),'stats':{**p,
            'win_rate':p['wins']/closed*100 if closed else None,
            'average_r':str(D(p['r_sum'])/closed) if closed else None,
            'average_mfe_r':str(D(p['mfe_r_sum'])/n) if n else None,
            'average_mae_r':str(D(p['mae_r_sum'])/n) if n else None}})
    return {'items':items,'next_after':rows[-1]['bucket'] if len(rows)==50 else None,'run_id':run_id,'automatic_selection':False}
