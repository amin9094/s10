"""Named immutable configurations; saving does not activate a trading rule."""
import time
import uuid
from core.storage.engine import normalized_engine
from modules.custom_strategy import parse_settings
from repositories.v2.common import json_load,json_dump


class CustomPresets:
    def __init__(self,engine=None):self.engine=engine or normalized_engine()

    def items(self,*,before=None,query=None,limit=100):
        from repositories.v2.live_signal_inbox import page_cursor
        stamp,key=page_cursor(before)
        if query is not None and (not isinstance(query,str) or len(query)>60):raise ValueError('CUSTOM_PRESET_SEARCH_INVALID')
        with self.engine.transaction(read_only=True) as c:
            rows=c.execute('''SELECT * FROM s9_custom_presets WHERE (created_ms<? OR (created_ms=? AND id<?))
                AND (?='' OR name LIKE ?) ORDER BY created_ms DESC,id DESC LIMIT ?''',
                (stamp,stamp,key,query or '', '%'+(query or '')+'%',max(1,min(100,int(limit))))).fetchall()
        return [{**r,'payload':json_load(r['payload'])} for r in rows]

    def page(self,*,before=None,query=None):
        rows=self.items(before=before,query=query)
        return {'items':rows,'next_before':f"{rows[-1]['created_ms']}:{rows[-1]['id']}" if len(rows)==100 else None}

    def save(self,name,settings,actor):
        if not isinstance(name,str) or not 1<=len(name.strip())<=60 or any(ord(x)<32 for x in name):raise ValueError('CUSTOM_PRESET_NAME_INVALID')
        cfg=parse_settings(settings);identifier=uuid.uuid4().hex
        with self.engine.transaction() as c:
            c.execute('INSERT INTO s9_custom_presets(id,name,created_ms,payload) VALUES(?,?,?,?)',
                (identifier,name.strip(),int(time.time()*1000),json_dump({'config':cfg.dto(),'profile_id':cfg.profile_id,'actor':str(actor)})))
        return {'id':identifier,'profile_id':cfg.profile_id,'activated':False}
