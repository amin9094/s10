"""Durable reminders with a 20-minute default and preserved explicit settings. A claimed slot is not resent after an uncertain receipt."""
import time
from core.storage.engine import normalized_engine
from repositories.v2.common import json_dump, json_load


class DeskNotifications:
    def __init__(self, engine=None):
        self.engine = engine or normalized_engine()

    def get(self, admin):
        with self.engine.transaction(read_only=True) as c:
            r = c.execute('SELECT * FROM s9_desk_notifications WHERE admin_id=?', (str(admin),)).fetchone()
        return {**r, 'payload': json_load(r['payload'])} if r else {
            'admin_id': str(admin), 'interval_minutes': 0, 'due_ms': 0, 'revision': 0, 'payload': {}}

    def ensure(self,admin,*,now_ms=None):
        now=now_ms if now_ms is not None else int(time.time()*1000)
        with self.engine.transaction() as c:
            c.execute("""INSERT INTO s9_desk_notifications(admin_id,interval_minutes,due_ms,payload)
                VALUES(?,20,?,?) ON CONFLICT(admin_id) DO NOTHING""",
                (str(admin),now+20*60000,json_dump({'actor':'USER_REQUEST_DEFAULT_20_MINUTES','updated_ms':now})))
        return self.get(admin)

    def configure(self, admin, minutes, *, now_ms=None,urgent_enabled=None):
        if type(minutes) is not int or not 0 <= minutes <= 1440:
            raise ValueError('REMINDER_INTERVAL_INVALID')
        now = now_ms if now_ms is not None else int(time.time()*1000)
        if urgent_enabled is not None and type(urgent_enabled) is not bool:raise ValueError('REMINDER_SETTINGS_INVALID')
        p = dict(self.get(admin)['payload']);p.update(updated_ms=now,actor=str(admin))
        if urgent_enabled is not None:p['urgent_enabled']=urgent_enabled
        with self.engine.transaction() as c:
            c.execute('''INSERT INTO s9_desk_notifications(admin_id,interval_minutes,due_ms,payload)
                VALUES(?,?,?,?) ON CONFLICT(admin_id) DO UPDATE SET interval_minutes=excluded.interval_minutes,
                due_ms=excluded.due_ms,payload=excluded.payload,revision=s9_desk_notifications.revision+1''',
                (str(admin), minutes, now+minutes*60000, json_dump(p)))
        return self.get(admin)

    def urgent_due(self,now):
        flag="CAST(payload AS JSONB)->>'urgent_enabled'='true'" if self.engine.dialect.name=='postgres' else "json_extract(payload,'$.urgent_enabled')=1"
        due="CAST(COALESCE(CAST(payload AS JSONB)->>'urgent_next_ms','0') AS BIGINT)" if self.engine.dialect.name=='postgres' else "COALESCE(json_extract(payload,'$.urgent_next_ms'),0)"
        with self.engine.transaction(read_only=True) as c:
            return c.execute(f'SELECT * FROM s9_desk_notifications WHERE {flag} AND {due}<=? ORDER BY due_ms,admin_id LIMIT 20',(now,)).fetchall()  # nosec B608 -- dialect-selected fixed expressions

    def claim_urgent(self,row,now,identifiers):
        p=json_load(row['payload']);old=set(p.get('urgent_last_ids',[]))
        if not set(identifiers)-old:return False
        p.update(urgent_next_ms=now+300000,urgent_last_ids=sorted(identifiers)[:500])
        with self.engine.transaction() as c:
            c.execute('UPDATE s9_desk_notifications SET payload=?,revision=revision+1 WHERE admin_id=? AND revision=?',
                (json_dump(p),row['admin_id'],row['revision']))
            return c.rowcount==1

    def near_entry_ids(self,now):
        from repositories.v2.live_signal_inbox import LiveSignalInbox
        from decimal import Decimal as D
        inbox=LiveSignalInbox(self.engine);cursor=None;found=[]
        # This is a bounded optional alert, not a complete count/report or an
        # execution gate. Standard reminders retain the complete pending count.
        for _ in range(5):
            rows=inbox.items(limit=100,before=cursor,publication_state='PENDING',paper_state='WAITING')
            for r in rows:
                if r['distance_r'] is not None and D(r['distance_r'])<=D('.25'):
                    found.append(r['id'])
            if len(rows)<100:break
            cursor=f"{rows[-1]['created_ms']}:{rows[-1]['id']}"
        return found

    def due(self, now):
        with self.engine.transaction(read_only=True) as c:
            return c.execute('''SELECT * FROM s9_desk_notifications WHERE interval_minutes>0 AND due_ms<=?
                ORDER BY due_ms,admin_id LIMIT 20''', (now,)).fetchall()

    def claim(self, row, now):
        with self.engine.transaction() as c:
            c.execute('''UPDATE s9_desk_notifications SET due_ms=?,revision=revision+1
                WHERE admin_id=? AND revision=? AND interval_minutes>0 AND due_ms<=?''',
                (now+row['interval_minutes']*60000, row['admin_id'], row['revision'], now))
            return c.rowcount == 1

    def pending_count(self):
        from repositories.v2.live_signal_inbox import global_inbox_scope
        scope,params=global_inbox_scope(self.engine)
        with self.engine.transaction(read_only=True) as c:
            return int(c.execute(f"SELECT COUNT(*) AS n FROM s9_signal_inbox WHERE state='PENDING' AND {scope}",params).fetchone()['n'])  # nosec B608 -- fixed internal scope; values use bound parameters
