from __future__ import annotations

import math
from datetime import UTC, datetime
from typing import Any
from zoneinfo import ZoneInfo

from core.storage.engine import DatabaseEngine, normalized_engine
from repositories.v2.common import decode_cursor, encode_cursor, json_dump, json_load, new_id, utc_iso

ACTIVE_STATES = {"planned", "open", "partial"}
FINAL_STATES = {"closed", "cancelled", "voided"}


class PositionRepository:
    def __init__(self, engine: DatabaseEngine | None = None):
        self.engine = engine or normalized_engine()

    def open(self, data: dict[str, Any]) -> dict[str, Any]:
        """Open one active position per user/account/signal.

        The database partial unique index is the final concurrency boundary.
        A generic ``ON CONFLICT DO NOTHING`` avoids PostgreSQL's aborted-
        transaction state and lets us translate races into stable domain errors.
        """
        now = str(data.get("opened_at") or utc_iso())
        position = {
            "id": str(data.get("id") or new_id("pos")),
            "user_id": str(data["user_id"]),
            "account_id": str(data["account_id"]),
            "signal_id": str(data.get("signal_id") or "") or None,
            "symbol": str(data["symbol"]).upper().replace("/", ""),
            "side": str(data["side"]).upper(),
            "status": str(data.get("status") or "open"),
            "actual_entry": float(data["actual_entry"]),
            "actual_stop": float(data["actual_stop"]),
            "actual_volume": float(data["actual_volume"]),
            "remaining_volume": float(data.get("remaining_volume", data["actual_volume"])),
            "risk_percent": float(data["risk_percent"]),
            "risk_money": float(data["risk_money"]),
            "realized_pnl": float(data.get("realized_pnl") or 0),
            "unrealized_pnl": float(data.get("unrealized_pnl") or 0),
            "opened_at": now,
            "closed_at": data.get("closed_at"),
            "updated_at": now,
            "data_source": str(data.get("data_source") or "manual"),
            "data_confidence": min(1.0, max(0.0, float(data.get("data_confidence") or 0.5))),
        }
        if position["status"] not in ACTIVE_STATES | FINAL_STATES:
            raise ValueError("INVALID_POSITION_STATUS")
        if position["actual_volume"] <= 0 or position["remaining_volume"] < 0:
            raise ValueError("INVALID_POSITION_VOLUME")
        if position["actual_entry"] <= 0 or position["actual_stop"] <= 0 or position["actual_entry"] == position["actual_stop"]:
            raise ValueError("INVALID_POSITION_LEVELS")
        with self.engine.transaction() as cursor:
            cursor.execute(
                """INSERT INTO v8_positions(id,user_id,account_id,signal_id,symbol,side,status,actual_entry,actual_stop,
                    actual_volume,remaining_volume,risk_percent,risk_money,realized_pnl,unrealized_pnl,opened_at,
                    closed_at,updated_at,data_source,data_confidence,payload)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT DO NOTHING""",
                (
                    position["id"],position["user_id"],position["account_id"],position["signal_id"],position["symbol"],
                    position["side"],position["status"],position["actual_entry"],position["actual_stop"],
                    position["actual_volume"],position["remaining_volume"],position["risk_percent"],position["risk_money"],
                    position["realized_pnl"],position["unrealized_pnl"],position["opened_at"],position["closed_at"],
                    position["updated_at"],position["data_source"],position["data_confidence"],json_dump({**position, **data}),
                ),
            )
            if cursor.rowcount == 1:
                return position
            if position["signal_id"]:
                duplicate = cursor.execute(
                    "SELECT id FROM v8_positions WHERE user_id=? AND account_id=? AND signal_id=? AND status IN ('planned','open','partial')",
                    (position["user_id"], position["account_id"], position["signal_id"]),
                ).fetchone()
                if duplicate:
                    raise ValueError("POSITION_ALREADY_OPEN")
            if cursor.execute("SELECT id FROM v8_positions WHERE id=?", (position["id"],)).fetchone():
                raise ValueError("POSITION_ID_CONFLICT")
            raise RuntimeError("POSITION_PERSISTENCE_FAILED")

    def get(self, user_id: int | str, position_id: str | int) -> dict[str, Any] | None:
        with self.engine.transaction(read_only=True) as cursor:
            sql = "SELECT * FROM v8_positions WHERE user_id=? AND id=?"
            if self.engine.dialect.name == "postgres" and getattr(self.engine._unit_of_work, "cursor", None) is not None:
                sql += " FOR UPDATE"
            row = cursor.execute(
                sql,
                (str(user_id), str(position_id)),
            ).fetchone()
        return self._decode(row) if row else None

    def list_for_user(self, user_id: int | str, *, account_id: str | int | None = None,
                      status: str | None = None, cursor: str | None = None, limit: int = 30) -> dict[str, Any]:
        size = max(1, min(int(limit or 30), 100))
        clauses = ["user_id=?"]
        params: list[Any] = [str(user_id)]
        if account_id is not None:
            clauses.append("account_id=?")
            params.append(str(account_id))
        if status:
            if status == "active":
                clauses.append("status IN ('planned','open','partial')")
            else:
                clauses.append("status=?")
                params.append(str(status))
        decoded = decode_cursor(cursor)
        if decoded:
            clauses.append("(opened_at < ? OR (opened_at = ? AND id < ?))")
            params.extend([decoded[0], decoded[0], decoded[1]])
        params.append(size + 1)
        with self.engine.transaction(read_only=True) as db:
            rows = db.execute(
                f"SELECT * FROM v8_positions WHERE {' AND '.join(clauses)} ORDER BY opened_at DESC,id DESC LIMIT ?",  # nosec B608
                params,
            ).fetchall()
        has_more = len(rows) > size
        rows = rows[:size]
        items = [self._decode(row) for row in rows]
        next_cursor = encode_cursor(str(rows[-1]["opened_at"]), str(rows[-1]["id"])) if has_more and rows else None
        return {"items": items, "next_cursor": next_cursor, "limit": size}

    def active_exposure(self, user_id: int | str, account_id: str | int | None = None) -> dict[str, Any]:
        account_filter = " AND account_id=?" if account_id is not None else ""
        with self.engine.transaction(read_only=True) as cursor:
            row = cursor.execute(
                f"""SELECT COUNT(*) AS open_count, COALESCE(SUM(risk_percent * CASE WHEN actual_volume > 0
                        THEN CASE WHEN remaining_volume <= 0 THEN 0 WHEN remaining_volume >= actual_volume THEN 1 ELSE remaining_volume / actual_volume END ELSE 1 END),0) AS risk_percent,
                    COALESCE(SUM(risk_money * CASE WHEN actual_volume > 0
                        THEN CASE WHEN remaining_volume <= 0 THEN 0 WHEN remaining_volume >= actual_volume THEN 1 ELSE remaining_volume / actual_volume END ELSE 1 END),0) AS risk_money
                    FROM v8_positions WHERE user_id=?{account_filter} AND status IN ('planned','open','partial')""",  # nosec B608 -- fixed predicate
                (str(user_id), str(account_id)) if account_id is not None else (str(user_id),),
            ).fetchone() or {}
        return {
            "open_count": int(row.get("open_count") or 0),
            "risk_percent": float(row.get("risk_percent") or 0),
            "risk_money": float(row.get("risk_money") or 0),
        }

    def cancel(self, user_id: int | str, position_id: str | int, *, reason: str = "") -> dict[str, Any]:
        position=self.get(user_id,position_id)
        if not position: raise ValueError("POSITION_NOT_FOUND")
        if position["status"] not in ACTIVE_STATES: return position
        now=utc_iso(); updated={**position,"status":"cancelled","closed_at":now,"updated_at":now,"cancel_reason":str(reason)[:500]}
        with self.engine.transaction() as cursor:
            cursor.execute("UPDATE v8_positions SET status='cancelled',closed_at=?,updated_at=?,payload=? WHERE id=? AND user_id=? AND status IN ('planned','open','partial')",
                           (now,now,json_dump(updated),str(position_id),str(user_id)))
        return self.get(user_id,position_id) or updated

    def active_for_signal(self, user_id: int | str, signal_id: str | int) -> list[dict[str, Any]]:
        with self.engine.transaction(read_only=True) as cursor:
            rows=cursor.execute("SELECT * FROM v8_positions WHERE user_id=? AND signal_id=? AND status IN ('planned','open','partial') ORDER BY opened_at DESC",
                                (str(user_id),str(signal_id))).fetchall()
        return [self._decode(row) for row in rows]

    def close(self, user_id: int | str, position_id: str | int, *, close_volume: float,
              realized_pnl: float, exit_price: float, commission: float = 0, swap: float = 0,
              fees: float = 0, occurred_at: str | None = None, note: str = "") -> dict[str, Any]:
        volume = float(close_volume)
        if not math.isfinite(volume) or volume <= 0:
            raise ValueError("INVALID_CLOSE_VOLUME")
        if not math.isfinite(float(exit_price)) or float(exit_price) <= 0:
            raise ValueError("INVALID_EXIT_PRICE")
        if any(not math.isfinite(float(x)) for x in (realized_pnl, commission, swap, fees)):
            raise ValueError("INVALID_PNL")
        if float(commission) < 0 or float(fees) < 0:
            raise ValueError("INVALID_TRADING_COST")
        occurred = occurred_at or utc_iso()
        event_id = new_id("pnl")
        net_pnl = float(realized_pnl) - float(commission) - float(swap) - float(fees)

        # All position-dependent calculations happen after the row is locked by
        # the write transaction. This prevents stale remaining-volume and PNL
        # values when two partial-close requests race. SQLite serializes via
        # BEGIN IMMEDIATE; PostgreSQL locks the selected row explicitly.
        with self.engine.transaction() as cursor:
            select_sql = "SELECT * FROM v8_positions WHERE id=? AND user_id=?"
            if self.engine.dialect.name == "postgres":
                select_sql += " FOR UPDATE"
            row = cursor.execute(select_sql, (str(position_id), str(user_id))).fetchone()
            if not row:
                raise ValueError("POSITION_NOT_FOUND")
            position = self._decode(row)
            if str(position["status"]) not in ACTIVE_STATES:
                raise ValueError("POSITION_NOT_ACTIVE")
            current_remaining = float(position["remaining_volume"])
            if volume > current_remaining + 1e-12:
                raise ValueError("INVALID_CLOSE_VOLUME")

            local_date = self._trading_local_date_in_cursor(cursor, position["account_id"], occurred)
            remaining = max(0.0, current_remaining - volume)
            status = "closed" if remaining <= 1e-12 else "partial"
            event_type = "close" if status == "closed" else "partial_close"
            new_realized = float(position.get("realized_pnl") or 0) + net_pnl
            closed_at = occurred if status == "closed" else None
            event_payload = {
                "id": event_id, "position_id": str(position_id), "event_type": event_type,
                "realized_pnl": float(realized_pnl), "net_realized_pnl": net_pnl, "commission": float(commission),
                "swap": float(swap), "fees": float(fees), "closed_volume": volume, "exit_price": float(exit_price),
                "occurred_at": occurred, "account_local_date": local_date, "note": str(note)[:1000],
            }
            updated_payload = {
                **position, "remaining_volume": remaining, "status": status, "realized_pnl": new_realized,
                "closed_at": closed_at, "last_exit_price": float(exit_price), "updated_at": occurred,
            }
            cursor.execute(
                """UPDATE v8_positions SET remaining_volume=?,status=?,realized_pnl=?,closed_at=?,updated_at=?,payload=?
                   WHERE id=? AND user_id=?""",
                (remaining,status,new_realized,closed_at,occurred,json_dump(updated_payload),str(position_id),str(user_id)),
            )
            cursor.execute(
                """INSERT INTO v8_position_pnl_events(id,user_id,account_id,position_id,event_type,realized_pnl,
                   commission,swap,fees,closed_volume,occurred_at,account_local_date,payload)
                   VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (event_id,str(user_id),position["account_id"],str(position_id),event_type,float(realized_pnl),
                 float(commission),float(swap),float(fees),volume,occurred,local_date,json_dump(event_payload)),
            )
            existing = cursor.execute(
                "SELECT realized_pnl FROM v8_daily_account_snapshots WHERE account_id=? AND local_date=?",
                (position["account_id"], local_date),
            ).fetchone()
            if existing:
                cursor.execute(
                    "UPDATE v8_daily_account_snapshots SET realized_pnl=?,updated_at=?,payload=? WHERE account_id=? AND local_date=?",
                    (float(existing["realized_pnl"])+net_pnl,occurred,json_dump(event_payload),position["account_id"],local_date),
                )
            else:
                account = cursor.execute(
                    "SELECT balance,equity,floating_pnl FROM v8_trading_accounts WHERE id=?",
                    (position["account_id"],),
                ).fetchone() or {}
                balance = float(account.get("balance") or 0)
                equity = float(account.get("equity") if account.get("equity") is not None else balance)
                cursor.execute(
                    """INSERT INTO v8_daily_account_snapshots(account_id,local_date,opening_balance,opening_equity,
                       lowest_equity,highest_equity,realized_pnl,floating_pnl,updated_at,source_event_id,payload)
                       VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
                    (position["account_id"],local_date,balance,equity,equity,equity,net_pnl,
                     float(account.get("floating_pnl") or 0),occurred,event_id,json_dump(event_payload)),
                )

        updated = self.get(user_id, position_id)
        return {**(updated or updated_payload), "pnl_event": event_payload}

    def pnl_for_date(self, account_id: str | int, local_date: str) -> dict[str, Any]:
        with self.engine.transaction(read_only=True) as cursor:
            row = cursor.execute(
                """SELECT COALESCE(SUM(realized_pnl-commission-swap-fees),0) AS net_pnl,
                    COUNT(*) AS event_count,COALESCE(SUM(closed_volume),0) AS closed_volume
                    FROM v8_position_pnl_events WHERE account_id=? AND account_local_date=?""",
                (str(account_id), str(local_date)),
            ).fetchone() or {}
        return {"net_pnl": float(row.get("net_pnl") or 0), "event_count": int(row.get("event_count") or 0),
                "closed_volume": float(row.get("closed_volume") or 0)}

    def events_for_position(self, position_id: str | int) -> list[dict[str, Any]]:
        with self.engine.transaction(read_only=True) as cursor:
            rows = cursor.execute(
                "SELECT * FROM v8_position_pnl_events WHERE position_id=? ORDER BY occurred_at,id",
                (str(position_id),),
            ).fetchall()
        return [json_load(row.get("payload"), {}) | {key: row[key] for key in row if key != "payload"} for row in rows]


    def _trading_local_date_in_cursor(self, cursor: Any, account_id: str | int, occurred_at: str) -> str:
        account = cursor.execute(
            "SELECT timezone,rule_template_id FROM v8_trading_accounts WHERE id=?",
            (str(account_id),),
        ).fetchone() or {}
        template_id = str(account.get("rule_template_id") or "personal-standard")
        template = cursor.execute(
            "SELECT rules FROM v8_prop_rule_templates WHERE id=? AND active=1",
            (template_id,),
        ).fetchone()
        rules = json_load((template or {}).get("rules"), {}) or {}
        timezone = str(rules.get("daily_reset_timezone") or account.get("timezone") or "UTC")
        reset_hour = max(0, min(int(rules.get("daily_reset_hour") or 0), 23))
        try:
            dt = datetime.fromisoformat(str(occurred_at).replace("Z", "+00:00"))
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=UTC)
            from datetime import timedelta
            return (dt.astimezone(ZoneInfo(timezone)) - timedelta(hours=reset_hour)).date().isoformat()
        except Exception:
            return datetime.now(UTC).date().isoformat()

    def _trading_local_date(self, account_id: str | int, occurred_at: str) -> str:
        """Resolve the prop template trading day, including non-midnight resets."""
        with self.engine.transaction(read_only=True) as cursor:
            return self._trading_local_date_in_cursor(cursor, account_id, occurred_at)

    @staticmethod
    def _decode(row: dict[str, Any]) -> dict[str, Any]:
        payload = json_load(row.get("payload"), {}) or {}
        payload.update({
            "id": str(row["id"]), "user_id": str(row["user_id"]), "account_id": str(row["account_id"]),
            "signal_id": str(row["signal_id"]) if row.get("signal_id") else None, "symbol": row["symbol"],
            "side": row["side"], "status": row["status"], "actual_entry": float(row["actual_entry"]),
            "actual_stop": float(row["actual_stop"]), "actual_volume": float(row["actual_volume"]),
            "remaining_volume": float(row["remaining_volume"]), "risk_percent": float(row["risk_percent"]),
            "risk_money": float(row["risk_money"]), "realized_pnl": float(row["realized_pnl"]),
            "unrealized_pnl": float(row["unrealized_pnl"]), "opened_at": str(row["opened_at"]),
            "closed_at": str(row["closed_at"]) if row.get("closed_at") else None, "updated_at": str(row["updated_at"]),
            "data_source": row["data_source"], "data_confidence": float(row["data_confidence"]),
        })
        volume = max(float(payload["actual_volume"]), 0.0)
        fraction = min(1.0, max(0.0, float(payload["remaining_volume"]) / volume)) if volume > 0 else 0.0
        payload["remaining_risk_percent"] = float(payload["risk_percent"]) * fraction
        payload["actual_risk_percent"] = float(payload["risk_percent"])
        payload["remaining_risk_money"] = float(payload["risk_money"]) * fraction
        return payload

    @staticmethod
    def _local_date(value: str, timezone: str) -> str:
        try:
            dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=UTC)
            return dt.astimezone(ZoneInfo(timezone)).date().isoformat()
        except Exception:
            return datetime.now(UTC).date().isoformat()
