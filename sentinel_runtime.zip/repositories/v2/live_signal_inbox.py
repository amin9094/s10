"""Private, durable signal folders and per-admin read receipts."""
from hashlib import sha256
import time
from core.storage.engine import normalized_engine
from repositories.v2.common import json_dump, json_load, content_hash
from modules.signal_execution import mode_of,MODES

MARKETS = {'gold':'طلا', 'forex':'فارکس', 'crypto':'کریپتو', 'indices':'شاخص‌ها'}
STRATEGIES = {'indicators':'اندیکاتورها', 'sweep_fvg':'سویپ و FVG',
              'order_block':'اوردر بلاک و POC', 'fibonacci_pullback':'فیبوناچی مستقل','custom':'استراتژی انتخابی'}


def market_for(symbol):
    if symbol == 'XAUUSD': return 'gold'
    if symbol.endswith('USDT'): return 'crypto'
    if symbol in {'US30','US100','NAS100'}: return 'indices'
    if len(symbol) == 6 and symbol.isascii(): return 'forex'
    return 'iran'


def page_cursor(value):
    if value is None:return 9223372036854775807,'~'
    parts=str(value).split(':')
    if len(parts)>2 or not parts[0].isdigit() or len(parts[0])>19:
        raise ValueError('SIGNAL_CURSOR_INVALID')
    if int(parts[0])>9223372036854775807:raise ValueError('SIGNAL_CURSOR_INVALID')
    return int(parts[0]),parts[1] if len(parts)==2 else '~'


from repositories.v2.signal_scope import global_inbox_scope  # compatibility export


class LiveSignalInbox:
    def __init__(self, engine=None):
        self.engine = engine or normalized_engine()

    def get(self, identifier):
        with self.engine.transaction(read_only=True) as c:
            r=c.execute('SELECT * FROM s9_signal_inbox WHERE id=?',(identifier,)).fetchone()
        return {**r,'payload':json_load(r['payload'])} if r else None

    def stage(self, source_id, kind, plan, digest, *, proposal=None, profile_id=None):
        from modules.automated_market_scope import require_global_symbol
        require_global_symbol(plan.get('symbol'))
        if kind not in {'native','review'} or plan.get('engine') not in STRATEGIES:
            raise ValueError('INBOX_SIGNAL_KIND_INVALID')
        if content_hash(plan) != digest: raise ValueError('INBOX_PLAN_CHANGED')
        identifier=sha256(json_dump([kind,source_id]).encode()).hexdigest()[:32]
        payload={'source_id':source_id,'kind':kind,'plan':plan,'plan_hash':digest,
                 'proposal':proposal,'profile_id':profile_id,'publications':{},'execution_mode':mode_of(plan)}
        from modules.signal_plan_policy import entry_eligibility
        payload['entry_policy']=entry_eligibility(plan)
        with self.engine.transaction() as c:
            c.execute('''INSERT INTO s9_signal_inbox(id,market,engine,state,created_ms,payload)
                         VALUES(?,?,?,'STAGING',?,?) ON CONFLICT(id) DO NOTHING''',
                      (identifier,market_for(plan['symbol']),plan['engine'],int(time.time()*1000),json_dump(payload)))
            from repositories.v2.signal_timeline import record
            record(c,identifier,'ANALYSIS_READY',int(plan.get('proposed_ms') or time.time()*1000),key='initial')
        return self.get(identifier)

    def items(self, *, market=None, engine=None, before=None, limit=40,execution_mode=None,
              symbol=None,timeframe=None,direction=None,publication_state=None,paper_state=None,unread=False,admin=None,sort=None):
        if sort not in {None,'newest','oldest','distance'}:raise ValueError('SIGNAL_SORT_INVALID')
        if execution_mode is not None and execution_mode not in MODES:raise ValueError('SIGNAL_EXECUTION_MODE_INVALID')
        if direction not in {None,'BUY','SELL'} or timeframe not in {None,'5m','1h'}:raise ValueError('SIGNAL_FILTER_INVALID')
        if publication_state not in {None,'PENDING','QUEUED','PUBLISHED','CANCELLED','EXPIRED','NEEDS_REVIEW'}:raise ValueError('SIGNAL_FILTER_INVALID')
        if paper_state not in {None,'WAITING','OPEN','CLOSED','NEEDS_REVIEW','CANCELLED','PAUSED','RESET_ARCHIVED','UNAVAILABLE'}:raise ValueError('SIGNAL_FILTER_INVALID')
        if symbol is not None:
            from modules.automated_market_scope import require_global_symbol
            require_global_symbol(symbol)
        if unread and admin is None:raise ValueError('SIGNAL_ADMIN_REQUIRED')
        if sort=='distance':
            from repositories.v2.signal_queue import SignalQueue
            filters=dict(market=market,engine=engine,execution_mode=execution_mode,symbol=symbol,timeframe=timeframe,
                         direction=direction,publication_state=publication_state,paper_state=paper_state,unread=unread)
            return self._decode_rows(SignalQueue(self.engine).page(admin,filters,before,limit))
        stamp,key=page_cursor(before)
        ascending=sort=='oldest'
        if ascending and before is None:stamp,key=-1,''
        def field(key):
            return f"CAST(i.payload AS JSONB)->'plan'->>'{key}'" if self.engine.dialect.name=='postgres' else f"json_extract(i.payload,'$.plan.{key}')"
        mode_expr="COALESCE(CAST(i.payload AS JSONB)->>'execution_mode','PENDING')" if self.engine.dialect.name=='postgres' else "COALESCE(json_extract(i.payload,'$.execution_mode'),'PENDING')"
        scope,params=global_inbox_scope(self.engine,'i.') if market!='iran' else ('i.market=?',('iran',))
        comparison='>' if ascending else '<'
        clauses=[scope,"i.state!='STAGING'",f"(i.created_ms{comparison}? OR (i.created_ms=? AND i.id{comparison}?))"]
        values=[*params,stamp,stamp,key]
        for expression,value in (('i.market',market),('i.engine',engine),(mode_expr,execution_mode),
            (field('symbol'),symbol),(field('timeframe'),timeframe),(field('direction'),direction),
            ('i.state',publication_state),("COALESCE(t.state,'UNAVAILABLE')",paper_state)):
            if value is not None:clauses.append(expression+'=?');values.append(value)
        if unread:clauses.extend(["i.state='PENDING'","r.signal_id IS NULL"])
        with self.engine.transaction(read_only=True) as c:
            order='ASC' if ascending else 'DESC'
            query="SELECT i.*,t.state AS paper_state,t.payload AS paper_payload,r.read_ms FROM s9_signal_inbox i LEFT JOIN s9_strategy_paper_trades t ON t.signal_id=i.id LEFT JOIN s9_signal_reads r ON r.signal_id=i.id AND r.admin_id=? WHERE "+' AND '.join(clauses)+f" ORDER BY i.created_ms {order},i.id {order} LIMIT ?"  # nosec B608 -- fixed enum direction and bound parameters
            rows=c.execute(query,(str(admin),*values,max(1,min(100,int(limit))))).fetchall()

        return self._decode_rows(rows)

    def _decode_rows(self,rows):
        result=[]
        for r in rows:
            p=json_load(r.get('paper_payload'),{});item={k:v for k,v in r.items() if k!='paper_payload'}
            item.update(payload=json_load(r['payload']),paper={'state':r['paper_state'] or 'UNAVAILABLE',
                **{k:p.get(k) for k in ('entered_ms','closed_ms','fill_price','realized_usd','unrealized_usd','remaining','reason','last_event_ms')}})
            from decimal import Decimal as D
            now=int(time.time()*1000);quote=p.get('last_quote') or {};plan=item['payload']['plan']
            item['age_ms']=max(0,now-r['created_ms']);item['distance_quote_ms']=quote.get('event_ms')
            from modules.desk_presentation import quote_status
            item['quote_status']=quote_status(quote,now)
            item['distance_r']=None
            if item['quote_status']['fresh']:
                risk=abs(D(plan['entry'])-D(plan['stop']))
                if risk>0:item['distance_r']=str(abs((D(quote['bid'])+D(quote['ask']))/2-D(plan['entry']))/risk)
            result.append(item)
        return result

    def folders(self, admin):
        scope,params=global_inbox_scope(self.engine,'i.')
        mode_expr="COALESCE(CAST(i.payload AS JSONB)->>'execution_mode','PENDING')" if self.engine.dialect.name=='postgres' else "COALESCE(json_extract(i.payload,'$.execution_mode'),'PENDING')"
        with self.engine.transaction(read_only=True) as c:
            rows=c.execute(f'''SELECT i.market,i.engine,{mode_expr} AS execution_mode,COUNT(*) AS total,
                SUM(CASE WHEN r.signal_id IS NULL AND i.state='PENDING' THEN 1 ELSE 0 END) AS unread
                FROM s9_signal_inbox i LEFT JOIN s9_signal_reads r ON r.signal_id=i.id AND r.admin_id=?
                WHERE {scope} AND i.state!='STAGING' GROUP BY i.market,i.engine,{mode_expr}''',(str(admin),*params)).fetchall()  # nosec B608 -- fixed internal scope; values use bound parameters
        counts={(r['market'],r['engine'],r['execution_mode']):r for r in rows}
        markets=[]
        for m,label in MARKETS.items():
            strategies=[]
            for e,l in STRATEGIES.items():
                modes=[{'id':mode,'label':label,'total':int(counts.get((m,e,mode),{}).get('total',0)),
                        'unread':int(counts.get((m,e,mode),{}).get('unread',0))} for mode,label in MODES.items()]
                strategies.append({'id':e,'label':l,'total':sum(x['total'] for x in modes),
                                   'unread':sum(x['unread'] for x in modes),'modes':modes})
            markets.append({'id':m,'label':label,'strategies':strategies,'unread':sum(s['unread'] for s in strategies)})
        return {'unread':sum(m['unread'] for m in markets),'markets':markets}

    def mark_read(self, identifiers, admin):
        now=int(time.time()*1000)
        with self.engine.transaction() as c:
            for key in identifiers:
                c.execute('''INSERT INTO s9_signal_reads(signal_id,admin_id,read_ms)
                    SELECT id,?,? FROM s9_signal_inbox WHERE id=?
                    ON CONFLICT(signal_id,admin_id) DO NOTHING''',(str(admin),now,key))
                if c.rowcount:
                    from repositories.v2.signal_timeline import record
                    record(c,key,'ADMIN_SEEN',now,{'actor':str(admin)},key=str(admin))

    def update(self, row, state, payload):
        with self.engine.transaction() as c:
            c.execute('UPDATE s9_signal_inbox SET state=?,payload=?,revision=revision+1 WHERE id=? AND revision=?',
                      (state,json_dump(payload),row['id'],row['revision']))
            if c.rowcount!=1: raise ValueError('INBOX_CONCURRENT_CHANGE')
            from repositories.v2.signal_timeline import record
            if state=='PENDING' and row['state']=='STAGING':
                record(c,row['id'],'AVAILABLE',int(time.time()*1000),key='initial')
            if state in {'QUEUED','CANCELLED','PUBLISHED'}:
                record(c,row['id'],'PUBLISHED' if state=='PUBLISHED' else 'REVIEW_DECISION',int(time.time()*1000),{'state':state},key=f"{state}:{row['revision']}")

    def terminate(self, identifier, state, reason):
        if state not in {'EXPIRED','CANCELLED','NEEDS_REVIEW'}: raise ValueError('INBOX_STATE_INVALID')
        with self.engine.atomic():
            row=self.get(identifier)
            if not row or row['state'] in {'CANCELLED','EXPIRED'}: return
            self.update(row,state,{**row['payload'],'status_reason':reason})
