"""Admin-only diagnostic cases, separate from executable locked setup plans."""

from __future__ import annotations

from hashlib import sha256

from core.storage.engine import normalized_engine
from repositories.v2.common import json_dump, json_load


class StrategyReviewRepository:
    def __init__(self, engine=None):
        self.engine = engine or normalized_engine()

    def store(self, rows):
        identifiers = []
        with self.engine.transaction() as cursor:
            for row in rows:
                if row.get("state") not in {"NEEDS_REVIEW","ANALYTICAL_OBSERVATION"} or not row.get("symbol"):
                    continue
                identity = [row.get(key) for key in ("engine", "symbol", "timeframe", "ob_source_id", "reason", "profile_id", "thesis_key")]
                key = sha256(json_dump(identity).encode()).hexdigest()[:32]
                cursor.execute("""INSERT INTO s9_strategy_reviews(id,engine,symbol,timeframe,state,created_ms,payload)
                               VALUES(?,?,?,?,?,?,?) ON CONFLICT(id) DO NOTHING""",
                               (key, row["engine"], row["symbol"], row["timeframe"], row['state'],
                                row["available_ms"], json_dump(row)))
                if cursor.rowcount:
                    identifiers.append(key)
        return identifiers

    def list(self, *, symbol=None, timeframe=None, engine=None, limit=100):
        with self.engine.transaction(read_only=True) as cursor:
            rows = cursor.execute("""SELECT * FROM s9_strategy_reviews WHERE (?='' OR symbol=?)
                                  AND (?='' OR timeframe=?) AND (?='' OR engine=?)
                                  ORDER BY created_ms DESC,id LIMIT ?""",
                                  (symbol or "", symbol or "", timeframe or "", timeframe or "",
                                   engine or "", engine or "", max(1, min(200, int(limit))))).fetchall()
        return [{**row, "payload": json_load(row["payload"])} for row in rows]

    def get(self, identifier):
        with self.engine.transaction(read_only=True) as cursor:
            row=cursor.execute('SELECT * FROM s9_strategy_reviews WHERE id=?',(identifier,)).fetchone()
        return {**row,'payload':json_load(row['payload'])} if row else None

    def mark_review_receipt(self,identifier,*,receipt_ms,verification):
        with self.engine.transaction() as cursor:
            row=cursor.execute('SELECT payload,state FROM s9_strategy_reviews WHERE id=?',(identifier,)).fetchone()
            if not row or row['state']!='NEEDS_REVIEW':raise ValueError('REVIEW_NOT_PENDING')
            p=json_load(row['payload'])
            if not p.get('draft_plan') or p.get('review_kind')!='PREENTRY_PROPOSAL':raise ValueError('REVIEW_NOT_PROPOSAL')
            p.setdefault('admin_delivery_ms',receipt_ms)
            p['admin_delivery_check']=verification
            cursor.execute('UPDATE s9_strategy_reviews SET payload=? WHERE id=? AND state=?',
                           (json_dump(p),identifier,'NEEDS_REVIEW'))

    def expire(self,identifier,reason):
        with self.engine.transaction() as cursor:
            row=cursor.execute('SELECT payload FROM s9_strategy_reviews WHERE id=?',(identifier,)).fetchone()
            if not row:return
            p=json_load(row['payload']);p['decision_reason']=reason
            cursor.execute("UPDATE s9_strategy_reviews SET state='EXPIRED',payload=? WHERE id=? AND state='NEEDS_REVIEW'",
                           (json_dump(p),identifier))

    def decide(self,identifier,*,actor,action,draft_hash,audience=None):
        from repositories.v2.strategy_live import StrategyLiveRepository
        from services.strategy_delivery_service import channel_target
        import time
        with self.engine.atomic():
            with self.engine.transaction() as cursor:
                row=cursor.execute('SELECT payload,state FROM s9_strategy_reviews WHERE id=?',(identifier,)).fetchone()
                if not row or row['state']!='NEEDS_REVIEW':raise ValueError('REVIEW_NOT_PENDING')
                p=json_load(row['payload'])
                if p.get('review_kind')!='PREENTRY_PROPOSAL' or p.get('draft_hash')!=draft_hash:
                    raise ValueError('REVIEW_PLAN_HASH_CHANGED')
                if action=='cancel':
                    p['decision']={'action':'CANCELLED','actor':str(actor),'decided_ms':int(time.time()*1000)}
                    cursor.execute("UPDATE s9_strategy_reviews SET state='CANCELLED',payload=? WHERE id=?",(json_dump(p),identifier))
                    return {'state':'CANCELLED'}
                if action!='publish' or audience not in {'telegram_public','telegram_private'}:
                    raise ValueError('REVIEW_DECISION_INVALID')
                if not p.get('admin_delivery_ms'):raise ValueError('REVIEW_ADMIN_RECEIPT_REQUIRED')
                p.setdefault('approvals',{})[audience]={'actor':str(actor),'draft_hash':draft_hash,'approved_ms':int(time.time()*1000)}
                cursor.execute('UPDATE s9_strategy_reviews SET payload=? WHERE id=?',(json_dump(p),identifier))
            target=channel_target(audience)
            key=StrategyLiveRepository(self.engine).enqueue(setup_id=identifier,version=1,event_id='ADMIN_REVIEW_SIGNAL',
                audience=audience,target_id=target,content_hash=draft_hash,actor=str(actor))
            return {'state':'QUEUED_NOT_SENT','delivery_id':key}

    def diagnostics(self, *, before=None, limit=30):
        from repositories.v2.live_signal_inbox import page_cursor
        from modules.automated_market_scope import global_symbol_sql
        scope,params=global_symbol_sql('symbol')
        stamp,key=page_cursor(before)
        with self.engine.transaction(read_only=True) as c:
            rows=c.execute(f"""SELECT * FROM s9_strategy_reviews WHERE {scope} AND state IN ('NEEDS_REVIEW','ANALYTICAL_OBSERVATION','RESCANNING')
                AND payload NOT LIKE '%PREENTRY_PROPOSAL%'
                AND (created_ms<? OR (created_ms=? AND id<?)) ORDER BY created_ms DESC,id DESC LIMIT ?""",  # nosec B608 -- fixed internal scope; values use bound parameters
                (*params,stamp,stamp,key,max(1,min(40,int(limit))))).fetchall()
        return [{**r,'payload':json_load(r['payload'])} for r in rows]

    def claim_diagnostic(self, identifier, *, expected_payload, actor, action, token):
        import time
        now=int(time.time()*1000)
        with self.engine.transaction() as c:
            row=c.execute('SELECT payload,state FROM s9_strategy_reviews WHERE id=?',(identifier,)).fetchone()
            if not row or row['payload']!=json_dump(expected_payload):raise ValueError('REVIEW_CASE_CHANGED')
            p=json_load(row['payload'])
            if p.get('review_kind')=='PREENTRY_PROPOSAL':raise ValueError('REVIEW_USE_SIGNAL_DESK')
            if row['state']=='RESCANNING' and now-p.get('review_processing',{}).get('started_ms',now)<120000:
                raise ValueError('REVIEW_ALREADY_PROCESSING')
            if row['state'] not in {'NEEDS_REVIEW','ANALYTICAL_OBSERVATION','RESCANNING'}:
                raise ValueError('REVIEW_NOT_PENDING')
            p['review_processing']={'token':token,'actor':str(actor),'action':action,'started_ms':now}
            c.execute("UPDATE s9_strategy_reviews SET state='RESCANNING',payload=? WHERE id=? AND state=? AND payload=?",
                (json_dump(p),identifier,row['state'],row['payload']))
            if c.rowcount!=1:raise ValueError('REVIEW_CASE_CHANGED')

    def finish_diagnostic(self, identifier, *, token, state, outcome):
        import time
        with self.engine.transaction() as c:
            row=c.execute('SELECT payload,state FROM s9_strategy_reviews WHERE id=?',(identifier,)).fetchone()
            if not row or row['state']!='RESCANNING':raise ValueError('REVIEW_CASE_CHANGED')
            p=json_load(row['payload']);processing=p.get('review_processing',{})
            if processing.get('token')!=token:raise ValueError('REVIEW_CASE_CHANGED')
            p.setdefault('review_decisions',[]).append({**processing,'finished_ms':int(time.time()*1000),'outcome':outcome})
            p.pop('review_processing',None)
            c.execute('UPDATE s9_strategy_reviews SET state=?,payload=? WHERE id=? AND payload=?',
                (state,json_dump(p),identifier,row['payload']))
            if c.rowcount!=1:raise ValueError('REVIEW_CASE_CHANGED')
