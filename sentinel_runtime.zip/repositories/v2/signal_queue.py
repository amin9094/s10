"""Global distance ranking, captured once for stable private pagination."""
import time
from uuid import uuid4
from repositories.v2.common import content_hash


class SignalQueue:
    def __init__(self,engine):self.engine=engine

    def page(self,admin,filters,before=None,limit=40):
        from repositories.v2.signal_scope import global_inbox_scope
        owner=str(admin);limit=max(1,min(100,int(limit)));now=int(time.time()*1000);digest=content_hash(filters)
        pg=self.engine.dialect.name=='postgres'
        def json_field(alias,*path):
            if pg:return 'CAST('+alias+" AS JSONB)"+''.join(("->>'" if i==len(path)-1 else "->'")+key+"'" for i,key in enumerate(path))
            return "json_extract("+alias+",'$."+'.'.join(path)+"')"
        def numeric(expr):return 'CAST('+expr+(' AS NUMERIC)' if pg else ' AS REAL)')
        plan=lambda key:json_field('i.payload','plan',key)
        quote=lambda key:json_field('t.payload','last_quote',key)
        mode="COALESCE("+json_field('i.payload','execution_mode')+",'PENDING')"
        scope,params=global_inbox_scope(self.engine,'i.')
        clauses=[scope,"i.state!='STAGING'"];values=list(params)
        for expression,key in [('i.market','market'),('i.engine','engine'),(mode,'execution_mode'),(plan('symbol'),'symbol'),
                               (plan('timeframe'),'timeframe'),(plan('direction'),'direction'),('i.state','publication_state'),
                               ("COALESCE(t.state,'UNAVAILABLE')",'paper_state')]:
            if filters.get(key) is not None:clauses.append(expression+'=?');values.append(filters[key])
        if filters.get('unread'):clauses.extend(["i.state='PENDING'","r.signal_id IS NULL"])
        joins=' FROM s9_signal_inbox i LEFT JOIN s9_strategy_paper_trades t ON t.signal_id=i.id LEFT JOIN s9_signal_reads r ON r.signal_id=i.id AND r.admin_id=? '
        with self.engine.transaction() as c:
            c.execute('DELETE FROM s9_desk_queue_views WHERE expires_ms<?',(now,))
            if before:
                parts=str(before).split(':')
                if len(parts)!=3 or parts[0]!='q' or len(parts[1])!=32 or not parts[2].isdigit() or len(parts[2])>12:raise ValueError('SIGNAL_QUEUE_CURSOR_INVALID')
                view,after=parts[1],int(parts[2])
                record=c.execute('SELECT * FROM s9_desk_queue_views WHERE id=?',(view,)).fetchone()
                if not record or record['admin_id']!=owner or record['filter_hash']!=digest or record['expires_ms']<now:
                    raise ValueError('SIGNAL_QUEUE_EXPIRED_REFRESH_REQUIRED')
            else:
                view=uuid4().hex;after=0
                c.execute('INSERT INTO s9_desk_queue_views VALUES(?,?,?,?,?)',(view,owner,digest,now,now+120000))
                fresh=' AND '.join(numeric(quote(key))+f' BETWEEN {now-5000} AND {now}' for key in ('event_ms','received_ms'))
                risk='ABS('+numeric(plan('entry'))+'-'+numeric(plan('stop'))+')'
                distance='CASE WHEN '+fresh+' THEN ABS(('+numeric(quote('bid'))+'+'+numeric(quote('ask'))+')/2-'+numeric(plan('entry'))+')/NULLIF('+risk+',0) END'
                allowed=json_field('i.payload','entry_policy','allowed')
                select="SELECT i.id,i.created_ms,i.state,"+distance+" AS distance_r,CASE WHEN i.state='PENDING' THEN 0 ELSE 1 END AS state_order,CASE WHEN r.signal_id IS NULL THEN 0 ELSE 1 END AS read_order,CASE WHEN CAST("+allowed+" AS TEXT) IN ('1','true') THEN 0 WHEN "+allowed+" IS NULL THEN 1 ELSE 2 END AS policy_order"+joins+'WHERE '+' AND '.join(clauses)  # nosec B608 -- internal JSON paths/order and bound filter values
                ordered="SELECT id,state,distance_r,ROW_NUMBER() OVER(ORDER BY state_order,policy_order,read_order,CASE WHEN distance_r IS NULL THEN 1 ELSE 0 END,distance_r,created_ms DESC,id DESC) AS ordinal FROM ("+select+") ranked"  # nosec B608 -- fixed window ordering over the bound subquery above
                c.execute('INSERT INTO s9_desk_queue_members(view_id,rank,signal_id,captured_state,distance_r) SELECT ?,ordinal,id,state,CAST(distance_r AS TEXT) FROM ('+ordered+') ordered',(view,owner,*values))  # nosec B608 -- fixed SQL fragments and bound filter values
                old=c.execute('SELECT id FROM s9_desk_queue_views WHERE admin_id=? AND id<>? ORDER BY created_ms DESC,id DESC LIMIT 100 OFFSET 9',(owner,view)).fetchall()
                for row in old:c.execute('DELETE FROM s9_desk_queue_views WHERE id=?',(row['id'],))
            rows=c.execute('''SELECT i.*,t.state AS paper_state,t.payload AS paper_payload,r.read_ms,
                m.rank AS queue_rank,m.distance_r AS distance_snapshot_r,m.captured_state
                FROM s9_desk_queue_members m JOIN s9_signal_inbox i ON i.id=m.signal_id
                LEFT JOIN s9_strategy_paper_trades t ON t.signal_id=i.id
                LEFT JOIN s9_signal_reads r ON r.signal_id=i.id AND r.admin_id=?
                WHERE m.view_id=? AND m.rank>? ORDER BY m.rank LIMIT ?''',(owner,view,after,max(1,min(100,int(limit)))+1)).fetchall()
            more=len(rows)>limit;rows=rows[:limit]
            for row in rows:
                row.update(queue_view_id=view,queue_captured_ms=record['created_ms'] if before else now,
                           queue_next_before=f"q:{view}:{rows[-1]['queue_rank']}" if more else None,
                           queue_state_changed=row['state']!=row['captured_state'])
            return rows
