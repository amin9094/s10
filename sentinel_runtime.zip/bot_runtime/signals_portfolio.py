"""Feature-owned Telegram handlers extracted from the v7 runtime: signals_portfolio."""

from bot_runtime import shared as _shared
globals().update({name: value for name, value in vars(_shared).items() if not name.startswith('__')})

def _market_category_menu(prefix: str, *, back_callback: str, title: str, db: dict[str, Any] | None = None, user_id: int | str | None = None) -> list[list[InlineKeyboardButton]]:
    language = _language_for_user(user_id) if user_id is not None else "fa"
    forex_count = crypto_count = 0
    if db is not None and user_id is not None:
        if prefix in {"u_signal_portal", "user_signal_stats"}:
            visible = user_visible_signals(db, vip=is_vip(db, user_id))
            forex_count = sum(1 for row in visible if signal_market_category(row) == MARKET_FOREX)
            crypto_count = sum(1 for row in visible if signal_market_category(row) == MARKET_CRYPTO)
        elif prefix == "user_watchlist":
            forex_count = len(watchlist_by_market(db, user_id, MARKET_FOREX))
            crypto_count = len(watchlist_by_market(db, user_id, MARKET_CRYPTO))
        elif prefix == "user_journal":
            forex_count = len(journal_entries_by_market(db, user_id, MARKET_FOREX, limit=5000))
            crypto_count = len(journal_entries_by_market(db, user_id, MARKET_CRYPTO, limit=5000))
    suffix = ":0" if prefix == "u_signal_portal" else ""
    return [
        [InlineKeyboardButton(f"💱 {'Forex' if language == 'en' else 'فارکس'} ({forex_count})", callback_data=f"{prefix}:forex{suffix}")],
        [InlineKeyboardButton(f"🪙 {'Crypto' if language == 'en' else 'کریپتو'} ({crypto_count})", callback_data=f"{prefix}:crypto{suffix}")],
        [InlineKeyboardButton("🔙 Back" if language == "en" else "🔙 بازگشت", callback_data=back_callback)],
    ]


def _localized_market_label(category: str, language: str) -> str:
    if language == "en":
        return "Crypto" if normalize_market_category(category) == MARKET_CRYPTO else "Forex"
    return market_label(category)


def _localized_signal_status(row: dict[str, Any], language: str) -> str:
    status = str(row.get("status") or "open").lower()
    if language != "en":
        return user_signal_status_text(row)
    labels = {
        "open": "Open",
        "entry_hit": "Entry triggered",
        "tp1": "TP1 hit",
        "tp2": "TP2 hit",
        "tp3": "TP3 hit",
        "breakeven": "Breakeven",
        "stop": "Stop loss",
        "loss": "Loss",
        "full_win": "Full win",
        "partial_win": "Partial win",
        "no_entry": "No entry",
        "cancelled": "Cancelled",
        "expired": "Expired",
        "manual_close": "Closed manually",
    }
    return labels.get(status, status.replace("_", " ").title())


def _user_signal_rows(db: dict[str, Any], user_id: int, category: str, page: int) -> tuple[str, list[list[InlineKeyboardButton]]]:
    category = normalize_market_category(category)
    language = _language_for_user(user_id)
    category_label = _localized_market_label(category, language)
    vip = is_vip(db, user_id)
    signals = user_visible_signals(db, vip=vip, market_category=category)
    cycle = current_signal_cycle(db)
    page_size = 8
    total_pages = max(1, (len(signals) + page_size - 1) // page_size)
    current = max(0, min(int(page), total_pages - 1))
    selected = signals[current * page_size : (current + 1) * page_size]
    lines = (
        [
            f"📡 <b>{category_label} signals</b>",
            f"Current cycle: <b>#{int(cycle.get('current_id', 1) or 1)}</b>",
            f"Access: <b>{'Public + VIP' if vip else 'Public channel'}</b>",
            "",
        ]
        if language == "en"
        else [
            f"📡 <b>سیگنال‌های {category_label}</b>",
            f"دوره فعلی: <b>#{int(cycle.get('current_id', 1) or 1)}</b>",
            f"دسترسی: <b>{'عمومی + VIP' if vip else 'کانال عمومی'}</b>",
            "",
        ]
    )
    rows: list[list[InlineKeyboardButton]] = []
    if not selected:
        lines.append(
            f"No {category_label.lower()} signals have been published yet."
            if language == "en"
            else f"در بخش {category_label} هنوز سیگنالی منتشر نشده است."
        )
    for row in selected:
        signal_id = int(row.get("id", 0) or 0)
        number = signal_display_number(row)
        choice = get_user_signal_choice(db, user_id, signal_id)
        choice_icon = "✅" if choice and choice.get("choice") == "taken" else "🚫" if choice and choice.get("choice") == "skipped" else "▫️"
        status = _localized_signal_status(row, language)
        lines.append(f"{choice_icon} <b>#{number}</b> | {esc(row.get('symbol'))} | {esc(status)}")
        rows.append([InlineKeyboardButton(f"#{number} | {str(row.get('symbol') or '-')} | {status}"[:62], callback_data=f"user_signal_view:{signal_id}")])
    nav: list[InlineKeyboardButton] = []
    if current > 0:
        nav.append(InlineKeyboardButton("◀️ Previous" if language == "en" else "◀️ قبلی", callback_data=f"u_signal_portal:{category}:{current - 1}"))
    if current < total_pages - 1:
        nav.append(InlineKeyboardButton("Next ▶️" if language == "en" else "بعدی ▶️", callback_data=f"u_signal_portal:{category}:{current + 1}"))
    if nav:
        rows.append(nav)
    rows.extend(
        [
            [InlineKeyboardButton("📊 Performance" if language == "en" else "📊 برآیند", callback_data=f"user_signal_stats:{category}"), InlineKeyboardButton("🔄 Refresh" if language == "en" else "🔄 بروزرسانی", callback_data=f"u_signal_portal:{category}:{current}")],
            [InlineKeyboardButton("⭐ Watchlist" if language == "en" else "⭐ واچ‌لیست", callback_data=f"user_watchlist:{category}"), InlineKeyboardButton("📔 Journal" if language == "en" else "📔 ژورنال", callback_data=f"user_journal:{category}")],
            [InlineKeyboardButton("🔀 Change market" if language == "en" else "🔀 تغییر بازار", callback_data="u_signal_portal"), InlineKeyboardButton("🔙 Trading center" if language == "en" else "🔙 مرکز معامله‌گری", callback_data="nav_user:trade")],
        ]
    )
    lines.extend(["", f"Page <b>{current + 1}</b> of <b>{total_pages}</b>" if language == "en" else f"صفحه <b>{current + 1}</b> از <b>{total_pages}</b>"])
    return "\n".join(lines), rows


async def user_signal_portal(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    db = await async_snapshot()
    parts = str(query.data or "").split(":")
    if len(parts) < 3:
        language = (await run_blocking(_language_for_user, query.from_user.id))
        await edit(
            query,
            (
                "📡 <b>My signals</b>\nChoose a market. Numbering and performance are tracked separately."
                if language == "en"
                else "📡 <b>سیگنال‌های من</b>\nبازار را انتخاب کنید؛ شماره‌گذاری و آمار هر بازار مستقل است:"
            ),
            (await run_blocking(_market_category_menu, "u_signal_portal", back_callback="nav_user:trade", title="سیگنال‌ها", db=db, user_id=query.from_user.id)),
        )
        return
    category = normalize_market_category(parts[1])
    try:
        page = int(parts[2])
    except ValueError:
        page = 0
    text_value, rows = (await run_blocking(_user_signal_rows, db, query.from_user.id, category, page))
    await edit(query, text_value, rows)


def _find_user_visible_signal(db: dict[str, Any], user_id: int, signal_id: int) -> dict[str, Any] | None:
    vip = is_vip(db, user_id)
    return next((row for row in user_visible_signals(db, vip=vip) if int(row.get("id", 0) or 0) == signal_id), None)


def _user_signal_detail_text(db: dict[str, Any], user_id: int, row: dict[str, Any]) -> str:
    language = _language_for_user(user_id)
    signal_id = int(row.get("id", 0) or 0)
    choice = get_user_signal_choice(db, user_id, signal_id)
    choice_text = (
        ("✅ Taken" if choice and choice.get("choice") == "taken" else "🚫 Skipped" if choice and choice.get("choice") == "skipped" else "Not selected")
        if language == "en"
        else ("✅ سیگنال گرفتم" if choice and choice.get("choice") == "taken" else "🚫 سیگنال نگرفتم" if choice and choice.get("choice") == "skipped" else "هنوز انتخاب نکرده‌اید")
    )
    targets = "\n".join(f"{'✅' if index <= int(row.get('highest_target_hit', 0) or 0) else '🎯'} TP{index}: <code>{esc(value)}</code>" for index, value in enumerate(row.get("targets", []), start=1))
    history = [item for item in row.get("lifecycle_history", []) if isinstance(item, dict)]
    updates = [f"• {esc(signal_status_label(str(item.get('event') or item.get('to') or 'open')))} — {display_dt(item.get('at'))}" for item in history[-5:]]
    category = signal_market_category(row)
    lines = (
        [
            f"📡 <b>{_localized_market_label(category, language)} signal #{signal_display_number(row)}</b>",
            f"Symbol: <b>{esc(row.get('symbol'))}</b>",
            f"Side: <b>{esc(str(row.get('side') or '').upper())}</b>",
            f"📍 Entries: <code>{esc(', '.join(str(item) for item in (row.get('entries') or [row.get('entry')])))}</code>",
            f"📐 Average entry: <code>{esc(row.get('entry'))}</code>",
            targets,
            f"🛑 Stop loss: <code>{esc(row.get('stop'))}</code>",
            f"📌 Status: <b>{esc(_localized_signal_status(row, language))}</b>",
            f"👤 Your choice: <b>{choice_text}</b>",
        ]
        if language == "en"
        else [
            f"📡 <b>سیگنال {market_label(category)} #{signal_display_number(row)}</b>",
            f"نماد: <b>{esc(row.get('symbol'))}</b>",
            f"نوع: <b>{esc(str(row.get('side') or '').upper())}</b>",
            f"📍 ورودها: <code>{esc('، '.join(str(item) for item in (row.get('entries') or [row.get('entry')])))}</code>",
            f"📐 میانگین ورود: <code>{esc(row.get('entry'))}</code>",
            targets,
            f"🛑 حد ضرر: <code>{esc(row.get('stop'))}</code>",
            f"📌 وضعیت فعلی: <b>{esc(user_signal_status_text(row))}</b>",
            f"👤 انتخاب شما: <b>{choice_text}</b>",
        ]
    )
    execution = row.get("execution", {}) if isinstance(row.get("execution"), dict) else {}
    if execution:
        lines.append(
            f"📦 {'Entry fill' if language == 'en' else 'میزان پرشدن ورودها'}: <b>{float(execution.get('filled_percent', 0) or 0):.0f}%</b>"
        )
        lines.append(
            f"✂️ {'Closed volume' if language == 'en' else 'حجم بسته‌شده'}: <b>{float(execution.get('closed_percent', 0) or 0):.0f}%</b>"
        )
    if row.get("profit_percent") is not None:
        lines.append(f"📈 {'Recorded result' if language == 'en' else 'برآیند ثبت‌شده'}: <b>{float(row.get('profit_percent', 0) or 0):+.2f}%</b>")
    if updates:
        lines.extend(["", "<b>Latest updates:</b>" if language == "en" else "<b>آخرین بروزرسانی‌ها:</b>", *updates])
    return "\n".join(lines)


def _user_signal_detail_rows(db: dict[str, Any], user_id: int | str, row: dict[str, Any]) -> list[list[InlineKeyboardButton]]:
    language = _language_for_user(user_id)
    signal_id = int(row.get("id", 0) or 0)
    symbol = normalize_market_symbol(str(row.get("symbol") or ""))
    category = signal_market_category(row)
    is_watched = any(item.get("symbol") == symbol for item in watchlist_for_user(db, user_id))
    return [
        [InlineKeyboardButton("✅ Taken" if language == "en" else "✅ سیگنال گرفتم", callback_data=f"user_signal_choice:{signal_id}:taken"), InlineKeyboardButton("🚫 Skipped" if language == "en" else "🚫 سیگنال نگرفتم", callback_data=f"user_signal_choice:{signal_id}:skipped")],
        [InlineKeyboardButton(("⭐ Remove from watchlist" if is_watched else "⭐ Add to watchlist") if language == "en" else ("⭐ حذف از واچ‌لیست" if is_watched else "⭐ افزودن به واچ‌لیست"), callback_data=f"watchlist_toggle:{symbol}"), InlineKeyboardButton("📔 Add to journal" if language == "en" else "📔 ثبت در ژورنال", callback_data=f"journal_signal:{signal_id}")],
        [InlineKeyboardButton("🧮 Risk calculator" if language == "en" else "🧮 محاسبه ریسک", callback_data=f"signal_calc:{signal_id}"), InlineKeyboardButton("🔔 Price alert" if language == "en" else "🔔 هشدار قیمت", callback_data=f"signal_alert:{signal_id}")],
        [InlineKeyboardButton("📊 Performance" if language == "en" else "📊 برآیند", callback_data=f"user_signal_stats:{category}"), InlineKeyboardButton("🔄 Refresh" if language == "en" else "🔄 بروزرسانی", callback_data=f"user_signal_view:{signal_id}")],
        [InlineKeyboardButton("⭐ Watchlist" if language == "en" else "⭐ واچ‌لیست", callback_data=f"user_watchlist:{category}"), InlineKeyboardButton("🔙 List" if language == "en" else "🔙 فهرست", callback_data=f"u_signal_portal:{category}:0")],
        [InlineKeyboardButton("↩️ Trading center" if language == "en" else "↩️ مرکز معامله‌گری", callback_data="nav_user:trade"), InlineKeyboardButton("🏠 Home" if language == "en" else "🏠 خانه", callback_data="home")],
    ]


async def user_signal_view(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    signal_id = int(query.data.split(":", 1)[1])
    db = await async_snapshot()
    row = _find_user_visible_signal(db, query.from_user.id, signal_id)
    if not row:
        language = (await run_blocking(_language_for_user, query.from_user.id))
        await edit(
            query,
            "❌ This signal is not available in the current cycle or your access tier."
            if language == "en"
            else "❌ این سیگنال در دوره فعلی یا سطح دسترسی شما موجود نیست.",
            [[InlineKeyboardButton("🔙 Markets" if language == "en" else "🔙 فهرست بازارها", callback_data="u_signal_portal")]],
        )
        return
    await edit(query, (await run_blocking(_user_signal_detail_text, db, query.from_user.id, row)), (await run_blocking(_user_signal_detail_rows, db, query.from_user.id, row)))


async def user_signal_choice_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    _, signal_id_text, choice = query.data.split(":", 2)
    signal_id = int(signal_id_text)
    db = await async_snapshot()
    row = _find_user_visible_signal(db, query.from_user.id, signal_id)
    if not row:
        await query.answer("Signal unavailable." if (await run_blocking(_language_for_user, query.from_user.id)) == "en" else "سیگنال در دسترس نیست.", show_alert=True)
        return
    await async_with_db(lambda current: set_user_signal_choice(current, query.from_user.id, signal_id, choice))
    await async_with_db(lambda current: record_user_activity(current, query.from_user.id, "signal_taken" if choice == "taken" else "signal_skipped", source="signal_portal", detail=f"#{signal_display_number(row)} {row.get('symbol')}", metadata={"signal_id": signal_id, "market_category": signal_market_category(row), "choice": choice}))
    if choice == "taken":
        try:
            if bool(control_module_state((await async_snapshot()), "journal").get("auto_from_signal", True)):
                await async_with_db(lambda current: ensure_signal_journal_entry(current, query.from_user.id, row))
        except ValueError:
            logger.info("Automatic journal entry skipped for user %s", query.from_user.id)
    await query.answer("Your choice was saved ✅" if (await run_blocking(_language_for_user, query.from_user.id)) == "en" else "انتخاب شما ثبت شد ✅", show_alert=True)
    refreshed = await async_snapshot()
    current_row = _find_user_visible_signal(refreshed, query.from_user.id, signal_id) or row
    await edit(query, (await run_blocking(_user_signal_detail_text, refreshed, query.from_user.id, current_row)), (await run_blocking(_user_signal_detail_rows, refreshed, query.from_user.id, current_row)))


async def user_signal_stats(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    db = await async_snapshot()
    parts = str(query.data or "").split(":")
    language = (await run_blocking(_language_for_user, query.from_user.id))
    if len(parts) < 2:
        await edit(
            query,
            "📊 <b>Signal performance</b>\nChoose a market:"
            if language == "en"
            else "📊 <b>برآیند سیگنال‌ها</b>\nبازار را انتخاب کنید:",
            (await run_blocking(_market_category_menu, "user_signal_stats", back_callback="u_signal_portal", title="آمار", db=db, user_id=query.from_user.id)),
        )
        return
    category = normalize_market_category(parts[1])
    stats = signal_portal_stats(db, query.from_user.id, vip=is_vip(db, query.from_user.id), market_category=category)
    text_value = (
        (
            f"📊 <b>{_localized_market_label(category, language)} performance — cycle #{stats['cycle_id']}</b>\n\n"
            f"Total: <b>{stats['total']}</b> | ⏳ Open: <b>{stats['open']}</b>\n"
            f"🏆 Full win: <b>{stats['full_win']}</b> | ✅ Partial win: <b>{stats['partial_win']}</b>\n"
            f"🟦 Breakeven: <b>{stats['breakeven']}</b> | 🛑 Loss: <b>{stats['loss']}</b>\n"
            f"🚫 No entry: <b>{stats['no_entry']}</b> | ❌ Cancelled: <b>{stats['cancelled']}</b>\n\n"
            f"👤 Taken: <b>{stats['taken']}</b> | Skipped: <b>{stats['skipped']}</b>"
        )
        if language == "en"
        else (
            f"📊 <b>برآیند سیگنال‌های {market_label(category)} — دوره #{stats['cycle_id']}</b>\n\n"
            f"کل: <b>{stats['total']}</b> | ⏳ باز: <b>{stats['open']}</b>\n"
            f"🏆 برد کامل: <b>{stats['full_win']}</b> | ✅ برد جزئی: <b>{stats['partial_win']}</b>\n"
            f"🟦 ریسک‌فری: <b>{stats['breakeven']}</b> | 🛑 زیان: <b>{stats['loss']}</b>\n"
            f"🚫 بدون ورود: <b>{stats['no_entry']}</b> | ❌ لغوشده: <b>{stats['cancelled']}</b>\n\n"
            f"👤 گرفته‌اید: <b>{stats['taken']}</b> | نگرفته‌اید: <b>{stats['skipped']}</b>"
        )
    )
    await edit(query, text_value, [[InlineKeyboardButton("🔄 Refresh" if language == "en" else "🔄 بروزرسانی", callback_data=f"user_signal_stats:{category}"), InlineKeyboardButton("🔙 Signals" if language == "en" else "🔙 سیگنال‌ها", callback_data=f"u_signal_portal:{category}:0")], [InlineKeyboardButton("🔀 Change market" if language == "en" else "🔀 تغییر بازار", callback_data="user_signal_stats"), InlineKeyboardButton("🏠 Home" if language == "en" else "🏠 خانه", callback_data="home")]])


def _journal_entry_line(row: dict[str, Any], language: str = "fa") -> str:
    pnl = row.get("pnl_percent")
    result_r = row.get("result_r")
    pnl_text = ("Open" if language == "en" else "باز") if pnl is None else f"{float(pnl):+.2f}%"
    r_text = "" if result_r is None else f" · <b>{float(result_r):+.2f}R</b>"
    return f"#{int(row.get('id', 0) or 0)} | {esc(row.get('symbol') or '-')} | {esc(row.get('side') or '-')} | <b>{pnl_text}</b>{r_text}"


async def _watchlist_price_map(rows_data: list[dict[str, Any]]) -> dict[str, float | None]:
    symbols = [str(item.get("symbol") or "") for item in rows_data[:12]]
    if not symbols:
        return {}
    results = await asyncio.gather(*(fetch_price(symbol) for symbol in symbols), return_exceptions=True)
    return {symbol: None if isinstance(result, Exception) else float(result) for symbol, result in zip(symbols, results, strict=True)}


def _watchlist_suggestion_rows(db: dict[str, Any], user_id: int | str, category: str) -> list[list[InlineKeyboardButton]]:
    watched = {str(item.get("symbol") or "") for item in watchlist_for_user(db, user_id)}
    suggestions: list[str] = []
    for row in user_visible_signals(db, vip=is_vip(db, user_id), market_category=category):
        symbol = normalize_market_symbol(str(row.get("symbol") or ""))
        if symbol and symbol not in watched and symbol not in suggestions:
            suggestions.append(symbol)
        if len(suggestions) >= 4:
            break
    rows: list[list[InlineKeyboardButton]] = []
    for i in range(0, len(suggestions), 2):
        rows.append([InlineKeyboardButton(f"➕ {symbol}", callback_data=f"watchlist_toggle:{symbol}") for symbol in suggestions[i:i+2]])
    return rows


async def _render_user_watchlist(query: Any, category: str) -> None:
    category = normalize_market_category(category)
    language = (await run_blocking(_language_for_user, query.from_user.id))
    category_label = _localized_market_label(category, language)
    db = await async_snapshot()
    rows_data = watchlist_by_market(db, query.from_user.id, category)
    price_map = await _watchlist_price_map(rows_data)
    lines = (
        [f"⭐ <b>{category_label} watchlist</b>", "", f"Symbols: <b>{len(rows_data)}</b>"]
        if language == "en"
        else [f"⭐ <b>واچ‌لیست {category_label}</b>", "", f"تعداد نمادها: <b>{len(rows_data)}</b>"]
    )
    if rows_data:
        alerts_on = sum(1 for item in rows_data if item.get("alerts_enabled", True))
        lines.extend([
            (
                f"Alerts on: <b>{alerts_on}</b> | off: <b>{len(rows_data) - alerts_on}</b>"
                if language == "en"
                else f"اعلان فعال: <b>{alerts_on}</b> | خاموش: <b>{len(rows_data) - alerts_on}</b>"
            ),
            "",
        ])
    rows: list[list[InlineKeyboardButton]] = []
    for item in rows_data:
        symbol = str(item.get("symbol") or "")
        alerts_enabled = bool(item.get("alerts_enabled", True))
        price = price_map.get(symbol)
        price_text = (
            f" | {'Price' if language == 'en' else 'قیمت'}: <code>{price:,.8g}</code>"
            if isinstance(price, float)
            else (" | Price: <i>unavailable</i>" if language == "en" else " | قیمت: <i>در دسترس نیست</i>")
        )
        lines.append(
            f"• <b>{esc(symbol)}</b> | {'Alert' if language == 'en' else 'اعلان'}: "
            f"<b>{('on' if alerts_enabled else 'off') if language == 'en' else ('روشن' if alerts_enabled else 'خاموش')}</b>{price_text}"
        )
        rows.append([InlineKeyboardButton(("🔔 Turn off" if alerts_enabled else "🔕 Turn on") if language == "en" else ("🔔 خاموش" if alerts_enabled else "🔕 روشن"), callback_data=f"watchlist_alert:{symbol}"), InlineKeyboardButton(f"🗑 {'Remove' if language == 'en' else 'حذف'} {symbol}", callback_data=f"watchlist_toggle:{symbol}")])
    if not rows_data:
        lines.extend(
            ["No symbols in this market yet.", "Add one from a signal or use a suggestion below."]
            if language == "en"
            else ["هنوز نمادی در این دسته ندارید.", "از صفحه سیگنال یا پیشنهادهای زیر می‌توانید نماد اضافه کنید."]
        )
    suggestion_rows = _watchlist_suggestion_rows(db, query.from_user.id, category)
    if suggestion_rows:
        lines.extend(["", "<b>Quick suggestions:</b>" if language == "en" else "<b>پیشنهاد سریع:</b>"])
        rows.extend(suggestion_rows)
    if rows_data:
        rows.append([InlineKeyboardButton("🧹 Clear market" if language == "en" else "🧹 پاک‌کردن این دسته", callback_data=f"watchlist_clear:{category}"), InlineKeyboardButton("🔄 Refresh" if language == "en" else "🔄 بروزرسانی", callback_data=f"user_watchlist:{category}")])
    else:
        rows.append([InlineKeyboardButton("🔄 Refresh" if language == "en" else "🔄 بروزرسانی", callback_data=f"user_watchlist:{category}")])
    rows.extend([[InlineKeyboardButton("📔 Journal" if language == "en" else "📔 ژورنال", callback_data=f"user_journal:{category}"), InlineKeyboardButton("📡 Signals" if language == "en" else "📡 سیگنال‌ها", callback_data=f"u_signal_portal:{category}:0")], [InlineKeyboardButton("🔀 Change market" if language == "en" else "🔀 تغییر بازار", callback_data="user_watchlist"), InlineKeyboardButton("🔙 Trading center" if language == "en" else "🔙 مرکز معامله‌گری", callback_data="nav_user:trade")]])
    await edit(query, "\n".join(lines)[:3900], rows)


async def user_watchlist(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    db = await async_snapshot()
    parts = str(query.data or "").split(":")
    if len(parts) < 2:
        await edit(
            query,
            "⭐ <b>My watchlist</b>\nChoose a market:"
            if (await run_blocking(_language_for_user, query.from_user.id)) == "en"
            else "⭐ <b>واچ‌لیست من</b>\nبازار را انتخاب کنید:",
            (await run_blocking(_market_category_menu, "user_watchlist", back_callback="nav_user:trade", title="واچ‌لیست", db=db, user_id=query.from_user.id)),
        )
        return
    await _render_user_watchlist(query, parts[1])


async def watchlist_toggle_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    symbol = str(query.data or "").split(":", 1)[1]
    try:
        added, _ = await async_with_db(lambda db: toggle_watchlist_symbol(db, query.from_user.id, symbol))
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    language = (await run_blocking(_language_for_user, query.from_user.id))
    await query.answer(
        ("Added to watchlist ⭐" if added else "Removed from watchlist")
        if language == "en"
        else ("به واچ‌لیست اضافه شد ⭐" if added else "از واچ‌لیست حذف شد")
    )
    await _render_user_watchlist(query, classify_market_symbol(symbol))


async def watchlist_alert_toggle_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    symbol = str(query.data or "").split(":", 1)[1]
    db = await async_snapshot()
    language = (await run_blocking(_language_for_user, query.from_user.id))
    item = next((row for row in watchlist_for_user(db, query.from_user.id) if str(row.get("symbol") or "") == normalize_market_symbol(symbol)), None)
    if not item:
        await query.answer("Symbol is not in your watchlist" if language == "en" else "نماد در واچ‌لیست نیست", show_alert=True)
        return
    updated = await async_with_db(lambda current: set_watchlist_alerts(current, query.from_user.id, symbol, not bool(item.get("alerts_enabled", True))))
    await query.answer(
        ("Symbol alerts enabled" if updated.get("alerts_enabled") else "Symbol alerts disabled")
        if language == "en"
        else ("اعلان این نماد روشن شد" if updated.get("alerts_enabled") else "اعلان این نماد خاموش شد")
    )
    await _render_user_watchlist(query, classify_market_symbol(symbol))


async def watchlist_clear_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    parts = str(query.data or "").split(":")
    category = normalize_market_category(parts[1] if len(parts) > 1 else MARKET_FOREX)
    count = await async_with_db(lambda db: clear_watchlist_market(db, query.from_user.id, category))
    await query.answer(
        f"{count} symbols removed"
        if (await run_blocking(_language_for_user, query.from_user.id)) == "en"
        else f"{count} نماد حذف شد",
        show_alert=True,
    )
    await _render_user_watchlist(query, category)


async def journal_signal_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    signal_id = int(str(query.data or "").split(":", 1)[1])
    db = await async_snapshot()
    row = _find_user_visible_signal(db, query.from_user.id, signal_id)
    if not row:
        await query.answer("سیگنال در دسترس نیست", show_alert=True)
        return
    try:
        entry = await async_with_db(lambda current: ensure_signal_journal_entry(current, query.from_user.id, row))
        from services.unified_journal_service import sync_legacy_journal_to_normalized
        await run_blocking(sync_legacy_journal_to_normalized, query.from_user.id, limit=5000)
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    language = (await run_blocking(_language_for_user, query.from_user.id))
    await query.answer(
        (
            f"Saved to {_localized_market_label(signal_market_category(row), language)} journal · record #{entry['id']}"
            if language == "en"
            else f"در ژورنال {market_label(signal_market_category(row))} ثبت شد؛ رکورد #{entry['id']}"
        ),
        show_alert=True,
    )
    refreshed = await async_snapshot()
    current_row = _find_user_visible_signal(refreshed, query.from_user.id, signal_id) or row
    await edit(query, (await run_blocking(_user_signal_detail_text, refreshed, query.from_user.id, current_row)), (await run_blocking(_user_signal_detail_rows, refreshed, query.from_user.id, current_row)))


def _render_user_journal_screen(db: dict[str, Any], user_id: int | str, category: str) -> tuple[str, list[list[InlineKeyboardButton]]]:
    category = normalize_market_category(category)
    language = _language_for_user(user_id)
    category_label = _localized_market_label(category, language)
    entries = journal_entries_by_market(db, user_id, category, limit=30)
    stats = journal_stats_by_market(db, user_id, category)
    lines = (
        [
            f"📔 <b>{category_label} journal</b>",
            "",
            f"Total: <b>{stats['total']}</b> | Open: <b>{stats['open']}</b> | Closed: <b>{stats['closed']}</b>",
            f"Wins: <b>{stats['wins']}</b> | Losses: <b>{stats['losses']}</b> | Win rate: <b>{stats['win_rate']:.1f}%</b>",
            f"Net R: <b>{stats['r_net']:+.2f}R</b> | Won: <b>+{stats['r_won']:.2f}R</b> | Lost: <b>-{stats['r_lost']:.2f}R</b>",
            f"Total P/L: <b>{stats['pnl_sum']:+.2f}%</b> | Equity index: <b>{stats['equity_index']:.2f}</b>",
            f"Max drawdown: <b>{stats['max_drawdown']:.2f}%</b> | Channel: <b>{stats['channel_signal_entries']}</b> | Personal: <b>{stats['personal_entries']}</b>",
            "",
        ]
        if language == "en"
        else [
            f"📔 <b>ژورنال {category_label}</b>",
            "",
            f"کل: <b>{stats['total']}</b> | باز: <b>{stats['open']}</b> | بسته: <b>{stats['closed']}</b>",
            f"برد: <b>{stats['wins']}</b> | باخت: <b>{stats['losses']}</b> | نرخ برد: <b>{stats['win_rate']:.1f}٪</b>",
            f"خالص عملکرد: <b>{stats['r_net']:+.2f}R</b> | سود: <b>+{stats['r_won']:.2f}R</b> | زیان: <b>-{stats['r_lost']:.2f}R</b>",
            f"مجموع P/L: <b>{stats['pnl_sum']:+.2f}٪</b> | شاخص سرمایه: <b>{stats['equity_index']:.2f}</b>",
            f"افت بیشینه: <b>{stats['max_drawdown']:.2f}٪</b> | سیگنال کانال: <b>{stats['channel_signal_entries']}</b> | شخصی: <b>{stats['personal_entries']}</b>",
            "",
        ]
    )
    rows: list[list[InlineKeyboardButton]] = []
    for item in entries:
        status = (
            ("Open" if item.get("status") == "open" else "Closed" if item.get("status") == "closed" else "Cancelled")
            if language == "en"
            else ("باز" if item.get("status") == "open" else "بسته" if item.get("status") == "closed" else "لغو")
        )
        lines.append("• " + _journal_entry_line(item, language) + f" | {'Status' if language == 'en' else 'وضعیت'}: <b>{status}</b>")
        reason = str(item.get("entry_reason") or "").strip()
        if reason:
            reason_label = "Channel signal" if item.get("entry_reason_type") == "channel_signal" else ("Personal/other" if language == "en" else "تحلیل شخصی/سایر")
            if language != "en" and item.get("entry_reason_type") == "channel_signal":
                reason_label = "سیگنال کانال"
            lines.append(f"  ├ {'Entry reason' if language == 'en' else 'دلیل ورود'} ({reason_label}): <i>{esc(reason[:160])}</i>")
        if item.get("note"):
            lines.append(f"  └ {'Note' if language == 'en' else 'یادداشت'}: <i>{esc(str(item.get('note'))[:120])}</i>")
        buttons: list[InlineKeyboardButton] = []
        if item.get("status") == "open":
            buttons.append(InlineKeyboardButton(f"📈 {'Record result' if language == 'en' else 'ثبت نتیجه'} #{item['id']}", callback_data=f"journal_result:{item['id']}"))
        buttons.append(InlineKeyboardButton("🗑 Delete" if language == "en" else "🗑 حذف", callback_data=f"journal_delete:{item['id']}"))
        rows.append(buttons)
    if not entries:
        lines.append(
            "No records in this market. Choose “Taken” on a signal or add a trade manually."
            if language == "en"
            else "رکوردی در این دسته ندارید. با انتخاب «سیگنال گرفتم» یا ثبت در ژورنال، معامله اضافه می‌شود."
        )
    rows.insert(0, [InlineKeyboardButton("➕ Add personal trade" if language == "en" else "➕ ثبت معامله شخصی", callback_data=f"journal_new:{category}", style="success")])
    if bool(control_module_state(db, "journal").get("export", True)) and entries:
        rows.append([InlineKeyboardButton("📦 Export CSV" if language == "en" else "📦 خروجی CSV", callback_data=f"journal_export:{category}"), InlineKeyboardButton("🔄 Refresh" if language == "en" else "🔄 بروزرسانی", callback_data=f"user_journal:{category}")])
    else:
        rows.append([InlineKeyboardButton("🔄 Refresh" if language == "en" else "🔄 بروزرسانی", callback_data=f"user_journal:{category}")])
    rows.extend([[InlineKeyboardButton("⭐ Watchlist" if language == "en" else "⭐ واچ‌لیست", callback_data=f"user_watchlist:{category}"), InlineKeyboardButton("📡 Signals" if language == "en" else "📡 سیگنال‌ها", callback_data=f"u_signal_portal:{category}:0")], [InlineKeyboardButton("🔀 Change market" if language == "en" else "🔀 تغییر بازار", callback_data="user_journal"), InlineKeyboardButton("🔙 Trading center" if language == "en" else "🔙 مرکز معامله‌گری", callback_data="nav_user:trade")]])
    return "\n".join(lines)[:3900], rows


async def user_journal(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    db = await async_snapshot()
    parts = str(query.data or "").split(":")
    if len(parts) < 2:
        await edit(
            query,
            "📔 <b>My trading journal</b>\nChoose a market:"
            if (await run_blocking(_language_for_user, query.from_user.id)) == "en"
            else "📔 <b>ژورنال معاملاتی من</b>\nبازار را انتخاب کنید:",
            (await run_blocking(_market_category_menu, "user_journal", back_callback="nav_user:trade", title="ژورنال", db=db, user_id=query.from_user.id)),
        )
        return
    category = normalize_market_category(parts[1])
    text_value, rows = (await run_blocking(_render_user_journal_screen, db, query.from_user.id, category))
    await edit(query, text_value, rows)


async def user_trading_coach(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    language = (await run_blocking(_language_for_user, query.from_user.id))
    from modules.trading_coach import trading_coach_snapshot
    report = trading_coach_snapshot(await async_snapshot(), query.from_user.id)
    stats = report.get("stats") or {}
    if language == "en":
        lines = [
            "🧭 <b>Trading Coach</b>", "",
            f"Closed trades: <b>{int(report.get('sample_size', 0) or 0)}</b>",
            f"Win rate: <b>{float(stats.get('win_rate', 0) or 0):.1f}%</b>",
            f"Net R: <b>{float(stats.get('r_net', 0) or 0):+.2f}R</b>",
            f"Max drawdown: <b>{float(stats.get('max_drawdown', 0) or 0):.2f}%</b>", "",
        ]
        lines.extend(f"• {esc(item)}" for item in report.get("findings", []))
        lines.extend(["", "<i>Descriptive journal analysis only; not a buy/sell recommendation.</i>"])
        back_label = "↩️ Trading center"
    else:
        lines = [
            "🧭 <b>مربی معاملاتی</b>", "",
            f"معاملات بسته‌شده: <b>{int(report.get('sample_size', 0) or 0)}</b>",
            f"نرخ برد: <b>{float(stats.get('win_rate', 0) or 0):.1f}٪</b>",
            f"خالص R: <b>{float(stats.get('r_net', 0) or 0):+.2f}R</b>",
            f"افت بیشینه: <b>{float(stats.get('max_drawdown', 0) or 0):.2f}٪</b>", "",
        ]
        lines.extend(f"• {esc(item)}" for item in report.get("findings", []))
        lines.extend(["", "<i>این گزارش صرفاً تحلیل توصیفی ژورنال است و توصیه خرید یا فروش نیست.</i>"])
        back_label = "↩️ مرکز معامله‌گری"
    await edit(query, "\n".join(lines)[:3900], [[InlineKeyboardButton(back_label, callback_data="nav_user:trade")]])


async def journal_new_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    language = (await run_blocking(_language_for_user, query.from_user.id))
    category = normalize_market_category(str(query.data or "").split(":", 1)[1])
    context.user_data["journal_new"] = {"market_category": category}
    await query.answer()
    await edit(
        query,
        "➕ <b>New journal trade</b>\nFirst choose why you entered this trade."
        if language == "en"
        else "➕ <b>ثبت معامله جدید در ژورنال</b>\nابتدا مشخص کنید دلیل ورود شما چه بوده است.",
        [
            [InlineKeyboardButton("📡 Channel signal" if language == "en" else "📡 سیگنال کانال", callback_data=f"journal_reason:{category}:channel_signal", style="primary")],
            [InlineKeyboardButton("🧠 Personal analysis" if language == "en" else "🧠 تحلیل شخصی", callback_data=f"journal_reason:{category}:personal_analysis")],
            [InlineKeyboardButton("✍️ Other reason" if language == "en" else "✍️ دلیل دیگر", callback_data=f"journal_reason:{category}:other")],
            [InlineKeyboardButton("↩️ Back" if language == "en" else "↩️ بازگشت", callback_data=f"user_journal:{category}")],
        ],
    )
    return JOURNAL_NEW_INPUT


async def journal_new_reason(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    language = (await run_blocking(_language_for_user, query.from_user.id))
    _, category, reason_type = str(query.data or "").split(":", 2)
    draft = context.user_data.setdefault("journal_new", {})
    draft.update({"market_category": normalize_market_category(category), "entry_reason_type": reason_type})
    await query.answer()
    await edit(
        query,
        (
            "Send one line in this format:\n<code>SYMBOL | BUY/SELL | entry | stop | volume | entry reason | note</code>\n"
            "Use <code>-</code> for optional values. Example:\n<code>XAUUSD | BUY | 2350 | 2338 | 0.10 | breakout + retest | partial at TP1</code>"
            if language == "en"
            else "اطلاعات را در یک خط با قالب زیر بفرستید:\n<code>نماد | BUY/SELL | ورود | استاپ | حجم | دلیل ورود | یادداشت</code>\n"
            "برای موارد اختیاری از <code>-</code> استفاده کنید. مثال:\n<code>XAUUSD | BUY | 2350 | 2338 | 0.10 | شکست و پولبک | خروج بخشی در TP1</code>"
        ),
        [[InlineKeyboardButton("↩️ Back" if language == "en" else "↩️ بازگشت", callback_data=f"journal_new:{category}")]],
    )
    return JOURNAL_NEW_INPUT


async def journal_new_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    language = (await run_blocking(_language_for_user, update.effective_user.id))
    draft = dict(context.user_data.get("journal_new") or {})
    if not draft.get("entry_reason_type"):
        await reply(update, "Choose the entry reason first." if language == "en" else "ابتدا نوع دلیل ورود را انتخاب کنید.")
        return JOURNAL_NEW_INPUT
    parts = [part.strip() for part in (update.effective_message.text or "").split("|", 6)]
    if len(parts) != 7:
        await reply(update, "❌ Seven sections are required." if language == "en" else "❌ قالب باید دقیقاً هفت بخش داشته باشد.")
        return JOURNAL_NEW_INPUT
    try:
        symbol = normalize_market_symbol(parts[0])
        side = parts[1].upper()
        entry_price = None if parts[2] in {"", "-"} else float(parts[2].replace(",", ""))
        stop_price = None if parts[3] in {"", "-"} else float(parts[3].replace(",", ""))
        volume = None if parts[4] in {"", "-"} else float(parts[4].replace(",", ""))
        reason = "" if parts[5] in {"", "-"} else parts[5]
        note = "" if parts[6] in {"", "-"} else parts[6]
        source = "channel_signal" if draft["entry_reason_type"] == "channel_signal" else "manual"
        row = await async_with_db(lambda db: add_journal_entry(
            db, update.effective_user.id, symbol=symbol, side=side, entry_price=entry_price,
            planned_entry=entry_price, actual_stop=stop_price, volume=volume, note=note,
            source=source, entry_reason_type=draft["entry_reason_type"], entry_reason=reason,
        ))
        from services.unified_journal_service import sync_legacy_journal_to_normalized
        await run_blocking(sync_legacy_journal_to_normalized, update.effective_user.id, limit=5000)
    except (ValueError, TypeError) as exc:
        await reply(update, f"❌ {esc(exc)}")
        return JOURNAL_NEW_INPUT
    category = draft.get("market_category") or classify_market_symbol(row.get("symbol"))
    context.user_data.pop("journal_new", None)
    await reply(
        update,
        f"✅ Trade #{row['id']} saved in your journal." if language == "en" else f"✅ معامله #{row['id']} با دلیل ورود در ژورنال ثبت شد.",
        [[InlineKeyboardButton("📔 Back to journal" if language == "en" else "📔 بازگشت به ژورنال", callback_data=f"user_journal:{category}")]],
    )
    return ConversationHandler.END


async def journal_result_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    language = (await run_blocking(_language_for_user, query.from_user.id))
    entry_id = int(str(query.data or "").split(":", 1)[1])
    entry = next((row for row in journal_entries((await async_snapshot()), query.from_user.id, limit=5000) if int(row.get("id", 0) or 0) == entry_id), None)
    if not entry:
        await query.answer("Record not found" if language == "en" else "رکورد پیدا نشد", show_alert=True)
        return ConversationHandler.END
    await query.answer()
    context.user_data["journal_result_id"] = entry_id
    context.user_data["journal_market_category"] = classify_market_symbol(entry.get("symbol"))
    await edit(
        query,
        "📈 Send the result in this format:\n<code>P/L percent | exit price | P/L amount | note</code>\n\nUse <code>-</code> for unknown fields. Example: <code>2.4 | 2350.5 | 120 | exited at target 2</code>" if language == "en" else "📈 نتیجه را با قالب زیر بفرستید:\n<code>درصد سود/زیان | قیمت خروج | مبلغ سود/زیان | یادداشت</code>\n\nبرای فیلدهای نامشخص از <code>-</code> استفاده کنید. مثال: <code>2.4 | 2350.5 | 120 | خروج در تارگت دوم</code>",
        [[InlineKeyboardButton("❌ Cancel" if language == "en" else "❌ انصراف", callback_data=f"user_journal:{context.user_data['journal_market_category']}")]],
    )
    return JOURNAL_RESULT_INPUT


async def journal_result_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    language = (await run_blocking(_language_for_user, update.effective_user.id))
    raw_parts = [part.strip() for part in (update.effective_message.text or "").split("|")]
    # Backward-compatible: old four-field entries remain accepted.
    if len(raw_parts) not in {4, 5}:
        await reply(update, "❌ The input must contain five sections." if language == "en" else "❌ قالب باید پنج بخش داشته باشد.")
        return JOURNAL_RESULT_INPUT
    try:
        if len(raw_parts) == 4:
            result_r = None
            pnl_raw, exit_raw, amount_raw, note = raw_parts
        else:
            result_r = None if raw_parts[0] in {"", "-"} else float(raw_parts[0].replace(",", ""))
            pnl_raw, exit_raw, amount_raw, note = raw_parts[1:]
        pnl = 0.0 if pnl_raw in {"", "-"} else float(pnl_raw.replace(",", ""))
        exit_price = None if exit_raw in {"", "-"} else float(exit_raw.replace(",", ""))
        pnl_amount = None if amount_raw in {"", "-"} else float(amount_raw.replace(",", ""))
        entry_id = int(context.user_data["journal_result_id"])
        row = await async_with_db(lambda db: update_journal_result(db, update.effective_user.id, entry_id, pnl_percent=pnl, result_r=result_r, exit_price=exit_price, pnl_amount=pnl_amount, note=note))
        from services.unified_journal_service import sync_legacy_journal_to_normalized
        await run_blocking(sync_legacy_journal_to_normalized, update.effective_user.id, limit=5000)
    except (ValueError, KeyError) as exc:
        await reply(update, f"❌ {esc(exc)}")
        return JOURNAL_RESULT_INPUT
    category = context.user_data.pop("journal_market_category", classify_market_symbol(row.get("symbol")))
    context.user_data.pop("journal_result_id", None)
    r_suffix = "" if row.get("result_r") is None else f" · <b>{float(row['result_r']):+.2f}R</b>"
    await reply(update, (f"✅ Result saved for record #{row['id']}: <b>{float(row['pnl_percent']):+.2f}%</b>{r_suffix}" if language == "en" else f"✅ نتیجه رکورد #{row['id']} ثبت شد: <b>{float(row['pnl_percent']):+.2f}٪</b>{r_suffix}"), [[InlineKeyboardButton("📔 Back to journal" if language == "en" else "📔 بازگشت به ژورنال", callback_data=f"user_journal:{category}")]])
    return ConversationHandler.END


async def journal_delete_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    language = (await run_blocking(_language_for_user, query.from_user.id))
    entry_id = int(str(query.data or "").split(":", 1)[1])
    db = await async_snapshot()
    existing = next((row for row in journal_entries(db, query.from_user.id, limit=5000) if int(row.get("id", 0) or 0) == entry_id), None)
    category = classify_market_symbol(existing.get("symbol")) if existing else MARKET_FOREX
    deleted = await async_with_db(lambda current: delete_journal_entry(current, query.from_user.id, entry_id))
    await query.answer(("Deleted" if deleted else "Record not found") if language == "en" else ("حذف شد" if deleted else "رکورد پیدا نشد"), show_alert=not deleted)
    db = await async_snapshot()
    text_value, rows = (await run_blocking(_render_user_journal_screen, db, query.from_user.id, category))
    await edit(query, text_value, rows)


async def journal_export_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    language = (await run_blocking(_language_for_user, query.from_user.id))
    await query.answer("Building export…" if language == "en" else "در حال ساخت خروجی…")
    parts = str(query.data or "").split(":")
    category = normalize_market_category(parts[1] if len(parts) > 1 else MARKET_FOREX)
    payload = journal_csv_by_market((await async_snapshot()), query.from_user.id, category)
    file_obj = io.BytesIO(payload)
    file_obj.name = f"sentinel-{category}-journal-{query.from_user.id}.csv"
    await query.message.reply_document(file_obj, caption=f"📔 Your {_localized_market_label(category, language)} journal export" if language == "en" else f"📔 خروجی ژورنال {market_label(category)} شما")


def _signal_cycle_status_label(status: str) -> str:
    return "فعال" if str(status or "active") == "active" else "بسته‌شده"


def _signal_cycle_summary_text(row: dict[str, Any], *, include_dates: bool = True) -> str:
    stats = row.get("stats") if isinstance(row.get("stats"), dict) else {}
    cycle_name = str(row.get("name") or f"دوره #{row.get('id')}")
    lines = [
        f"📌 <b>{esc(cycle_name)}</b>",
        f"شناسه دوره: <b>#{int(row.get('id', 0) or 0)}</b> · وضعیت: <b>{_signal_cycle_status_label(str(row.get('status') or 'active'))}</b>",
        f"کل سیگنال: <b>{int(stats.get('total', row.get('signal_count', 0)) or 0)}</b> | فارکس: <b>{int(stats.get('forex', 0) or 0)}</b> | کریپتو: <b>{int(stats.get('crypto', 0) or 0)}</b>",
        f"برد: <b>{int(stats.get('wins', 0) or 0)}</b> | باخت: <b>{int(stats.get('losses', 0) or 0)}</b> | نرخ برد: <b>{float(stats.get('win_rate', 0) or 0):.1f}٪</b>",
        f"سود/زیان تجمعی ثبت‌شده: <b>{float(stats.get('profit_percent_sum', 0) or 0):+.2f}٪</b>",
    ]
    if include_dates:
        lines.append(f"شروع: <code>{esc(str(row.get('started_at') or '-'))}</code>")
        if row.get("closed_at"):
            lines.append(f"پایان: <code>{esc(str(row.get('closed_at') or '-'))}</code>")
    return "\n".join(lines)


async def admin_signal_cycle(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SIGNAL_BOARD_MANAGE):
        return
    query = update.callback_query
    await query.answer()
    db = await async_snapshot()
    cycle = current_signal_cycle(db)
    current = signal_cycle_summary(db, cycle.get("current_id", 1))
    pending = len([
        row for row in db.get("scheduled_signals", [])
        if isinstance(row, dict) and row.get("status") in {"pending", "retry"}
    ])
    archived_periods = max(0, len(list_signal_cycles(db, limit=1000)) - (1 if current.get("status") == "active" else 0))
    text = (
        "🗂 <b>مدیریت دوره‌های سیگنال</b>\n\n"
        f"{_signal_cycle_summary_text(current)}\n"
        f"ارسال‌های زمان‌بندی‌شده: <b>{pending}</b>\n"
        f"دوره‌های نگهداری‌شده: <b>{archived_periods}</b>\n\n"
        "بستن دوره، هیچ سیگنال یا گزارشی را حذف نمی‌کند. دوره بسته‌شده در آرشیو می‌ماند و هر زمان می‌توانید سیگنال‌ها و PDF عملکرد آن را بررسی کنید."
    )
    rows: list[list[InlineKeyboardButton]] = []
    if str(current.get("status") or "active") == "active":
        rows.append([InlineKeyboardButton("🔁 بستن و شروع دوره جدید", callback_data="a_signal_cycle_name", style="primary")])
        rows.append([InlineKeyboardButton("🔒 فقط بستن دوره فعلی", callback_data="a_signal_cycle_close_confirm", style="danger")])
    else:
        rows.append([InlineKeyboardButton("➕ شروع دوره جدید", callback_data="a_signal_cycle_name", style="primary")])
    rows.append([
        InlineKeyboardButton("✏️ تغییر نام دوره", callback_data="a_signal_cycle_rename", style="primary"),
        InlineKeyboardButton("🗃 دوره‌های قبلی", callback_data="a_signal_cycles:0"),
    ])
    rows.append([InlineKeyboardButton("🔙 پنل ادمین", callback_data="admin_home", style="danger")])
    await edit(query, text, rows)


async def admin_signal_cycle_name_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_SIGNAL_BOARD_MANAGE):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    cycle = current_signal_cycle(await async_snapshot())
    mode = "rollover" if str(cycle.get("status") or "active") == "active" else "start"
    context.user_data["signal_cycle_name_mode"] = mode
    await edit(
        query,
        "📝 <b>نام دوره جدید</b>\n\n"
        "نام دلخواه را ارسال کنید؛ برای نمونه:\n"
        "<code>کمپین تبدیل ۱۰۰ به ۱۰۰۰</code>\n\n"
        + ("پس از ثبت نام، دوره فعلی بسته و دوره جدید بدون حذف تاریخچه آغاز می‌شود." if mode == "rollover" else "پس از ثبت نام، دوره جدید آغاز می‌شود."),
        [[InlineKeyboardButton("❌ انصراف", callback_data="a_signal_cycle", style="danger")]],
    )
    return SIGNAL_CYCLE_NAME_INPUT


async def admin_signal_cycle_name_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_SIGNAL_BOARD_MANAGE):
        return ConversationHandler.END
    name = " ".join(str(update.effective_message.text or "").split())
    mode = str(context.user_data.get("signal_cycle_name_mode") or "rollover")
    try:
        if mode == "start":
            started = await async_with_db(lambda db: start_signal_cycle(db, update.effective_user.id, name))
            closed = None
        else:
            result = await async_with_db(lambda db: rollover_signal_cycle(db, update.effective_user.id, new_name=name))
            closed = result["closed"]
            started = result["started"]
    except ValueError as exc:
        await reply(update, f"❌ {esc(exc)}\nنام دیگری ارسال کنید یا /cancel را بزنید.")
        return SIGNAL_CYCLE_NAME_INPUT
    context.user_data.pop("signal_cycle_name_mode", None)
    await async_with_db(
        lambda db: audit(
            db,
            update.effective_user.id,
            "signal_cycle_rollover" if closed else "signal_cycle_started",
            f"{int(closed.get('id', 0) or 0) if closed else '-'}->{int(started.get('id', 0) or 0)}:{started.get('name')}",
        )
    )
    await _sync_smart_pin(context.bot)
    closed_text = ""
    if closed:
        closed_text = (
            f"\nدوره بسته‌شده: <b>{esc(closed.get('name'))}</b> · "
            f"<b>{int((closed.get('stats') or {}).get('total', 0) or 0)}</b> سیگنال\n"
        )
    await reply(
        update,
        "✅ <b>دوره جدید با موفقیت آغاز شد</b>\n"
        f"{closed_text}"
        f"دوره فعال: <b>{esc(started.get('name'))}</b>\n"
        f"شناسه: <b>#{int(started.get('id', 0) or 0)}</b>\n"
        "شماره‌گذاری فارکس و کریپتو از <b>#1</b> آغاز شد.",
        [[
            InlineKeyboardButton("📡 ساخت سیگنال", callback_data="a_signal", style="primary"),
            InlineKeyboardButton("🗂 مدیریت دوره‌ها", callback_data="a_signal_cycle"),
        ]],
    )
    return ConversationHandler.END


async def admin_signal_cycle_rename_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_SIGNAL_BOARD_MANAGE):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    cycle = current_signal_cycle(await async_snapshot())
    context.user_data["signal_cycle_rename_id"] = int(cycle.get("current_id", 1) or 1)
    await edit(
        query,
        "✏️ <b>تغییر نام دوره</b>\n\n"
        f"نام فعلی: <b>{esc(cycle.get('name') or '')}</b>\n"
        "نام جدید را ارسال کنید:",
        [[InlineKeyboardButton("❌ انصراف", callback_data="a_signal_cycle", style="danger")]],
    )
    return SIGNAL_CYCLE_RENAME_INPUT


async def admin_signal_cycle_rename_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_SIGNAL_BOARD_MANAGE):
        return ConversationHandler.END
    cycle_id = int(context.user_data.get("signal_cycle_rename_id", 0) or 0)
    name = " ".join(str(update.effective_message.text or "").split())
    try:
        row = await async_with_db(lambda db: rename_signal_cycle(db, cycle_id, name, update.effective_user.id))
    except ValueError as exc:
        await reply(update, f"❌ {esc(exc)}\nنام دیگری ارسال کنید یا /cancel را بزنید.")
        return SIGNAL_CYCLE_RENAME_INPUT
    context.user_data.pop("signal_cycle_rename_id", None)
    await async_with_db(lambda db: audit(db, update.effective_user.id, "signal_cycle_renamed", f"{cycle_id}:{row.get('name')}"))
    await reply(
        update,
        f"✅ نام دوره <b>#{cycle_id}</b> به <b>{esc(row.get('name'))}</b> تغییر کرد.",
        [[InlineKeyboardButton("🗂 مدیریت دوره‌ها", callback_data="a_signal_cycle")]],
    )
    return ConversationHandler.END


async def admin_signal_cycle_close_confirm(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SIGNAL_BOARD_MANAGE):
        return
    query = update.callback_query
    cycle = current_signal_cycle(await async_snapshot())
    if str(cycle.get("status") or "active") != "active":
        await query.answer("این دوره قبلاً بسته شده است.", show_alert=True)
        await admin_signal_cycle(update, context)
        return
    await query.answer()
    await edit(
        query,
        "🔒 <b>تأیید بستن دوره فعلی</b>\n\n"
        f"دوره <b>{esc(cycle.get('name'))}</b> بسته می‌شود. سیگنال‌ها حذف نمی‌شوند و در آرشیو، گزارش و PDF باقی می‌مانند. تا شروع دوره جدید، امکان ساخت سیگنال تازه وجود ندارد.",
        [
            [InlineKeyboardButton("🔒 بستن دوره بدون حذف", callback_data="a_signal_cycle_close", style="danger")],
            [InlineKeyboardButton("❌ انصراف", callback_data="a_signal_cycle", style="danger")],
        ],
    )


async def admin_signal_cycle_close(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SIGNAL_BOARD_MANAGE):
        return
    query = update.callback_query
    await query.answer("در حال بستن دوره…")
    row = await async_with_db(lambda db: close_signal_cycle(db, query.from_user.id))
    await async_with_db(lambda db: audit(db, query.from_user.id, "signal_cycle_closed", f"{row.get('id')}:{row.get('name')}"))
    await _sync_smart_pin(context.bot)
    await edit(
        query,
        "✅ <b>دوره بدون حذف تاریخچه بسته شد</b>\n\n"
        f"{_signal_cycle_summary_text(row)}\n\n"
        "اکنون می‌توانید دوره جدیدی با نام دلخواه آغاز کنید.",
        [
            [InlineKeyboardButton("➕ شروع دوره جدید", callback_data="a_signal_cycle_name", style="primary")],
            [InlineKeyboardButton("📄 دریافت PDF", callback_data=f"a_signal_cycle_pdf:{int(row.get('id', 0) or 0)}")],
            [InlineKeyboardButton("🗃 همه دوره‌ها", callback_data="a_signal_cycles:0")],
        ],
    )


async def admin_signal_cycles_list(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SIGNAL_BOARD_MANAGE):
        return
    query = update.callback_query
    await query.answer()
    try:
        page = max(0, int(str(query.data or "").split(":", 1)[1]))
    except (IndexError, ValueError):
        page = 0
    rows = list_signal_cycles(await async_snapshot(), limit=1000)
    page_size = 6
    pages = max(1, (len(rows) + page_size - 1) // page_size)
    page = min(page, pages - 1)
    selected = rows[page * page_size : (page + 1) * page_size]
    lines = ["🗃 <b>آرشیو دوره‌های سیگنال</b>", "", "هیچ دوره‌ای حذف نمی‌شود؛ برای دیدن سیگنال‌ها یا دریافت PDF، دوره را انتخاب کنید.", ""]
    buttons: list[list[InlineKeyboardButton]] = []
    for row in selected:
        stats = row.get("stats") if isinstance(row.get("stats"), dict) else {}
        lines.append(
            f"• <b>#{int(row.get('id', 0) or 0)} · {esc(row.get('name'))}</b> — "
            f"{_signal_cycle_status_label(str(row.get('status') or 'closed'))} — {int(stats.get('total', 0) or 0)} سیگنال"
        )
        buttons.append([InlineKeyboardButton(
            f"#{int(row.get('id', 0) or 0)} · {str(row.get('name') or '')[:35]}",
            callback_data=f"a_signal_cycle_view:{int(row.get('id', 0) or 0)}:0",
        )])
    nav: list[InlineKeyboardButton] = []
    if page > 0:
        nav.append(InlineKeyboardButton("◀️ قبلی", callback_data=f"a_signal_cycles:{page - 1}"))
    if page < pages - 1:
        nav.append(InlineKeyboardButton("بعدی ▶️", callback_data=f"a_signal_cycles:{page + 1}"))
    if nav:
        buttons.append(nav)
    buttons.append([InlineKeyboardButton("🔙 مدیریت دوره‌ها", callback_data="a_signal_cycle", style="danger")])
    lines.append(f"\nصفحه <b>{page + 1}</b> از <b>{pages}</b>")
    await edit(query, "\n".join(lines), buttons)


async def admin_signal_cycle_view(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SIGNAL_BOARD_MANAGE):
        return
    query = update.callback_query
    await query.answer()
    parts = str(query.data or "").split(":")
    cycle_id = int(parts[1])
    page = max(0, int(parts[2]) if len(parts) > 2 else 0)
    db = await async_snapshot()
    detail = signal_cycle_detail(db, cycle_id, offset=page * 8, limit=8)
    cycle = detail["cycle"]
    rows = detail["items"]
    pages = max(1, (int(detail["total"]) + 7) // 8)
    page = min(page, pages - 1)
    lines = [_signal_cycle_summary_text(cycle), "", "<b>سیگنال‌های این دوره:</b>"]
    if not rows:
        lines.append("این دوره سیگنالی ندارد.")
    for row in rows:
        lines.append(
            f"• <b>#{signal_display_number(row)}</b> | {esc(row.get('symbol'))} | "
            f"{esc(user_signal_status_text(row))} | {float(row.get('profit_percent', 0) or 0):+.2f}٪"
        )
    buttons: list[list[InlineKeyboardButton]] = [[InlineKeyboardButton("📄 PDF عملکرد کامل", callback_data=f"a_signal_cycle_pdf:{cycle_id}", style="primary")]]
    if str(cycle.get("status") or "closed") != "active":
        buttons.append([InlineKeyboardButton("🗑 حذف این دوره", callback_data=f"a_signal_cycle_delete_confirm:{cycle_id}", style="danger")])
    nav: list[InlineKeyboardButton] = []
    if page > 0:
        nav.append(InlineKeyboardButton("◀️ قبلی", callback_data=f"a_signal_cycle_view:{cycle_id}:{page - 1}"))
    if page < pages - 1:
        nav.append(InlineKeyboardButton("بعدی ▶️", callback_data=f"a_signal_cycle_view:{cycle_id}:{page + 1}"))
    if nav:
        buttons.append(nav)
    buttons.append([InlineKeyboardButton("🔙 دوره‌های قبلی", callback_data="a_signal_cycles:0", style="danger")])
    lines.append(f"\nصفحه <b>{page + 1}</b> از <b>{pages}</b>")
    await edit(query, "\n".join(lines), buttons)



async def admin_signal_cycle_delete_confirm(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SIGNAL_BOARD_MANAGE):
        return
    query = update.callback_query
    await query.answer()
    cycle_id = int(str(query.data or "").rsplit(":", 1)[1])
    try:
        summary = signal_cycle_summary(await async_snapshot(), cycle_id)
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    if str(summary.get("status") or "closed") == "active":
        await query.answer("دوره فعال قابل حذف نیست.", show_alert=True)
        return
    await edit(
        query,
        "⚠️ <b>حذف دائمی دوره</b>\n\n"
        f"دوره <b>#{cycle_id} · {esc(summary.get('name'))}</b> و تمام سیگنال‌های متعلق به آن حذف می‌شوند. این عملیات قابل بازگشت نیست.",
        [[InlineKeyboardButton("🗑 حذف قطعی", callback_data=f"a_signal_cycle_delete:{cycle_id}", style="danger")],
         [InlineKeyboardButton("⬅️ انصراف", callback_data=f"a_signal_cycle_view:{cycle_id}:0")]],
    )


async def admin_signal_cycle_delete(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SIGNAL_BOARD_MANAGE):
        return
    query = update.callback_query
    await query.answer("در حال حذف…")
    cycle_id = int(str(query.data or "").rsplit(":", 1)[1])
    try:
        result = await async_with_db(lambda db: delete_signal_cycle(db, cycle_id, query.from_user.id))
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    await async_with_db(lambda db: audit(db, query.from_user.id, "signal_cycle_deleted", f"{cycle_id}:{result.get('name')}"))
    await edit(
        query,
        f"✅ دوره <b>#{cycle_id} · {esc(result.get('name'))}</b> حذف شد.\n"
        f"سیگنال زنده حذف‌شده: <b>{int(result.get('deleted_live', 0))}</b> | آرشیوی: <b>{int(result.get('deleted_archive', 0))}</b>",
        [[InlineKeyboardButton("🗃 دوره‌های باقی‌مانده", callback_data="a_signal_cycles:0")]],
    )

async def admin_signal_cycle_pdf(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SIGNAL_BOARD_MANAGE):
        return
    query = update.callback_query
    cycle_id = int(str(query.data or "").split(":", 1)[1])
    await query.answer("در حال ساخت PDF…")
    db = await async_snapshot()
    try:
        from services.signal_cycle_pdf_service import build_signal_cycle_pdf
        payload = await run_blocking(build_signal_cycle_pdf, db, cycle_id, language="fa")
        summary = signal_cycle_summary(db, cycle_id)
    except (ValueError, RuntimeError) as exc:
        await query.answer(str(exc), show_alert=True)
        return
    file_obj = io.BytesIO(payload)
    file_obj.name = f"sentinel-signal-period-{cycle_id}.pdf"
    await query.message.reply_document(
        document=file_obj,
        caption=f"📄 گزارش عملکرد <b>{esc(summary.get('name'))}</b> · دوره #{cycle_id}",
        parse_mode=ParseMode.HTML,
    )


async def admin_signal_cycle_confirm(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Recover old pre-v8.14.7 buttons into the named-period workflow."""
    await admin_signal_cycle_name_start(update, context)


async def admin_signal_cycle_reset(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer("برای دوره جدید ابتدا نام انتخاب کنید.", show_alert=True)
    await admin_signal_cycle(update, context)


async def signal_cycle_conversation_cancel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    context.user_data.pop("signal_cycle_name_mode", None)
    context.user_data.pop("signal_cycle_rename_id", None)
    await admin_signal_cycle(update, context)
    return ConversationHandler.END

def _alert_value_text(alert: dict[str, Any], language: str = "fa") -> str:
    language = normalize_language(language)
    condition = str(alert.get("condition") or "")
    target = float(alert.get("target_price", 0) or 0)
    if condition == "above":
        relation = "≥"
    elif condition == "below":
        relation = "≤"
    elif condition == "up_pct":
        return f"Increase ≥ {target:g}%" if language == "en" else f"افزایش ≥ {target:g}٪"
    elif condition == "down_pct":
        return f"Decrease ≥ {target:g}%" if language == "en" else f"کاهش ≥ {target:g}٪"
    else:
        relation = "Near" if language == "en" else "نزدیک"
    digits = 0 if str(alert.get("asset")) in ALERT_LOCAL_ASSETS else 5
    return f"{relation} {target:,.{digits}f}"


async def _fetch_alert_asset_price(asset: str) -> float:
    if asset in ALERT_LOCAL_ASSETS:
        snapshot = await fetch_iran_market_snapshot()
        quote = snapshot.quote(asset)
        if quote is None:
            raise ValueError("این قیمت محلی در منبع فعلی موجود نیست")
        return quote.price
    return await fetch_price(asset)


async def price_alerts_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    language = (await run_blocking(_language_for_user, query.from_user.id))
    rows = [
        [InlineKeyboardButton("➕ New alert" if language == "en" else "➕ هشدار جدید", callback_data="price_alert_new")],
        [
            InlineKeyboardButton("📋 My alerts" if language == "en" else "📋 هشدارهای من", callback_data="price_alert_list"),
            InlineKeyboardButton("🕘 History" if language == "en" else "🕘 تاریخچه", callback_data="price_alert_history"),
        ],
        [InlineKeyboardButton("↩️ Market prices" if language == "en" else "↩️ قیمت بازار", callback_data="u_price")],
    ]
    await edit(
        query,
        (
            "🔔 <b>Personal price alerts</b>\nCreate numeric, percentage, proximity or recurring alerts for crypto, forex, indices and supported local assets."
            if language == "en"
            else "🔔 <b>هشدار قیمت شخصی</b>\nهشدار عددی، درصدی، نزدیک‌شدن و تکرارشونده برای بازار ایران، فارکس، رمزارز و شاخص‌ها."
        ),
        rows,
    )
    return ConversationHandler.END


async def price_alert_new(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    language = (await run_blocking(_language_for_user, query.from_user.id))
    popular = popular_assets()[:10]
    rows = [
        [
            InlineKeyboardButton("💵 Free-market USD" if language == "en" else "💵 دلار آزاد", callback_data="pa_asset:dollar"),
            InlineKeyboardButton("🪙 Tether" if language == "en" else "🪙 تتر", callback_data="pa_asset:tether"),
        ],
        [
            InlineKeyboardButton("🥇 18K gold" if language == "en" else "🥇 طلای ۱۸ عیار", callback_data="pa_asset:gold18"),
            InlineKeyboardButton("🪙 Emami coin" if language == "en" else "🪙 سکه امامی", callback_data="pa_asset:coin_emami"),
        ],
    ]
    for index in range(0, len(popular), 2):
        pair = popular[index : index + 2]
        rows.append([InlineKeyboardButton(item.symbol, callback_data=f"pa_asset:{item.symbol}") for item in pair])
    rows.append([InlineKeyboardButton("🔎 Enter any market symbol" if language == "en" else "🔎 واردکردن هر نماد بازار", callback_data="pa_asset:custom")])
    rows.append([InlineKeyboardButton("↩️ Back" if language == "en" else "↩️ بازگشت", callback_data="price_alerts")])
    await edit(query, "Choose an asset or enter any supported symbol:" if language == "en" else "دارایی موردنظر را انتخاب کنید یا نماد دلخواه را وارد کنید:", rows)
    return PRICE_ALERT_ASSET


def _price_alert_condition_rows(language: str, settings: dict[str, Any]) -> list[list[InlineKeyboardButton]]:
    rows: list[list[InlineKeyboardButton]] = [
        [
            InlineKeyboardButton("Once ≥" if language == "en" else "یک‌بار ≥", callback_data="pa_cond:above:once"),
            InlineKeyboardButton("Once ≤" if language == "en" else "یک‌بار ≤", callback_data="pa_cond:below:once"),
        ]
    ]
    if bool(settings.get("recurring", True)):
        rows.append(
            [
                InlineKeyboardButton("Recurring ≥" if language == "en" else "تکراری ≥", callback_data="pa_cond:above:repeat"),
                InlineKeyboardButton("Recurring ≤" if language == "en" else "تکراری ≤", callback_data="pa_cond:below:repeat"),
            ]
        )
    if bool(settings.get("percent_change", True)):
        rows.append(
            [
                InlineKeyboardButton("📈 Percentage rise" if language == "en" else "📈 رشد درصدی", callback_data="pa_cond:up_pct:once"),
                InlineKeyboardButton("📉 Percentage drop" if language == "en" else "📉 افت درصدی", callback_data="pa_cond:down_pct:once"),
            ]
        )
    if bool(settings.get("proximity", True)):
        rows.append([InlineKeyboardButton("🎯 Approaching price" if language == "en" else "🎯 نزدیک‌شدن به قیمت", callback_data="pa_cond:proximity:once")])
    rows.append([InlineKeyboardButton("↩️ Back" if language == "en" else "↩️ بازگشت", callback_data="price_alerts")])
    return rows


async def signal_alert_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Start a price-alert flow with the selected signal symbol prefilled."""
    query = update.callback_query
    language = (await run_blocking(_language_for_user, query.from_user.id))
    try:
        signal_id = int(query.data.split(":", 1)[1])
    except (TypeError, ValueError, IndexError):
        await query.answer("Invalid signal." if language == "en" else "سیگنال نامعتبر است.", show_alert=True)
        return ConversationHandler.END
    db = await async_snapshot()
    row = _find_user_visible_signal(db, query.from_user.id, signal_id)
    if not row:
        await query.answer("Signal unavailable." if language == "en" else "سیگنال در دسترس نیست.", show_alert=True)
        return ConversationHandler.END
    try:
        asset = normalize_asset_symbol(str(row.get("symbol") or ""))
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return ConversationHandler.END
    ALERT_ASSETS.setdefault(asset, asset_title(asset))
    context.user_data["price_alert"] = {"asset": asset, "source_signal_id": signal_id}
    settings = control_module_state(db, "alerts")
    await query.answer()
    await edit(
        query,
        f"Choose the alert condition for <b>{ALERT_ASSETS[asset]}</b>:"
        if language == "en"
        else f"شرط هشدار برای <b>{ALERT_ASSETS[asset]}</b> را انتخاب کنید:",
        _price_alert_condition_rows(language, settings),
    )
    return PRICE_ALERT_CONDITION


async def price_alert_asset(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    language = (await run_blocking(_language_for_user, query.from_user.id))
    asset = query.data.split(":", 1)[1]
    if asset == "custom":
        await query.answer()
        await edit(
            query,
            "🔎 Enter a symbol; for example <code>AUDUSD</code>, <code>SOLUSDT</code>, <code>US30</code>, <code>WTI</code> or <code>AAPL</code>" if language == "en" else "🔎 نماد را وارد کنید؛ مثال: <code>AUDUSD</code>، <code>SOLUSDT</code>، <code>US30</code>، <code>WTI</code> یا <code>AAPL</code>",
            [[InlineKeyboardButton("↩️ Back" if language == "en" else "↩️ بازگشت", callback_data="price_alerts")]],
        )
        return PRICE_ALERT_ASSET
    try:
        asset = normalize_asset_symbol(asset)
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return ConversationHandler.END
    ALERT_ASSETS.setdefault(asset, asset_title(asset))
    await query.answer()
    context.user_data["price_alert"] = {"asset": asset}
    settings = control_module_state((await async_snapshot()), "alerts")
    await edit(
        query,
        f"Choose the alert condition for <b>{ALERT_ASSETS[asset]}</b>:"
        if language == "en"
        else f"شرط هشدار برای <b>{ALERT_ASSETS[asset]}</b> را انتخاب کنید:",
        _price_alert_condition_rows(language, settings),
    )
    return PRICE_ALERT_CONDITION


async def price_alert_asset_text(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    language = (await run_blocking(_language_for_user, update.effective_user.id))
    try:
        asset = normalize_asset_symbol(update.effective_message.text or "")
        await _fetch_alert_asset_price(asset)
    except (ValueError, RuntimeError) as exc:
        await reply(update, f"❌ {esc(exc)}\nEnter the symbol again:" if language == "en" else f"❌ {esc(exc)}\nنماد را دوباره وارد کنید:")
        return PRICE_ALERT_ASSET
    ALERT_ASSETS.setdefault(asset, asset_title(asset))
    context.user_data["price_alert"] = {"asset": asset}
    settings = control_module_state((await async_snapshot()), "alerts")
    rows: list[list[InlineKeyboardButton]] = [
        [
            InlineKeyboardButton("Once ≥" if language == "en" else "یک‌بار ≥", callback_data="pa_cond:above:once"),
            InlineKeyboardButton("Once ≤" if language == "en" else "یک‌بار ≤", callback_data="pa_cond:below:once"),
        ]
    ]
    if bool(settings.get("recurring", True)):
        rows.append(
            [
                InlineKeyboardButton("Recurring ≥" if language == "en" else "تکراری ≥", callback_data="pa_cond:above:repeat"),
                InlineKeyboardButton("Recurring ≤" if language == "en" else "تکراری ≤", callback_data="pa_cond:below:repeat"),
            ]
        )
    if bool(settings.get("percent_change", True)):
        rows.append(
            [
                InlineKeyboardButton("📈 Percentage rise" if language == "en" else "📈 رشد درصدی", callback_data="pa_cond:up_pct:once"),
                InlineKeyboardButton("📉 Percentage drop" if language == "en" else "📉 افت درصدی", callback_data="pa_cond:down_pct:once"),
            ]
        )
    if bool(settings.get("proximity", True)):
        rows.append([InlineKeyboardButton("🎯 Approaching price" if language == "en" else "🎯 نزدیک‌شدن به قیمت", callback_data="pa_cond:proximity:once")])
    rows.append([InlineKeyboardButton("↩️ Back" if language == "en" else "↩️ بازگشت", callback_data="price_alerts")])
    await reply(update, f"✅ <b>{esc(asset_title(asset))}</b> was selected. Choose the alert condition:" if language == "en" else f"✅ نماد <b>{esc(asset_title(asset))}</b> ثبت شد. شرط هشدار را انتخاب کنید:", rows)
    return PRICE_ALERT_CONDITION


async def price_alert_condition(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    language = (await run_blocking(_language_for_user, query.from_user.id))
    parts = str(query.data or "").split(":")
    if len(parts) != 3:
        await query.answer("Invalid condition" if language == "en" else "شرط نامعتبر است", show_alert=True)
        return ConversationHandler.END
    _, condition, mode = parts
    data = context.user_data.setdefault("price_alert", {})
    data["condition"] = condition
    data["recurring"] = mode == "repeat"
    await query.answer()
    if condition in {"up_pct", "down_pct"}:
        prompt = "Enter the percentage change; for example <code>2.5</code>" if language == "en" else "درصد تغییر را وارد کنید؛ مثال: <code>2.5</code>"
    else:
        unit = ("IRT" if data.get("asset") in ALERT_LOCAL_ASSETS else "market price") if language == "en" else ("تومان" if data.get("asset") in ALERT_LOCAL_ASSETS else "قیمت بازار")
        prompt = f"Enter the target in {unit}; for example <code>85000</code>" if language == "en" else f"مقدار هدف را به {unit} وارد کنید؛ مثال: <code>85000</code>"
    await edit(query, prompt, [[InlineKeyboardButton("↩️ Back" if language == "en" else "↩️ بازگشت", callback_data="price_alerts")]])
    return PRICE_ALERT_VALUE


async def price_alert_value(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    language = (await run_blocking(_language_for_user, update.effective_user.id))
    raw = (update.effective_message.text or "").replace(",", "").strip()
    try:
        target = float(raw)
        data = context.user_data.get("price_alert") or {}
        baseline = None
        if data.get("condition") in {"up_pct", "down_pct"}:
            baseline = await _fetch_alert_asset_price(str(data["asset"]))
        alert = await async_with_db(
            lambda db: create_price_alert(
                db,
                update.effective_user.id,
                data["asset"],
                data["condition"],
                target,
                recurring=bool(data.get("recurring")),
                baseline_price=baseline,
            )
        )
    except (ValueError, KeyError) as exc:
        await reply(update, f"❌ {esc(exc)}")
        return PRICE_ALERT_VALUE
    except Exception:
        logger.exception("Could not initialize percent price alert")
        await reply(update, "❌ The baseline price is unavailable; please try again." if language == "en" else "❌ دریافت قیمت مبنا ممکن نشد؛ دوباره تلاش کنید.")
        return PRICE_ALERT_VALUE
    context.user_data.pop("price_alert", None)
    repeat_text = ("recurring" if alert.get("recurring") else "one-time") if language == "en" else ("تکرارشونده" if alert.get("recurring") else "یک‌بار")
    await reply(
        update,
        f"✅ {repeat_text.title()} alert created.\n{ALERT_ASSETS[alert['asset']]} | <b>{_alert_value_text(alert, language)}</b>" if language == "en" else f"✅ هشدار {repeat_text} ثبت شد.\n{ALERT_ASSETS[alert['asset']]} | <b>{_alert_value_text(alert, language)}</b>",
        [[InlineKeyboardButton("↩️ Alerts" if language == "en" else "↩️ هشدارها", callback_data="price_alerts")]],
    )
    return ConversationHandler.END


async def _render_price_alert_list(query: Any) -> None:
    language = (await run_blocking(_language_for_user, query.from_user.id))
    alerts = [row for row in user_price_alerts((await async_snapshot()), query.from_user.id) if not row.get('disabled_at')]
    raw_page = str(query.data).partition(':')[2] if str(query.data).startswith('price_alert_list:') else ''
    page = min(int(raw_page) if raw_page.isdigit() else 0,max(0,(len(alerts)-1)//8))
    lines = ["📋 <b>My alerts</b>" if language == "en" else "📋 <b>هشدارهای من</b>"]
    rows: list[list[InlineKeyboardButton]] = []
    for row in alerts[page*8:page*8+8]:
        repeat = " 🔁" if row.get("recurring") else ""
        lines.append(f"• #{row['id']} | {ALERT_ASSETS.get(row.get('asset'), row.get('asset'))} | {_alert_value_text(row, language)}{repeat}")
        rows.append(
            [
                InlineKeyboardButton(f"{'✅' if row.get('status')=='active' else '⏸'} #{row['id']}", callback_data=f"pa_toggle:{row['id']}"),
                InlineKeyboardButton(f"🗑 {'Delete' if language == 'en' else 'حذف'} #{row['id']}", callback_data=f"pa_delete:{row['id']}"),
                InlineKeyboardButton('🎫 پیگیری', callback_data=f"ticket_from:price_alert:{row['id']}"),
            ]
        )
    if not alerts:
        lines.append("You have no active alerts." if language == "en" else "هشدار فعالی ندارید.")
    if page: rows.append([InlineKeyboardButton('صفحه قبل',callback_data=f'price_alert_list:{page-1}')])
    if (page+1)*8 < len(alerts): rows.append([InlineKeyboardButton('صفحه بعد',callback_data=f'price_alert_list:{page+1}')])
    rows.append([InlineKeyboardButton("↩️ Alerts" if language == "en" else "↩️ هشدارها", callback_data="price_alerts")])
    await edit(query, "\n".join(lines), rows)


async def price_alert_list(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    await _render_price_alert_list(query)


async def price_alert_delete(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    language = (await run_blocking(_language_for_user, query.from_user.id))
    alert_id = int(query.data.split(":", 1)[1])
    ok = await async_with_db(lambda db: delete_price_alert(db, query.from_user.id, alert_id))
    await query.answer(("Deleted" if ok else "Alert not found") if language == "en" else ("حذف شد" if ok else "هشدار پیدا نشد"), show_alert=not ok)
    await _render_price_alert_list(query)


async def price_alert_toggle_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    language = (await run_blocking(_language_for_user, query.from_user.id))
    alert_id = int(query.data.split(":", 1)[1])
    try:
        alert = await async_with_db(lambda db: toggle_price_alert(db, query.from_user.id, alert_id))
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    await query.answer(("Enabled" if alert.get("status") == "active" else "Disabled") if language == "en" else ("فعال شد" if alert.get("status") == "active" else "غیرفعال شد"))
    await _render_price_alert_list(query)


async def price_alert_history_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    language = (await run_blocking(_language_for_user, query.from_user.id))
    rows_data = price_alert_history((await async_snapshot()), query.from_user.id, limit=30)
    lines = ["🕘 <b>Triggered alert history</b>" if language == "en" else "🕘 <b>تاریخچه هشدارهای فعال‌شده</b>"]
    for row in rows_data:
        asset = ALERT_ASSETS.get(str(row.get("asset")), str(row.get("asset")))
        lines.append(f"• {asset} | {_alert_value_text(row, language)} | {'Price' if language == 'en' else 'قیمت'}: <code>{float(row.get('trigger_price', 0) or 0):,.5f}</code>")
    if not rows_data:
        lines.append("No alert has triggered yet." if language == "en" else "هنوز هشداری فعال نشده است.")
    await edit(query, "\n".join(lines), [[InlineKeyboardButton("↩️ Alerts" if language == "en" else "↩️ هشدارها", callback_data="price_alerts")]])


async def check_price_alerts_job(context: ContextTypes.DEFAULT_TYPE) -> None:
    db = await async_snapshot()
    active_rows = [row for row in db.get("price_alerts", []) if isinstance(row, dict) and row.get("status") == "active"]
    if not active_rows:
        return
    allowed_users = await async_with_db(
        lambda current: {
            str(row.get("user_id"))
            for row in active_rows
            if route_notification(
                current,
                str(row.get("user_id")),
                "alerts",
                symbol=str(row.get("asset") or ""),
            )
        }
    )
    if not allowed_users:
        return
    assets = {str(row.get("asset")) for row in active_rows if str(row.get("user_id")) in allowed_users}
    prices: dict[str, float] = {}
    try:
        if assets & ALERT_LOCAL_ASSETS:
            snapshot = await fetch_iran_market_snapshot()
            if snapshot.stale:
                logger.info("Skipping stale Iran-market snapshot for price alerts")
            else:
                for asset in sorted(assets & ALERT_LOCAL_ASSETS):
                    quote = snapshot.quote(asset)
                    if quote is None:
                        continue
                    if bool(getattr(quote, "estimated", False)):
                        logger.info("Skipping estimated Iran-market quote for alert %s", asset)
                        continue
                    prices[asset] = float(quote.price)
        remote_assets = sorted(assets - ALERT_LOCAL_ASSETS)
        if remote_assets:
            remote_quotes = await fetch_prices(remote_assets)
            for asset in remote_assets:
                quote = remote_quotes.get(asset)
                if isinstance(quote, Exception):
                    logger.warning("Price alert provider failed for %s: %s", asset, quote.__class__.__name__)
                    continue
                if quote is None:
                    logger.warning("Price alert provider returned no quote for %s", asset)
                    continue
                if bool(getattr(quote, "stale", False)):
                    logger.info("Skipping stale price alert quote for %s", asset)
                    continue
                if bool(getattr(quote, "delayed", False)):
                    logger.info("Skipping delayed price alert quote for %s", asset)
                    continue
                if getattr(quote, "market_open", None) is False:
                    logger.info("Skipping closed-market price alert quote for %s", asset)
                    continue
                prices[asset] = float(quote.price)
        rows = await async_with_db(lambda database: prepare_price_alert_deliveries(database, prices, allowed_user_ids=allowed_users))
    except Exception:
        logger.exception("Price alert check failed")
        return
    for row in rows:
        delivery_token = str(row.get("id") or "")
        try:
            await _telegram_request_with_button_fallback(
                context.bot.send_message,
                int(row["user_id"]),
                f"🔔 <b>هشدار قیمت فعال شد</b>\n{ALERT_ASSETS.get(row.get('asset'), row.get('asset'))}\nشرط: <b>{_alert_value_text(row)}</b>\nقیمت فعلی: <code>{float(row.get('trigger_price', 0)):,.5f}</code>",
                parse_mode=ParseMode.HTML,
            )
            await async_with_db(lambda database, token=delivery_token: complete_price_alert_delivery(database, token, delivered=True))
        except TelegramError:
            logger.warning("Could not deliver price alert %s", row.get("id"))
            await async_with_db(
                lambda database, token=delivery_token: complete_price_alert_delivery(
                    database, token, delivered=False, error="telegram_delivery_failed"
                )
            )


async def usdt_convert_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    await edit(query, "🪙 مقدار تتر را وارد کنید؛ مثال: <code>125.5</code>", back("u_price"))
    return USDT_CONVERT_AMOUNT


async def usdt_convert_amount(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    raw = (update.effective_message.text or "").replace(",", "").strip()
    try:
        amount = float(raw)
        if amount <= 0 or amount > 1_000_000_000:
            raise ValueError("مقدار تتر نامعتبر است")
        snapshot = await fetch_iran_market_snapshot()
    except ValueError as exc:
        await reply(update, f"❌ {esc(exc)}")
        return USDT_CONVERT_AMOUNT
    except Exception:
        logger.exception("USDT converter failed")
        await reply(update, "❌ دریافت قیمت تتر ممکن نشد؛ کمی بعد دوباره تلاش کنید.", back("u_price"))
        return ConversationHandler.END
    toman = amount * snapshot.tether.price
    await reply(
        update,
        f"🪙 <b>{amount:,.4f} USDT</b>\n≈ <b>{toman:,.0f} تومان</b>\n\nقیمت هر تتر: <code>{snapshot.tether.price:,.0f}</code> تومان\nمنبع: {esc(snapshot.tether.source)}",
        [
            [
                InlineKeyboardButton("🔁 تبدیل دوباره", callback_data="usdt_convert"),
                InlineKeyboardButton("🔙 بازار", callback_data="u_price"),
            ]
        ],
    )
    return ConversationHandler.END


async def feature_gate_guard(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    user = update.effective_user
    if not query or not user or (await run_blocking(_is_any_admin, user.id)):
        return
    module_key = feature_for_callback(str(query.data or ""))
    if not module_key:
        return
    db = await async_snapshot()
    if is_module_enabled(db, module_key):
        return
    language = (await run_blocking(_language_for_user, user.id))
    module = CONTROL_MODULES.get(module_key)
    label = module.label if module and language != "en" else ("This section" if language == "en" else "این بخش")
    await query.answer(
        f"{label} has been temporarily disabled by the administrator."
        if language == "en"
        else f"{label} موقتاً توسط مدیریت غیرفعال شده است.",
        show_alert=True,
    )
    raise ApplicationHandlerStop


async def feature_gate_message_guard(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    message = update.effective_message
    if not user or not message or (await run_blocking(_is_any_admin, user.id)):
        return
    text = str(getattr(message, "text", "") or "")
    if text.startswith(("/start", "/menu", "/cancel")):
        return
    module_key = feature_for_context(context.user_data)
    if not module_key:
        return
    db = await async_snapshot()
    if is_module_enabled(db, module_key):
        return
    language = (await run_blocking(_language_for_user, user.id))
    module = CONTROL_MODULES.get(module_key)
    label = module.label if module and language != "en" else ("This section" if language == "en" else "این بخش")
    context.user_data.clear()
    await message.reply_text(
        (
            f"⛔️ {label} has been temporarily disabled by the administrator.\n"
            "The unfinished operation was closed. Choose an available section from the main menu."
            if language == "en"
            else f"⛔️ {label} موقتاً توسط مدیریت غیرفعال شده است.\n"
            "عملیات نیمه‌تمام بسته شد؛ از منوی اصلی یک بخش فعال را انتخاب کنید."
        ),
        reply_markup=InlineKeyboardMarkup(
            [[InlineKeyboardButton(tr("home", language), callback_data="home")]]
        ),
    )
    raise ApplicationHandlerStop


async def global_rate_limit_guard(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Bound abusive update bursts before any conversation mutates state."""
    if update.effective_user is not None and update.callback_query is not None:
        context.application.bot_data.get('live_signal_panels',{}).pop(str(update.effective_user.id),None)
    user = update.effective_user
    if user is None:
        return
    db = await run_blocking(load_db, timeout=10)
    if not is_module_enabled(db, "security"):
        return
    security = control_module_state(db, "security")
    if not bool(security.get("anti_spam", True)):
        return
    is_callback = update.callback_query is not None
    cooldown = 0.08 if (await run_blocking(_is_any_admin, user.id)) else (0.22 if is_callback else 0.55)
    action = "telegram:callback" if is_callback else "telegram:message"
    if (await run_blocking(rate_limit_allow, user.id, action, cooldown)):
        return
    metric_increment("telegram_rate_limited_total")
    if update.callback_query is not None:
        try:
            language = (await run_blocking(_language_for_user, user.id))
            await update.callback_query.answer(
                "Please slow down for a moment." if language == "en" else "لطفاً کمی آهسته‌تر ادامه بدهید.",
                show_alert=False,
            )
        except TelegramError:
            pass
    raise ApplicationHandlerStop


async def _render_account_notifications(query: Any) -> None:
    language = (await run_blocking(_language_for_user, query.from_user.id))
    pref = await async_with_db(lambda database: notification_preferences(database, query.from_user.id))
    rows: list[list[InlineKeyboardButton]] = []
    for key, label in NOTIFICATION_KEYS:
        enabled = bool(pref.get(key, True))
        english_labels = {
            "signals": "New signals",
            "results": "Signal results",
            "alerts": "Price alerts",
            "calendar": "Economic calendar",
            "campaigns": "Offers & campaigns",
            "education": "Education",
        }
        display_label = english_labels.get(key, key.replace("_", " ").title()) if language == "en" else label
        rows.append([InlineKeyboardButton(f"{'✅' if enabled else '⛔️'} {display_label}", callback_data=f"notification_toggle:{key}")])
    quiet = bool(pref.get("quiet_enabled", True))
    markets = {str(value) for value in pref.get("markets", [])}
    rows.extend(
        [
            [
                InlineKeyboardButton(
                    f"{'✅' if not markets or 'forex' in markets else '⛔️'} {'Forex' if language == 'en' else 'فارکس'}",
                    callback_data="notification_market:forex",
                ),
                InlineKeyboardButton(
                    f"{'✅' if not markets or 'crypto' in markets else '⛔️'} {'Crypto' if language == 'en' else 'کریپتو'}",
                    callback_data="notification_market:crypto",
                ),
            ],
            [InlineKeyboardButton(f"{'✅' if quiet else '⛔️'} {'Quiet hours' if language == 'en' else 'ساعات سکوت'}", callback_data="notification_toggle:quiet_enabled")],
            [
                InlineKeyboardButton("🌙 23–07" if language == "en" else "🌙 ۲۳ تا ۷", callback_data="notification_quiet:23_07"),
                InlineKeyboardButton("🌙 22–08" if language == "en" else "🌙 ۲۲ تا ۸", callback_data="notification_quiet:22_08"),
                InlineKeyboardButton("No quiet hours" if language == "en" else "بدون سکوت", callback_data="notification_quiet:off"),
            ],
            [
                InlineKeyboardButton("🇮🇷 Tehran" if language == "en" else "🇮🇷 تهران", callback_data="notification_tz:tehran"),
                InlineKeyboardButton("🇦🇿 Baku" if language == "en" else "🇦🇿 باکو", callback_data="notification_tz:baku"),
                InlineKeyboardButton("🌐 UTC", callback_data="notification_tz:utc"),
            ],
            [
                InlineKeyboardButton("⏸ Pause 8 hours" if language == "en" else "⏸ توقف ۸ ساعته", callback_data="notification_pause:8"),
                InlineKeyboardButton("⏸ Pause 24 hours" if language == "en" else "⏸ توقف ۲۴ ساعته", callback_data="notification_pause:24"),
            ],
            [InlineKeyboardButton("▶️ Resume notifications" if language == "en" else "▶️ لغو توقف", callback_data="notification_pause:0")],
            [
                InlineKeyboardButton("☀️ 09:00", callback_data="notification_digest_time:09"),
                InlineKeyboardButton("☀️ 12:00", callback_data="notification_digest_time:12"),
                InlineKeyboardButton("🌆 18:00", callback_data="notification_digest_time:18"),
            ],
            *(await run_blocking(_account_back, query.from_user.id)),
        ]
    )
    rows.insert(0, [InlineKeyboardButton(f"{'✅' if not markets or key in markets else '⛔'} {label}", callback_data=f"notification_market:{key}") for key,label in (("gold","طلا"),("stocks","سهام"),("energy","انرژی"))])
    paused = pref.get("paused_until") or ("None" if language == "en" else "ندارد")
    text = (
        "🔔 <b>My notification center</b>\n\n"
        "Choose what you want to receive and when notifications may be delivered.\n\n"
        f"Timezone: <code>{esc(pref.get('timezone'))}</code>\n"
        f"Quiet hours: <code>{esc(pref.get('quiet_start'))}</code> to <code>{esc(pref.get('quiet_end'))}</code>\n"
        f"Digest time: <code>{esc(pref.get('digest_time') or '09:00')}</code>\n"
        f"Paused until: <code>{esc(paused)}</code>"
        if language == "en"
        else (
            "🔔 <b>مرکز اعلان‌های من</b>\n\n"
            "نوع اعلان‌هایی را که می‌خواهید دریافت کنید مشخص کنید.\n\n"
            f"منطقه زمانی: <code>{esc(pref.get('timezone'))}</code>\n"
            f"ساعات سکوت: <code>{esc(pref.get('quiet_start'))}</code> تا <code>{esc(pref.get('quiet_end'))}</code>\n"
            f"زمان خلاصه: <code>{esc(pref.get('digest_time') or '09:00')}</code>\n"
            f"توقف موقت تا: <code>{esc(paused)}</code>"
        )
    )
    await edit(query, text, rows)


async def account_notifications(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    await _render_account_notifications(query)


async def notification_toggle_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    language = (await run_blocking(_language_for_user, query.from_user.id))
    key = str(query.data or "").split(":", 1)[1]
    try:
        enabled = await async_with_db(lambda db: toggle_notification(db, query.from_user.id, key))
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    await query.answer(("Notification enabled" if enabled else "Notification disabled") if language == "en" else ("اعلان فعال شد" if enabled else "اعلان غیرفعال شد"), show_alert=False)
    await _render_account_notifications(query)


async def notification_pause_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    language = (await run_blocking(_language_for_user, query.from_user.id))
    try:
        hours = int(str(query.data or "").split(":", 1)[1])
    except ValueError:
        await query.answer("Invalid duration" if language == "en" else "زمان نامعتبر است", show_alert=True)
        return
    paused_until = await async_with_db(lambda db: pause_notifications(db, query.from_user.id, hours))
    await query.answer(("Notifications paused" if paused_until else "Notifications resumed") if language == "en" else ("اعلان‌ها موقتاً متوقف شد" if paused_until else "توقف اعلان‌ها لغو شد"), show_alert=False)
    await _render_account_notifications(query)


async def notification_timezone_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    language = (await run_blocking(_language_for_user, query.from_user.id))
    slug = str(query.data or "").split(":", 1)[1]
    zones = {"tehran": "Asia/Tehran", "baku": "Asia/Baku", "utc": "UTC"}
    timezone_name = zones.get(slug)
    if not timezone_name:
        await query.answer("Invalid timezone" if language == "en" else "منطقه زمانی نامعتبر است", show_alert=True)
        return
    try:
        await async_with_db(lambda db: set_notification_timezone(db, query.from_user.id, timezone_name))
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    await query.answer("Timezone saved" if language == "en" else "منطقه زمانی ذخیره شد")
    await _render_account_notifications(query)


async def notification_quiet_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    language = (await run_blocking(_language_for_user, query.from_user.id))
    preset = str(query.data or "").split(":", 1)[1]
    presets = {"23_07": ("23:00", "07:00", True), "22_08": ("22:00", "08:00", True), "off": ("23:00", "07:00", False)}
    values = presets.get(preset)
    if not values:
        await query.answer("Invalid quiet-hours preset" if language == "en" else "بازه سکوت نامعتبر است", show_alert=True)
        return
    await async_with_db(lambda db: set_notification_quiet_hours(db, query.from_user.id, values[0], values[1], enabled=values[2]))
    await query.answer("Quiet hours saved" if language == "en" else "ساعات سکوت ذخیره شد")
    await _render_account_notifications(query)


async def notification_digest_time_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    language = (await run_blocking(_language_for_user, query.from_user.id))
    hour = str(query.data or "").split(":", 1)[1]
    if hour not in {"09", "12", "18"}:
        await query.answer("Invalid digest time" if language == "en" else "زمان خلاصه نامعتبر است", show_alert=True)
        return
    value = await async_with_db(lambda db: set_notification_digest_time(db, query.from_user.id, f"{hour}:00"))
    await query.answer((f"Digest time set to {value}" if language == "en" else f"زمان خلاصه روی {value} تنظیم شد"))
    await _render_account_notifications(query)


async def notification_market_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    language = (await run_blocking(_language_for_user, query.from_user.id))
    selected = str(query.data or "").split(":", 1)[1]

    if selected not in {"forex", "crypto", "gold", "stocks", "energy"}:
        await query.answer("بازار نامعتبر است", show_alert=True)
        return

    def mutate(db: dict[str, Any]) -> dict[str, Any]:
        pref = notification_preferences(db, query.from_user.id)
        current = {str(value) for value in pref.get("markets", [])}
        if not current:
            current = {"forex", "crypto", "gold", "stocks", "energy"}
        if selected in current and len(current) > 1:
            current.remove(selected)
        else:
            current.add(selected)
        # Empty means "all"; preserve an explicit one-market filter otherwise.
        return set_notification_filters(
            db,
            query.from_user.id,
            markets=[] if current == {"forex", "crypto", "gold", "stocks", "energy"} else sorted(current),
        )

    await async_with_db(mutate)
    await query.answer("Market filter saved." if language == "en" else "فیلتر بازار ذخیره شد.")
    await _render_account_notifications(query)


def _account_rows(user_id: int | str | None = None) -> list[list[InlineKeyboardButton]]:
    """Keep Account as one dashboard; feature categories live on the main menu."""
    language = _language_for_user(user_id) if user_id is not None else "fa"
    return [[InlineKeyboardButton("⚙️ تنظیمات", callback_data="u_settings"), InlineKeyboardButton("🎁 پاداش‌ها", callback_data="u_rewards")], [
        InlineKeyboardButton("🔄 Refresh" if language == "en" else "🔄 تازه‌سازی", callback_data="u_account"),
        InlineKeyboardButton("🏠 Main menu" if language == "en" else "🏠 منوی اصلی", callback_data="home", style="primary"),
    ]]


def _account_back(user_id: int | str | None = None) -> list[list[InlineKeyboardButton]]:
    language = _language_for_user(user_id) if user_id is not None else "fa"
    return [[InlineKeyboardButton("🔙 My account" if language == "en" else "🔙 حساب من", callback_data="u_account")]]


def _account_display_name(snapshot: dict[str, Any]) -> str:
    user = snapshot.get("user", {})
    full_name = " ".join(value.strip() for value in (str(user.get("first_name") or ""), str(user.get("last_name") or "")) if value.strip())
    return full_name or str(user.get("username") or snapshot.get("user_id") or "کاربر")


async def u_account(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    await run_blocking(register_current_user, update)
    db = await async_snapshot()
    snapshot = user_account_snapshot(db, query.from_user.id)
    points = int(snapshot["points"])
    rank = snapshot.get("rank")
    language = (await run_blocking(_language_for_user, query.from_user.id))
    vip_text = (
        f"فعال تا {display_dt(snapshot.get('vip_expires_at'))} — {int(snapshot.get('vip_days_left', 0))} روز باقی‌مانده"
        if snapshot.get("vip_active")
        else "غیرفعال"
    )
    if language == "en":
        vip_text = (
            f"Active until {display_dt(snapshot.get('vip_expires_at'))} — {int(snapshot.get('vip_days_left', 0))} days left"
            if snapshot.get("vip_active")
            else "Inactive"
        )
        text_value = (
            "👤 <b>My account</b>\n\n"
            f"Hello <b>{esc(_account_display_name(snapshot))}</b> 👋\n"
            f"🆔 ID: <code>{esc(snapshot['user_id'])}</code>\n"
            f"📅 Member since: <b>{display_dt(snapshot.get('created_at'))}</b>\n"
            f"🕒 Last activity: <b>{display_dt(snapshot.get('last_seen_at'))}</b>\n\n"
            f"🏷 Behavior: <b>{esc((snapshot.get('profile') or {}).get('behavior_persona') or 'explorer')}</b>\n"
            f"💎 VIP: <b>{esc(vip_text)}</b>\n"
            f"⭐ Points: <b>{points:,}</b> | Rank: <b>{rank or '—'}</b>\n"
            f"➕ Earned: <b>{int(snapshot.get('points_received', 0)):,}</b>"
            f" | ➖ Spent: <b>{int(snapshot.get('points_spent', 0)):,}</b>\n\n"
            f"🧾 Approved VIP orders: <b>{snapshot['vip_approved_count']}</b>"
            f" | Renewals: <b>{snapshot.get('vip_renewal_count', 0)}</b>"
            f" | Pending: <b>{snapshot['vip_pending_count']}</b>\n"
            f"🎓 Purchased lessons: <b>{snapshot['accessible_lesson_count']}</b>\n"
            f"🎫 Open tickets: <b>{snapshot['open_ticket_count']}</b>\n"
            f"🔔 Active price alerts: <b>{snapshot['active_alert_count']}</b>"
        )
    else:
        text_value = (
            "👤 <b>حساب من</b>\n\n"
            f"سلام <b>{esc(_account_display_name(snapshot))}</b> 👋\n"
            f"🆔 شناسه: <code>{esc(snapshot['user_id'])}</code>\n"
            f"📅 عضویت از: <b>{display_dt(snapshot.get('created_at'))}</b>\n"
            f"🕒 آخرین فعالیت: <b>{display_dt(snapshot.get('last_seen_at'))}</b>\n\n"
            f"🏷 دسته کاربر: <b>{esc(snapshot.get('primary_category_label') or 'کاربر عادی')}</b>\n"
            f"💎 وضعیت VIP: <b>{esc(vip_text)}</b>\n"
            f"⭐ مانده امتیاز: <b>{points:,}</b> | رتبه: <b>{rank or '—'}</b>\n"
            f"➕ امتیاز دریافتی: <b>{int(snapshot.get('points_received', 0)):,}</b>"
            f" | ➖ خرج‌شده: <b>{int(snapshot.get('points_spent', 0)):,}</b>\n"
            f"🎖 سطح: <b>{esc(get_level(points, db))}</b> | لیگ: <b>{esc(get_league(points))}</b>\n\n"
            f"🧾 خرید VIP: <b>{snapshot['vip_approved_count']}</b> تأییدشده"
            f" | تمدید: <b>{snapshot.get('vip_renewal_count', 0)}</b>"
            f" | <b>{snapshot['vip_pending_count']}</b> در انتظار\n"
            f"🎓 آموزش خریداری‌شده: <b>{snapshot['accessible_lesson_count']}</b>\n"
            f"🎫 تیکت باز: <b>{snapshot['open_ticket_count']}</b>\n"
            f"🔔 هشدار قیمت فعال: <b>{snapshot['active_alert_count']}</b>"
        )
    await edit(query, text_value, (await run_blocking(_account_rows, query.from_user.id)))


async def user_rules_view(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    db = await async_snapshot()
    language = (await run_blocking(_language_for_user, query.from_user.id))
    state = current_rules(db, language)
    history = rules_acceptance_history(db, query.from_user.id, limit=5, language=language)
    if not state.get("text"):
        await edit(
            query,
            (
                "📜 <b>Terms of use</b>\n\nThe English rules have not been published yet."
                if language == "en"
                else "📜 <b>قوانین استفاده</b>\n\nهنوز متنی از طرف مدیریت منتشر نشده است."
            ),
            ([[InlineKeyboardButton("↩️ Sentinel academy" if language == "en" else "↩️ آکادمی Sentinel", callback_data="nav_user:learning", style="primary")]] if str(query.data or "") == "learning_rules" else (await run_blocking(_account_back, query.from_user.id))),
        )
        return
    accepted = user_has_accepted_rules(db, query.from_user.id, language)
    history_lines = [
        (
            f"• Version <b>{int(row.get('version', 0) or 0)}</b> — {display_dt(row.get('accepted_at'))}"
            if language == "en"
            else f"• نسخه <b>{int(row.get('version', 0) or 0)}</b> — {display_dt(row.get('accepted_at'))}"
        )
        for row in history
    ]
    if language == "en":
        text = (
            "📜 <b>SENTINEL Terms of Use</b>\n\n"
            f"Current version: <b>{int(state.get('version', 0) or 0)}</b> | "
            f"Your status: <b>{'Accepted ✅' if accepted else 'Acceptance required ⏳'}</b>\n\n"
            f"{esc(state.get('text'))}\n\n"
            "<b>Your recent acceptance history</b>\n"
            + ("\n".join(history_lines) if history_lines else "• No acceptance history.")
        )
    else:
        text = (
            "📜 <b>قوانین استفاده SENTINEL</b>\n\n"
            f"نسخه فعلی: <b>{int(state.get('version', 0) or 0)}</b> | "
            f"وضعیت شما: <b>{'پذیرفته‌شده ✅' if accepted else 'نیازمند تأیید ⏳'}</b>\n\n"
            f"{esc(state.get('text'))}\n\n"
            "<b>سوابق اخیر پذیرش شما</b>\n"
            + ("\n".join(history_lines) if history_lines else "• سابقه‌ای ثبت نشده است.")
        )
    rows = []
    back_rows = ([[InlineKeyboardButton("↩️ Sentinel academy" if language == "en" else "↩️ آکادمی Sentinel", callback_data="nav_user:learning", style="primary")]] if str(query.data or "") == "learning_rules" else (await run_blocking(_account_back, query.from_user.id)))
    if not accepted and state.get("enabled"):
        rows.append(
            [InlineKeyboardButton(tr("rules_accept", language), callback_data="rules_accept")]
        )
    rows.extend(back_rows)
    await edit(query, text[:3900], rows)


async def account_privacy(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
    *,
    answer_callback: bool = True,
) -> None:
    query = update.callback_query
    if query:
        if answer_callback:
            await query.answer()
        user_id = query.from_user.id
    else:
        user_id = update.effective_user.id
    language = (await run_blocking(_language_for_user, user_id))
    row = (await async_snapshot()).get("privacy_requests", {}).get(str(user_id), {})
    status = str(row.get("status") or "none") if isinstance(row, dict) else "none"
    status_text = (
        {
            "pending": f"Scheduled for deletion at <code>{esc(row.get('execute_after'))}</code>",
            "cancelled": "Cancelled",
            "completed": "Completed",
            "none": "No request",
        }.get(status, status)
        if language == "en"
        else {
            "pending": f"در انتظار حذف تا <code>{esc(row.get('execute_after'))}</code>",
            "cancelled": "لغوشده",
            "completed": "انجام‌شده",
            "none": "درخواستی ثبت نشده",
        }.get(status, status)
    )
    rows = [
        [InlineKeyboardButton("📦 Export my data" if language == "en" else "📦 دریافت نسخه اطلاعات من", callback_data="privacy_export")],
    ]
    if status == "pending":
        rows.append([InlineKeyboardButton("↩️ Cancel deletion request" if language == "en" else "↩️ لغو درخواست حذف", callback_data="privacy_delete_cancel")])
    else:
        rows.append([InlineKeyboardButton("🗑 Request account deletion" if language == "en" else "🗑 درخواست حذف حساب", callback_data="privacy_delete_request")])
    rows += (await run_blocking(_account_back, user_id))
    text = (
        "🔐 <b>Privacy & my data</b>\n\n"
        "Download a JSON copy of your stored data or request account deletion. Required financial records are retained only in anonymized form.\n\n"
        f"Deletion request: <b>{status_text}</b>\n"
        f"Event retention: <b>{SETTINGS.privacy_retention_days} days</b>"
        if language == "en"
        else (
            "🔐 <b>حریم خصوصی و اطلاعات من</b>\n\n"
            "می‌توانید نسخه JSON اطلاعات ذخیره‌شده را دریافت کنید یا حذف حساب را درخواست دهید. "
            "رکوردهای مالی ضروری پس از حذف فقط به‌صورت ناشناس نگهداری می‌شوند.\n\n"
            f"وضعیت درخواست حذف: <b>{status_text}</b>\n"
            f"دوره نگهداری رخدادها: <b>{SETTINGS.privacy_retention_days} روز</b>"
        )
    )
    if query:
        await edit(query, text, rows)
    else:
        await reply(update, text, rows)


async def privacy_export(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    if query:
        await query.answer("در حال ساخت فایل…")
        user_id = query.from_user.id
        message = query.message
    else:
        user_id = update.effective_user.id
        message = update.effective_message
    language = (await run_blocking(_language_for_user, user_id))
    from services.privacy_service import complete_user_json
    payload = await run_blocking(complete_user_json, (await async_snapshot()), user_id)
    file_obj = io.BytesIO(payload)
    file_obj.name = f"sentinel-user-{user_id}.json"
    await message.reply_document(
        document=file_obj,
        caption="📦 Your stored SENTINEL account data" if language == "en" else "📦 نسخه اطلاعات ذخیره‌شده شما در SENTINEL",
    )


async def privacy_delete_request(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    language = (await run_blocking(_language_for_user, query.from_user.id))
    rows = [
        [InlineKeyboardButton("✅ Confirm deletion request" if language == "en" else "✅ تأیید درخواست حذف", callback_data="privacy_delete_confirm")],
        [InlineKeyboardButton("❌ Cancel" if language == "en" else "❌ انصراف", callback_data="account_privacy")],
    ]
    await edit(
        query,
        (
            "⚠️ <b>Confirm account deletion</b>\n\n"
            f"The request is executed after <b>{SETTINGS.privacy_delete_grace_days} days</b> and can be cancelled until then. "
            "Your profile, points, alerts and personal content are removed; required financial records are anonymized."
            if language == "en"
            else "⚠️ <b>تأیید حذف حساب</b>\n\n"
            f"درخواست پس از <b>{SETTINGS.privacy_delete_grace_days} روز</b> اجرا می‌شود و تا آن زمان قابل لغو است. "
            "پروفایل، امتیازها، هشدارها و محتوای شخصی حذف می‌شوند؛ رکوردهای مالی فقط ناشناس خواهند شد."
        ),
        rows,
    )


async def privacy_delete_confirm(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    language = (await run_blocking(_language_for_user, query.from_user.id))
    row = await async_with_db(lambda db: request_account_deletion(db, query.from_user.id, SETTINGS.privacy_delete_grace_days))
    await query.answer("Request submitted" if language == "en" else "درخواست ثبت شد", show_alert=True)
    await edit(
        query,
        f"✅ Account deletion request submitted.\nExecution time: <code>{esc(row['execute_after'])}</code>\nYou can cancel it before that time." if language == "en" else f"✅ درخواست حذف حساب ثبت شد.\nزمان اجرا: <code>{esc(row['execute_after'])}</code>\nتا قبل از آن می‌توانید درخواست را لغو کنید.",
        [[InlineKeyboardButton("↩️ Cancel deletion" if language == "en" else "↩️ لغو درخواست حذف", callback_data="privacy_delete_cancel")], *(await run_blocking(_account_back, query.from_user.id))],
    )


async def privacy_delete_cancel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    language = (await run_blocking(_language_for_user, query.from_user.id))
    changed = await async_with_db(lambda db: cancel_account_deletion(db, query.from_user.id))
    await query.answer(("Request cancelled" if changed else "No active request") if language == "en" else ("درخواست لغو شد" if changed else "درخواست فعالی وجود ندارد"), show_alert=not changed)
    await account_privacy(update, context, answer_callback=False)


async def privacy_cleanup_job(context: ContextTypes.DEFAULT_TYPE) -> None:
    def cleanup(db: dict[str, Any]) -> tuple[list[dict[str, Any]], dict[str, int]]:
        completed = process_due_deletions(db)
        counts = retention_cleanup(db, SETTINGS.privacy_retention_days)
        return completed, counts

    completed, counts = await async_with_db(cleanup)
    if completed:
        logger.info("Completed %s privacy deletion requests", len(completed))
    if any(counts.values()):
        logger.info("Privacy retention cleanup: %s", counts)


async def privacy_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await account_privacy(update, context)


async def export_me_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await privacy_export(update, context)


async def delete_me_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await reply(
        update,
        "برای ثبت امن درخواست حذف، وارد بخش حریم خصوصی شوید.",
        [[InlineKeyboardButton("🔐 حریم خصوصی", callback_data="account_privacy")]],
    )


async def account_vip(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    language = (await run_blocking(_language_for_user, query.from_user.id))
    snapshot = user_account_snapshot((await async_snapshot()), query.from_user.id)
    vip_text = (
        (f"✅ Active until {display_dt(snapshot.get('vip_expires_at'))}" if snapshot.get("vip_active") else "❌ Inactive")
        if language == "en"
        else (f"✅ فعال تا {display_dt(snapshot.get('vip_expires_at'))}" if snapshot.get("vip_active") else "❌ غیرفعال")
    )
    lines = (
        [
            "💎 <b>My subscription & orders</b>",
            "",
            f"Subscription: <b>{vip_text}</b>",
            f"Days remaining: <b>{int(snapshot.get('vip_days_left', 0))}</b>",
            f"Orders: <b>{snapshot['vip_order_count']}</b>",
            f"Approved purchases: <b>{snapshot['vip_approved_count']}</b>",
            f"Renewals: <b>{snapshot.get('vip_renewal_count', 0)}</b>",
            f"Approved spend: <b>{int(snapshot['vip_spend']):,} IRT</b>",
            "",
            "<b>Latest orders</b>",
        ]
        if language == "en"
        else [
            "💎 <b>اشتراک و خریدهای من</b>",
            "",
            f"وضعیت اشتراک: <b>{vip_text}</b>",
            f"روز باقی‌مانده: <b>{int(snapshot.get('vip_days_left', 0))}</b>",
            f"تعداد سفارش‌ها: <b>{snapshot['vip_order_count']}</b>",
            f"خریدهای تأییدشده: <b>{snapshot['vip_approved_count']}</b>",
            f"تعداد تمدیدها: <b>{snapshot.get('vip_renewal_count', 0)}</b>",
            f"مجموع پرداخت تأییدشده: <b>{int(snapshot['vip_spend']):,} تومان</b>",
            "",
            "<b>آخرین سفارش‌ها</b>",
        ]
    )
    orders = snapshot["vip_orders"][:8]
    if not orders:
        lines.append("No VIP order has been submitted yet." if language == "en" else "هنوز سفارش VIP ثبت نشده است.")
    for row in orders:
        status = (str(row.get("status") or "unknown").replace("_", " ").title() if language == "en" else _ACCOUNT_ORDER_STATUS.get(str(row.get("status")), str(row.get("status") or "نامشخص")))
        lines.append(
            f"• <code>{esc(row.get('order_id'))}</code> | {int(row.get('price', 0) or 0):,} {'IRT' if language == 'en' else 'تومان'}"
            f" | {esc(status)} | {display_dt(row.get('created_at'))}"
        )
    rows = [
        [InlineKeyboardButton("💎 Buy/renew VIP" if language == "en" else "💎 خرید/تمدید VIP", callback_data="u_vip")],
        *(await run_blocking(_account_back, query.from_user.id)),
    ]
    await edit(query, "\n".join(lines), rows)



__feature_exports__ = ('_market_category_menu', '_localized_market_label', '_localized_signal_status', '_user_signal_rows', 'user_signal_portal', '_find_user_visible_signal', '_user_signal_detail_text', '_user_signal_detail_rows', 'user_signal_view', 'user_signal_choice_handler', 'user_signal_stats', '_journal_entry_line', '_watchlist_price_map', '_watchlist_suggestion_rows', '_render_user_watchlist', 'user_watchlist', 'watchlist_toggle_handler', 'watchlist_alert_toggle_handler', 'watchlist_clear_handler', 'journal_signal_handler', '_render_user_journal_screen', 'user_journal', 'user_trading_coach', 'journal_new_start', 'journal_new_reason', 'journal_new_input', 'journal_result_start', 'journal_result_input', 'journal_delete_handler', 'journal_export_handler', 'admin_signal_cycle', 'admin_signal_cycle_confirm', 'admin_signal_cycle_reset', '_alert_value_text', '_fetch_alert_asset_price', 'price_alerts_menu', 'price_alert_new', '_price_alert_condition_rows', 'signal_alert_start', 'price_alert_asset', 'price_alert_asset_text', 'price_alert_condition', 'price_alert_value', '_render_price_alert_list', 'price_alert_list', 'price_alert_delete', 'price_alert_toggle_handler', 'price_alert_history_handler', 'check_price_alerts_job', 'usdt_convert_start', 'usdt_convert_amount', 'feature_gate_guard', 'feature_gate_message_guard', 'global_rate_limit_guard', '_render_account_notifications', 'account_notifications', 'notification_toggle_handler', 'notification_pause_handler', 'notification_timezone_handler', 'notification_quiet_handler', 'notification_digest_time_handler', 'notification_market_handler', '_account_rows', '_account_back', '_account_display_name', 'u_account', 'user_rules_view', 'account_privacy', 'privacy_export', 'privacy_delete_request', 'privacy_delete_confirm', 'privacy_delete_cancel', 'privacy_cleanup_job', 'privacy_command', 'export_me_command', 'delete_me_command', 'account_vip', 'admin_signal_cycle_name_start', 'admin_signal_cycle_name_input', 'admin_signal_cycle_rename_start', 'admin_signal_cycle_rename_input', 'admin_signal_cycle_close_confirm', 'admin_signal_cycle_close', 'admin_signal_cycles_list', 'admin_signal_cycle_view', 'admin_signal_cycle_delete_confirm', 'admin_signal_cycle_delete', 'admin_signal_cycle_pdf', 'signal_cycle_conversation_cancel')
