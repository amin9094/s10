"""SENTINEL v9 no-cost platform expansion Telegram surfaces."""

from bot_runtime import shared as _shared
globals().update({name: value for name, value in vars(_shared).items() if not name.startswith('__')})

from config import is_primary_admin

import time


_PLATFORM_PERMISSIONS = {
    "local_copilot": PERMISSION_AI_COPILOT,
    "risk_coach": PERMISSION_RISK_COACH,
    "paper_arena": PERMISSION_PAPER_TRADING,
    "prop_guardian": PERMISSION_PROP_GUARDIAN,
    "market_intelligence_v2": PERMISSION_MARKET_INTELLIGENCE,
    "multi_channel_publisher": PERMISSION_PUBLISHER,
    "partner_hub": PERMISSION_PARTNERS,
    "public_performance": PERMISSION_PUBLIC_PERFORMANCE,
    "content_factory": PERMISSION_CONTENT_FACTORY,
    "business_inbox": PERMISSION_BUSINESS_INBOX,
    "miniapp_next": PERMISSION_FEATURE_MANAGEMENT,
    "developer_platform": PERMISSION_DEVELOPER_API,
    "workspace_saas": PERMISSION_WORKSPACES,
}


def _status_icon(item: dict[str, Any]) -> str:
    return "✅" if item.get("available") else "⛔️"


async def a_platform_expansion(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SYSTEM_CONTROL):
        return
    query = update.callback_query
    await query.answer()
    db = await async_snapshot()
    snapshot = platform_dashboard(db)
    matrix = snapshot["matrix"]
    lines = [
        "🚀 <b>SENTINEL Platform Expansion</b>",
        "",
        "تمام قابلیت‌های این بخش در حالت بدون هزینه خارجی طراحی شده‌اند.",
        f"قابلیت‌ها: <b>{matrix['total']}</b> | آماده: <b>{matrix['available']}</b> | مسدود: <b>{matrix['blocked']}</b>",
        f"سیاست هزینه: <code>{esc(snapshot['cost_policy']['policy'])}</code>",
        "",
        f"🎮 حساب آزمایشی: <b>{snapshot['paper']['accounts']}</b> | معامله باز: <b>{snapshot['paper']['open_trades']}</b>",
        f"📣 کانال ناشر: <b>{snapshot['publisher']['channels']}</b> | صف: <b>{snapshot['publisher']['queued']}</b>",
        f"🤝 همکار فعال: <b>{snapshot['partners']['active']}</b> | رویداد: <b>{snapshot['partners']['events']}</b>",
        f"🔌 Webhook: <b>{snapshot['developer']['webhooks']}</b> | Held: <b>{snapshot['developer']['held_events']}</b>",
        f"🏢 فضای کاری: <b>{snapshot['workspaces']}</b>",
        "",
        "جزئیات هر قابلیت مستقیماً در دستهٔ کاری مرتبط نمایش داده می‌شود.",
    ]
    rows = [[InlineKeyboardButton("⬅️ ادمین و امنیت", callback_data="admin_cat:system")]]
    await edit(query, "\n".join(lines), rows)


async def platform_capability_view(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    key = str(query.data or "").split(":", 1)[1]
    permission = _PLATFORM_PERMISSIONS.get(key, PERMISSION_SYSTEM_CONTROL)
    if not await require_admin(update, permission):
        return
    await query.answer()
    db = await async_snapshot()
    matrix = platform_matrix(db)
    item = next((row for row in matrix["items"] if row["key"] == key), None)
    if not item:
        await query.answer("قابلیت پیدا نشد", show_alert=True)
        return
    reasons = "، ".join(item["reasons"]) if item["reasons"] else "ندارد"
    lines = [
        f"{_status_icon(item)} <b>{esc(item['label'])}</b>",
        "",
        esc(item["description"]),
        "",
        f"وضعیت: <b>{'عملیاتی' if item['available'] else 'مسدود'}</b>",
        f"ماژول کنترل: <code>{esc(item['control_module'])}</code>",
        f"مجوز ادمین: <code>{esc(permission)}</code>",
        f"وابستگی‌ها: <code>{esc(', '.join(item['dependencies']) or 'none')}</code>",
        f"هزینه خارجی: <b>{esc(item['external_cost'])}</b>",
        f"علت مسدودی: <code>{esc(reasons)}</code>",
        "",
        "فعال/غیرفعال‌کردن از مرکز کنترل انجام می‌شود و همه تغییرات ثبت می‌شوند.",
    ]
    rows = []
    if (await run_blocking(_has_admin_permission, query.from_user.id, PERMISSION_SYSTEM_CONTROL)):
        rows.append([InlineKeyboardButton("⚙️ تنظیمات ماژول", callback_data=f"ecc_mod:{item['control_module']}")])
    rows.append([InlineKeyboardButton("⬅️ " + _admin_navigation_categories()[_admin_control_domain(item['control_module'])]['title'],
                                     callback_data=f"admin_cat:{_admin_control_domain(item['control_module'])}")])
    await edit(query, "\n".join(lines), rows)


_AI_SOURCE_BACK = {
    "home": "home",
    "u_price": "u_price",
    "u_calc": "u_calc",
    "trade": "nav_user:trade",
    "markets": "nav_user:markets",
    "tools": "nav_user:tools",
    "learning": "nav_user:learning",
    "account": "u_account",
    "club": "nav_user:club",
    "support": "nav_user:support",
    "challenges": "u_challenges",
}


def _ai_source(query_data: str, prefix: str, default: str = "home") -> str:
    value = str(query_data or "")
    source = value[len(prefix) + 1:] if value.startswith(prefix + ":") else default
    return source if source in _AI_SOURCE_BACK else default


USER_AI_PRESETS = {
    "open_signals": ("📡 سیگنال‌های فعال من", "📡 My active signals"),
    "account_review": ("📊 بررسی حساب و رفتار من", "📊 Review my account"),
    "risk_review": ("🛡 بررسی ریسک من", "🛡 Review my risk"),
    "journal_summary": ("📓 خلاصه ژورنال من", "📓 Summarize my journal"),
    "vip_status": ("💎 وضعیت اشتراک و آموزش", "💎 Subscription & education"),
    "bot_help": ("🧭 راهنمای استفاده از Sentinel", "🧭 Sentinel guidance"),
}

def _user_ai_preset_rows(language: str) -> list[list[InlineKeyboardButton]]:
    keys = list(USER_AI_PRESETS)
    rows: list[list[InlineKeyboardButton]] = []
    for index in range(0, len(keys), 2):
        rows.append([
            InlineKeyboardButton(
                USER_AI_PRESETS[key][1 if language == "en" else 0],
                callback_data=f"u_ai_preset:{key}",
            )
            for key in keys[index:index + 2]
        ])
    rows.append([
        InlineKeyboardButton("🏠 Main menu" if language == "en" else "🏠 منوی اصلی", callback_data="ai_chat_home:user", style="primary"),
        InlineKeyboardButton("✖️ End" if language == "en" else "✖️ پایان", callback_data="ai_chat_stop:user", style="danger"),
    ])
    return rows

def _user_ai_chat_prompt(language: str) -> tuple[str, list[list[InlineKeyboardButton]]]:
    if language == "en":
        text = (
            "🧠 <b>Sentinel Gemini assistant</b>\n\n"
            "For privacy and accuracy, user Gemini is limited to the preset questions below. "
            "It reviews only your own signals, journal, risk, access and Sentinel usage. Choose a question:"
        )
    else:
        text = (
            "🧠 <b>دستیار Gemini کاربران Sentinel</b>\n\n"
            "برای حفظ حریم خصوصی و پاسخ دقیق، Gemini کاربر فقط سؤال‌های مشخص زیر را بررسی می‌کند و "
            "تنها به اطلاعات حساب، سیگنال، ژورنال، ریسک و دسترسی‌های خود شما متصل است. یک سؤال را انتخاب کنید:"
        )
    return text, _user_ai_preset_rows(language)


_AI_CHAT_STATE_KEY = "sentinel_ai_chat"


def _set_ai_chat_state(context: ContextTypes.DEFAULT_TYPE, state: dict[str, Any]) -> dict[str, Any]:
    """Persist chat state in both PTB user and chat scopes.

    PostgreSQL persistence can flush one scope before the next Telegram update
    reaches a different worker. Mirroring this tiny state prevents the first
    message after opening Gemini from being interpreted as an ended session.
    """
    normalized = {
        "role": str(state.get("role") or "user"),
        "scope": str(state.get("scope") or ("personal" if state.get("role") == "user" else "management")),
        "language": str(state.get("language") or "fa"),
        "active": True,
        "updated_at": utc_iso(),
        "search_mode": bool(state.get("search_mode", False)),
        "search_domain": str(state.get("search_domain") or ""),
    }
    context.user_data[_AI_CHAT_STATE_KEY] = dict(normalized)
    if isinstance(getattr(context, "chat_data", None), dict):
        context.chat_data[_AI_CHAT_STATE_KEY] = dict(normalized)
    return normalized


def _clear_ai_chat_state(context: ContextTypes.DEFAULT_TYPE) -> None:
    context.user_data.pop(_AI_CHAT_STATE_KEY, None)
    if isinstance(getattr(context, "chat_data", None), dict):
        context.chat_data.pop(_AI_CHAT_STATE_KEY, None)


async def _restore_ai_chat_state(update: Update, context: ContextTypes.DEFAULT_TYPE) -> dict[str, Any]:
    """Recover a conversation state instead of returning ConversationHandler.END."""
    state = context.user_data.get(_AI_CHAT_STATE_KEY)
    if not isinstance(state, dict) and isinstance(getattr(context, "chat_data", None), dict):
        state = context.chat_data.get(_AI_CHAT_STATE_KEY)
    if isinstance(state, dict) and state.get("active", True):
        return _set_ai_chat_state(context, state)

    actor_id = int(update.effective_user.id)
    if is_primary_admin(actor_id):
        return _set_ai_chat_state(context, {"role": "admin", "scope": "management", "language": "fa"})

    db = await async_snapshot()
    from modules.admin_access import AI_SCOPE_PERMISSIONS, has_permission, is_any_admin

    if is_any_admin(db, actor_id) and has_permission(db, actor_id, "ai_command_center"):
        scope = next(
            (candidate for candidate, permission in AI_SCOPE_PERMISSIONS.items() if has_permission(db, actor_id, permission)),
            "management",
        )
        return _set_ai_chat_state(context, {"role": "admin", "scope": scope, "language": "fa"})
    language = user_language(db, actor_id) or "fa"
    return _set_ai_chat_state(context, {"role": "user", "scope": "personal", "language": language})


async def u_ai_chat_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> str | int:
    query = update.callback_query
    if is_primary_admin(query.from_user.id):
        return await a_ai_chat_start(update, context)
    db = await async_snapshot()
    language = user_language(db, query.from_user.id) or "fa"
    from modules.gemini_ai import user_ai_access

    access = user_ai_access(query.from_user.id)
    if not access.get("allowed"):
        message = (
            "Gemini is available to VIP users only." if language == "en"
            else "دسترسی Gemini در حالت فعلی فقط برای کاربران VIP فعال است."
        )
        await query.answer(message, show_alert=True)
        return ConversationHandler.END
    _set_ai_chat_state(context, {"role": "user", "scope": "personal", "language": language})
    await query.answer()
    text, rows = _user_ai_chat_prompt(language)
    await edit(query, text, rows)
    return "AI_CHAT_INPUT"


async def u_ai_hub(update: Update, context: ContextTypes.DEFAULT_TYPE) -> str | int:
    """Compatibility entry for old buttons; all user chat now stays in Telegram."""
    return await u_ai_chat_start(update, context)


async def u_copilot(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    source = _ai_source(query.data, "u_copilot", default="trade")
    language = user_language(await run_blocking(load_db, timeout=10), query.from_user.id) or "fa"
    try:
        from modules.gemini_ai import user_ai_review
        result = await run_blocking(user_ai_review, query.from_user.id, language=language)
    except (ValueError, PermissionError, RuntimeError) as exc:
        await query.answer(str(exc), show_alert=True)
        return
    await query.answer()
    engine = "Gemini" if result.get("engine") == "google-gemini" else "SENTINEL Local"
    text = (
        (
            "🧠 <b>Sentinel smart account review</b>\n\n"
            f"{esc(str(result.get('answer') or '')[:3500])}\n\n"
            f"<i>Engine: {esc(engine)} — payments, receipts and VIP are outside AI access.</i>"
        )
        if language == "en"
        else
        (
            "🧠 <b>بررسی هوشمند حساب Sentinel</b>\n\n"
            f"{esc(str(result.get('answer') or '')[:3500])}\n\n"
            f"<i>موتور: {esc(engine)} — پرداخت، رسید و VIP خارج از دسترسی هوش مصنوعی هستند.</i>"
        )
    )
    await edit(
        query,
        text,
        [
            [InlineKeyboardButton("🔄 Review again" if language == "en" else "🔄 بررسی دوباره", callback_data=f"u_copilot:{source}", style="primary")],
            [InlineKeyboardButton("🛡 Risk coach" if language == "en" else "🛡 مربی ریسک", callback_data=f"u_risk_coach:{source}")],
            [InlineKeyboardButton("💬 Chat with Gemini" if language == "en" else "💬 گفت‌وگو با Gemini", callback_data="u_ai_chat_start", style="primary")],
            [InlineKeyboardButton("↩️ Main menu" if language == "en" else "↩️ منوی اصلی", callback_data="home")],
        ],
    )


async def u_risk_coach(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    source = _ai_source(query.data, "u_risk_coach", default="trade")
    try:
        from services.risk_coach_service import consolidated_behavioral_report
        report = await run_blocking(consolidated_behavioral_report, query.from_user.id)
    except (PermissionError, ValueError) as exc:
        await query.answer(str(exc), show_alert=True)
        return
    await query.answer()
    plan = report.get("daily_plan") or {}
    lines = [
        "🧭 <b>مربی رفتار و ریسک</b>", "",
        f"امتیاز انضباط: <b>{report.get('discipline_score', 0)}/100</b>",
        f"نمونه: <b>{report.get('sample_size', 0)}</b> | برد: <b>{report.get('wins', 0)}</b> | باخت: <b>{report.get('losses', 0)}</b>",
        f"Net R: <b>{report.get('net_r', 0)}</b> | بیشترین زیان متوالی: <b>{report.get('max_loss_streak', 0)}</b>",
        f"معامله بدون SL: <b>{report.get('missing_stop_count', 0)}</b>", "",
    ]
    if plan:
        lines.extend([
            "<b>برنامه امروز</b>",
            f"• ریسک هر معامله: <b>{plan.get('max_risk_per_trade_percent', 0)}%</b>",
            f"• ریسک کل روز: <b>{plan.get('max_daily_risk_percent', 0)}%</b>",
            f"• سقف معاملات: <b>{plan.get('max_trades', 0)}</b>",
            f"• توقف بعد از <b>{plan.get('stop_after_losses', 0)}</b> ضرر | حداقل R:R <b>{plan.get('minimum_rr', 0)}</b>", "",
        ])
    if report.get("findings"):
        lines.append("<b>الگوهای شناسایی‌شده</b>")
        lines.extend(f"• {esc(item.get('title') or item.get('code'))} — {item.get('count', 0)}" for item in report["findings"])
    lines.extend(["", "<b>پیشنهادها</b>"])
    lines.extend(f"• {esc(value)}" for value in report.get("recommendations", []))
    rows = [
        [InlineKeyboardButton("🧠 بررسی هوشمند", callback_data=f"u_copilot:{source}")],
        [InlineKeyboardButton("💬 گفت‌وگو با Gemini", callback_data="u_ai_chat_start", style="primary")],
        [InlineKeyboardButton("↩️ منوی اصلی", callback_data="home")],
    ]
    await edit(query, "\n".join(lines), rows)


def _paper_arena_content(
    db: dict[str, Any], user_id: int | str
) -> tuple[str, list[list[InlineKeyboardButton]]]:
    snapshot = paper_arena_snapshot(db, user_id)
    accounts = snapshot["accounts"]
    lines = [
        "🎮 <b>Paper Trading Arena</b>",
        "",
        f"حساب‌ها: <b>{len(accounts)}</b> | معاملات: <b>{len(snapshot['trades'])}</b>",
    ]
    for row in accounts[:5]:
        lines.append(f"• {esc(row['title'])}: <b>{row['balance']:,.2f}</b> | DD {row['max_drawdown_percent']}%")
    rows: list[list[InlineKeyboardButton]] = []
    if not accounts:
        lines.extend([
            "",
            "برای شروع، همین‌جا یک حساب آزمایشی رایگان بسازید؛ Mini App اجباری نیست.",
        ])
        rows.append([
            InlineKeyboardButton(
                "➕ ساخت حساب ۱۰٬۰۰۰ دلاری", callback_data="paper_create"
            )
        ])
    else:
        open_trades = [
            row for row in snapshot["trades"] if row.get("status") == "open"
        ]
        if open_trades:
            lines.extend(["", "<b>معاملات باز</b>"])
        for trade in open_trades[-4:]:
            lines.append(
                f"• #{trade['id']} {esc(trade['symbol'])} "
                f"{str(trade['side']).upper()} | R:R {trade['planned_rr']}"
            )
            targets = list(trade.get("targets") or [trade.get("target")])
            resolved = set(trade.get("target_hits") or []) | set(trade.get("cancelled_targets") or [])
            for index, target_price in enumerate(targets, 1):
                if index in resolved:
                    continue
                rows.append([
                    InlineKeyboardButton(f"✅ TP{index} · {target_price}", callback_data=f"paper_close:{trade['id']}:tp{index}"),
                    InlineKeyboardButton(f"لغو TP{index}", callback_data=f"paper_close:{trade['id']}:cancel_tp{index}"),
                ])
            rows.append([
                InlineKeyboardButton("↔️ سر‌به‌سر", callback_data=f"paper_close:{trade['id']}:be"),
                InlineKeyboardButton("🛑 SL", callback_data=f"paper_close:{trade['id']}:sl"),
                InlineKeyboardButton("❌ لغو", callback_data=f"paper_close:{trade['id']}:cancel"),
            ])

        used_signal_ids = {
            int(row.get("signal_id"))
            for row in snapshot["trades"]
            if row.get("signal_id") not in {None, ""}
        }
        eligible_signals: list[dict[str, Any]] = []
        for signal in reversed(db.get("signals", [])):
            if not isinstance(signal, dict):
                continue
            signal_id = int(signal.get("id", 0) or 0)
            targets = list(signal.get("targets") or [])
            entries = list(signal.get("entries") or [])
            entry = entries[0] if entries else signal.get("entry")
            status = str(signal.get("status") or "open").lower()
            if (
                signal_id > 0
                and signal_id not in used_signal_ids
                and status not in {"win", "loss", "closed", "cancelled", "expired"}
                and entry not in {None, ""}
                and signal.get("stop") not in {None, ""}
                and targets
            ):
                eligible_signals.append(signal)
            if len(eligible_signals) >= 4:
                break
        if eligible_signals:
            lines.extend(["", "<b>افزودن سیگنال فعال به حساب آزمایشی</b>"])
            for signal in eligible_signals:
                rows.append([
                    InlineKeyboardButton(
                        f"➕ #{signal['id']} {str(signal.get('symbol') or '')[:16]}",
                        callback_data=f"paper_signal:{signal['id']}",
                    )
                ])
        elif not open_trades:
            lines.extend([
                "",
                "فعلاً سیگنال فعال و قابل‌ثبت وجود ندارد. با انتشار سیگنال جدید این بخش خودکار فعال می‌شود.",
            ])
    rank = next(
        (
            index
            for index, row in enumerate(snapshot["leaderboard"], 1)
            if str(row["user_id"]) == str(user_id)
        ),
        None,
    )
    if rank:
        lines.append(f"\nرتبه شما: <b>#{rank}</b>")
    rows.extend([
        [InlineKeyboardButton("🛡 نگهبان پراپ", callback_data="u_prop_guardian")],
        [InlineKeyboardButton("🧰 ابزارهای مستقل ربات", callback_data="u_bot_tools")],
        [InlineKeyboardButton("↩️ آزمایشگاه ریسک و تمرین", callback_data="nav_user:tools", style="primary")],
    ])
    return "\n".join(lines), rows


async def _show_paper_arena(query: Any, user_id: int | str) -> None:
    text, rows = _paper_arena_content(await async_snapshot(), user_id)
    await edit(query, text, rows)


async def u_paper_arena(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    try:
        text, rows = _paper_arena_content(await async_snapshot(), query.from_user.id)
    except (ValueError, PermissionError) as exc:
        await query.answer(str(exc), show_alert=True)
        return
    await query.answer()
    await edit(query, text, rows)


async def paper_create_default(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> None:
    query = update.callback_query
    try:
        await async_with_db(
            lambda db: create_paper_account(
                db, query.from_user.id, "حساب آزمایشی تلگرام", 10_000
            )
        )
    except (ValueError, PermissionError) as exc:
        await query.answer(str(exc), show_alert=True)
        return
    await query.answer("حساب آزمایشی ساخته شد ✅", show_alert=True)
    await _show_paper_arena(query, query.from_user.id)


def _open_signal_as_paper_trade(
    db: dict[str, Any], user_id: int | str, signal_id: int
) -> dict[str, Any]:
    arena = paper_arena_snapshot(db, user_id)
    if not arena["accounts"]:
        raise ValueError("ابتدا حساب آزمایشی بسازید.")
    signal = next(
        (
            row
            for row in db.get("signals", [])
            if isinstance(row, dict) and int(row.get("id", 0) or 0) == signal_id
        ),
        None,
    )
    if not signal:
        raise ValueError("سیگنال پیدا نشد.")
    if any(
        int(row.get("signal_id", 0) or 0) == signal_id
        for row in arena["trades"]
    ):
        raise ValueError("این سیگنال قبلاً به حساب آزمایشی اضافه شده است.")
    entries = list(signal.get("entries") or [])
    targets = list(signal.get("targets") or [])
    entry = entries[0] if entries else signal.get("entry")
    if entry in {None, ""} or signal.get("stop") in {None, ""} or not targets:
        raise ValueError("سطوح این سیگنال برای معامله آزمایشی کامل نیست.")
    return open_paper_trade(
        db,
        user_id,
        arena["accounts"][0]["id"],
        symbol=str(signal.get("symbol") or ""),
        side=str(signal.get("side") or "").lower(),
        entry=float(entry),
        stop=float(signal["stop"]),
        targets=[float(value) for value in targets],
        risk_percent=min(
            max(float(str(signal.get("risk") or 1).replace("%", "").strip()), 0.1),
            5,
        ),
        signal_id=signal_id,
    )


async def paper_open_signal(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> None:
    query = update.callback_query
    signal_id = int(str(query.data or "").split(":", 1)[1])
    try:
        trade = await async_with_db(
            lambda db: _open_signal_as_paper_trade(
                db, query.from_user.id, signal_id
            )
        )
    except (ValueError, PermissionError, TypeError) as exc:
        await query.answer(str(exc), show_alert=True)
        return
    await query.answer(
        f"معامله آزمایشی #{trade['id']} ثبت شد ✅", show_alert=True
    )
    await _show_paper_arena(query, query.from_user.id)


async def paper_close_trade(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> None:
    query = update.callback_query
    _, trade_id, outcome = str(query.data or "").split(":", 2)

    def close_at_selected_level(db: dict[str, Any]) -> dict[str, Any]:
        trade = next(
            (
                row
                for row in db.get("paper_trades", [])
                if int(row.get("id", 0) or 0) == int(trade_id)
                and str(row.get("user_id")) == str(query.from_user.id)
            ),
            None,
        )
        if not trade:
            raise ValueError("معامله باز پیدا نشد.")
        if outcome.startswith("tp") and outcome[2:].isdigit():
            return paper_trade_action(db, query.from_user.id, trade_id, outcome)
        if outcome.startswith("cancel_tp") and outcome[9:].isdigit():
            return paper_trade_action(
                db, query.from_user.id, trade_id, "cancel_target",
                target_index=int(outcome[9:]),
            )
        mapped = {"be": "breakeven", "sl": "sl", "cancel": "cancel"}
        return paper_trade_action(
            db, query.from_user.id, trade_id, mapped.get(outcome, outcome)
        )

    try:
        trade = await async_with_db(close_at_selected_level)
    except (ValueError, PermissionError, TypeError) as exc:
        await query.answer(str(exc), show_alert=True)
        return
    await query.answer(
        f"وضعیت معامله به‌روزرسانی شد: {trade.get('status')} · {trade.get('realized_r', trade.get('result_r', 0))}R",
        show_alert=True,
    )
    await _show_paper_arena(query, query.from_user.id)


def _prop_guardian_content(
    db: dict[str, Any], user_id: int | str
) -> tuple[str, list[list[InlineKeyboardButton]]]:
    try:
        from services.prop_guardian_service import prop_guardian_dashboard
        dashboard = prop_guardian_dashboard(user_id, record=True)
    except (ValueError, PermissionError):
        dashboard = {"accounts": [], "status": "unconfigured", "summary": {}}
    accounts = dashboard.get("accounts") or []
    if not accounts:
        return (
            "🛡 <b>نگهبان پراپ</b>\n\nابتدا یک حساب معاملاتی در RISK OS بسازید؛ سپس می‌توانید MT5 را فقط‌خواندنی متصل کنید.",
            [[InlineKeyboardButton("⬅️ برگشت", callback_data="nav_user:tools", style="danger")]],
        )
    row = accounts[0]
    account = row.get("account") or {}
    capacity = row.get("capacity") or {}
    broker = row.get("broker_positions") or {}
    connector = row.get("connector") or {}
    def cap(name: str) -> dict[str, Any]:
        return capacity.get(name) if isinstance(capacity.get(name), dict) else {}
    lines = [
        "🛡 <b>نگهبان زنده حساب پراپ</b>", "",
        f"حساب: <b>{esc(account.get('name') or account.get('id') or '—')}</b>",
        f"وضعیت: <b>{esc(row.get('status') or 'unconfigured')}</b>",
        f"اتصال MT5: <b>{esc(connector.get('status') or 'offline')}</b> | {esc(connector.get('account_login_masked') or '—')}", "",
        f"افت روزانه: <b>{cap('daily_loss').get('actual', 0)}%</b> | باقی‌مانده <b>{cap('daily_loss').get('remaining', 0)}%</b>",
        f"افت کل: <b>{cap('total_drawdown').get('actual', 0)}%</b> | باقی‌مانده <b>{cap('total_drawdown').get('remaining', 0)}%</b>",
        f"ریسک باز: <b>{cap('open_risk').get('actual', 0)}%</b> | باقی‌مانده <b>{cap('open_risk').get('remaining', 0)}%</b>",
        f"معاملات باز: <b>{broker.get('open_count', 0)}</b> | بدون SL: <b>{broker.get('missing_stop_count', 0)}</b>",
        f"اگر همه SLها بخورند: <b>{(row.get('what_if') or {}).get('all_stops_loss_amount', 0):,.2f} {esc(account.get('currency') or 'USD')}</b>", "",
    ]
    alerts = row.get("alerts") or []
    if alerts:
        lines.append("<b>هشدارهای فعال</b>")
        lines.extend(f"• {esc(item.get('title_fa') or item.get('code') or 'هشدار')}" for item in alerts[:8])
    else:
        lines.append("✅ هشدار فعالی وجود ندارد.")
    rows = [[InlineKeyboardButton("🎮 معامله آزمایشی", callback_data="u_paper_arena")], [InlineKeyboardButton("⬅️ برگشت", callback_data="nav_user:tools", style="danger")]]
    return "\n".join(lines), rows


async def _show_prop_guardian(query: Any, user_id: int | str) -> None:
    text, rows = _prop_guardian_content(await async_snapshot(), user_id)
    await edit(query, text, rows)


async def u_prop_guardian(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    try:
        text, rows = _prop_guardian_content(
            await async_snapshot(), query.from_user.id
        )
    except (ValueError, PermissionError) as exc:
        await query.answer(str(exc), show_alert=True)
        return
    await query.answer()
    await edit(query, text, rows)


async def prop_configure_default(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> None:
    query = update.callback_query
    account_id = int(str(query.data or "").split(":", 1)[1])
    try:
        await async_with_db(
            lambda db: configure_prop_challenge(
                db,
                query.from_user.id,
                account_id,
                {
                    "daily_loss_limit_percent": 5,
                    "total_loss_limit_percent": 10,
                    "profit_target_percent": 8,
                    "min_trading_days": 5,
                    "max_risk_per_trade_percent": 2,
                    "news_trading_allowed": True,
                    "weekend_holding_allowed": True,
                },
            )
        )
    except (ValueError, PermissionError) as exc:
        await query.answer(str(exc), show_alert=True)
        return
    await query.answer("قوانین استاندارد پراپ فعال شد ✅", show_alert=True)
    await _show_prop_guardian(query, query.from_user.id)


async def u_public_performance(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    db = await async_snapshot()
    try:
        result = verified_public_performance(db)
    except PermissionError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    await query.answer()
    text = (
        "📊 <b>عملکرد عمومی قابل راستی‌آزمایی</b>\n\n"
        f"سیگنال نهایی: <b>{result['total']}</b>\n"
        f"برد: <b>{result['wins']}</b> | باخت: <b>{result['losses']}</b>\n"
        f"Win Rate: <b>{result['win_rate']}%</b> | Net R: <b>{result['net_r']}</b>\n"
        f"اصلاحات ثبت‌شده: <b>{result['revision_count']}</b>\n\n"
        f"Evidence: <code>{esc(result['evidence_hash'][:24])}…</code>"
    )
    await edit(query, text, [[InlineKeyboardButton("🧭 مرکز تمرین معامله و ریسک", callback_data="u_bot_tools")], [InlineKeyboardButton("↩️ مرکز قبلی", callback_data="nav_user:markets")]])


def _bot_tools_content() -> tuple[str, list[list[InlineKeyboardButton]]]:
    return (
        "🧭 <b>مرکز تمرین معامله و مدیریت ریسک</b>\n\n"
        "ابزارهای تکراری در یک مسیر ادغام شدند و هم داخل ربات و هم Mini App کار می‌کنند:\n\n"
        "• حساب و معامله آزمایشی چندهدفه\n"
        "• TPهای متعدد، خروج بخشی، سر‌به‌سر، SL و لغو تارگت/معامله\n"
        "• نگهبان قوانین پراپ\n"
        "• مربی رفتار متصل به سیگنال‌های گرفته‌شده\n"
        "• عملکرد عمومی قابل راستی‌آزمایی",
        [
            [
                InlineKeyboardButton("🎮 معامله آزمایشی", callback_data="u_paper_arena"),
                InlineKeyboardButton("🛡 نگهبان پراپ", callback_data="u_prop_guardian"),
            ],
            [InlineKeyboardButton("🧭 مربی ریسک", callback_data="u_risk_coach")],
            [
                InlineKeyboardButton("📊 عملکرد عمومی", callback_data="u_public_performance"),
            ],
            [InlineKeyboardButton("↩️ آزمایشگاه ریسک و تمرین", callback_data="nav_user:tools", style="primary")],
        ],
    )


async def u_bot_tools(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    text, rows = _bot_tools_content()
    await edit(query, text, rows)


async def tools_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    text, rows = _bot_tools_content()
    await reply(update, text, rows)


async def paper_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    try:
        text, rows = _paper_arena_content(
            await async_snapshot(), update.effective_user.id
        )
    except (ValueError, PermissionError) as exc:
        await reply(update, f"⛔️ {esc(exc)}")
        return
    await reply(update, text, rows)


async def prop_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    try:
        text, rows = _prop_guardian_content(
            await async_snapshot(), update.effective_user.id
        )
    except (ValueError, PermissionError) as exc:
        await reply(update, f"⛔️ {esc(exc)}")
        return
    await reply(update, text, rows)


async def copilot_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> str | int:
    language = user_language(await run_blocking(load_db, timeout=10), update.effective_user.id) or "fa"
    from modules.gemini_ai import user_ai_access

    access = user_ai_access(update.effective_user.id)
    if not access.get("allowed"):
        await reply(
            update,
            "⛔️ Gemini is available to VIP users only."
            if language == "en"
            else "⛔️ دسترسی Gemini در حالت فعلی فقط برای کاربران VIP فعال است.",
        )
        return ConversationHandler.END
    context.user_data["sentinel_ai_chat"] = {"role": "user", "scope": "personal", "language": language}
    text, rows = _user_ai_chat_prompt(language)
    await reply(update, text, rows)
    return "AI_CHAT_INPUT"


async def ai_asset_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, "ai_command_center"):
        return
    context.user_data["awaiting_ai_asset"] = True
    await reply(
        update,
        "🖼 <b>ثبت فایل برای فرماندهی Gemini</b>\n\n"
        "عکس JPG، PNG یا WEBP را بفرست. پس از ذخیره می‌توانی بگویی:\n"
        "<code>/adminai signals آخرین عکس را قالب BUY قرار بده و آخرین سیگنال را در کانال بازسازی کن</code>",
        [[InlineKeyboardButton("⬅️ مرکز AI", callback_data="a_ai_command_center", style="danger")]],
    )


async def ai_asset_capture(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not context.user_data.get("awaiting_ai_asset"):
        return
    if not await require_admin(update, "ai_command_center"):
        context.user_data.pop("awaiting_ai_asset", None)
        return
    message = update.effective_message
    telegram_file = None; original_name = "asset.jpg"; mime_type = "image/jpeg"; file_id = ""
    if message.photo:
        item = message.photo[-1]; file_id = item.file_id; telegram_file = await context.bot.get_file(item.file_id)
    elif message.document:
        file_id = message.document.file_id; original_name = message.document.file_name or "asset.bin"; mime_type = message.document.mime_type or ""; telegram_file = await context.bot.get_file(message.document.file_id)
    if telegram_file is None:
        await reply(update, "⛔️ فقط تصویر JPG، PNG یا WEBP قابل ثبت است.")
        return
    payload = bytes(await telegram_file.download_as_bytearray())
    try:
        from modules.admin_ai_assets import register_admin_ai_asset
        row = await async_with_db(lambda db: register_admin_ai_asset(db, update.effective_user.id, payload, original_name=original_name, mime_type=mime_type, telegram_file_id=file_id))
    except Exception as exc:
        await reply(update, f"⛔️ ذخیره فایل ناموفق بود: <code>{esc(str(exc))}</code>")
        return
    context.user_data.pop("awaiting_ai_asset", None)
    await reply(
        update,
        "✅ <b>فایل در کتابخانه فرماندهی ذخیره شد.</b>\n\n"
        f"Asset ID: <code>{row.get('id')}</code>\n"
        f"نام: <code>{esc(row.get('original_name'))}</code>\n\n"
        "اکنون می‌توانی با <code>/adminai</code> بگویی این فایل قالب BUY/SELL شود یا روی پیام کانال اعمال شود.",
    )


_ADMIN_AI_SCOPE_LABELS = {
    "management": "مدیریت و گزارش",
    "crm": "CRM و کمپین",
    "user_behavior": "رفتار کاربران",
    "channel": "کانال و محتوا",
    "tickets": "پشتیبانی و تیکت",
    "signals": "سیگنال‌ها",
    "risk": "ریسک و پراپ",
    "system": "سلامت سیستم",
    "knowledge": "دانش Sentinel",
}


async def a_ai_chat_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> str | int:
    if not await require_admin(update, "ai_command_center"):
        return ConversationHandler.END
    query = update.callback_query
    from modules.admin_access import AI_SCOPE_PERMISSIONS, has_permission

    db = await async_snapshot()
    available = (
        list(AI_SCOPE_PERMISSIONS)
        if is_primary_admin(query.from_user.id)
        else [
            scope for scope, permission in AI_SCOPE_PERMISSIONS.items()
            if has_permission(db, query.from_user.id, permission)
        ]
    )
    if not available:
        await query.answer("برای هیچ حوزه‌ای مجوز گفت‌وگوی مدیریتی ندارید.", show_alert=True)
        return ConversationHandler.END
    if is_primary_admin(query.from_user.id):
        _set_ai_chat_state(context, {"role": "admin", "scope": "management", "language": "fa"})
        await query.answer()
        await edit(
            query,
            "🧠 <b>Gemini مدیر آماده است</b>\n\n"
            "فرمان خود را مستقیم بفرستید. Gemini موضوع را از متن تشخیص می‌دهد، داده و ابزار مرتبط "
            "Sentinel را پیدا می‌کند، عملیات ثبت‌شده را اجرا می‌کند و نتیجه واقعی اجرا را گزارش می‌دهد.\n\n"
            "نمونه: «تیکت‌های باز را بررسی کن»، «پلن شماره ۳ را غیرفعال کن» یا «این سیگنال را منتشر کن».\n\n"
            "<i>گفت‌وگو فقط با دکمه پایان گفتگو بسته می‌شود.</i>",
            [[
                InlineKeyboardButton("🏠 منوی اصلی", callback_data="ai_chat_home:admin", style="primary"),
                InlineKeyboardButton("✖️ پایان گفتگو", callback_data="ai_chat_stop:admin", style="danger"),
            ]],
        )
        return "AI_CHAT_INPUT"

    _set_ai_chat_state(context, {"role": "admin", "scope": "", "language": "fa"})
    rows: list[list[InlineKeyboardButton]] = []
    for index in range(0, len(available), 2):
        rows.append([
            InlineKeyboardButton(_ADMIN_AI_SCOPE_LABELS[scope], callback_data=f"a_ai_chat_scope:{scope}")
            for scope in available[index:index + 2]
        ])
    rows.append([
        InlineKeyboardButton("🏠 منوی اصلی", callback_data="ai_chat_home:admin", style="primary"),
        InlineKeyboardButton("✖️ پایان گفتگو", callback_data="ai_chat_stop:admin", style="danger"),
    ])
    await query.answer()
    await edit(
        query,
        "🧠 <b>گفت‌وگو و فرمان مدیریتی با Gemini</b>\n\n"
        "حوزه را انتخاب کنید. بعد از آن می‌توانید پشت سر هم سؤال بپرسید یا فرمان عملیاتی بدهید. "
        "هر اقدام از فهرست مجاز، کنترل دسترسی و Audit عبور می‌کند؛ اقدامات حساس مشخص‌شده "
        "تا تأیید انسانی اجرا نمی‌شوند.",
        rows,
    )
    return "AI_CHAT_SCOPE"


async def a_ai_chat_scope(update: Update, context: ContextTypes.DEFAULT_TYPE) -> str | int:
    query = update.callback_query
    scope = str(query.data or "").split(":", 1)[1]
    from modules.admin_access import AI_SCOPE_PERMISSIONS

    permission = AI_SCOPE_PERMISSIONS.get(scope)
    if not permission or not await require_admin(update, permission):
        return ConversationHandler.END
    _set_ai_chat_state(context, {"role": "admin", "scope": scope, "language": "fa"})
    await query.answer()
    await edit(
        query,
        "💬 <b>Gemini آماده دریافت فرمان است</b>\n\n"
        f"حوزه فعال: <b>{esc(_ADMIN_AI_SCOPE_LABELS.get(scope, scope))}</b>\n\n"
        "پیام مدیریتی خود را ارسال کنید؛ برای نمونه:\n"
        "• یک کمپین برای کاربران غیرفعال بساز\n"
        "• یک کد تخفیف عمومی ۱۵ درصدی هفت‌روزه با کد WELCOME15 بساز\n"
        "• وضعیت تیکت‌های باز را بررسی و پاسخ پیشنهادی آماده کن\n\n"
        "<i>برای ادمین اصلی، عملیات ثبت‌شده ربات شامل پرداخت، رسید، VIP، تخفیف و سیگنال فعال است. Shell، SQL آزاد، Deploy و کلیدهای محرمانه ابزار Gemini نیستند.</i>",
        [[InlineKeyboardButton("✖️ پایان گفتگو", callback_data="ai_chat_stop:admin", style="danger")]],
    )
    return "AI_CHAT_INPUT"


def _admin_ai_result_rows(result: dict[str, Any], actor_id: int | str) -> list[list[InlineKeyboardButton]]:
    execution = result.get("execution") if isinstance(result.get("execution"), dict) else {}
    rows: list[list[InlineKeyboardButton]] = []
    if is_primary_admin(actor_id):
        for item in (execution.get("queued") or [])[:5]:
            if not isinstance(item, dict) or not item.get("id"):
                continue
            command_id = int(item["id"])
            rows.append([
                InlineKeyboardButton(f"✅ تأیید #{command_id}", callback_data=f"ai_cmd_approve:{command_id}", style="success"),
                InlineKeyboardButton(f"❌ رد #{command_id}", callback_data=f"ai_cmd_reject:{command_id}", style="danger"),
            ])
    rows.append([InlineKeyboardButton("✖️ پایان گفتگو", callback_data="ai_chat_stop:admin", style="danger")])
    return rows


def _admin_ai_execution_summary(result: dict[str, Any]) -> str:
    execution = result.get("execution") if isinstance(result.get("execution"), dict) else {}
    lines: list[str] = []
    for row in list(execution.get("executions") or [])[:10]:
        if not isinstance(row, dict):
            continue
        action = esc(str(row.get("action") or "operation"))
        status = str(row.get("status") or "unknown")
        if status == "executed":
            detail = row.get("result") if isinstance(row.get("result"), dict) else row.get("detail")
            compact = ""
            if isinstance(detail, dict):
                compact = str(
                    detail.get("message")
                    or detail.get("status")
                    or detail.get("order_id")
                    or detail.get("id")
                    or ""
                )[:160]
            lines.append(f"• ✅ <code>{action}</code>" + (f" — {esc(compact)}" if compact else ""))
        else:
            error = str(row.get("error") or row.get("detail") or "ناموفق")[:180]
            lines.append(f"• ❌ <code>{action}</code> — {esc(error)}")
    for row in list(execution.get("queued") or [])[:5]:
        if isinstance(row, dict):
            lines.append(f"• 🕒 <code>{esc(str(row.get('action') or 'operation'))}</code> — منتظر تأیید")
    if result.get("execution_requested") and not lines:
        lines.append("• ⚠️ ابزار اجرایی معتبر تولید نشد؛ هیچ تغییری در ربات ثبت نشد.")
    return "\n".join(lines)


def _infer_primary_admin_ai_scope(question: str, current_scope: str, actor_id: int | str) -> str:
    """Infer scope independently for every primary-admin message.

    A delegated administrator remains pinned to the explicitly authorized
    scope. The primary owner is routed statelessly so an earlier risk, ticket or
    signal request can never contaminate the next unrelated command.
    """
    selected = str(current_scope or "management").strip().lower()
    if not is_primary_admin(actor_id):
        return selected
    from modules.gemini_command_router import infer_admin_scope
    return infer_admin_scope(question, default="management")



def _format_admin_search_result(result: dict[str, Any]) -> str:
    items = list(result.get("items") or [])
    if not items:
        return (
            "🔎 <b>جست‌وجوی سراسری Sentinel</b>\n\n"
            f"برای <code>{esc(str(result.get('query') or ''))}</code> نتیجه‌ای در حوزه‌های مجاز پیدا نشد."
        )
    lines = [
        "🔎 <b>نتایج جست‌وجوی سراسری</b>",
        "",
        f"عبارت: <code>{esc(str(result.get('query') or ''))}</code>",
        f"نتیجه قابل‌مشاهده: <b>{int(result.get('total', len(items)) or 0)}</b>",
        "",
    ]
    for index, item in enumerate(items[:20], start=1):
        title = esc(str(item.get("title") or item.get("id") or "—")[:160])
        subtitle = esc(str(item.get("subtitle") or "")[:220])
        label = esc(str(item.get("domain_label") or item.get("type") or "داده"))
        row_id = esc(str(item.get("id") or ""))
        lines.append(f"{index}. <b>{title}</b> · {label}")
        if subtitle:
            lines.append(f"   {subtitle}")
        if row_id:
            lines.append(f"   ID: <code>{row_id}</code>")
    if len(items) > 20:
        lines.append(f"\n… {len(items) - 20} نتیجه دیگر با فیلتر دقیق‌تر قابل مشاهده است.")
    return "\n".join(lines)[:3900]


def _admin_search_result_rows(result: dict[str, Any]) -> list[list[InlineKeyboardButton]]:
    """Build compact, actionable navigation for search results."""
    rows: list[list[InlineKeyboardButton]] = []
    for index, item in enumerate(list(result.get("items") or [])[:10], start=1):
        callback = str(item.get("open_callback") or "").strip()
        if not callback or len(callback.encode("utf-8")) > 64:
            continue
        title = str(item.get("title") or item.get("id") or "نتیجه").strip()
        label = f"{index}. بازکردن {title}"[:60]
        rows.append([InlineKeyboardButton(label, callback_data=callback, style="primary")])
        if len(rows) >= 6:
            break
    rows.append([
        InlineKeyboardButton("🔎 جست‌وجوی جدید", callback_data="a_admin_search", style="primary"),
        InlineKeyboardButton("✖️ پایان", callback_data="ai_chat_stop:admin", style="danger"),
    ])
    return rows


async def a_admin_search_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> str | int:
    if not await require_admin(update, "ai_command_center"):
        return ConversationHandler.END
    query = update.callback_query
    _set_ai_chat_state(
        context,
        {"role": "admin", "scope": "management", "language": "fa", "search_mode": True},
    )
    await query.answer()
    await edit(
        query,
        "🔎 <b>جست‌وجوی سراسری Sentinel</b>\n\n"
        "نام، شناسه تلگرام، شماره سیگنال، نماد، TXID، رسید، تیکت، متن CRM، تبلیغ، آموزش، مسابقه، "
        "اتوماسیون، ادمین، لاگ یا عبارت تقریبی—even با غلط املایی—را بفرستید.\n\n"
        "جست‌وجو فقط اطلاعاتی را نمایش می‌دهد که مجوز مشاهده آن‌ها را دارید. فرمان صوتی نیز قابل استفاده است.",
        [[
            InlineKeyboardButton("🧠 دستیار اجرایی", callback_data="a_ai_chat_start", style="primary"),
            InlineKeyboardButton("✖️ پایان", callback_data="ai_chat_stop:admin", style="danger"),
        ]],
    )
    return "AI_CHAT_INPUT"


async def admin_search_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> str | int:
    if not await require_admin(update, "ai_command_center"):
        return ConversationHandler.END
    query = " ".join(context.args or []).strip()
    if not query:
        _set_ai_chat_state(
            context,
            {"role": "admin", "scope": "management", "language": "fa", "search_mode": True},
        )
        await reply(
            update,
            "🔎 عبارت جست‌وجو را بفرستید. می‌توانید متن یا فرمان صوتی ارسال کنید.",
            [[InlineKeyboardButton("✖️ پایان", callback_data="ai_chat_stop:admin", style="danger")]],
        )
        return "AI_CHAT_INPUT"
    try:
        from modules.admin_command_os import admin_global_search
        result = await run_blocking(admin_global_search, await async_snapshot(), update.effective_user.id, query, limit=30)
    except (ValueError, PermissionError) as exc:
        await reply(update, f"⛔️ {esc(str(exc))}")
        return ConversationHandler.END
    await reply(update, _format_admin_search_result(result), _admin_search_result_rows(result))
    return ConversationHandler.END


async def _execute_confirmed_voice_transcript(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
    transcript: str,
    state: dict[str, Any],
) -> str | int:
    if state.get("search_mode"):
        from modules.admin_command_os import admin_global_search
        result = await run_blocking(
            admin_global_search,
            await async_snapshot(),
            update.effective_user.id,
            transcript,
            limit=30,
        )
        await reply(
            update,
            _format_admin_search_result(result),
            _admin_search_result_rows(result),
        )
        return "AI_CHAT_INPUT"
    scope = _infer_primary_admin_ai_scope(transcript, str(state.get("scope") or "management"), update.effective_user.id)
    from modules.gemini_ai import admin_ai_query
    result = await run_blocking(
        admin_ai_query,
        update.effective_user.id,
        transcript,
        scope=scope,
        language=str(state.get("language") or "fa"),
    )
    execution = result.get("execution") if isinstance(result.get("execution"), dict) else {}
    executed = sum(1 for row in execution.get("executions", []) if isinstance(row, dict) and row.get("status") == "executed")
    failed = sum(1 for row in execution.get("executions", []) if isinstance(row, dict) and row.get("status") == "failed")
    queued = len(execution.get("queued", []) or [])
    detail = _admin_ai_execution_summary(result)
    await reply(
        update,
        "🧠 <b>نتیجه فرمان صوتی</b>\n\n"
        f"{esc(str(result.get('answer') or '')[:3100])}\n\n"
        f"✅ اجراشده: <b>{executed}</b> · ❌ ناموفق: <b>{failed}</b> · 🕒 منتظر تأیید: <b>{queued}</b>"
        + (f"\n\n<b>نتیجه عملیات</b>\n{detail}" if detail else ""),
        _admin_ai_result_rows(result, update.effective_user.id),
    )
    return "AI_CHAT_INPUT"


async def ai_chat_voice_router(update: Update, context: ContextTypes.DEFAULT_TYPE) -> str | int:
    state = await _restore_ai_chat_state(update, context)
    if str(state.get("role") or "") != "admin":
        await reply(update, "فرمان صوتی فقط در دستیار اجرایی ادمین فعال است.")
        return "AI_CHAT_INPUT"
    if not await require_admin(update, "ai_command_center"):
        return "AI_CHAT_INPUT"
    message = update.effective_message
    voice = getattr(message, "voice", None)
    if voice is None:
        await reply(update, "⛔️ فایل صوتی معتبر دریافت نشد.")
        return "AI_CHAT_INPUT"
    from config import SETTINGS
    duration = int(getattr(voice, "duration", 0) or 0)
    file_size = int(getattr(voice, "file_size", 0) or 0)
    if duration and duration > int(SETTINGS.gemini_voice_max_seconds):
        await reply(update, f"⛔️ فرمان صوتی باید حداکثر {SETTINGS.gemini_voice_max_seconds} ثانیه باشد.")
        return "AI_CHAT_INPUT"
    if file_size and file_size > int(SETTINGS.gemini_voice_max_bytes):
        await reply(update, "⛔️ حجم فایل صوتی از سقف مجاز بیشتر است.")
        return "AI_CHAT_INPUT"
    try:
        telegram_file = await context.bot.get_file(voice.file_id)
        payload = bytes(await telegram_file.download_as_bytearray())
        from modules.gemini_ai import gemini_transcribe_admin_audio
        transcription = await run_blocking(
            gemini_transcribe_admin_audio,
            update.effective_user.id,
            payload,
            mime_type=str(getattr(voice, "mime_type", None) or "audio/ogg"),
            language=str(state.get("language") or "fa"),
        )
        transcript = str(transcription.get("transcript") or "").strip()
        if not transcript:
            raise RuntimeError("VOICE_TRANSCRIPT_EMPTY")
        token = uuid.uuid4().hex[:16]
        context.user_data["pending_ai_voice_command"] = {
            "token": token,
            "transcript": transcript[:6000],
            "state": {
                "role": "admin",
                "scope": str(state.get("scope") or "management"),
                "language": str(state.get("language") or "fa"),
                "search_mode": bool(state.get("search_mode")),
            },
            "user_id": int(update.effective_user.id),
            "expires_at": time.time() + 300,
        }
        await reply(
            update,
            "🎙 <b>متن تشخیص‌داده‌شده</b>\n\n"
            f"{esc(transcript[:3500])}\n\n"
            "قبل از اجرا متن را بررسی کنید. تا زمانی که «تأیید و اجرا» را نزنید، هیچ فرمانی اجرا نمی‌شود.",
            [[
                InlineKeyboardButton("✅ تأیید و اجرا", callback_data=f"ai_voice_confirm:{token}", style="success"),
                InlineKeyboardButton("✖️ لغو", callback_data=f"ai_voice_cancel:{token}", style="danger"),
            ]],
        )
    except (ValueError, PermissionError, RuntimeError) as exc:
        await reply(update, f"⛔️ پردازش فرمان صوتی ناموفق بود: {esc(str(exc))}")
    except Exception:
        ref = uuid.uuid4().hex[:10].upper()
        logger.exception("Admin voice transcription failed ref=%s", ref)
        await reply(update, f"⛔️ فرمان صوتی کامل نشد. کد پیگیری: <code>{ref}</code>")
    return "AI_CHAT_INPUT"


async def ai_voice_transcript_action(update: Update, context: ContextTypes.DEFAULT_TYPE) -> str | int:
    query = update.callback_query
    if not await require_admin(update, "ai_command_center"):
        return "AI_CHAT_INPUT"
    data = str(query.data or "")
    action, _, token = data.partition(":")
    pending = context.user_data.get("pending_ai_voice_command")
    if not isinstance(pending, dict) or token != str(pending.get("token") or ""):
        await query.answer("این فرمان منقضی شده یا قبلاً استفاده شده است.", show_alert=True)
        return "AI_CHAT_INPUT"
    if int(pending.get("user_id") or 0) != int(update.effective_user.id) or float(pending.get("expires_at") or 0) < time.time():
        context.user_data.pop("pending_ai_voice_command", None)
        await query.answer("اعتبار فرمان صوتی پایان یافته است.", show_alert=True)
        return "AI_CHAT_INPUT"
    context.user_data.pop("pending_ai_voice_command", None)  # one-time token; prevents double execution
    if action == "ai_voice_cancel":
        await query.answer("لغو شد")
        await edit(query, "✖️ فرمان صوتی بدون اجرا لغو شد.")
        return "AI_CHAT_INPUT"
    if action != "ai_voice_confirm":
        await query.answer("عملیات نامعتبر است.", show_alert=True)
        return "AI_CHAT_INPUT"
    await query.answer("در حال اجرا…")
    await edit(query, "⏳ فرمان صوتی تأیید شد و در حال اجرا است…")
    try:
        transcript = str(pending.get("transcript") or "").strip()
        state = pending.get("state") if isinstance(pending.get("state"), dict) else {}
        return await _execute_confirmed_voice_transcript(update, context, transcript, state)
    except (ValueError, PermissionError, RuntimeError) as exc:
        await reply(update, f"⛔️ اجرای فرمان صوتی ناموفق بود: {esc(str(exc))}")
    except Exception:
        ref = uuid.uuid4().hex[:10].upper()
        logger.exception("Confirmed admin voice command failed ref=%s", ref)
        await reply(update, f"⛔️ فرمان صوتی کامل نشد. کد پیگیری: <code>{ref}</code>")
    return "AI_CHAT_INPUT"


async def ai_chat_message_router(update: Update, context: ContextTypes.DEFAULT_TYPE) -> str | int:
    state = await _restore_ai_chat_state(update, context)
    question = str(update.effective_message.text or "").strip()
    if not 2 <= len(question) <= 4000:
        await reply(update, "پیام باید بین ۲ تا ۴۰۰۰ کاراکتر باشد.")
        return "AI_CHAT_INPUT"
    role = str(state.get("role") or "")
    language = str(state.get("language") or "fa")
    scope = str(state.get("scope") or "management")
    if role == "admin" and state.get("search_mode"):
        try:
            from modules.admin_command_os import admin_global_search
            result = await run_blocking(admin_global_search, await async_snapshot(), update.effective_user.id, question, limit=30)
            await reply(
                update,
                _format_admin_search_result(result),
                _admin_search_result_rows(result),
            )
        except (ValueError, PermissionError) as exc:
            await reply(update, f"⛔️ {esc(str(exc))}")
        return "AI_CHAT_INPUT"
    if role == "admin":
        scope = _infer_primary_admin_ai_scope(question, scope, update.effective_user.id)
        state["scope"] = scope
        _set_ai_chat_state(context, state)
    try:
        if role == "user":
            from modules.gemini_ai import user_ai_query, user_ai_question_allowed
            if not user_ai_question_allowed(question):
                await reply(
                    update,
                    "برای دریافت پاسخ دقیق، یکی از سؤال‌های آماده را انتخاب کنید." if language != "en" else "Choose one of the preset questions for an accurate answer.",
                    _user_ai_preset_rows(language),
                )
                return "AI_CHAT_INPUT"
            result = await run_blocking(
                user_ai_query, update.effective_user.id, question, language=language
            )
            engine = "Gemini" if result.get("engine") == "google-gemini" else "SENTINEL Local"
            await reply(
                update,
                (
                    "🧠 <b>Gemini</b>\n\n"
                    f"{esc(str(result.get('answer') or '')[:3500])}\n\n"
                    f"<i>Engine: {esc(engine)} · chat stays inside Telegram</i>"
                    if language == "en"
                    else
                    "🧠 <b>Gemini</b>\n\n"
                    f"{esc(str(result.get('answer') or '')[:3500])}\n\n"
                    f"<i>موتور: {esc(engine)} · پاسخ داخل خود تلگرام</i>"
                ),
_user_ai_preset_rows(language),
            )
            return "AI_CHAT_INPUT"

        from modules.admin_access import AI_SCOPE_PERMISSIONS

        if not await require_admin(update, "ai_command_center"):
            await reply(update, "⛔️ دسترسی فرماندهی Gemini برای این حساب فعال نیست.")
            return "AI_CHAT_INPUT"
        if not await require_admin(update, AI_SCOPE_PERMISSIONS.get(scope, "ai_management_reports")):
            await reply(update, "⛔️ برای حوزه تشخیص‌داده‌شده مجوز ندارید؛ گفت‌وگو همچنان فعال است.")
            return "AI_CHAT_INPUT"
        from modules.gemini_ai import admin_ai_query

        result = await run_blocking(
            admin_ai_query, update.effective_user.id, question, scope=scope, language=language
        )
        execution = result.get("execution") if isinstance(result.get("execution"), dict) else {}
        executed = sum(
            1 for row in execution.get("executions", [])
            if isinstance(row, dict) and row.get("status") == "executed"
        )
        failed = sum(
            1 for row in execution.get("executions", [])
            if isinstance(row, dict) and row.get("status") == "failed"
        )
        queued = len(execution.get("queued", []) or [])
        execution_detail = _admin_ai_execution_summary(result)
        await reply(
            update,
            "🧠 <b>پاسخ Gemini مدیر</b>\n\n"
            f"{esc(str(result.get('answer') or '')[:3200])}\n\n"
            f"✅ اجراشده: <b>{executed}</b> · ❌ ناموفق: <b>{failed}</b> · "
            f"🕒 منتظر تأیید: <b>{queued}</b>"
            + (f"\n\n<b>نتیجه عملیات</b>\n{execution_detail}" if execution_detail else ""),
            _admin_ai_result_rows(result, update.effective_user.id),
        )
        return "AI_CHAT_INPUT"
    except (ValueError, PermissionError, RuntimeError) as exc:
        error = str(exc)
        messages = {
            "AI_VIP_REQUIRED": "دسترسی Gemini فقط برای کاربران VIP فعال است.",
            "AI_USER_ASSISTANT_DISABLED": "دستیار Gemini کاربران غیرفعال است.",
            "AI_FINANCIAL_ACCESS_BLOCKED": "این عملیات برای حساب کاربری عادی مجاز نیست؛ از مرکز فرماندهی ادمین اصلی استفاده کنید.",
            "AI_SCOPE_DISABLED": "این حوزه Gemini غیرفعال است.",
            "AI_DAILY_REQUEST_LIMIT_REACHED": "سقف درخواست روزانه Gemini تکمیل شده است؛ پاسخ بازیابی Sentinel فعال شد.",
            "AI_DAILY_TOKEN_LIMIT_REACHED": "سقف مصرف روزانه Gemini تکمیل شده است؛ پاسخ بازیابی Sentinel فعال شد.",
            "AI_MONTHLY_TOKEN_LIMIT_REACHED": "سقف مصرف ماهانه Gemini تکمیل شده است؛ پاسخ بازیابی Sentinel فعال شد.",
        }
        await reply(update, f"⛔️ {esc(messages.get(error, error))}")
        return "AI_CHAT_INPUT"
    except Exception:
        # Keep the conversation alive even when an unforeseen provider, parser,
        # persistence, optional-import or tool-execution error occurs. The old
        # behavior leaked this exception to the global Telegram error handler and
        # produced the generic tracking-ID message shown by the user.
        error_ref = uuid.uuid4().hex[:10].upper()
        logger.exception(
            "Gemini in-bot chat recovered from unexpected failure ref=%s role=%s scope=%s",
            error_ref,
            role,
            scope,
        )
        try:
            if role == "admin":
                from modules.gemini_ai import admin_ai_recovery_response

                recovered = await run_blocking(
                    admin_ai_recovery_response,
                    update.effective_user.id,
                    question,
                    scope=scope,
                    language=language,
                    error_ref=error_ref,
                )
                await reply(
                    update,
                    "🧠 <b>پاسخ بازیابی Gemini مدیر</b>\n\n"
                    f"{esc(str(recovered.get('answer') or '')[:3300])}\n\n"
                    "<i>گفت‌وگو فعال است و می‌توانید فرمان بعدی را ارسال کنید.</i>",
                    _admin_ai_result_rows(recovered, update.effective_user.id),
                )
            else:
                await reply(
                    update,
                    (
                        "🧠 Gemini could not complete this response, but the chat remains active. Please send the message again."
                        if language == "en"
                        else "🧠 پاسخ این پیام کامل نشد، اما گفت‌وگو همچنان فعال است. پیام را دوباره ارسال کنید."
                    ),
                    [[InlineKeyboardButton(
                        "✖️ End chat" if language == "en" else "✖️ پایان گفتگو",
                        callback_data="ai_chat_stop:user",
                        style="danger",
                    )]],
                )
        except Exception:
            logger.exception("Gemini recovery response delivery failed ref=%s", error_ref)
            try:
                await update.effective_message.reply_text(
                    "گفت‌وگوی Gemini همچنان فعال است؛ پیام را دوباره ارسال کنید."
                    if language != "en"
                    else "The Gemini chat is still active; please send the message again."
                )
            except TelegramError:
                pass
        return "AI_CHAT_INPUT"


async def user_ai_preset_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> str | int:
    query = update.callback_query
    state = await _restore_ai_chat_state(update, context)
    language = str(state.get("language") or (await run_blocking(_language_for_user, query.from_user.id)))
    key = str(query.data or "").split(":", 1)[1]
    try:
        from modules.gemini_ai import user_ai_preset_question, user_ai_query
        question = user_ai_preset_question(key, language=language)
        await query.answer("در حال بررسی…" if language != "en" else "Reviewing…")
        result = await run_blocking(user_ai_query, query.from_user.id, question, language=language)
    except (ValueError, PermissionError, RuntimeError) as exc:
        await query.answer(str(exc), show_alert=True)
        return "AI_CHAT_INPUT"
    engine = "Gemini" if result.get("engine") == "google-gemini" else "SENTINEL Local"
    await edit(
        query,
        (
            "🧠 <b>Gemini</b>\n\n" + esc(str(result.get("answer") or "")[:3500]) + f"\n\n<i>Engine: {esc(engine)}</i>"
            if language == "en"
            else "🧠 <b>Gemini</b>\n\n" + esc(str(result.get("answer") or "")[:3500]) + f"\n\n<i>موتور: {esc(engine)}</i>"
        ),
        _user_ai_preset_rows(language),
    )
    return "AI_CHAT_INPUT"


async def ai_chat_home(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    _clear_ai_chat_state(context)
    await query.answer()
    await edit(query, (await run_blocking(user_home_text, query.from_user.id)), (await run_blocking(main_menu, query.from_user.id)))
    return ConversationHandler.END


async def ai_chat_stop(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    state = context.user_data.get("sentinel_ai_chat")
    role = (
        str(query.data or "").split(":", 1)[1]
        if str(query.data or "").startswith("ai_chat_stop:")
        else str((state or {}).get("role") or "user")
    )
    _clear_ai_chat_state(context)
    await query.answer("گفت‌وگو پایان یافت")
    await edit(query, (await run_blocking(user_home_text, query.from_user.id)), (await run_blocking(main_menu, query.from_user.id)))
    return ConversationHandler.END


async def admin_ai_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, "ai_command_center"):
        return
    from modules.admin_access import AI_SCOPE_PERMISSIONS

    args = list(context.args or [])
    requested_scope = args[0].strip().lower() if args else ""
    scope = requested_scope if requested_scope in AI_SCOPE_PERMISSIONS else "management"
    if requested_scope == scope:
        args = args[1:]
    # The command center permission only opens the surface. Every analysis scope
    # must independently pass the same granular permission used by the Mini App.
    if not await require_admin(update, AI_SCOPE_PERMISSIONS[scope]):
        return
    question = " ".join(args).strip() or "وضعیت امروز Sentinel را خلاصه کن و مهم‌ترین اقدام‌های مدیریتی را پیشنهاد بده."
    try:
        from modules.gemini_ai import admin_ai_query
        result = await run_blocking(admin_ai_query, update.effective_user.id, question, scope=scope, language="fa")
    except (ValueError, PermissionError, RuntimeError) as exc:
        await reply(update, f"⛔️ {esc(exc)}")
        return
    except Exception:
        error_ref = uuid.uuid4().hex[:10].upper()
        logger.exception("Gemini admin command recovered ref=%s scope=%s", error_ref, scope)
        from modules.gemini_ai import admin_ai_recovery_response
        result = await run_blocking(
            admin_ai_recovery_response,
            update.effective_user.id,
            question,
            scope=scope,
            language="fa",
            error_ref=error_ref,
        )
    proposal_count = len(result.get("proposals") or [])
    execution = result.get("execution") if isinstance(result.get("execution"), dict) else {}
    executed = sum(1 for row in execution.get("executions", []) if isinstance(row, dict) and row.get("status") == "executed")
    failed = sum(1 for row in execution.get("executions", []) if isinstance(row, dict) and row.get("status") == "failed")
    queued = len(execution.get("queued", []) or [])
    mode_label = {
        "primary_autonomous": "اجرای مستقیم ادمین اصلی",
        "primary_approval_required": "در انتظار تأیید ادمین اصلی",
        "execution_disabled": "اجرای AI متوقف",
        "analysis_only": "فقط تحلیل",
    }.get(str(execution.get("mode") or ""), "فقط تحلیل")
    await reply(
        update,
        "🧠 <b>فرماندهی هوشمند Sentinel</b>\n\n"
        f"حوزه: <code>{esc(scope)}</code>\n"
        f"حالت اجرا: <b>{esc(mode_label)}</b>\n\n"
        f"{esc(str(result.get('answer') or '')[:3000])}\n\n"
        f"✅ اجراشده: <b>{executed}</b> | ❌ ناموفق: <b>{failed}</b> | 🕒 منتظر مالک: <b>{queued}</b>\n"
        f"📝 پیش‌نویس‌ها: <b>{proposal_count}</b>\n"
        "<i>ادمین اصلی به عملیات ثبت‌شده مالی، VIP، تخفیف، سیگنال و مدیریت ربات دسترسی مستقیم دارد؛ Shell، SQL آزاد، Deploy و کلیدهای محرمانه خارج از ابزارهای برنامه هستند.</i>",
        [[InlineKeyboardButton("💬 شروع گفت‌وگوی مدیریتی", callback_data="a_ai_chat_start", style="primary")]],
    )


async def a_ai_command_center(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, "ai_command_center"):
        return
    query = update.callback_query
    await query.answer()
    from modules.gemini_ai import ai_runtime_settings, ai_usage_dashboard, gemini_status
    from modules.gemini_admin_control import ai_execution_settings, pending_ai_admin_commands
    status = gemini_status(); settings = ai_runtime_settings(); usage = ai_usage_dashboard(); execution = ai_execution_settings(); pending = pending_ai_admin_commands(limit=100)
    mode = settings.get("user_access_mode", "vip_only")
    text = (
        "🧠 <b>مرکز فرماندهی هوش مصنوعی Sentinel</b>\n\n"
        f"تنظیم: <b>{'فعال' if status.get('enabled') else 'غیرفعال'}</b>\n"
        f"احراز هویت: <b>{'موفق' if status.get('authenticated') else 'تأیید نشده'}</b>\n"
        f"مدل: <code>{esc(status.get('model') or '')}</code>\n"
        f"تأخیر: <b>{esc(status.get('latency_ms') or '—')}</b> ms\n"
        f"آخرین خطا: <code>{esc(status.get('last_error') or 'ندارد')}</code>\n\n"
        f"دسترسی کاربران: <b>{'همه کاربران' if mode == 'all' else 'فقط VIP'}</b>\n"
        f"دکمه Gemini کاربران: <b>{'نمایش داده می‌شود' if settings.get('user_menu_visible', True) else 'پنهان است'}</b>\n"
        f"توکن امروز: <b>{int((usage.get('today') or {}).get('total_tokens', 0) or 0)}</b>\n"
        f"اجرای ابزارها: <b>{'فعال' if execution.get('execution_enabled') else 'متوقف'}</b>\n"
        f"عملیات حساس: <b>{'پیش‌نمایش و تأیید انسانی' if execution.get('confirm_sensitive_actions', True) else 'مطابق سیاست دسترسی'}</b>\n"
        f"دستورهای منتظر مالک: <b>{len(pending)}</b>\n\n"
        "حوزه‌ها: کنترل عملیاتی ربات و مینی‌اپ، CRM، کانال، قالب سیگنال، کاربران، ادمین‌ها، تیکت، آموزش، مسابقات، ریسک، سلامت سیستم، گزارش روزانه و پایگاه دانش.\n\n"
        "✅ ادمین اصلی دسترسی کامل به عملیات ثبت‌شده ربات را از مسیر Action Registry رسمی Sentinel دارد؛ Gemini می‌تواند گزارش بگیرد، پیش‌نویس بسازد و عملیات مجاز را اجرا کند. پرداخت، حذف، تغییر دسترسی و انتشار عمومی همیشه پیش‌نمایش و تأیید انسانی دارند. فرمان صوتی نیز از همین مسیر امن عبور می‌کند. دسترسی خام به Shell، SQL، Deploy و اسرار سرور ارائه نمی‌شود."
    )
    rows = [
        [InlineKeyboardButton("💬 گفت‌وگو و فرمان به Gemini", callback_data="a_ai_chat_start", style="primary")],
        [InlineKeyboardButton("🔎 جست‌وجوی سراسری", callback_data="a_admin_search", style="primary")],
        [InlineKeyboardButton("🎙 فرمان صوتی داخل گفتگو فعال است", callback_data="a_ai_chat_start")],
        [InlineKeyboardButton("🧪 تست زنده Gemini", callback_data="a_ai_health_test", style="primary")],
        [InlineKeyboardButton("📋 گزارش روزانه مدیر", callback_data="a_ai_daily_report")],
        [InlineKeyboardButton(f"👥 دسترسی کاربران: {'همه' if mode == 'all' else 'فقط VIP'}", callback_data="a_ai_access_toggle", style="success" if mode == "all" else "primary")],
        [InlineKeyboardButton(
            "👁 حذف Gemini از منوی کاربر" if settings.get("user_menu_visible", True) else "👁 افزودن Gemini به منوی کاربر",
            callback_data="a_ai_menu_toggle",
            style="danger" if settings.get("user_menu_visible", True) else "success",
        )],
        [InlineKeyboardButton("⛔ توقف اجرای Gemini" if execution.get("execution_enabled") else "✅ فعال‌کردن اجرای Gemini", callback_data="a_ai_execution_toggle", style="danger" if execution.get("execution_enabled") else "success")],
        [InlineKeyboardButton("⬅️ برگشت", callback_data="admin_home", style="danger")],
    ]
    await edit(query, text, rows)


async def a_ai_health_test(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, "ai_system_monitoring"):
        return
    query = update.callback_query; await query.answer("در حال تست زنده…")
    from modules.gemini_ai import gemini_live_health
    health = await run_blocking(gemini_live_health, force=True, generation_test=True)
    await query.answer("اتصال Gemini سالم است ✅" if health.get("status") == "healthy" else f"خطا: {health.get('last_error') or 'نامشخص'}", show_alert=True)
    await a_ai_command_center(update, context)


async def a_ai_access_toggle(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, "ai_confirm_standard_actions"):
        return
    query = update.callback_query; await query.answer()
    from modules.gemini_ai import toggle_user_ai_access_mode
    row = await run_blocking(toggle_user_ai_access_mode, query.from_user.id)
    await query.answer("دسترسی AI برای همه فعال شد" if row.get("user_access_mode") == "all" else "دسترسی AI فقط برای VIP فعال شد", show_alert=True)
    await a_ai_command_center(update, context)


async def a_ai_menu_toggle(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, "ai_confirm_standard_actions"):
        return
    query = update.callback_query
    from modules.gemini_ai import toggle_user_ai_menu_visible
    row = await run_blocking(toggle_user_ai_menu_visible, query.from_user.id)
    await query.answer("دکمه Gemini نمایش داده می‌شود" if row.get("user_menu_visible", True) else "دکمه Gemini پنهان شد", show_alert=True)
    await a_ai_command_center(update, context)


async def a_ai_execution_toggle(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    from config import is_primary_admin

    if not is_primary_admin(query.from_user.id):
        await query.answer("فقط ادمین اصلی می‌تواند اجرای Gemini را متوقف یا فعال کند.", show_alert=True)
        return
    from modules.gemini_admin_control import ai_execution_settings, set_ai_execution_enabled
    current = ai_execution_settings()
    row = await run_blocking(set_ai_execution_enabled, query.from_user.id, not bool(current.get("execution_enabled")))
    await query.answer("اجرای Gemini فعال شد" if row.get("execution_enabled") else "اجرای Gemini فوراً متوقف شد", show_alert=True)
    await a_ai_command_center(update, context)


async def a_ai_daily_report(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, "ai_management_reports"):
        return
    query = update.callback_query; await query.answer("در حال ساخت گزارش…")
    from modules.gemini_ai import build_daily_manager_report
    report = await run_blocking(build_daily_manager_report, query.from_user.id, language="fa", force=True)
    await edit(query, "📋 <b>گزارش روزانه مدیر</b>\n\n" + esc(str(report.get("answer") or "")[:3600]), [[InlineKeyboardButton("⬅️ مرکز AI", callback_data="a_ai_command_center", style="danger")]])


async def ai_command_approve_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    from config import is_primary_admin

    if not is_primary_admin(query.from_user.id):
        await query.answer("فقط ادمین اصلی می‌تواند این دستور را اجرا کند.", show_alert=True)
        return
    command_id = int(str(query.data).split(":", 1)[1])
    await query.answer("در حال اجرا…")
    try:
        from services.ai_control_service import approve_queued_ai_command
        result = await run_blocking(approve_queued_ai_command, command_id, query.from_user.id, human_confirmation_source="telegram_callback")
    except Exception as exc:
        await query.answer(f"خطا: {str(exc)[:160]}", show_alert=True)
        return
    await edit(query, "✅ <b>دستور Gemini تأیید و اجرا شد.</b>\n\n" f"شناسه: <code>{command_id}</code>\n" f"وضعیت: <b>{'موفق' if result.get('executed') else 'ناموفق'}</b>", [[InlineKeyboardButton("⬅️ مرکز AI", callback_data="a_ai_command_center", style="danger")]])


async def ai_command_reject_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    from config import is_primary_admin

    if not is_primary_admin(query.from_user.id):
        await query.answer("فقط ادمین اصلی می‌تواند این دستور را رد کند.", show_alert=True)
        return
    command_id = int(str(query.data).split(":", 1)[1])
    try:
        from services.ai_control_service import reject_queued_ai_command
        await run_blocking(reject_queued_ai_command, command_id, query.from_user.id, reason="رد توسط ادمین اصلی", human_confirmation_source="telegram_callback")
    except Exception as exc:
        await query.answer(f"خطا: {str(exc)[:160]}", show_alert=True)
        return
    await edit(query, "❌ <b>دستور Gemini رد شد.</b>\n\n" f"شناسه: <code>{command_id}</code>", [[InlineKeyboardButton("⬅️ مرکز AI", callback_data="a_ai_command_center", style="danger")]])


async def delegated_admin_approve_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    from config import is_primary_admin

    if not is_primary_admin(query.from_user.id):
        await query.answer("فقط ادمین اصلی می‌تواند ادمین جدید را تأیید کند.", show_alert=True)
        return
    user_id = str(query.data).split(":", 1)[1]
    try:
        from modules.admin_access import approve_delegated_admin
        row = await async_with_db(lambda db: approve_delegated_admin(db, user_id, query.from_user.id))
    except Exception as exc:
        await query.answer(f"خطا: {str(exc)[:160]}", show_alert=True)
        return
    await edit(query, "✅ <b>ادمین جدید تأیید شد.</b>\n\n" f"آیدی: <code>{esc(user_id)}</code>\n" f"نقش: <b>{esc(row.get('role') or 'admin')}</b>", [[InlineKeyboardButton("⬅️ مرکز AI", callback_data="a_ai_command_center", style="danger")]])


async def delegated_admin_reject_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    from config import is_primary_admin

    if not is_primary_admin(query.from_user.id):
        await query.answer("فقط ادمین اصلی می‌تواند این درخواست را رد کند.", show_alert=True)
        return
    user_id = str(query.data).split(":", 1)[1]
    try:
        from modules.admin_access import reject_delegated_admin
        await async_with_db(lambda db: reject_delegated_admin(db, user_id, query.from_user.id, reason="رد توسط ادمین اصلی"))
    except Exception as exc:
        await query.answer(f"خطا: {str(exc)[:160]}", show_alert=True)
        return
    await edit(query, "❌ <b>درخواست ادمین رد شد.</b>\n\n" f"آیدی: <code>{esc(user_id)}</code>", [[InlineKeyboardButton("⬅️ مرکز AI", callback_data="a_ai_command_center", style="danger")]])


async def ai_status_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, "ai_system_monitoring"):
        return
    from modules.gemini_ai import gemini_live_health, gemini_status
    await run_blocking(gemini_live_health, force=True, generation_test=True)
    status = gemini_status()
    await reply(update, "🧪 <b>وضعیت Gemini</b>\n\n" f"فعال: <b>{status.get('enabled')}</b>\n" f"احراز هویت: <b>{status.get('authenticated')}</b>\n" f"مدل قابل دسترس: <b>{status.get('model_available')}</b>\n" f"تأخیر: <b>{esc(status.get('latency_ms') or '—')}</b> ms\n" f"خطا: <code>{esc(status.get('last_error') or 'ندارد')}</code>")


async def ai_daily_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, "ai_management_reports"):
        return
    from modules.gemini_ai import build_daily_manager_report
    report = await run_blocking(build_daily_manager_report, update.effective_user.id, language="fa", force=True)
    await reply(update, "📋 <b>گزارش روزانه مدیر</b>\n\n" + esc(str(report.get("answer") or "")[:3600]))


__feature_exports__ = (
    'a_platform_expansion', 'platform_capability_view', 'u_ai_chat_start', 'u_ai_hub', 'u_copilot', 'u_risk_coach',
    'u_paper_arena', 'paper_create_default', 'paper_open_signal',
    'paper_close_trade', 'u_prop_guardian', 'prop_configure_default',
    'u_public_performance', 'u_bot_tools', 'tools_command',
    'paper_command', 'prop_command', 'copilot_command', 'ai_asset_command', 'ai_asset_capture',
    'a_ai_chat_start', 'a_ai_chat_scope', 'a_admin_search_start', 'admin_search_command', 'ai_chat_voice_router', 'ai_voice_transcript_action', 'ai_chat_message_router', 'user_ai_preset_handler', 'ai_chat_home', 'ai_chat_stop',
    'admin_ai_command', 'a_ai_command_center', 'a_ai_menu_toggle',
    'a_ai_health_test', 'a_ai_access_toggle', 'a_ai_execution_toggle', 'a_ai_daily_report', 'ai_command_approve_callback',
    'ai_command_reject_callback', 'delegated_admin_approve_callback', 'delegated_admin_reject_callback', 'ai_status_command', 'ai_daily_command',
)
