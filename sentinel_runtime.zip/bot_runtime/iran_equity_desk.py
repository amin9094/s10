"""Dedicated private Telegram entry for Iran equity analyses, H4 / D1."""

from html import escape

from telegram import InlineKeyboardButton as B
from telegram import InlineKeyboardMarkup

from core.async_runtime import run_blocking
from services.iran_equity_desk_service import detail, legacy_detail, snapshot
from services.live_signal_service import permitted


async def iran_equity_callback(update, context, *, route=None, already_answered=False):
    q = update.callback_query
    user = q.from_user.id
    try:
        await run_blocking(permitted, user, timeout=5)
    except PermissionError:
        await q.answer("دسترسی ندارید", show_alert=True)
        return
    if not already_answered:
        await q.answer()
    parts = (route or q.data).split(":")
    kind = parts[1]
    rows = []
    if kind == "v":
        try:
            r = await run_blocking(legacy_detail, user, parts[2], timeout=5)
        except ValueError:
            return
        p = r["payload"]["plan"]
        text = f"سابقهٔ بورس ایران / {p['symbol']} · {p['timeframe']}\nوضعیت سابقه: {r['state']}\nEntry: {p['entry']} · SL: {p['stop']}"
        text += " · " + " · ".join(f"{k.upper()}: {p[k]}" for k in ("tp1", "tp2", "tp3") if p.get(k) is not None)
        text += "\n\nسابقهٔ بایگانی‌شده؛ از بخش سیگنال‌های بازار جداست."
        rows = [[B("برگشت به بورس ایران", callback_data="ir:h")]]
    elif kind == "a":
        try:
            r = await run_blocking(detail, user, parts[2], timeout=5)
        except ValueError:
            return
        p = r["payload"]
        a = p["analysis"]
        text = f"بورس ایران / {r['symbol']} / {r['timeframe'].upper()}\nوضعیت: {r['state']}\nقیمت‌ها: ریال\nآخرین روز بسته: {a.get('latest_closed_date', '—')}\nروند: {a.get('trend', '—')} · مومنتوم: {a.get('momentum', '—')}"
        for k, v in a.get("indicators", {}).items():
            text += f"\n{k}: {v}"
        text += "\n\nتحلیل اختصاصی بورس است؛ انتشار عمومی یا معامله ایجاد نمی‌کند."
        rows = [[B("برگشت به بورس ایران", callback_data="ir:h")]]
    elif kind in {"h", "t", "p"}:
        before = None
        legacy_before = None
        tf = None
        section = "all"
        if kind == "t":
            tf = parts[2]
        if kind == "p":
            page = context.user_data.get("iran_equity_pages", {}).get(parts[2])
            if not page:
                return
            tf, before, legacy_before, section = page
        try:
            d = await run_blocking(
                snapshot, user, timeframe=tf, before=before, legacy_before=legacy_before, section=section, timeout=10
            )
        except ValueError:
            return
        text = "🇮🇷 بورس ایران\nتحلیل‌های ۴ساعته و روزانه، مستقل از سیگنال‌های فارکس، طلا و کریپتو.\nنمودار و جست‌وجوی سهم: مینی‌اپ ← بخش مدیریت ← بورس ایران."
        rows = [[B("۴ساعته", callback_data="ir:t:4h"), B("روزانه", callback_data="ir:t:1d")]]
        rows.extend(
            [
                [B(f"{r['symbol']} · {r['timeframe'].upper()} · {r['state']}", callback_data="ir:a:" + r["id"])]
                for r in d["items"]
            ]
        )
        if not d["items"]:
            text += "\nهنوز تحلیل ذخیره‌شده‌ای در این بخش نیست."
        rows.extend(
            [
                [
                    B(
                        f"سابقهٔ بورس / {r['payload']['plan']['symbol']} · {r['payload']['plan']['timeframe']}",
                        callback_data="ir:v:" + r["id"],
                    )
                ]
                for r in d["legacy_items"]
            ]
        )
        for label, cursor, is_legacy in [
            ("تحلیل‌های قدیمی‌تر", d["next_before"], False),
            ("سوابق قدیمی‌تر بورس", d["legacy_next_before"], True),
        ]:
            if not cursor:
                continue
            import uuid

            token = uuid.uuid4().hex[:8]
            pages = context.user_data.setdefault("iran_equity_pages", {})
            if len(pages) >= 20:
                pages.pop(next(iter(pages)))
            pages[token] = (
                tf,
                None if is_legacy else cursor,
                cursor if is_legacy else None,
                "legacy" if is_legacy else "analyses",
            )
            rows.append([B(label, callback_data="ir:p:" + token)])
        from bot_runtime.navigation import webapp_row

        app = webapp_row()
        if app:
            rows.append(app)
        rows.append([B("برگشت به مدیریت", callback_data="admin_home")])
    else:
        return
    await q.edit_message_text(escape(text[:3900]), parse_mode="HTML", reply_markup=InlineKeyboardMarkup(rows))
