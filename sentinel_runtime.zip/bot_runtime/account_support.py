"""Feature-owned Telegram handlers extracted from the v7 runtime: account_support."""

import secrets
from urllib.parse import urlencode

from bot_runtime import shared as _shared
from modules.reward_wallet import (
    mark_wallet_seen,
    point_summary,
    reward_seen_key,
    reward_source_label,
    rewards_badge,
    wallet_items,
)

globals().update({name: value for name, value in vars(_shared).items() if not name.startswith('__')})

async def account_education(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    language = (await run_blocking(_language_for_user, query.from_user.id))
    snapshot = user_account_snapshot((await async_snapshot()), query.from_user.id)
    lines = [
        "🎓 <b>آموزش‌های من</b>",
        "",
        f"دسترسی فعال: <b>{snapshot['accessible_lesson_count']}</b> آموزش",
        f"سفارش تأییدشده: <b>{snapshot['education_approved_count']}</b>",
        f"سفارش در انتظار: <b>{snapshot['education_pending_count']}</b>",
        f"مجموع پرداخت: <b>{int(snapshot['education_spend']):,} تومان</b>",
        "",
        "<b>آموزش‌های در دسترس</b>",
    ]
    if language == "en":
        lines = [
            "🎓 <b>My education</b>",
            "",
            f"Active access: <b>{snapshot['accessible_lesson_count']}</b> lessons",
            f"Approved orders: <b>{snapshot['education_approved_count']}</b>",
            f"Pending orders: <b>{snapshot['education_pending_count']}</b>",
            f"Total spend: <b>{int(snapshot['education_spend']):,} IRT</b>",
            "",
            "<b>Accessible lessons</b>",
        ]
    lessons = snapshot["accessible_lessons"][:12]
    if not lessons:
        lines.append("No paid lesson is active for your account." if language == "en" else "هنوز آموزش پولی برای حساب شما فعال نشده است.")
    for lesson in lessons:
        lines.append(f"• {esc(lesson.get('title') or ('Untitled' if language == 'en' else 'بدون عنوان'))}")
    lines.extend(["", "<b>Latest orders</b>" if language == "en" else "<b>آخرین سفارش‌ها</b>"])
    orders = snapshot["education_orders"][:6]
    if not orders:
        lines.append("No order has been submitted." if language == "en" else "سفارشی ثبت نشده است.")
    for row in orders:
        status = (str(row.get("status") or "unknown").replace("_", " ").title() if language == "en" else _ACCOUNT_ORDER_STATUS.get(str(row.get("status")), str(row.get("status") or "نامشخص")))
        lines.append(f"• <code>{esc(row.get('order_id'))}</code> | {esc(row.get('lesson_title') or ('Lesson' if language == 'en' else 'آموزش'))} | {esc(status)}")
    rows = [[InlineKeyboardButton("📚 Open education" if language == "en" else "📚 ورود به آموزش", callback_data="u_edu")], *(await run_blocking(_account_back, query.from_user.id))]
    await edit(query, "\n".join(lines), rows)


async def account_rewards(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    db = await async_snapshot()
    language = (await run_blocking(_language_for_user, query.from_user.id))
    snapshot = user_account_snapshot(db, query.from_user.id)
    points = int(snapshot["points"])
    lines = [
        "🏆 <b>امتیاز، معرفی و جوایز</b>",
        "",
        f"⭐ امتیاز فعلی: <b>{points:,}</b>",
        f"➕ کل امتیاز دریافتی: <b>{int(snapshot.get('points_received', 0)):,}</b>",
        f"➖ کل امتیاز خرج‌شده: <b>{int(snapshot.get('points_spent', 0)):,}</b>",
        f"🔄 تعداد گردش‌های امتیاز: <b>{int(snapshot.get('point_transaction_count', 0))}</b>",
        f"🎖 سطح: <b>{esc(get_level(points, db))}</b>",
        f"🏅 لیگ: <b>{esc(get_league(points))}</b>",
        f"📊 رتبه کل: <b>{snapshot.get('rank') or '—'}</b>",
        f"👥 دعوت موفق: <b>{snapshot['referral_count']}</b>",
        f"🛍 خریداران معرفی‌شده: <b>{len(ensure_referral(db, query.from_user.id).get('purchasers', []))}</b>",
        f"🎁 امتیاز معرفی: <b>{snapshot['referral_points']}</b>",
        f"📦 جوایز ثبت‌شده: <b>{snapshot['reward_count']}</b>",
        f"⏳ درخواست جایزه در انتظار: <b>{snapshot['pending_reward_count']}</b>",
        "",
        "<b>آخرین جوایز</b>",
    ]
    if language == "en":
        lines = [
            "🏆 <b>Points, referrals & rewards</b>",
            "",
            f"⭐ Current points: <b>{points:,}</b>",
            f"➕ Total earned: <b>{int(snapshot.get('points_received', 0)):,}</b>",
            f"➖ Total spent: <b>{int(snapshot.get('points_spent', 0)):,}</b>",
            f"🔄 Point transactions: <b>{int(snapshot.get('point_transaction_count', 0))}</b>",
            f"📊 Overall rank: <b>{snapshot.get('rank') or '—'}</b>",
            f"👥 Successful referrals: <b>{snapshot['referral_count']}</b>",
            f"🎁 Referral points: <b>{snapshot['referral_points']}</b>",
            f"📦 Rewards: <b>{snapshot['reward_count']}</b>",
            f"⏳ Pending reward requests: <b>{snapshot['pending_reward_count']}</b>",
            "",
            "<b>Latest rewards</b>",
        ]
    rewards = list(reversed(snapshot["rewards"]))[:6]
    if not rewards:
        lines.append("No reward is registered yet." if language == "en" else "هنوز جایزه‌ای در حساب شما ثبت نشده است.")
    for row in rewards:
        lines.append(f"• {esc(row.get('title') or row.get('reward_name') or ('Reward' if language == 'en' else 'جایزه'))} | {esc(row.get('status') or ('Unknown' if language == 'en' else 'نامشخص'))}")
    rows = [
        [
            InlineKeyboardButton("🎁 Rewards store" if language == "en" else "🎁 فروشگاه جوایز", callback_data="u_rewards"),
            InlineKeyboardButton("👥 Referral link" if language == "en" else "👥 لینک معرف", callback_data="u_referral"),
        ],
        [
            InlineKeyboardButton("🏅 Leaderboard" if language == "en" else "🏅 لیدربورد", callback_data="u_leaderboard"),
            InlineKeyboardButton("✅ Missions" if language == "en" else "✅ مأموریت‌ها", callback_data="u_missions"),
        ],
        *(await run_blocking(_account_back, query.from_user.id)),
    ]
    await edit(query, "\n".join(lines), rows)


async def account_activity(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    language = (await run_blocking(_language_for_user, query.from_user.id))
    snapshot = user_account_snapshot((await async_snapshot()), query.from_user.id)
    lines = [
        "📋 <b>فعالیت و پشتیبانی</b>",
        "",
        f"🎫 کل تیکت‌ها: <b>{snapshot['ticket_count']}</b>",
        f"🟢 تیکت باز: <b>{snapshot['open_ticket_count']}</b>",
        f"🔔 هشدار قیمت فعال: <b>{snapshot['active_alert_count']}</b>",
        f"✅ مأموریت انجام‌شده: <b>{snapshot['completed_mission_count']}/{snapshot['mission_count']}</b>",
        f"📊 کل فعالیت ثبت‌شده: <b>{int(snapshot.get('activity_total', 0)):,}</b>",
        f"🕒 آخرین رویداد: <b>{display_dt(snapshot.get('last_activity_at'))}</b>",
        "",
        "<b>آخرین تیکت‌ها</b>",
    ]
    if language == "en":
        lines = [
            "📋 <b>Activity & support</b>",
            "",
            f"🎫 Total tickets: <b>{snapshot['ticket_count']}</b>",
            f"🟢 Open tickets: <b>{snapshot['open_ticket_count']}</b>",
            f"🔔 Active price alerts: <b>{snapshot['active_alert_count']}</b>",
            f"✅ Completed missions: <b>{snapshot['completed_mission_count']}/{snapshot['mission_count']}</b>",
            f"📊 Recorded activity: <b>{int(snapshot.get('activity_total', 0)):,}</b>",
            f"🕒 Latest event: <b>{display_dt(snapshot.get('last_activity_at'))}</b>",
            "",
            "<b>Latest tickets</b>",
        ]
    tickets = snapshot["tickets"][:6]
    if not tickets:
        lines.append("You have not submitted a ticket yet." if language == "en" else "هنوز تیکتی ثبت نکرده‌اید.")
    for row in tickets:
        icon = "🟢" if row.get("status") == "open" else "⚪️"
        lines.append(
            f"• {icon} #{int(row.get('id', 0) or 0)} — {esc(row.get('subject') or ('Support' if language == 'en' else 'پشتیبانی'))}"
            f" | {display_dt(row.get('updated_at') or row.get('created_at'))}"
        )
    rows = [
        [
            InlineKeyboardButton("🎫 Support center" if language == "en" else "🎫 مرکز پشتیبانی", callback_data="u_support"),
            InlineKeyboardButton("🔔 Price alerts" if language == "en" else "🔔 هشدارهای قیمت", callback_data="price_alerts"),
        ],
        *(await run_blocking(_account_back, query.from_user.id)),
    ]
    await edit(query, "\n".join(lines), rows)


async def u_score(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    db = await async_snapshot()
    language = (await run_blocking(_language_for_user, query.from_user.id))
    points = int(db.get("user_points", {}).get(str(query.from_user.id), 0))
    vip = db.get("vip_users", {}).get(str(query.from_user.id), {})
    vip_text = (
        (f"Active until {display_dt(vip.get('expires_at'))}" if is_vip(db, query.from_user.id) else "Inactive")
        if language == "en"
        else (f"فعال تا {display_dt(vip.get('expires_at'))}" if is_vip(db, query.from_user.id) else "غیرفعال")
    )
    text = (
        "🏆 <b>Your account status</b>\n\n"
        f"⭐ Points: <b>{points}</b>\n"
        f"🎖 Level: <b>{esc(get_level(points, db, language=language))}</b>\n"
        f"🏅 League: <b>{esc(get_league(points, db, language=language))}</b>\n"
        f"💎 VIP: <b>{esc(vip_text)}</b>"
        if language == "en"
        else
        "🏆 <b>وضعیت حساب شما</b>\n\n"
        f"⭐ امتیاز: <b>{points}</b>\n"
        f"🎖 سطح: <b>{esc(get_level(points, db, language=language))}</b>\n"
        f"🏅 لیگ: <b>{esc(get_league(points, db, language=language))}</b>\n"
        f"💎 VIP: <b>{esc(vip_text)}</b>"
    )
    raw_page=str(query.data).partition(':')[2]
    history_page=max(0,int(raw_page)) if raw_page.isdigit() else 0
    summary = point_summary(db, query.from_user.id, cursor=history_page*8, limit=8, language=language)
    text += (f"\n\n➕ Recorded earnings: {summary['earned']}\n➖ Recorded spending: {summary['spent']}" if language == 'en' else f"\n\n➕ مجموع دریافتی ثبت‌شده: {summary['earned']}\n➖ مجموع مصرف ثبت‌شده: {summary['spent']}")
    for row in summary["history"]:
        text += f"\n{int(row.get('amount', 0)):+d} — {esc(str(row.get('reason_label') or row.get('reason') or '')[:100])}\n{display_dt(row.get('created_at'))} | {'Balance' if language=='en' else 'مانده'}: {row.get('balance_after','—')}"
    history_rows=[]
    if history_page:history_rows.append([InlineKeyboardButton('⬅️ Previous' if language=='en' else '⬅️ قبلی',callback_data=f'u_score:{history_page-1}')])
    if summary['next_cursor'] is not None:history_rows.append([InlineKeyboardButton('Next ➡️' if language=='en' else 'بعدی ➡️',callback_data=f'u_score:{history_page+1}')])
    history_rows.append([InlineKeyboardButton('🎁 Rewards' if language=='en' else '🎁 پاداش‌ها',callback_data='u_rewards'),InlineKeyboardButton('🏠 Home' if language=='en' else '🏠 خانه',callback_data='home')])
    await edit(query,text[:3900],history_rows)



async def u_leaderboard(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    db = await async_snapshot()
    language = (await run_blocking(_language_for_user, query.from_user.id))
    top = sorted(db.get("user_points", {}).items(), key=lambda item: (-int(item[1]), item[0]))[:10]
    lines = ["🏆 <b>TOP 10 leaderboard</b>" if language == "en" else "🏆 <b>لیدربورد TOP 10</b>", ""]
    medals = ["🥇", "🥈", "🥉"]
    for index, (uid, points) in enumerate(top):
        user = db.get("users", {}).get(str(uid), {})
        name = user.get("username") or user.get("first_name") or uid
        prefix = medals[index] if index < 3 else f"{index + 1}."
        lines.append(f"{prefix} {esc(name)} — <b>{int(points)}</b>")
    if not top:
        lines.append("No score has been recorded yet." if language == "en" else "هنوز امتیازی ثبت نشده است.")
    await edit(query, "\n".join(lines), [[InlineKeyboardButton("↩️ Club & rewards" if language == "en" else "↩️ باشگاه و جوایز", callback_data="nav_user:club", style="primary")]])


async def u_referral(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    db = await async_snapshot()
    data = await async_with_db(lambda state: ensure_referral(state, query.from_user.id))
    settings = referral_program_settings(db)
    language = (await run_blocking(_language_for_user, query.from_user.id))
    username = _remember_runtime_bot_username(getattr(context.bot, "username", None))
    if not username:
        await query.answer("نام کاربری ربات هنوز از تلگرام دریافت نشده است؛ دوباره تلاش کنید.", show_alert=True)
        return
    link = f"https://t.me/{username}?start={data['code']}"
    invited = len({str(value) for value in data.get("invited", [])})
    purchases = len({str(value) for value in data.get("purchasers", [])})
    required = int(settings.get("purchase_required", 2) or 2)
    progress = purchases % required
    vip_days = int(settings.get("vip_reward_days", 30) or 30)
    text = (
        "👥 <b>Your referral program</b>\n\n"
        f"🔗 <code>{esc(link)}</code>\n\nInvited users: <b>{invited}</b>\nReferred buyers: <b>{purchases}</b>\n"
        f"Current VIP reward progress: <b>{progress}/{required}</b>\n\nEvery {required} different referred buyers add <b>{vip_days} VIP days</b> to your current expiry. Existing VIP time is extended, not replaced."
        if language == "en"
        else "👥 <b>برنامه معرفی و جایزه VIP</b>\n\n"
        f"🔗 <code>{esc(link)}</code>\n\nکاربران دعوت‌شده: <b>{invited}</b>\nخریداران معرفی‌شده: <b>{purchases}</b>\n"
        f"پیشرفت جایزه فعلی: <b>{progress}/{required}</b>\n\nهر {required} خریدار متفاوت که با لینک شما وارد شده باشند، <b>{vip_days} روز</b> به پایان اشتراک VIP شما اضافه می‌کند. اگر VIP فعال داشته باشید زمان باقیمانده حفظ و تمدید می‌شود."
    )
    await edit(query, text, [
        [InlineKeyboardButton("📤 ارسال لینک دعوت", url="https://t.me/share/url?" + urlencode({"url": link, "text": "دعوت به SENTINEL"}))],
        [InlineKeyboardButton("🎯 مراحل پاداش معرفی", callback_data="referral_milestones")],
        [InlineKeyboardButton("⬅️ منوی اصلی", callback_data="home")],
    ])


async def u_rewards(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    db = await async_snapshot()
    points = int(db.get("user_points", {}).get(str(query.from_user.id), 0))
    en = (await run_blocking(_language_for_user, query.from_user.id)) == "en"
    await edit(query, f"🎁 <b>{'Rewards' if en else 'جوایز'}</b>\n⭐ {'Your points' if en else 'امتیاز شما'}: <b>{points}</b>", [
        [InlineKeyboardButton(("📦 My rewards" if en else "📦 جوایز من") + rewards_badge(db, query.from_user.id), callback_data="u_my_rewards"),
         InlineKeyboardButton("🎁 Available rewards" if en else "🎁 پاداش‌ها", callback_data="u_reward_catalog")],
        [InlineKeyboardButton("⭐ My points" if en else "⭐ امتیاز من", callback_data="u_score"),
         InlineKeyboardButton("🏅 Rankings" if en else "🏅 رتبه‌بندی", callback_data="u_leaderboard")],
        [InlineKeyboardButton("⬅️ Main menu" if en else "⬅️ منوی اصلی", callback_data="home")],
    ])


async def u_settings(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    # Compatibility alias: there is one notifications screen and one language
    # entry in the user catalog, rather than another settings submenu.
    from bot_runtime.signals_portfolio import account_notifications
    await account_notifications(update, context)


async def u_reward_catalog(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    await async_with_db(ensure_discount_system)
    db = await async_snapshot()
    language = (await run_blocking(_language_for_user, query.from_user.id))
    points = int(db.get("user_points", {}).get(str(query.from_user.id), 0))
    rows: list[list[InlineKeyboardButton]] = []
    claim_token = secrets.token_hex(8)
    from services.reward_claims import available_rewards
    items = available_rewards(db, query.from_user.id)
    raw_page = str(query.data).partition(':')[2]
    page = min(int(raw_page) if raw_page.isdigit() else 0, max(0,(len(items)-1)//8))
    details = []
    for item in items[page*8:page*8+8]:
        icon = "✅" if points >= int(item.get("points", 0)) else "🔒"
        missing = max(0, int(item.get('points',0))-points)
        if item.get('prize'):
            from modules.prize_delivery import prize_label
            details.append(esc(prize_label(item['prize'],language)))
        details.append(f"\n🎁 <b>{esc(str(item.get('name') or '')[:100])}</b>\n{esc(str(item.get('description') or item.get('detail') or '')[:180])}\n⭐ {int(item.get('points',0)):,}" + ((f' | Missing points: {missing:,}' if language=='en' else f' | کسری امتیاز: {missing:,}') if missing else (' | Available' if language=='en' else ' | قابل دریافت')))
        rows.append(
            [
                InlineKeyboardButton(
                    f"{icon} {item.get('name')} ({int(item.get('points', 0))} {'points' if language == 'en' else 'امتیاز'})", callback_data=f"redeem:{item.get('id')}:{claim_token}"
                )
            ]
        )
    if page: rows.append([InlineKeyboardButton('Previous page' if language=='en' else 'صفحه قبل', callback_data=f'u_reward_catalog:{page-1}')])
    if (page+1)*8 < len(items): rows.append([InlineKeyboardButton('Next page' if language=='en' else 'صفحه بعد', callback_data=f'u_reward_catalog:{page+1}')])
    rows.append([InlineKeyboardButton("↩️ Club & rewards" if language == "en" else "↩️ جوایز", callback_data="u_rewards")])
    text = (
        f"🎁 <b>Rewards store</b>\n⭐ Your points: <b>{points}</b>\n\n"
        "💳 Every verified private-subscription purchase adds <b>100 bonus points</b>. "
        "The subscription itself cannot be purchased with points."
        if language == "en"
        else
        f"🎁 <b>فروشگاه جوایز</b>\n⭐ امتیاز شما: <b>{points}</b>\n\n"
        "💳 با تأیید هر خرید اشتراک خصوصی، <b>۱۰۰ امتیاز هدیه</b> به حساب شما اضافه می‌شود؛ "
        "خود اشتراک با امتیاز خریداری نمی‌شود."
    )
    await edit(
        query,
        text + '\n'.join(details),
        rows,
    )


async def redeem_reward(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    language = (await run_blocking(_language_for_user, query.from_user.id))
    try:
        reward_id = int(query.data.split(":")[1])
    except ValueError:
        await query.answer("Invalid reward." if language == "en" else "جایزه نامعتبر است.", show_alert=True)
        return

    parts = str(query.data).split(":")
    claim_key = parts[2] if len(parts) > 2 else f"legacy:{getattr(query.message, 'message_id', 0)}"
    claim_key = f"shop:{query.from_user.id}:{reward_id}:{claim_key}"

    from services.reward_claims import claim_reward
    try:
        kind, payload, error = await async_with_db(lambda db: claim_reward(db, query.from_user.id, reward_id, claim_key))
    except ValueError as exc:
        kind, payload, error = "error", None, str(exc)
    if kind == "error" or not payload:
        await query.answer("The reward could not be redeemed. Check your point balance and try again." if language == "en" else (error or "دریافت جایزه انجام نشد."), show_alert=True)
        return
    if kind == "delivered":
        await edit(query, "✅ جایزه تحویل شد؛ در جایزه‌های من ببینید.", [[InlineKeyboardButton("جایزه‌های من",callback_data="u_my_rewards")]])
        return
    if kind == "discount":
        code = payload["code"]
        await edit(
            query,
            f"✅ Reward delivered automatically.\n\n🎟 Your <b>{code['percent']}%</b> coupon:\n<code>{code['code']}</code>\nExpires: {display_dt(code['expires_at'])}" if language == "en" else f"✅ جایزه به‌صورت خودکار تحویل شد.\n\n🎟 کد اختصاصی <b>{code['percent']}٪</b> شما:\n<code>{code['code']}</code>\nمهلت: {display_dt(code['expires_at'])}",
            [[InlineKeyboardButton("↩️ Rewards" if language == "en" else "↩️ جوایز", callback_data="u_rewards")]],
        )
        if int(payload.get("remaining", 0)) <= 1:
            for admin_id in (await run_blocking(_admin_ids_for_permission, PERMISSION_DISCOUNTS)):
                try:
                    await _telegram_request_with_button_fallback(
                        context.bot.send_message,
                        admin_id,
                        f"⚠️ موجودی کد تخفیف {code['percent']}٪ به {int(payload.get('remaining', 0))} رسیده است. از پنل تخفیف موجودی را شارژ کنید.",
                    )
                except TelegramError:
                    logger.exception("Could not send discount low-stock warning")
        return

    request_data = payload["request"]
    for admin_id in (await run_blocking(_admin_ids_for_permission, PERMISSION_REWARD_REQUESTS)):
        try:
            await _telegram_request_with_button_fallback(
                context.bot.send_message,
                admin_id,
                "🎁 <b>درخواست جایزه جدید</b>\n"
                f"🆔 درخواست: <code>{request_data['id']}</code>\n"
                f"👤 کاربر: <code>{query.from_user.id}</code>\n"
                f"🎁 جایزه: <b>{esc(request_data['reward_name'])}</b>",
                parse_mode=ParseMode.HTML,
                reply_markup=InlineKeyboardMarkup(
                    [[InlineKeyboardButton("✅ انجام شد", callback_data=f"reward_done:{request_data['id']}")]]
                ),
            )
        except TelegramError:
            logger.exception("Could not notify admin about reward request")
    await edit(query, "✅ Reward request submitted. An administrator will review it." if language == "en" else "✅ درخواست جایزه ثبت شد. ادمین پس از بررسی با شما تماس می‌گیرد.", [[InlineKeyboardButton("↩️ Rewards" if language == "en" else "↩️ جوایز", callback_data="u_rewards")]])


async def u_my_rewards(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    db = await async_snapshot()
    language = (await run_blocking(_language_for_user, query.from_user.id))
    en = language == "en"
    items = wallet_items(db, query.from_user.id)
    raw_page = str(query.data).partition(":")[2]
    page = min(int(raw_page) if raw_page.isdigit() else 0, max(0, (len(items) - 1) // 5))
    points = int(db.get("user_points", {}).get(str(query.from_user.id), 0))
    lines = [f"🎁 <b>{'My rewards' if en else 'جایزه‌های من'}</b>\n⭐ {'Points' if en else 'امتیاز'}: {points}"]
    labels = {"pending": "در انتظار تحویل", "delivered": "تحویل‌شده", "cancelled": "لغوشده", "active": "قابل استفاده", "used": "استفاده‌شده", "expired": "منقضی", "scheduled":"هنوز شروع نشده", "reserved":"رزرو برای سفارش", "disabled":"غیرفعال"}
    if en:labels={"pending":"Awaiting delivery","delivered":"Delivered","cancelled":"Cancelled","active":"Available","used":"Used","expired":"Expired","scheduled":"Not started yet","reserved":"Reserved for order","disabled":"Disabled"}
    visible_items = items[page * 5:page * 5 + 5]
    for item in visible_items:
        lines.append(f"\n• <b>{esc(str(item.get('title') or '')[:100])}</b>\n{esc(labels.get(item.get('status'), item.get('status')))} | {display_dt(item.get('created_at'))}\n<code>{esc(str(item.get('detail') or '')[:180])}</code>")
        lines.append(f"منبع: {esc(reward_source_label(item.get('source'),language))}")
        if item.get('conditions'):
            conditions=item['conditions']
            lines.append('اعتبار: '+('فقط تمدید VIP' if conditions['renewal_only'] else 'پلن‌های مجاز')+' | تعداد استفاده: '+str(conditions['per_user_limit'] or 'نامحدود'))
        if item.get("expires_at"):
            lines.append(f"مهلت: {display_dt(item['expires_at'])}")
    if not items:
        lines.append("No rewards yet." if en else "هنوز جایزه‌ای ثبت نشده است.")
    pages = []
    if page:
        pages.append(InlineKeyboardButton("Previous page" if en else "صفحه قبل", callback_data=f"u_my_rewards:{page-1}"))
    if (page+1)*5 < len(items):
        pages.append(InlineKeyboardButton("Next page" if en else "صفحه بعد", callback_data=f"u_my_rewards:{page+1}"))
    from modules.ticket_context import reward_context_reference
    rows = [[InlineKeyboardButton(f"🎫 پیگیری {str(item.get('title') or 'جایزه')[:30]}", callback_data=f"ticket_from:reward:{reward_context_reference(item)}")] for item in items[page * 5:page * 5 + 5]]
    rows += ([pages] if pages else []) + [[InlineKeyboardButton("⭐ Point history" if en else "⭐ تاریخچه امتیاز",callback_data="u_score")],[InlineKeyboardButton("⬅️ Rewards" if en else "⬅️ جوایز", callback_data="u_rewards"),InlineKeyboardButton("🏠 Home" if en else "🏠 خانه",callback_data="home")]]
    await edit(query, "\n".join(lines), rows)



    await async_with_db(lambda database: mark_wallet_seen(database, query.from_user.id, [reward_seen_key(item) for item in visible_items]))


async def a_user_rewards(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_USER_REWARDS):
        return
    query = update.callback_query
    await query.answer()
    uid = None
    if ":" in str(query.data):
        uid = query.data.split(":", 1)[1]
    rows = (await async_snapshot()).get("user_rewards", [])
    if uid:
        rows = [row for row in rows if str(row.get("user_id")) == str(uid)]
    rows = list(reversed(rows))[:15]
    lines = ["🎁 <b>جوایز کاربران</b>", ""]
    for item in rows:
        lines.append(
            f"• #{item.get('id')} | کاربر <code>{esc(item.get('user_id'))}</code> | {esc(item.get('title'))} | {esc(item.get('status'))}"
            + (f" | <code>{esc(str(item.get('detail') or '')[:120])}</code>" if item.get("detail") else "")
        )
    if not rows:
        lines.append("جایزه‌ای ثبت نشده است.")
    await edit(query, "\n".join(lines), back("admin_home"))


async def a_reward_points(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_REWARD_POINTS):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    items = (await async_snapshot()).get("settings", {}).get("rewardItems", [])
    db = await async_snapshot()
    referral_settings = referral_program_settings(db)
    rows = [
        [InlineKeyboardButton(f"{item.get('name')} — {int(item.get('points', 0))} امتیاز", callback_data=f"reward_points:{item.get('id')}")]
        for item in items
    ]
    rows.extend([
        [InlineKeyboardButton(f"👥 امتیاز هر بسته دعوت: {referral_settings['signup_batch_points']}", callback_data="reward_referral:signup_batch_points")],
        [InlineKeyboardButton(f"👤 تعداد دعوت در هر بسته: {referral_settings['signup_batch_size']}", callback_data="reward_referral:signup_batch_size")],
        [InlineKeyboardButton(f"🛍 خریدار لازم برای VIP: {referral_settings['purchase_required']}", callback_data="reward_referral:purchase_required")],
        [InlineKeyboardButton(f"💎 روز جایزه VIP: {referral_settings['vip_reward_days']}", callback_data="reward_referral:vip_reward_days")],
    ])
    rows.append(back("admin_home")[0])
    await edit(query, "⚙️ جایزه‌ای را برای تغییر امتیاز انتخاب کنید:", rows)
    return ConversationHandler.END


async def reward_points_select(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_REWARD_POINTS):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    prefix, value = query.data.split(":", 1)
    if prefix == "reward_referral":
        context.user_data["reward_referral_key"] = value
        context.user_data.pop("reward_points_id", None)
        await edit(query, "مقدار جدید تنظیم رفرال را وارد کنید:", back("a_reward_points"))
    else:
        context.user_data["reward_points_id"] = int(value)
        context.user_data.pop("reward_referral_key", None)
        await edit(query, "امتیاز جدید جایزه را وارد کنید:", back("a_reward_points"))
    return REWARD_POINTS_INPUT


async def reward_points_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_REWARD_POINTS):
        return ConversationHandler.END
    try:
        points = int((update.effective_message.text or "").replace(",", "").strip())
        referral_key = context.user_data.get("reward_referral_key")
        if referral_key:
            item = await async_with_db(lambda db: update_referral_program_setting(db, str(referral_key), points, update.effective_user.id))
            reward_id = None
            await async_with_db(lambda db: audit(db, update.effective_user.id, "referral_setting_change", f"{referral_key}:{points}"))
        else:
            reward_id = int(context.user_data.get("reward_points_id"))
            item = await async_with_db(lambda db: set_reward_points(db, reward_id, points))
            await async_with_db(lambda db: audit(db, update.effective_user.id, "reward_points_change", f"{reward_id}:{points}"))
    except (ValueError, TypeError) as exc:
        await reply(update, f"❌ {esc(exc)}")
        return REWARD_POINTS_INPUT
    context.user_data.pop("reward_points_id", None)
    context.user_data.pop("reward_referral_key", None)
    label = item.get("name") if isinstance(item, dict) and item.get("name") else "تنظیم رفرال"
    await reply(update, f"✅ مقدار «{esc(label)}» به <b>{points}</b> تغییر کرد.", back("a_reward_points"))
    return ConversationHandler.END


async def u_missions(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    db = await async_snapshot()
    language = (await run_blocking(_language_for_user, query.from_user.id))
    period_labels = (
        {"one_time": "one time", "daily": "daily", "weekly": "weekly", "monthly": "monthly"}
        if language == "en"
        else {"one_time": "یک‌بار", "daily": "روزانه", "weekly": "هفتگی", "monthly": "ماهانه"}
    )
    lines = ["🧭 <b>Your missions</b>" if language == "en" else "🧭 <b>مأموریت‌های شما</b>", ""]
    visible = [item for item in db.get("missions", []) if isinstance(item, dict) and mission_available(item)]
    from modules.prize_delivery import prize_label
    for mission in visible:
        snapshot = mission_progress_snapshot(db, query.from_user.id, mission)
        icon = "✅" if snapshot["completed"] else "⏳"
        lines.append(
            f"{icon} <b>{esc(mission.get('title'))}</b>\n"
            f"   {'Progress' if language == 'en' else 'پیشرفت'}: {snapshot['progress']}/{snapshot['target']} | "
            f"{period_labels.get(str(mission.get('period')), mission.get('period'))} | "
            f"{'Reward' if language == 'en' else 'پاداش'}: {esc(prize_label(mission.get('prize') or {'points':mission.get('reward',0)},language))}"
        )
        if mission.get("description"):
            lines.append(f"   {esc(str(mission.get('description'))[:300])}")
    if not visible:
        lines.append("No active mission is available." if language == "en" else "مأموریت فعالی تعریف نشده است.")
    await edit(
        query,
        "\n".join(lines)[:3900],
        [[InlineKeyboardButton("↩️ Main menu" if language == "en" else "↩️ منوی اصلی", callback_data="home")]],
    )








async def internal_search_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    language = (await run_blocking(_language_for_user, query.from_user.id))
    await edit(
        query,
        (
            "🔎 <b>Search SENTINEL</b>\n\nSend a feature, lesson topic, question, symbol or keyword.\n"
            "Examples: <code>subscription</code>, <code>stop loss</code>, <code>XAUUSD</code> or <code>journal</code>"
            if language == "en"
            else "🔎 <b>جست‌وجوی داخلی ربات</b>\n\n"
            "نام بخش، موضوع آموزش، سوال، نماد یا عبارت موردنظر را بفرستید.\n"
            "مثال: <code>خرید اشتراک</code>، <code>حد ضرر</code>، <code>XAUUSD</code> یا <code>ژورنال</code>"
        ),
        standard_user_nav(section_callback="nav_user:growth", section_label="🧭 Services & support" if language == "en" else "🧭 خدمات و پشتیبانی"),
    )
    return INTERNAL_SEARCH_INPUT


async def internal_search_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    language = (await run_blocking(_language_for_user, update.effective_user.id))
    term = str(update.effective_message.text or "").strip()
    if len(term) < 2:
        await reply(update, "❌ Search requires at least two characters." if language == "en" else "❌ عبارت جست‌وجو باید حداقل دو کاراکتر باشد.")
        return INTERNAL_SEARCH_INPUT
    results = search_internal((await async_snapshot()), update.effective_user.id, term, limit=12, language=language)
    if not results:
        await reply(
            update,
            f"🔎 No result found for <b>{esc(term)}</b>. Try a simpler term or a market symbol." if language == "en" else f"🔎 برای <b>{esc(term)}</b> نتیجه‌ای پیدا نشد. عبارت ساده‌تر یا نام نماد را امتحان کنید.",
            [
                [InlineKeyboardButton("🔁 Search again" if language == "en" else "🔁 جست‌وجوی دوباره", callback_data="u_search")],
                *standard_user_nav(section_callback="nav_user:growth", section_label="🧭 Services & support" if language == "en" else "🧭 خدمات و پشتیبانی"),
            ],
        )
        return ConversationHandler.END
    icons = {"guide": "📘", "menu": "🧭", "faq": "❓", "lesson": "📚", "signal": "📡"}
    rows: list[list[InlineKeyboardButton]] = []
    lines = [f"🔎 <b>Search results for {esc(term)}</b>" if language == "en" else f"🔎 <b>نتایج جست‌وجو برای {esc(term)}</b>", ""]
    for index, item in enumerate(results, start=1):
        icon = icons.get(str(item.get("kind")), "•")
        lines.append(f"{index}. {icon} <b>{esc(item.get('title'))}</b> — {esc(item.get('subtitle'))}")
        rows.append([InlineKeyboardButton(f"{icon} {str(item.get('title'))[:48]}", callback_data=str(item.get("callback")))])
    rows.append([InlineKeyboardButton("🔁 New search" if language == "en" else "🔁 جست‌وجوی جدید", callback_data="u_search")])
    rows.extend(standard_user_nav(section_callback="nav_user:growth", section_label="🧭 Services & support" if language == "en" else "🧭 خدمات و پشتیبانی"))
    await reply(update, "\n".join(lines)[:3900], rows)
    return ConversationHandler.END


def _categories(db: dict) -> list[str]:
    return sorted({str(item.get("category", "")).strip() for item in visible_lessons(db) if str(item.get("category", "")).strip()})


async def u_edu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    db = await async_snapshot()
    language = (await run_blocking(_language_for_user, query.from_user.id))
    lessons = visible_lessons(db)
    trading_count = len(lessons)
    rows = [[InlineKeyboardButton(
        f"📚 Education library ({trading_count})" if language == "en" else f"📚 کتابخانه آموزش ({trading_count})",
        callback_data="edu_type:trading")],
        [InlineKeyboardButton("🏠 Main menu" if language == "en" else "🏠 منوی اصلی", callback_data="home")]]
    rows.insert(1,[InlineKeyboardButton('▶️ ادامه و مسیر یادگیری' if language!='en' else '▶️ Continue learning',callback_data='up:learn')])
    text = ("🎓 <b>Education library</b>\n\nLessons published by authorized instructors."
            if language == "en" else "🎓 <b>کتابخانه آموزش</b>\n\nمحتوای منتشرشده توسط مدرس‌های مجاز مجموعه.")
    await edit(query, text, rows)


async def edu_type(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    language = (await run_blocking(_language_for_user, query.from_user.id))
    requested = query.data.split(":", 1)[1]
    db = await async_snapshot()
    # ``free``/``paid`` are retained only for stale buttons; the live menu is a
    # single trading catalogue backed by the administrator's lesson registry.
    lessons = visible_lessons(db) if requested == "trading" else visible_lessons(db, access_type=requested)
    if not lessons:
        await edit(
            query,
            "No trading lesson has been published yet." if language == "en" else "هنوز آموزش تریدی منتشر نشده است.",
            [[InlineKeyboardButton("⬅️ Education" if language == "en" else "⬅️ آموزش", callback_data="u_edu")]],
        )
        return
    rows: list[list[InlineKeyboardButton]] = []
    for lesson in lessons:
        access_type = str(lesson.get("access_type") or "free")
        allowed = has_education_access(db,query.from_user.id,lesson) and (not lesson.get("vip") or is_vip(db,query.from_user.id))
        title = str(lesson.get("title_en") or lesson.get("title") or "Lesson") if language == "en" else str(lesson.get("title") or "آموزش")
        price = int(lesson.get("price", 0) or 0)
        badge = "📖" if allowed or access_type == "free" else "🔒"
        suffix = "" if access_type == "free" else (f" · {price:,} IRT" if language == "en" else f" · {price:,} تومان")
        rows.append([InlineKeyboardButton(f"{badge} {title}{suffix}"[:64], callback_data=f"lesson:{lesson.get('id')}")])
    rows.append([InlineKeyboardButton("⬅️ Education" if language == "en" else "⬅️ آموزش", callback_data="u_edu")])
    await edit(
        query,
        "📈 <b>Trading education</b>\nLessons published by the administrator:" if language == "en" else "📈 <b>آموزش ترید</b>\nآموزش‌های منتشرشده توسط ادمین:",
        rows,
    )


async def edu_category(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    language = (await run_blocking(_language_for_user, query.from_user.id))
    db = await async_snapshot()
    parts = query.data.split(":")
    try:
        if len(parts) == 3:
            access_type, index_text = parts[1], parts[2]
            categories = sorted(
                {
                    str(item.get("category", "")).strip()
                    for item in visible_lessons(db, access_type=access_type)
                    if str(item.get("category", "")).strip()
                }
            )
            category = categories[int(index_text)]
        else:
            access_type = "free"
            categories = _categories(db)
            category = categories[int(parts[1])]
    except (ValueError, IndexError):
        await query.answer("Category not found; reopen Education." if language == "en" else "دسته پیدا نشد؛ دوباره وارد آموزش شوید.", show_alert=True)
        return
    lessons = [item for item in visible_lessons(db, access_type=access_type) if item.get("category") == category]
    rows = []
    for lesson in lessons:
        allowed = has_education_access(db,query.from_user.id,lesson) and (not lesson.get("vip") or is_vip(db,query.from_user.id))
        price = int(lesson.get("price", 0) or 0)
        suffix = "" if access_type == "free" else (f" — {price:,} IRT" if language == "en" else f" — {price:,} تومان")
        title = str(lesson.get("title_en") or lesson.get("title") or "Lesson") if language == "en" else str(lesson.get("title") or "آموزش")
        media_count = len(lesson.get("attachments") or [])
        media_badge = f" · 🎞 {media_count}" if media_count else ""
        rows.append(
            [
                InlineKeyboardButton(
                    f"{'📖' if allowed else '🔒'} {title}{suffix}{media_badge}",
                    callback_data=f"lesson:{lesson.get('id')}",
                )
            ]
        )
    rows.append([InlineKeyboardButton("🔙 Categories" if language == "en" else "🔙 دسته‌ها", callback_data="edu_type:trading")])
    category_title = next((str(item.get("category_en")) for item in lessons if item.get("category_en")), category) if language == "en" else category
    await edit(query, f"📂 <b>{esc(category_title)}</b>", rows)


async def _deliver_lesson_attachments(context: ContextTypes.DEFAULT_TYPE, chat_id: int | str, lesson: dict[str, Any], language: str) -> None:
    from telegram import InputMediaAudio, InputMediaDocument, InputMediaPhoto, InputMediaVideo
    from telegram.error import BadRequest
    attachments = list(lesson.get("attachments") or [])
    groups = {}
    media_classes = {"photo": InputMediaPhoto, "video": InputMediaVideo, "audio": InputMediaAudio, "document": InputMediaDocument, "pdf": InputMediaDocument}
    for position, attachment in enumerate(attachments):
        if not isinstance(attachment, dict) or not attachment.get('media_group_id') or not attachment.get('file_id'):
            continue
        kind = attachment.get('type')
        if kind in media_classes:
            family = 'visual' if kind in {'photo', 'video'} else 'document' if kind in {'document', 'pdf'} else kind
            groups.setdefault((str(attachment['media_group_id']), family), []).append(position)
    albums = {}
    for positions in groups.values():
        for offset in range(0, len(positions), 10):
            batch = positions[offset:offset + 10]
            if len(batch) > 1:
                albums[batch[0]] = batch
    handled = set()
    labels_fa = {"video": "ویدئوی آموزشی", "voice": "وویس آموزشی", "audio": "فایل صوتی", "pdf": "فایل PDF", "document": "فایل آموزشی", "photo": "تصویر آموزشی", "link": "لینک آموزشی"}
    labels_en = {"video": "Training video", "voice": "Voice lesson", "audio": "Audio file", "pdf": "PDF file", "document": "Lesson file", "photo": "Lesson image", "link": "Lesson link"}
    for index, item in enumerate(attachments, start=1):
        position = index - 1
        if position in handled:
            continue
        if position in albums:
            batch = albums[position]
            media = [media_classes[attachments[p]['type']](
                media=attachments[p]['file_id'], caption=str(attachments[p].get('caption') or '')[:1024],
            ) for p in batch]
            try:
                await context.bot.send_media_group(chat_id=chat_id, media=media, protect_content=True)
            except BadRequest:
                # A rejected album was not sent; deliver its files individually.
                logger.warning('Album rejected; delivering individual files lesson=%s', lesson.get('id'))
            except TelegramError:
                # A network timeout is ambiguous. Do not send duplicate files.
                handled.update(batch)
                logger.exception('Album delivery uncertain lesson=%s', lesson.get('id'))
                await context.bot.send_message(chat_id=chat_id, text='ارسال آلبوم کامل نشد؛ دوباره درس را باز کنید.' if language != 'en' else 'Album delivery could not be confirmed; please reopen the lesson.')
                continue
            else:
                handled.update(batch)
                continue
        if not isinstance(item, dict):
            continue
        kind = str(item.get("type") or "document")
        if kind == "link":
            url = str(item.get("url") or "").strip()
            if not url:
                continue
            raw_caption = str(item.get("caption") or "").strip()
            button_label = raw_caption or ("Open lesson link" if language == "en" else "باز کردن لینک آموزش")
            try:
                await context.bot.send_message(
                    chat_id=chat_id,
                    text=(
                        f"🔗 <b>Lesson link {index}/{len(lesson.get('attachments') or [])}</b>"
                        if language == "en"
                        else f"🔗 <b>لینک آموزشی {index}/{len(lesson.get('attachments') or [])}</b>"
                    ),
                    parse_mode=ParseMode.HTML,
                    disable_web_page_preview=True,
                    protect_content=True,
                    reply_markup=InlineKeyboardMarkup(
                        [[InlineKeyboardButton(button_label[:60], url=url, style="primary")]]
                    ),
                )
            except TelegramError:
                logger.exception("Could not deliver lesson link lesson=%s index=%s", lesson.get("id"), index)
            continue
        if not str(item.get("file_id") or ""):
            continue
        label = (labels_en if language == "en" else labels_fa).get(kind, "Lesson file" if language == "en" else "فایل آموزشی")
        raw_caption = str(item.get("caption") or "").strip()
        caption = f"{label} {index}/{len(lesson.get('attachments') or [])}" + (f"\n{raw_caption}" if raw_caption else "")
        kwargs = {"chat_id": chat_id, "caption": esc(caption)[:1000], "parse_mode": ParseMode.HTML, "protect_content": True}
        try:
            if kind == "video":
                await context.bot.send_video(video=item["file_id"], supports_streaming=True, **kwargs)
            elif kind == "voice":
                await context.bot.send_voice(voice=item["file_id"], **kwargs)
            elif kind == "audio":
                await context.bot.send_audio(audio=item["file_id"], **kwargs)
            elif kind == "animation":
                await context.bot.send_animation(animation=item["file_id"], **kwargs)
            elif kind == "photo":
                await context.bot.send_photo(photo=item["file_id"], **kwargs)
            else:
                await context.bot.send_document(document=item["file_id"], **kwargs)
        except TelegramError:
            logger.exception("Could not deliver lesson attachment lesson=%s index=%s", lesson.get("id"), index)
            await context.bot.send_message(
                chat_id=chat_id,
                text=(f"⚠️ فایل شماره {index} موقتاً قابل دریافت نیست؛ به پشتیبانی اطلاع دهید." if language != "en" else f"⚠️ File {index} is temporarily unavailable; please contact support."),
                protect_content=True,
            )


async def edu_lesson(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    language = (await run_blocking(_language_for_user, query.from_user.id))
    if not (await run_blocking(rate_limit_allow, query.from_user.id, "lesson_open", 1)):
        await query.answer("Please slow down." if language == "en" else "کمی آهسته‌تر لطفاً.", show_alert=False)
        return
    await query.answer()
    try:
        lesson_id = int(query.data.split(":", 1)[1])
    except ValueError:
        await query.answer("Invalid lesson." if language == "en" else "درس نامعتبر است.", show_alert=True)
        return

    def fetch(db: dict[str, Any]):
        lesson = find_education_lesson(db, lesson_id)
        if not lesson or not lesson.get("active", True) or lesson.get("status", "published") != "published":
            return None, False
        allowed = has_education_access(db,query.from_user.id,lesson) and (not lesson.get("vip") or is_vip(db,query.from_user.id))
        if allowed:
            lesson["views"] = int(lesson.get("views", 0)) + 1
            from modules.learning_path import lesson_for_user
            return lesson_for_user(db,query.from_user.id,lesson_id,pin=True),allowed
        return dict(lesson),allowed

    lesson, allowed = await async_with_db(fetch)
    if not lesson:
        await query.answer("Lesson not found." if language == "en" else "درس پیدا نشد.", show_alert=True)
        return
    if not allowed:
        price = int(lesson.get("price", 0) or 0)
        settings = (await async_snapshot()).get("vip_settings", {})
        card = str(settings.get("card_number") or ("Not configured" if language == "en" else "تنظیم نشده"))
        owner = str(settings.get("owner_name") or ("Not configured" if language == "en" else "تنظیم نشده"))
        rows = [
            [InlineKeyboardButton("💳 Buy and send receipt" if language == "en" else "💳 خرید و ارسال فیش", callback_data=f"edu_buy:{lesson_id}")],
            [InlineKeyboardButton("🔙 Paid lessons" if language == "en" else "🔙 آموزش پولی", callback_data="edu_type:trading")],
        ]
        await edit(
            query,
            (
                f"🔒 <b>{esc(lesson.get('title_en') or lesson.get('title'))}</b>\n\n"
                f"Price: <b>{price:,} IRT</b>\n"
                f"Card number: <code>{esc(card)}</code>\n"
                f"Card holder: <b>{esc(owner)}</b>\n\n"
                "After payment, send the receipt image. Access becomes permanent after admin approval."
                if language == "en"
                else f"🔒 <b>{esc(lesson.get('title'))}</b>\n\n"
                f"مبلغ: <b>{price:,} تومان</b>\n"
                f"شماره کارت: <code>{esc(card)}</code>\n"
                f"به نام: <b>{esc(owner)}</b>\n\n"
                "پس از واریز، تصویر فیش را ارسال کنید. دسترسی پس از تأیید ادمین دائمی باز می‌شود."
            ),
            rows,
        )
        return
    raw_chunks = chunk_text(str(lesson.get("text_en") or lesson.get("text") or "") if language == "en" else str(lesson.get("text", "")), limit=3000)
    title = esc(lesson.get("title_en") or lesson.get("title")) if language == "en" else esc(lesson.get("title"))
    progress = lesson_progress((await async_snapshot()), query.from_user.id, lesson_id)
    rating_count = int(lesson.get("rating_count", 0) or 0)
    rating_avg = (float(lesson.get("rating_total", 0) or 0) / rating_count) if rating_count else 0.0
    first = (
        f"📖 <b>{title}</b>\n"
        f"📚 {esc(lesson.get('course_en') or lesson.get('category_en') or lesson.get('course') or lesson.get('category'))} / {esc(lesson.get('chapter_en') or lesson.get('chapter') or 'Chapter 1')}\n"
        f"⏱ {int(lesson.get('duration_minutes', 5) or 5)} minutes\n\n"
        f"{esc(raw_chunks[0] if raw_chunks else '')}\n\n"
        f"👁 {int(lesson.get('views', 0))} | ⭐ {rating_avg:.1f} ({rating_count}) | "
        f"{'✅ Completed' if progress.get('completed') else '⏳ In progress'}"
        if language == "en"
        else f"📖 <b>{title}</b>\n"
        f"📚 {esc(lesson.get('course') or lesson.get('category'))} / {esc(lesson.get('chapter') or 'فصل ۱')}\n"
        f"⏱ {int(lesson.get('duration_minutes', 5) or 5)} دقیقه\n\n"
        f"{esc(raw_chunks[0] if raw_chunks else '')}\n\n"
        f"👁 {int(lesson.get('views', 0))} | ⭐ {rating_avg:.1f} ({rating_count}) | "
        f"{'✅ مطالعه‌شده' if progress.get('completed') else '⏳ در حال مطالعه'}"
    )
    rows = [
        [InlineKeyboardButton("✅ Mark as completed" if language == "en" else "✅ علامت‌گذاری به‌عنوان مطالعه‌شده", callback_data=f"lesson_complete:{lesson_id}")],
        [InlineKeyboardButton('📝 آزمون و ثبت قبولی' if language!='en' else '📝 Assessment',callback_data=f'up:quiz:{lesson_id}')],
        [
            InlineKeyboardButton("⭐ ۱", callback_data=f"lesson_rate:{lesson_id}:1"),
            InlineKeyboardButton("⭐ ۳", callback_data=f"lesson_rate:{lesson_id}:3"),
            InlineKeyboardButton("⭐ ۵", callback_data=f"lesson_rate:{lesson_id}:5"),
        ],
        [InlineKeyboardButton("🔙 Education" if language == "en" else "🔙 آموزش", callback_data="u_edu")],
    ]
    await edit(query, first, rows)
    for extra in raw_chunks[1:]:
        await query.message.reply_text(esc(extra), parse_mode=ParseMode.HTML, protect_content=True)
    await _deliver_lesson_attachments(context, query.message.chat_id, lesson, language)


async def lesson_complete_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    language = (await run_blocking(_language_for_user, query.from_user.id))
    lesson_id = query.data.split(":", 1)[1]
    try:
        await async_with_db(lambda db: mark_lesson_complete(db, query.from_user.id, lesson_id))
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    await query.answer("Progress saved" if language == "en" else "پیشرفت شما ثبت شد", show_alert=True)


async def lesson_rate_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    language = (await run_blocking(_language_for_user, query.from_user.id))
    _, lesson_id, rating = query.data.split(":", 2)
    try:
        await async_with_db(lambda db: rate_lesson(db, query.from_user.id, lesson_id, int(rating)))
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    await query.answer("Your rating was saved" if language == "en" else "امتیاز شما ثبت شد", show_alert=True)


async def education_buy_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    language = (await run_blocking(_language_for_user, query.from_user.id))
    lesson_id = int(query.data.split(":", 1)[1])
    db = await async_snapshot()
    lesson = next(
        (item for item in db.get("lessons", []) if int(item.get("id", 0) or 0) == lesson_id),
        None,
    )
    if not lesson or str(lesson.get("access_type") or "free") != "paid":
        await query.answer("This lesson cannot be purchased." if language == "en" else "این آموزش قابل خرید نیست", show_alert=True)
        return ConversationHandler.END
    if has_education_access(db, query.from_user.id, lesson):
        await query.answer("You already have access to this lesson." if language == "en" else "دسترسی این آموزش قبلاً برای شما فعال شده است", show_alert=True)
        return ConversationHandler.END
    vip_settings = db.get("vip_settings", {})
    if (
        int(lesson.get("price", 0) or 0) <= 0
        or not str(vip_settings.get("card_number") or "").strip()
        or not str(vip_settings.get("owner_name") or "").strip()
    ):
        await query.answer("Payment details for this lesson are not configured yet." if language == "en" else "اطلاعات پرداخت این آموزش هنوز توسط ادمین کامل نشده است", show_alert=True)
        return ConversationHandler.END
    context.user_data["education_lesson_id"] = lesson_id
    price = int(lesson.get("price", 0) or 0)
    card = str(vip_settings.get("card_number") or "")
    owner = str(vip_settings.get("owner_name") or "")
    text = (
        f"💳 <b>Lesson payment</b>\n\nLesson: <b>{esc(lesson.get('title_en') or lesson.get('title'))}</b>\nAmount: <b>{price:,} IRT</b>\nCard: <code>{esc(card)}</code>\nCard holder: <b>{esc(owner)}</b>\n\n📸 Now send a clear receipt image."
        if language == "en"
        else f"💳 <b>پرداخت آموزش</b>\n\nآموزش: <b>{esc(lesson.get('title'))}</b>\nمبلغ: <b>{price:,} تومان</b>\nشماره کارت: <code>{esc(card)}</code>\nبه نام: <b>{esc(owner)}</b>\n\n📸 اکنون تصویر واضح فیش را ارسال کنید."
    )
    await edit(query, text, [[InlineKeyboardButton("⬅️ آموزش", callback_data="u_edu")]])
    return EDUCATION_RECEIPT


async def education_receipt(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    language = (await run_blocking(_language_for_user, update.effective_user.id))
    lesson_id = context.user_data.pop("education_lesson_id", None)
    if not lesson_id or not update.message.photo:
        await reply(update, "❌ No receipt image was received. Try again." if language == "en" else "❌ تصویر فیش دریافت نشد. دوباره تلاش کنید.")
        return EDUCATION_RECEIPT
    try:
        order = await async_with_db(
            lambda db: create_education_order(db, update.effective_user.id, lesson_id, update.message.photo[-1].file_id)
        )
    except ValueError as exc:
        await reply(update, f"❌ {esc(exc)}", [[InlineKeyboardButton("↩️ Education" if language == "en" else "↩️ آموزش", callback_data="u_edu")]])
        return ConversationHandler.END
    caption = (
        "🎓 <b>پرداخت آموزش جدید</b>\n"
        f"سفارش: <code>{order['order_id']}</code>\n"
        f"کاربر: <code>{order['user_id']}</code>\n"
        f"آموزش: <b>{esc(order['lesson_title'])}</b>\n"
        f"مبلغ: <b>{int(order['price']):,} تومان</b>"
    )
    keyboard = InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton("✅ تأیید", callback_data=f"edu_order_approve:{order['order_id']}"),
                InlineKeyboardButton("❌ رد", callback_data=f"edu_order_reject:{order['order_id']}"),
            ]
        ]
    )
    for admin_id in (await run_blocking(_admin_ids_for_permission, PERMISSION_PAID_EDUCATION)):
        try:
            await _telegram_request_with_button_fallback(
                context.bot.send_photo,
                admin_id,
                order["receipt_file_id"],
                caption=caption,
                parse_mode=ParseMode.HTML,
                reply_markup=keyboard,
            )
        except TelegramError:
            logger.exception("Could not notify admin about education order %s", order["order_id"])
    await reply(update, "✅ Receipt submitted. You will receive the result after admin review." if language == "en" else "✅ فیش ثبت شد. بعد از بررسی ادمین، نتیجه برای شما ارسال می‌شود.", [[InlineKeyboardButton("↩️ Education" if language == "en" else "↩️ آموزش", callback_data="u_edu")]])
    return ConversationHandler.END


async def education_receipt_invalid(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    language = (await run_blocking(_language_for_user, update.effective_user.id))
    await reply(update, "❌ Send only the receipt image." if language == "en" else "❌ لطفاً فقط تصویر فیش را ارسال کنید.")
    return EDUCATION_RECEIPT


async def education_order_review(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_PAID_EDUCATION):
        return
    query = update.callback_query
    await query.answer()
    action, order_id = query.data.split(":", 1)
    approve = action.endswith("approve")
    try:
        order = await async_with_db(lambda db: approve_education_order(db, order_id, query.from_user.id, approve))
        await async_with_db(lambda db: audit(db, query.from_user.id, "education_order_review", f"{order_id}:{approve}"))
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    try:
        language = (await run_blocking(_language_for_user, order["user_id"]))
        if approve:
            text = f"✅ Payment for “{esc(order['lesson_title'])}” was approved and access is active." if language == "en" else f"✅ پرداخت آموزش «{esc(order['lesson_title'])}» تأیید شد و دسترسی شما فعال است."
        else:
            text = f"❌ Payment for “{esc(order['lesson_title'])}” was not approved. Open a support ticket for follow-up." if language == "en" else f"❌ پرداخت آموزش «{esc(order['lesson_title'])}» تأیید نشد. برای پیگیری تیکت بزنید."
        await _telegram_request_with_button_fallback(context.bot.send_message, int(order["user_id"]), text, parse_mode=ParseMode.HTML)
    except TelegramError:
        logger.warning("Could not notify education buyer %s", order.get("user_id"))
    await mark_callback_message(query, "✅ بررسی شد" if approve else "❌ رد شد")


async def a_edu_orders(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_PAID_EDUCATION):
        return
    query = update.callback_query
    await query.answer()
    orders = [row for row in reversed((await async_snapshot()).get("education_orders", [])) if isinstance(row, dict)]
    pending = [row for row in orders if row.get("status") == "pending"][:30]
    rows = []
    for row in pending:
        rows.append(
            [
                InlineKeyboardButton(
                    f"#{row['order_id']} | {row.get('lesson_title')} | {int(row.get('price', 0)):,}",
                    callback_data=f"edu_order_view:{row['order_id']}",
                )
            ]
        )
    rows += back("admin_home")
    await edit(query, f"🎓 <b>پرداخت‌های آموزش</b>\nدر انتظار: <b>{len(pending)}</b>", rows)


async def education_order_view(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_PAID_EDUCATION):
        return
    query = update.callback_query
    await query.answer()
    order_id = query.data.split(":", 1)[1]
    order = find_education_order((await async_snapshot()), order_id)
    if not order:
        await query.answer("سفارش پیدا نشد", show_alert=True)
        return
    rows = [
        [
            InlineKeyboardButton("✅ تأیید", callback_data=f"edu_order_approve:{order_id}"),
            InlineKeyboardButton("❌ رد", callback_data=f"edu_order_reject:{order_id}"),
        ],
        back("a_edu_orders")[0],
    ]
    caption = (
        f"🎓 <b>{esc(order.get('lesson_title'))}</b>\n"
        f"سفارش: <code>{order_id}</code>\n"
        f"کاربر: <code>{order.get('user_id')}</code>\n"
        f"مبلغ: <b>{int(order.get('price', 0)):,} تومان</b>\n"
        f"وضعیت: <b>{esc(order.get('status'))}</b>"
    )
    try:
        await _telegram_request_with_button_fallback(
            query.message.reply_photo,
            order.get("receipt_file_id"),
            caption=caption,
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup(rows),
        )
    except TelegramError:
        await edit(query, caption, rows)


def _ticket_attachment_from_message(message: Any) -> dict[str, Any] | None:
    if not message:
        return None
    settings = control_module_state(load_db(), "support")
    if not bool(settings.get("attachments", True)):
        return None
    attachment: dict[str, Any] | None = None
    if getattr(message, "photo", None):
        item = message.photo[-1]
        attachment = {
            "type": "photo",
            "file_id": item.file_id,
            "file_unique_id": item.file_unique_id,
            "file_size": int(getattr(item, "file_size", 0) or 0),
            "caption": str(message.caption or ""),
        }
    elif getattr(message, "document", None):
        item = message.document
        attachment = {
            "type": "document",
            "file_id": item.file_id,
            "file_unique_id": item.file_unique_id,
            "file_name": str(item.file_name or ""),
            "mime_type": str(item.mime_type or ""),
            "file_size": int(item.file_size or 0),
            "caption": str(message.caption or ""),
        }
    elif getattr(message, "video", None):
        item = message.video
        attachment = {
            "type": "video",
            "file_id": item.file_id,
            "file_unique_id": item.file_unique_id,
            "mime_type": str(item.mime_type or "video/mp4"),
            "file_size": int(item.file_size or 0),
            "caption": str(message.caption or ""),
        }
    elif getattr(message, "voice", None):
        item = message.voice
        attachment = {
            "type": "voice",
            "file_id": item.file_id,
            "file_unique_id": item.file_unique_id,
            "mime_type": str(item.mime_type or "audio/ogg"),
            "file_size": int(item.file_size or 0),
            "caption": str(message.caption or ""),
        }
    elif getattr(message, "audio", None):
        item = message.audio
        attachment = {
            "type": "audio",
            "file_id": item.file_id,
            "file_unique_id": item.file_unique_id,
            "file_name": str(item.file_name or ""),
            "mime_type": str(item.mime_type or "audio/mpeg"),
            "file_size": int(item.file_size or 0),
            "caption": str(message.caption or ""),
        }
    if not attachment:
        return None
    max_mb = int(settings.get("max_attachment_mb", 20) or 20)
    if int(attachment.get("file_size", 0) or 0) > max_mb * 1024 * 1024:
        raise ValueError(f"حجم فایل بیشتر از {max_mb} مگابایت است")
    return attachment


def _ticket_body_and_attachment(message: Any) -> tuple[str, dict[str, Any] | None]:
    attachment = _ticket_attachment_from_message(message)
    body = str(getattr(message, "text", None) or getattr(message, "caption", None) or "").strip()
    if not body and attachment:
        labels = {
            "photo": "تصویر پیوست شد",
            "document": "فایل پیوست شد",
            "video": "ویدئو پیوست شد",
            "voice": "پیام صوتی پیوست شد",
            "audio": "فایل صوتی پیوست شد",
        }
        body = labels.get(str(attachment.get("type")), "پیوست ارسال شد")
    if not body:
        raise ValueError("متن یا فایل تیکت را ارسال کنید")
    return body, attachment


def _ticket_attachment_text(attachment: dict[str, Any] | None) -> str:
    if not attachment:
        return ""
    labels = {
        "photo": "🖼 تصویر",
        "document": "📎 فایل",
        "video": "🎬 ویدئو",
        "voice": "🎙 پیام صوتی",
        "audio": "🎵 فایل صوتی",
    }
    label = labels.get(str(attachment.get("type")), "📎 پیوست")
    name = str(attachment.get("file_name") or "").strip()
    return f"{label}{f' — {name}' if name else ''}"


async def _copy_ticket_message(
    context: ContextTypes.DEFAULT_TYPE,
    source_message: Any,
    destination: int,
    *,
    rows: list[list[InlineKeyboardButton]] | None = None,
) -> bool:
    if not source_message or not (await run_blocking(_ticket_attachment_from_message, source_message)):
        return False
    try:
        await _telegram_request_with_button_fallback(
            context.bot.copy_message,
            chat_id=destination,
            from_chat_id=source_message.chat_id,
            message_id=source_message.message_id,
            reply_markup=InlineKeyboardMarkup(rows) if rows else None,
        )
        return True
    except TelegramError:
        logger.warning("Could not copy ticket attachment to %s", destination)
        return False


async def _send_ticket_attachment(
    context: ContextTypes.DEFAULT_TYPE,
    attachment: dict[str, Any] | None,
    destination: int,
    *,
    caption: str = "",
    rows: list[list[InlineKeyboardButton]] | None = None,
) -> bool:
    """Send a stored Telegram attachment by file_id instead of relying on copy_message.

    This works for admin replies even when Telegram cannot copy the original
    private-chat message. Support replies are transactional and are delivered
    independently from the user's optional marketing notification settings.
    """
    transport = ticket_attachment_transport(attachment)
    if not transport:
        return False
    media_type, file_id = transport
    method = {
        "photo": context.bot.send_photo,
        "document": context.bot.send_document,
        "video": context.bot.send_video,
        "voice": context.bot.send_voice,
        "audio": context.bot.send_audio,
    }[media_type]
    media_key = {
        "photo": "photo",
        "document": "document",
        "video": "video",
        "voice": "voice",
        "audio": "audio",
    }[media_type]
    kwargs: dict[str, Any] = {
        "chat_id": int(destination),
        media_key: file_id,
        "reply_markup": InlineKeyboardMarkup(rows) if rows else None,
    }
    clean_caption = str(caption or "").strip()
    if clean_caption:
        kwargs["caption"] = clean_caption[:1000]
        kwargs["parse_mode"] = ParseMode.HTML
    try:
        await _telegram_request_with_button_fallback(method, **kwargs)
        return True
    except TelegramError as exc:
        logger.warning("Could not send ticket %s attachment to %s: %s", media_type, destination, exc)
        return False


async def u_support(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    language = (await run_blocking(_language_for_user, query.from_user.id))
    tickets = user_tickets((await async_snapshot()), query.from_user.id)
    open_count = sum(1 for item in tickets if item.get("status") == "open")
    rows = [[InlineKeyboardButton("➕ New ticket" if language == "en" else "➕ ثبت تیکت جدید", callback_data="ticket_new")]]
    if tickets:
        rows.append([InlineKeyboardButton(f"📋 My tickets ({len(tickets)})" if language == "en" else f"📋 تیکت‌های من ({len(tickets)})", callback_data="ticket_user_list")])
    rows.append([InlineKeyboardButton("↩️ Support & services" if language == "en" else "↩️ پشتیبانی و خدمات", callback_data="nav_user:support", style="primary")])
    text = (
        "🎫 <b>Support center</b>\n\nYour message is delivered to the support team and the reply appears inside this bot.\n"
        f"Open tickets: <b>{open_count}</b>"
        if language == "en"
        else "🎫 <b>پشتیبانی تیکتی</b>\n\nپیام شما مستقیماً برای ادمین ارسال می‌شود و پاسخ را داخل همین ربات دریافت می‌کنید.\n"
        f"تیکت باز: <b>{open_count}</b>"
    )
    await edit(
        query,
        text,
        rows,
    )
    return ConversationHandler.END


async def ticket_new_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    context.user_data.pop("ticket_context", None)
    query = update.callback_query
    await query.answer()
    language = (await run_blocking(_language_for_user, query.from_user.id))
    context.user_data.pop("ticket_category", None)
    rows = [
        [
            InlineKeyboardButton("👤 Account & VIP" if language == "en" else "👤 حساب و اشتراک", callback_data="ticket_cat:account"),
            InlineKeyboardButton("💳 Payment" if language == "en" else "💳 پرداخت", callback_data="ticket_cat:payment"),
        ],
        [
            InlineKeyboardButton("🎯 Signal" if language == "en" else "🎯 سیگنال", callback_data="ticket_cat:signal"),
            InlineKeyboardButton("🎓 Education" if language == "en" else "🎓 آموزش", callback_data="ticket_cat:education"),
        ],
        [
            InlineKeyboardButton("🛠 Technical" if language == "en" else "🛠 مشکل فنی", callback_data="ticket_cat:technical"),
            InlineKeyboardButton("💬 General" if language == "en" else "💬 عمومی", callback_data="ticket_cat:general"),
        ],
        [InlineKeyboardButton("↩️ Support" if language == "en" else "↩️ پشتیبانی", callback_data="u_support")],
    ]
    await edit(query, "📝 <b>New support ticket</b>\n\nChoose a category:" if language == "en" else "📝 <b>ثبت تیکت جدید</b>\n\nابتدا موضوع تیکت را انتخاب کنید:", rows)
    return TICKET_NEW_MESSAGE


async def ticket_new_category(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    category = query.data.split(":", 1)[1]
    language = (await run_blocking(_language_for_user, query.from_user.id))
    context.user_data["ticket_category"] = category
    await query.answer("Category selected." if language == "en" else "موضوع انتخاب شد")
    await edit(
        query,
        "Describe your issue or question in one complete message. You may attach a supported file:" if language == "en" else "حالا مشکل یا سؤال خود را کامل در یک پیام بنویسید:",
        [[InlineKeyboardButton("↩️ Support" if language == "en" else "↩️ پشتیبانی", callback_data="u_support")]],
    )
    return TICKET_NEW_MESSAGE


async def ticket_new_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    ticket_context = context.user_data.get("ticket_context")
    ticket_context = ticket_context if isinstance(ticket_context, dict) else {}
    context_type = ticket_context.get("type", "")
    context_id = ticket_context.get("id", "")
    language = (await run_blocking(_language_for_user, update.effective_user.id))
    try:
        body, attachment = (await run_blocking(_ticket_body_and_attachment, update.effective_message))
    except ValueError as exc:
        await reply(update, f"❌ {esc(exc)}", back("u_support"))
        return TICKET_NEW_MESSAGE
    category = str(context.user_data.pop("ticket_category", "general"))
    priority = "high" if category in {"payment", "technical"} else "normal"
    try:
        ticket = await async_with_db(
            lambda db: create_ticket(
                db,
                update.effective_user.id,
                body,
                subject=(body.splitlines()[0] if body else "پشتیبانی")[:80],
                category=category,
                priority=priority,
                attachment=attachment,
                context_type=context_type,
                context_id=context_id,
            )
        )
    except ValueError as exc:
        await reply(update, f"❌ {esc(exc)}", back("u_support"))
        return ConversationHandler.END

    context.user_data.pop("ticket_context", None)
    username = f"@{update.effective_user.username}" if update.effective_user.username else "بدون نام کاربری"
    attach_text = _ticket_attachment_text(attachment)
    admin_text = (
        f"🎫 <b>تیکت جدید #{ticket['id']}</b>\n"
        f"کاربر: <code>{update.effective_user.id}</code> — {esc(username)}\n"
        f"دسته: <b>{esc(category)}</b> | اولویت: <b>{esc(priority)}</b>\n"
        f"{esc(attach_text)}\n\n"
        f"{esc(body[:3200])}"
    )
    rows = [[InlineKeyboardButton("مشاهده و پاسخ", callback_data=f"ticket_a:{ticket['id']}")]]
    for admin_id in (await run_blocking(_admin_ids_for_permission, PERMISSION_TICKETS)):
        try:
            media_sent = False
            if attachment:
                media_caption = (
                    f"🎫 <b>تیکت جدید #{ticket['id']}</b>\n"
                    f"کاربر: <code>{update.effective_user.id}</code> — {esc(username)}\n\n"
                    f"{esc(body[:760])}"
                )
                media_sent = await _send_ticket_attachment(
                    context,
                    attachment,
                    admin_id,
                    caption=media_caption,
                    rows=rows,
                )
            if not media_sent:
                await _telegram_request_with_button_fallback(
                    context.bot.send_message,
                    admin_id,
                    admin_text,
                    parse_mode=ParseMode.HTML,
                    reply_markup=InlineKeyboardMarkup(rows),
                )
        except TelegramError:
            logger.warning("Could not notify admin %s about ticket %s", admin_id, ticket["id"])
    await reply(
        update,
        (
            f"✅ Ticket <b>#{ticket['id']}</b> has been created. The support reply will appear in this bot."
            if language == "en"
            else f"✅ تیکت <b>#{ticket['id']}</b> ثبت شد. پاسخ ادمین در همین ربات ارسال می‌شود."
        ),
        [
            [InlineKeyboardButton("View ticket" if language == "en" else "مشاهده تیکت", callback_data=f"ticket_u:{ticket['id']}")],
            [InlineKeyboardButton("↩️ Support center" if language == "en" else "↩️ مرکز پشتیبانی", callback_data="u_support", style="primary")],
        ],
    )
    return ConversationHandler.END


def _ticket_detail_text(ticket: dict[str, Any], *, admin_view: bool = False, language: str = "fa") -> str:
    language = normalize_language(language)
    if language == "en" and not admin_view:
        status = "🟢 Open" if ticket.get("status") == "open" else "🔴 Closed"
        waiting = {"user": "User", "admin": "Admin"}.get(str(ticket.get("waiting_for")), "Closed")
        lines = [
            f"🎫 <b>Ticket #{int(ticket.get('id', 0))}</b>",
            f"Status: <b>{status}</b>",
            f"Category: <b>{esc(ticket.get('category', 'general'))}</b> | Priority: <b>{esc(ticket.get('priority', 'normal'))}</b>",
            f"Waiting for: <b>{waiting}</b>",
            "",
        ]
        messages = ticket.get("messages", [])
        visible = messages[-8:]
        if len(messages) > len(visible):
            lines.append(f"… {len(messages) - len(visible)} older messages are hidden.")
        for item in visible:
            sender = "👨‍💼 Admin" if item.get("sender") == "admin" else "👤 User"
            body = str(item.get("text") or "")
            if len(body) > 460:
                body = body[:457] + "…"
            attachment = _ticket_attachment_text(item.get("attachment"))
            suffix = f"\n{esc(attachment)}" if attachment else ""
            lines.append(f"<b>{sender}:</b> {esc(body)}{suffix}")
        return "\n\n".join(lines)[:3900]
    status = "🟢 باز" if ticket.get("status") == "open" else "🔴 بسته"
    lines = [
        f"🎫 <b>تیکت #{int(ticket.get('id', 0))}</b>",
        f"وضعیت: <b>{status}</b>",
        f"دسته: <b>{esc(ticket.get('category', 'general'))}</b> | اولویت: <b>{esc(ticket.get('priority', 'normal'))}</b>",
        f"در انتظار: <b>{'کاربر' if ticket.get('waiting_for') == 'user' else 'ادمین' if ticket.get('waiting_for') == 'admin' else 'بسته'}</b>",
    ]
    if admin_view:
        lines.append(f"کاربر: <code>{esc(ticket.get('user_id'))}</code>")
        lines.append(
            f"مسئول: <code>{esc(ticket.get('assigned_admin') or 'تخصیص‌نیافته')}</code>"
            f" | SLA: <code>{esc(ticket.get('sla_due_at') or '-')}</code>"
        )
        note_count = len(internal_notes(load_db(), ticket.get("id", 0)))
        lines.append(f"یادداشت خصوصی: <b>{note_count}</b>")
    lines.append("")
    messages = ticket.get("messages", [])
    visible = messages[-8:]
    if len(messages) > len(visible):
        lines.append(f"… {len(messages) - len(visible)} پیام قدیمی‌تر نمایش داده نشده است.")
    for item in visible:
        sender = "👨‍💼 ادمین" if item.get("sender") == "admin" else "👤 کاربر"
        body = str(item.get("text") or "")
        if len(body) > 460:
            body = body[:457] + "…"
        attachment = _ticket_attachment_text(item.get("attachment"))
        suffix = f"\n{esc(attachment)}" if attachment else ""
        lines.append(f"<b>{sender}:</b> {esc(body)}{suffix}")
    return "\n\n".join(lines)[:3900]


def _ticket_user_rows(ticket: dict[str, Any], language: str = "fa") -> list[list[InlineKeyboardButton]]:
    language = normalize_language(language)
    rows: list[list[InlineKeyboardButton]] = []
    if ticket.get("status") == "open":
        rows.append([InlineKeyboardButton("✍️ Send reply" if language == "en" else "✍️ ارسال پاسخ", callback_data=f"ticket_u_reply:{ticket['id']}")])
    elif not ticket.get("satisfaction"):
        rows.append(
            [
                InlineKeyboardButton("⭐ 1", callback_data=f"ticket_rate:{ticket['id']}:1"),
                InlineKeyboardButton("⭐ 3", callback_data=f"ticket_rate:{ticket['id']}:3"),
                InlineKeyboardButton("⭐ 5", callback_data=f"ticket_rate:{ticket['id']}:5"),
            ]
        )
    return [*rows, [InlineKeyboardButton("↩️ My tickets" if language == "en" else "↩️ تیکت‌های من", callback_data="ticket_user_list")]]


def _ticket_admin_rows(ticket: dict[str, Any]) -> list[list[InlineKeyboardButton]]:
    rows: list[list[InlineKeyboardButton]] = []
    if ticket.get("status") == "open":
        rows.append(
            [
                InlineKeyboardButton("✍️ پاسخ", callback_data=f"ticket_a_reply:{ticket['id']}"),
                InlineKeyboardButton("⚡ پاسخ آماده", callback_data=f"ticket_canned_for:{ticket['id']}"),
            ]
        )
        rows.append(
            [
                InlineKeyboardButton("📝 یادداشت خصوصی", callback_data=f"ticket_note:{ticket['id']}"),
                InlineKeyboardButton("🔒 بستن", callback_data=f"ticket_a_close:{ticket['id']}"),
            ]
        )
        rows.append(
            [
                InlineKeyboardButton("⚡ فوری", callback_data=f"ticket_priority:{ticket['id']}:urgent"),
                InlineKeyboardButton("🔶 بالا", callback_data=f"ticket_priority:{ticket['id']}:high"),
                InlineKeyboardButton("👤 تخصیص به من", callback_data=f"ticket_assign_me:{ticket['id']}"),
            ]
        )
    else:
        rows.append([InlineKeyboardButton("🔓 بازکردن دوباره", callback_data=f"ticket_a_open:{ticket['id']}")])
    if ticket.get("context_type"):
        rows.append([InlineKeyboardButton("📎 مورد مرتبط", callback_data=f"ticket_context:{ticket['id']}")])
    if ticket.get("status") != "closed":
        rows.append([InlineKeyboardButton("🔄 مسئول و واگذاری", callback_data=f"ticket_work:{ticket['id']}")])
    rows.append([InlineKeyboardButton("📒 مشاهده یادداشت‌ها", callback_data=f"ticket_notes:{ticket['id']}")])
    return [*rows, *back("a_tickets")]


async def ticket_user_list(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    language = (await run_blocking(_language_for_user, query.from_user.id))
    tickets = user_tickets((await async_snapshot()), query.from_user.id)
    if not tickets:
        await edit(query, "You have not submitted a ticket yet." if language == "en" else "هنوز تیکتی ثبت نکرده‌اید.", [[InlineKeyboardButton("↩️ Support" if language == "en" else "↩️ پشتیبانی", callback_data="u_support")]])
        return
    rows = []
    for item in tickets[:30]:
        icon = "🟢" if item.get("status") == "open" else "🔴"
        rows.append(
            [
                InlineKeyboardButton(
                    f"{icon} {'Ticket' if language == 'en' else 'تیکت'} #{item['id']} — {str(item.get('subject', 'Support' if language == 'en' else 'پشتیبانی'))[:28]}",
                    callback_data=f"ticket_u:{item['id']}",
                )
            ]
        )
    rows.append([InlineKeyboardButton("↩️ Support" if language == "en" else "↩️ پشتیبانی", callback_data="u_support")])
    await edit(query, "📋 <b>My tickets</b>" if language == "en" else "📋 <b>تیکت‌های من</b>", rows)


async def ticket_user_detail(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    language = (await run_blocking(_language_for_user, query.from_user.id))
    ticket_id = query.data.split(":", 1)[1]
    ticket = find_ticket((await async_snapshot()), ticket_id)
    if not ticket or str(ticket.get("user_id")) != str(query.from_user.id):
        await query.answer("Ticket not found." if language == "en" else "تیکت پیدا نشد.", show_alert=True)
        return
    await query.answer()
    await edit(query, (await run_blocking(_ticket_detail_text, ticket, language=language)), _ticket_user_rows(ticket, language))


async def ticket_user_reply_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    language = (await run_blocking(_language_for_user, query.from_user.id))
    ticket_id = int(query.data.split(":", 1)[1])
    ticket = find_ticket((await async_snapshot()), ticket_id)
    if not ticket or str(ticket.get("user_id")) != str(query.from_user.id) or ticket.get("status") != "open":
        await query.answer("This ticket is not available for replies." if language == "en" else "این تیکت برای پاسخ‌دادن در دسترس نیست.", show_alert=True)
        return ConversationHandler.END
    await query.answer()
    context.user_data["ticket_user_reply_id"] = ticket_id
    await edit(
        query,
        f"Send text, photo, file, video, audio or voice for ticket <b>#{ticket_id}</b>:" if language == "en" else f"پاسخ، تصویر، فایل، ویدئو یا پیام صوتی خود را برای تیکت <b>#{ticket_id}</b> ارسال کنید:",
        [[InlineKeyboardButton("↩️ Ticket" if language == "en" else "↩️ تیکت", callback_data=f"ticket_u:{ticket_id}")]],
    )
    return TICKET_USER_REPLY


async def ticket_user_reply_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    language = (await run_blocking(_language_for_user, update.effective_user.id))
    ticket_id = context.user_data.pop("ticket_user_reply_id", None)
    if not ticket_id:
        await reply(update, "❌ The reply session expired." if language == "en" else "❌ فرایند پاسخ منقضی شده است.", [[InlineKeyboardButton("↩️ Support" if language == "en" else "↩️ پشتیبانی", callback_data="u_support")]])
        return ConversationHandler.END
    try:
        body, attachment = (await run_blocking(_ticket_body_and_attachment, update.effective_message))
        ticket = await async_with_db(
            lambda db: append_ticket_message(
                db,
                ticket_id,
                "user",
                update.effective_user.id,
                body,
                attachment=attachment,
            )
        )
    except (ValueError, PermissionError) as exc:
        await reply(update, f"❌ {esc(exc)}", [[InlineKeyboardButton("↩️ Support" if language == "en" else "↩️ پشتیبانی", callback_data="u_support")]])
        return ConversationHandler.END
    attach_text = _ticket_attachment_text(attachment)
    admin_text = (
        f"💬 <b>پاسخ جدید در تیکت #{ticket_id}</b>\n"
        f"کاربر: <code>{update.effective_user.id}</code>\n"
        f"{esc(attach_text)}\n\n{esc(body[:3200])}"
    )
    rows = [[InlineKeyboardButton("مشاهده و پاسخ", callback_data=f"ticket_a:{ticket_id}")]]
    for admin_id in (await run_blocking(_admin_ids_for_permission, PERMISSION_TICKETS)):
        try:
            media_sent = False
            if attachment:
                media_caption = (
                    f"💬 <b>پاسخ جدید در تیکت #{ticket_id}</b>\nکاربر: <code>{update.effective_user.id}</code>\n\n{esc(body[:800])}"
                )
                media_sent = await _send_ticket_attachment(
                    context,
                    attachment,
                    admin_id,
                    caption=media_caption,
                    rows=rows,
                )
            if not media_sent:
                await _telegram_request_with_button_fallback(
                    context.bot.send_message,
                    admin_id,
                    admin_text,
                    parse_mode=ParseMode.HTML,
                    reply_markup=InlineKeyboardMarkup(rows),
                )
        except TelegramError:
            logger.warning("Could not notify admin %s about ticket reply %s", admin_id, ticket_id)
    await reply(
        update,
        "✅ Your reply was saved and sent to the support team." if language == "en" else "✅ پاسخ شما ثبت و برای ادمین ارسال شد.",
        [[InlineKeyboardButton("Back to ticket" if language == "en" else "بازگشت به تیکت", callback_data=f"ticket_u:{ticket['id']}")]],
    )
    return ConversationHandler.END


async def a_tickets(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_TICKETS_VIEW):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    tickets = admin_tickets(await async_snapshot())
    open_rows = [item for item in tickets if item.get("status") == "open"]
    rows: list[list[InlineKeyboardButton]] = []
    for item in open_rows[:30]:
        rows.append(
            [
                InlineKeyboardButton(
                    f"🟢 #{item['id']} | کاربر {item.get('user_id')} | {str(item.get('subject', ''))[:22]}",
                    callback_data=f"ticket_a:{item['id']}",
                )
            ]
        )
    if not rows:
        rows.append([InlineKeyboardButton("تیکت بازی وجود ندارد", callback_data="a_tickets")])
    closed_count = len(tickets) - len(open_rows)
    if closed_count:
        rows.append([InlineKeyboardButton(f"🔴 تیکت‌های بسته ({closed_count})", callback_data="a_tickets_closed")])
    rows.append([InlineKeyboardButton("⚡ مدیریت پاسخ‌های آماده", callback_data="ticket_canned")])
    rows += back("admin_home")
    await edit(
        query,
        f"🎫 <b>مدیریت تیکت‌ها</b>\n\nباز: <b>{len(open_rows)}</b> | کل: <b>{len(tickets)}</b>",
        rows,
    )
    return ConversationHandler.END


async def ticket_admin_closed_list(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_TICKETS_VIEW):
        return
    query = update.callback_query
    await query.answer()
    closed = admin_tickets((await async_snapshot()), status="closed")
    rows = [
        [
            InlineKeyboardButton(
                f"🔴 #{item['id']} | کاربر {item.get('user_id')} | {str(item.get('subject', ''))[:22]}",
                callback_data=f"ticket_a:{item['id']}",
            )
        ]
        for item in closed[:30]
    ]
    rows += back("a_tickets")
    await edit(query, f"🔴 <b>تیکت‌های بسته</b>\n\nتعداد: <b>{len(closed)}</b>", rows)


async def ticket_admin_detail(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_TICKETS_VIEW):
        return
    query = update.callback_query
    ticket_id = query.data.split(":", 1)[1]
    ticket = find_ticket((await async_snapshot()), ticket_id)
    if not ticket:
        await query.answer("تیکت پیدا نشد.", show_alert=True)
        return
    await query.answer()
    await edit(query, (await run_blocking(_ticket_detail_text, ticket, admin_view=True)), _ticket_admin_rows(ticket))


async def ticket_priority_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_TICKETS_PRIORITY_MANAGE):
        return
    query = update.callback_query
    _, ticket_id, priority = query.data.split(":", 2)
    ticket = await async_with_db(lambda db: set_ticket_priority(db, ticket_id, priority))
    await query.answer("اولویت بروزرسانی شد")
    await edit(query, (await run_blocking(_ticket_detail_text, ticket, admin_view=True)), _ticket_admin_rows(ticket))


async def ticket_assign_me_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_TICKETS_ASSIGN):
        return
    query = update.callback_query
    ticket_id = query.data.split(":", 1)[1]
    ticket = await async_with_db(lambda db: assign_ticket(db, ticket_id, query.from_user.id))
    await query.answer("تیکت به شما تخصیص یافت")
    await edit(query, (await run_blocking(_ticket_detail_text, ticket, admin_view=True)), _ticket_admin_rows(ticket))


async def ticket_rate_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    language = (await run_blocking(_language_for_user, query.from_user.id))
    _, ticket_id, score = query.data.split(":", 2)
    try:
        await async_with_db(lambda db: set_ticket_satisfaction(db, ticket_id, query.from_user.id, int(score)))
    except (ValueError, PermissionError) as exc:
        await query.answer(str(exc), show_alert=True)
        return
    ticket = find_ticket((await async_snapshot()), ticket_id)
    await query.answer(
        "Thank you for your feedback ⭐" if language == "en" else "ممنون از بازخورد شما ⭐",
        show_alert=True,
    )
    if ticket:
        await edit(
            query,
            (await run_blocking(_ticket_detail_text, ticket, language=language)),
            _ticket_user_rows(ticket, language),
        )


async def ticket_admin_reply_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_TICKETS_REPLY):
        return ConversationHandler.END
    query = update.callback_query
    ticket_id = int(query.data.split(":", 1)[1])
    ticket = find_ticket((await async_snapshot()), ticket_id)
    if not ticket or ticket.get("status") != "open":
        await query.answer("تیکت باز پیدا نشد.", show_alert=True)
        return ConversationHandler.END
    await query.answer()
    context.user_data["ticket_admin_reply_id"] = ticket_id
    await edit(
        query,
        f"پاسخ ادمین، تصویر، فایل، ویدئو یا پیام صوتی را برای تیکت <b>#{ticket_id}</b> ارسال کنید:",
        back(f"ticket_a:{ticket_id}"),
    )
    return TICKET_ADMIN_REPLY


async def ticket_admin_reply_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_TICKETS_REPLY):
        return ConversationHandler.END
    ticket_id = context.user_data.pop("ticket_admin_reply_id", None)
    if not ticket_id:
        await reply(update, "❌ فرایند پاسخ منقضی شده است.", back("a_tickets"))
        return ConversationHandler.END
    try:
        body, attachment = (await run_blocking(_ticket_body_and_attachment, update.effective_message))
        ticket = await async_with_db(
            lambda db: append_ticket_message(
                db,
                ticket_id,
                "admin",
                update.effective_user.id,
                body,
                attachment=attachment,
            )
        )
    except ValueError as exc:
        await reply(update, f"❌ {esc(exc)}", back("a_tickets"))
        return ConversationHandler.END
    await async_with_db(lambda db: audit(db, update.effective_user.id, "ticket_reply", str(ticket_id)))
    user_id = int(ticket["user_id"])
    user_rows = [[InlineKeyboardButton("مشاهده تیکت", callback_data=f"ticket_u:{ticket_id}")]]
    try:
        # Direct support replies are transactional. They must not be suppressed
        # by optional notification preferences because the user opened the ticket.
        media_sent = False
        if attachment:
            media_caption = f"💬 <b>پاسخ ادمین به تیکت #{ticket_id}</b>\n\n{esc(body[:820])}"
            media_sent = await _send_ticket_attachment(
                context,
                attachment,
                user_id,
                caption=media_caption,
                rows=user_rows,
            )
        if not media_sent:
            fallback_note = "\n\n⚠️ پیوست در تیکت ذخیره شد اما ارسال مستقیم فایل ناموفق بود." if attachment else ""
            await _telegram_request_with_button_fallback(
                context.bot.send_message,
                user_id,
                f"💬 <b>پاسخ ادمین به تیکت #{ticket_id}</b>\n\n{esc(body[:3100])}{fallback_note}",
                parse_mode=ParseMode.HTML,
                reply_markup=InlineKeyboardMarkup(user_rows),
            )
        elif len(body) > 820:
            await _telegram_request_with_button_fallback(
                context.bot.send_message,
                user_id,
                f"ادامه پاسخ تیکت <b>#{ticket_id}</b>:\n\n{esc(body[820:3900])}",
                parse_mode=ParseMode.HTML,
                reply_markup=InlineKeyboardMarkup(user_rows),
            )
    except TelegramError:
        logger.warning("Could not notify user %s about ticket %s", ticket.get("user_id"), ticket_id)
    await reply(
        update,
        "✅ پاسخ ارسال شد.",
        [[InlineKeyboardButton("بازگشت به تیکت", callback_data=f"ticket_a:{ticket_id}")]],
    )
    return ConversationHandler.END


async def ticket_note_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_TICKET_INTERNAL_NOTES):
        return ConversationHandler.END
    query = update.callback_query
    ticket_id = int(query.data.split(":", 1)[1])
    if not find_ticket((await async_snapshot()), ticket_id):
        await query.answer("تیکت پیدا نشد", show_alert=True)
        return ConversationHandler.END
    context.user_data["ticket_note_id"] = ticket_id
    await query.answer()
    await edit(
        query,
        f"📝 یادداشت خصوصی تیکت <b>#{ticket_id}</b> را ارسال کنید. این متن برای کاربر نمایش داده نمی‌شود.",
        back(f"ticket_a:{ticket_id}"),
    )
    return TICKET_INTERNAL_NOTE_INPUT


async def ticket_note_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_TICKET_INTERNAL_NOTES):
        return ConversationHandler.END
    ticket_id = context.user_data.pop("ticket_note_id", None)
    if not ticket_id:
        await reply(update, "❌ فرایند یادداشت منقضی شده است.", back("a_tickets"))
        return ConversationHandler.END
    try:
        note = await async_with_db(
            lambda db: add_internal_note(
                db,
                ticket_id,
                update.effective_user.id,
                update.effective_message.text or "",
            )
        )
    except ValueError as exc:
        await reply(update, f"❌ {esc(exc)}", back(f"ticket_a:{ticket_id}"))
        return ConversationHandler.END
    await async_with_db(lambda db: audit(db, update.effective_user.id, "ticket_internal_note", str(ticket_id)))
    await reply(
        update,
        f"✅ یادداشت خصوصی ثبت شد.\n\n{esc(note['text'][:1000])}",
        [[InlineKeyboardButton("بازگشت به تیکت", callback_data=f"ticket_a:{ticket_id}")]],
    )
    return ConversationHandler.END


async def ticket_notes_view(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_TICKET_INTERNAL_NOTES):
        return
    query = update.callback_query
    ticket_id = int(query.data.split(":", 1)[1])
    rows = internal_notes((await async_snapshot()), ticket_id)
    lines = [f"📒 <b>یادداشت‌های خصوصی تیکت #{ticket_id}</b>", ""]
    if not rows:
        lines.append("یادداشتی ثبت نشده است.")
    for item in rows[-20:]:
        lines.append(f"• ادمین <code>{esc(item.get('admin_id'))}</code> — {display_dt(item.get('created_at'))}\n{esc(item.get('text'))}")
    await query.answer()
    await edit(query, "\n\n".join(lines)[:3900], back(f"ticket_a:{ticket_id}"))


async def ticket_canned_panel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_TICKETS_REPLY):
        return
    query = update.callback_query
    await query.answer()
    replies = canned_replies((await async_snapshot()), active_only=False)
    rows: list[list[InlineKeyboardButton]] = [[InlineKeyboardButton("➕ افزودن پاسخ آماده", callback_data="ticket_canned_add")]]
    lines = ["⚡ <b>پاسخ‌های آماده پشتیبانی</b>", ""]
    if not replies:
        lines.append("هنوز پاسخی ثبت نشده است.")
    for item in replies[:50]:
        active = bool(item.get("active", True))
        lines.append(f"{'✅' if active else '⛔️'} #{item['id']} — {esc(item.get('title'))}")
        rows.append(
            [
                InlineKeyboardButton(
                    f"{'⛔️ غیرفعال' if active else '✅ فعال'} #{item['id']}",
                    callback_data=f"ticket_canned_toggle:{item['id']}",
                ),
                InlineKeyboardButton("🗑 حذف", callback_data=f"ticket_canned_delete:{item['id']}"),
            ]
        )
    rows += back("a_tickets")
    await edit(query, "\n".join(lines), rows)


async def ticket_canned_add_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_TICKETS_REPLY):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    await edit(
        query,
        "پاسخ آماده را با این قالب ارسال کنید:\n<code>عنوان | متن کامل پاسخ</code>",
        back("ticket_canned"),
    )
    return TICKET_CANNED_REPLY_INPUT


async def ticket_canned_add_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_TICKETS_REPLY):
        return ConversationHandler.END
    raw = str(update.effective_message.text or "")
    if "|" not in raw:
        await reply(update, "❌ قالب صحیح: عنوان | متن پاسخ", back("ticket_canned"))
        return TICKET_CANNED_REPLY_INPUT
    title, text = (part.strip() for part in raw.split("|", 1))
    try:
        item = await async_with_db(lambda db: create_canned_reply(db, title, text, update.effective_user.id))
    except ValueError as exc:
        await reply(update, f"❌ {esc(exc)}", back("ticket_canned"))
        return TICKET_CANNED_REPLY_INPUT
    await async_with_db(lambda db: audit(db, update.effective_user.id, "ticket_canned_add", str(item["id"])))
    await reply(update, f"✅ پاسخ آماده «{esc(item['title'])}» ثبت شد.", back("ticket_canned"))
    return ConversationHandler.END


async def ticket_canned_toggle_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_TICKETS_REPLY):
        return
    query = update.callback_query
    reply_id = query.data.split(":", 1)[1]
    try:
        item = await async_with_db(lambda db: toggle_canned_reply(db, reply_id))
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    await query.answer("فعال شد" if item.get("active") else "غیرفعال شد")
    await ticket_canned_panel(update, context)


async def ticket_canned_delete_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_TICKETS_REPLY):
        return
    query = update.callback_query
    reply_id = query.data.split(":", 1)[1]
    item = await async_with_db(lambda db: delete_canned_reply(db, reply_id))
    if not item:
        await query.answer("پاسخ پیدا نشد", show_alert=True)
        return
    await async_with_db(lambda db: audit(db, query.from_user.id, "ticket_canned_delete", str(reply_id)))
    await query.answer("حذف شد")
    await ticket_canned_panel(update, context)


async def ticket_canned_for_ticket(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_TICKETS_REPLY):
        return
    query = update.callback_query
    ticket_id = int(query.data.split(":", 1)[1])
    ticket = find_ticket((await async_snapshot()), ticket_id)
    if not ticket or ticket.get("status") != "open":
        await query.answer("تیکت باز پیدا نشد", show_alert=True)
        return
    replies = canned_replies(await async_snapshot())
    rows = [
        [InlineKeyboardButton(str(item.get("title"))[:40], callback_data=f"ticket_canned_use:{ticket_id}:{item['id']}")]
        for item in replies[:50]
    ]
    if not rows:
        rows.append([InlineKeyboardButton("➕ ساخت پاسخ آماده", callback_data="ticket_canned_add")])
    rows += back(f"ticket_a:{ticket_id}")
    await query.answer()
    await edit(query, f"⚡ <b>انتخاب پاسخ آماده برای تیکت #{ticket_id}</b>", rows)


async def ticket_canned_use_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_TICKETS_REPLY):
        return
    query = update.callback_query
    _, ticket_id, reply_id = query.data.split(":", 2)
    db = await async_snapshot()
    item = find_canned_reply(db, reply_id)
    ticket = find_ticket(db, ticket_id)
    if not item or not item.get("active", True) or not ticket or ticket.get("status") != "open":
        await query.answer("پاسخ یا تیکت در دسترس نیست", show_alert=True)
        return
    ticket = await async_with_db(
        lambda database: append_ticket_message(
            database,
            ticket_id,
            "admin",
            query.from_user.id,
            str(item.get("text") or ""),
        )
    )
    await async_with_db(lambda database: audit(database, query.from_user.id, "ticket_canned_use", f"{ticket_id}:{reply_id}"))
    try:
        if await async_with_db(
            lambda db: route_notification(db, int(ticket["user_id"]), "support")
        ):
            await _telegram_request_with_button_fallback(
                context.bot.send_message,
                int(ticket["user_id"]),
                f"💬 <b>پاسخ ادمین به تیکت #{ticket_id}</b>\n\n{esc(item.get('text'))}",
                parse_mode=ParseMode.HTML,
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("مشاهده تیکت", callback_data=f"ticket_u:{ticket_id}")]]),
            )
    except TelegramError:
        logger.warning("Could not deliver canned reply to ticket %s", ticket_id)
    await query.answer("پاسخ آماده ارسال شد", show_alert=True)
    await edit(query, (await run_blocking(_ticket_detail_text, ticket, admin_view=True)), _ticket_admin_rows(ticket))


async def ticket_admin_status(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_TICKETS_STATUS_MANAGE):
        return
    query = update.callback_query
    action, ticket_id = query.data.split(":", 1)
    existing = find_ticket((await async_snapshot()), ticket_id)
    if not existing:
        await query.answer("تیکت پیدا نشد.", show_alert=True)
        return
    await query.answer()
    status = "closed" if action == "ticket_a_close" else "open"
    ticket = await async_with_db(lambda db: set_ticket_status(db, ticket_id, status))
    await async_with_db(lambda db: audit(db, query.from_user.id, f"ticket_{status}", str(ticket_id)))
    try:
        label = "بسته شد" if status == "closed" else "دوباره باز شد"
        await _telegram_request_with_button_fallback(
            context.bot.send_message, int(ticket["user_id"]), f"🎫 تیکت #{ticket_id} توسط ادمین {label}."
        )
    except TelegramError:
        logger.warning("Could not notify user about ticket status %s", ticket_id)
    rows = []
    if ticket.get("status") == "open":
        rows.append(
            [
                InlineKeyboardButton("✍️ پاسخ", callback_data=f"ticket_a_reply:{ticket['id']}"),
                InlineKeyboardButton("🔒 بستن", callback_data=f"ticket_a_close:{ticket['id']}"),
            ]
        )
        rows.append(
            [
                InlineKeyboardButton("⚡ فوری", callback_data=f"ticket_priority:{ticket['id']}:urgent"),
                InlineKeyboardButton("🔶 بالا", callback_data=f"ticket_priority:{ticket['id']}:high"),
                InlineKeyboardButton("👤 تخصیص به من", callback_data=f"ticket_assign_me:{ticket['id']}"),
            ]
        )
    else:
        rows.append([InlineKeyboardButton("🔓 بازکردن دوباره", callback_data=f"ticket_a_open:{ticket['id']}")])
    rows += back("a_tickets")
    await edit(query, (await run_blocking(_ticket_detail_text, ticket, admin_view=True)), rows)


async def u_faq(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    language = (await run_blocking(_language_for_user, query.from_user.id))
    state = control_module_state((await async_snapshot()), "faq")
    faqs = search_faqs((await async_snapshot()), "", active_only=True, limit=40)
    if not faqs:
        await edit(query, "❓ No active FAQ is available." if language == "en" else "❓ هنوز سؤال متداول فعالی ثبت نشده است.", [[InlineKeyboardButton("↩️ Support & services" if language == "en" else "↩️ پشتیبانی و خدمات", callback_data="nav_user:support", style="primary")]])
        return
    rows: list[list[InlineKeyboardButton]] = []
    if state.get("search", True):
        rows.append([InlineKeyboardButton("🔎 Search FAQs" if language == "en" else "🔎 جستجو در سوالات", callback_data="faq_search")])
    categories: dict[str, list[dict[str, Any]]] = {}
    for item in faqs:
        category = (
            str(item.get("category_en") or item.get("category") or "General")
            if language == "en"
            else str(item.get("category") or "عمومی")
        )
        categories.setdefault(category, []).append(item)
    for category, items in list(categories.items())[:12]:
        if state.get("categories", True):
            rows.append([InlineKeyboardButton(f"📁 {category}", callback_data="faq_noop")])
        rows.extend([InlineKeyboardButton(f"❓ {str(item.get('q_en') or item.get('q'))[:45]}", callback_data=f"faq:{item.get('id')}")] for item in items[:10])
    rows.append([InlineKeyboardButton("↩️ Support & services" if language == "en" else "↩️ پشتیبانی و خدمات", callback_data="nav_user:support", style="primary")])
    await edit(query, "❓ <b>Frequently asked questions</b>\nChoose a question or search the knowledge base." if language == "en" else "❓ <b>سؤالات متداول</b>\nسؤال موردنظر را انتخاب یا جستجو کنید.", rows)


async def faq_search_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    language = (await run_blocking(_language_for_user, query.from_user.id))
    await edit(query, "🔎 Send a keyword to search questions and answers:" if language == "en" else "🔎 عبارت موردنظر را برای جستجو در سؤال و پاسخ ارسال کنید:", [[InlineKeyboardButton("↩️ FAQ", callback_data="u_faq")]])
    return FAQ_SEARCH_INPUT


async def faq_search_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    language = (await run_blocking(_language_for_user, update.effective_user.id))
    query_text = str(update.effective_message.text or "").strip()
    rows_found = search_faqs((await async_snapshot()), query_text, active_only=True, limit=20)
    rows = [[InlineKeyboardButton(f"❓ {str(item.get('q_en') or item.get('q'))[:45] if language == 'en' else str(item.get('q'))[:45]}", callback_data=f"faq:{item.get('id')}")] for item in rows_found]
    rows.append([InlineKeyboardButton("↩️ FAQ", callback_data="u_faq")])
    text = f"🔎 <b>Search results for:</b> {esc(query_text)}\n\n" if language == "en" else f"🔎 <b>نتایج جستجو برای:</b> {esc(query_text)}\n\n"
    text += (f"Results: <b>{len(rows_found)}</b>" if rows_found else "No result found.") if language == "en" else (f"تعداد نتیجه: <b>{len(rows_found)}</b>" if rows_found else "نتیجه‌ای پیدا نشد.")
    await reply(update, text, rows)
    return ConversationHandler.END


async def faq_answer(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    language = (await run_blocking(_language_for_user, query.from_user.id))
    faq_id = query.data.split(":", 1)[1]
    try:
        item = await async_with_db(lambda db: record_faq_view(db, faq_id))
    except ValueError:
        await query.answer("سؤال پیدا نشد یا غیرفعال است.", show_alert=True)
        return
    await query.answer()
    question = str(item.get("q_en") or item.get("q") or "")[:300] if language == "en" else str(item.get("q") or "")[:300]
    answer = str(item.get("a_en") or item.get("a") or "")[:3300] if language == "en" else str(item.get("a") or "")[:3300]
    state = control_module_state((await async_snapshot()), "faq")
    rows: list[list[InlineKeyboardButton]] = []
    if state.get("feedback", True):
        rows.append(
            [
                InlineKeyboardButton("👍 Helpful" if language == "en" else "👍 مفید بود", callback_data=f"faq_vote:{item['id']}:yes"),
                InlineKeyboardButton("👎 Not helpful" if language == "en" else "👎 مفید نبود", callback_data=f"faq_vote:{item['id']}:no"),
            ]
        )
    rows += back("u_faq")
    await edit(
        query,
        f"❓ <b>{esc(question)}</b>\n\n💬 {esc(answer)}\n\n📁 {esc(item.get('category_en') or item.get('category') or ('General' if language == 'en' else 'عمومی'))} | 👁 {int(item.get('views', 0) or 0)}",
        rows,
    )


async def faq_vote_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    language = (await run_blocking(_language_for_user, query.from_user.id))
    _, faq_id, vote = query.data.split(":", 2)
    try:
        await async_with_db(lambda db: record_faq_feedback(db, faq_id, query.from_user.id, vote == "yes"))
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    await query.answer("Your feedback was recorded." if language == "en" else "بازخورد شما ثبت شد", show_alert=True)
    await async_with_db(lambda db: record_user_activity(db, query.from_user.id, "faq_feedback", f"{faq_id}:{vote}"))


async def faq_noop(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    language = (await run_blocking(_language_for_user, update.callback_query.from_user.id))
    await update.callback_query.answer("Choose a question below this category." if language == "en" else "برای مشاهده سؤال، یکی از موارد زیر دسته را انتخاب کنید.")


async def a_faq(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_FAQ):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    faqs = search_faqs((await async_snapshot()), "", active_only=False, limit=200)
    active_count = sum(bool(item.get("active", True)) for item in faqs)
    rows = [[InlineKeyboardButton("➕ افزودن سؤال متداول", callback_data="faq_add")]]
    for item in faqs[:60]:
        rows.append(
            [
                InlineKeyboardButton(
                    f"{'✅' if item.get('active', True) else '⛔️'} #{item.get('id')} — {str(item.get('q'))[:30]}",
                    callback_data=f"faq_manage:{item.get('id')}",
                )
            ]
        )
    rows += back("admin_home")
    await edit(
        query,
        "❓ <b>مدیریت کامل سوالات متداول</b>\n\n"
        f"کل: <b>{len(faqs)}</b> | فعال: <b>{active_count}</b> | غیرفعال: <b>{len(faqs) - active_count}</b>",
        rows,
    )
    return ConversationHandler.END


async def faq_manage(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_FAQ):
        return
    query = update.callback_query
    item = find_faq((await async_snapshot()), query.data.split(":", 1)[1])
    if not item:
        await query.answer("سؤال پیدا نشد", show_alert=True)
        return
    await query.answer()
    rows = [
        [
            InlineKeyboardButton("✏️ ویرایش", callback_data=f"faq_edit:{item['id']}"),
            InlineKeyboardButton("⛔️ غیرفعال" if item.get("active", True) else "✅ فعال", callback_data=f"faq_toggle:{item['id']}"),
        ],
        [InlineKeyboardButton("🗑 حذف", callback_data=f"faq_delete:{item['id']}")],
        *back("a_faq"),
    ]
    await edit(
        query,
        f"❓ <b>مدیریت FAQ #{item['id']}</b>\n\n"
        f"سؤال: {esc(item.get('q'))}\n\nپاسخ: {esc(item.get('a'))}\n\n"
        f"دسته: <b>{esc(item.get('category') or 'عمومی')}</b>\n"
        f"وضعیت: <b>{'فعال' if item.get('active', True) else 'غیرفعال'}</b>\n"
        f"👁 {int(item.get('views', 0) or 0)} | 👍 {int(item.get('helpful', 0) or 0)} | 👎 {int(item.get('not_helpful', 0) or 0)}",
        rows,
    )


async def faq_add_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_FAQ):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    context.user_data.pop("faq_question", None)
    await edit(query, "متن سؤال متداول را ارسال کنید:", back("a_faq"))
    return FAQ_ADD_QUESTION


async def faq_add_question(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_FAQ):
        return ConversationHandler.END
    question = (update.effective_message.text or "").strip()
    if not question:
        await reply(update, "❌ سؤال نمی‌تواند خالی باشد.")
        return FAQ_ADD_QUESTION
    context.user_data["faq_question"] = question[:300]
    await reply(update, "پاسخ را ارسال کنید. برای تعیین دسته بنویسید: <code>نام دسته | متن پاسخ</code>", back("a_faq"))
    return FAQ_ADD_ANSWER


async def faq_add_answer(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_FAQ):
        return ConversationHandler.END
    question = context.user_data.pop("faq_question", None)
    if not question:
        await reply(update, "❌ فرایند افزودن سؤال منقضی شده است.", back("a_faq"))
        return ConversationHandler.END
    raw = str(update.effective_message.text or "").strip()
    category, answer = ("عمومی", raw)
    if "|" in raw:
        category, answer = (part.strip() for part in raw.split("|", 1))
    try:
        item = await async_with_db(lambda db: create_faq(db, question, answer, category=category))
    except ValueError as exc:
        await reply(update, f"❌ {esc(exc)}", back("a_faq"))
        return ConversationHandler.END
    await async_with_db(lambda db: audit(db, update.effective_user.id, "faq_add", str(item["id"])))
    await reply(update, f"✅ سؤال متداول <b>#{item['id']}</b> اضافه شد.", back("a_faq"))
    return ConversationHandler.END


async def faq_edit_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_FAQ):
        return ConversationHandler.END
    query = update.callback_query
    faq_id = query.data.split(":", 1)[1]
    item = find_faq((await async_snapshot()), faq_id)
    if not item:
        await query.answer("سؤال پیدا نشد", show_alert=True)
        return ConversationHandler.END
    context.user_data["faq_edit_id"] = int(faq_id)
    await query.answer()
    await edit(
        query,
        "اطلاعات جدید را با قالب زیر ارسال کنید:\n<code>سؤال | پاسخ | دسته‌بندی</code>\n\nهر سه قسمت الزامی است.",
        back(f"faq_manage:{faq_id}"),
    )
    return FAQ_EDIT_INPUT


async def faq_edit_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_FAQ):
        return ConversationHandler.END
    faq_id = context.user_data.get("faq_edit_id")
    parts = [part.strip() for part in str(update.effective_message.text or "").split("|", 2)]
    if len(parts) != 3 or not all(parts):
        await reply(update, "❌ قالب صحیح: سؤال | پاسخ | دسته‌بندی")
        return FAQ_EDIT_INPUT
    try:
        item = await async_with_db(lambda db: update_faq(db, faq_id, question=parts[0], answer=parts[1], category=parts[2]))
    except ValueError as exc:
        await reply(update, f"❌ {esc(exc)}", back("a_faq"))
        return ConversationHandler.END
    context.user_data.pop("faq_edit_id", None)
    await async_with_db(lambda db: audit(db, update.effective_user.id, "faq_edit", str(item["id"])))
    await reply(update, f"✅ FAQ #{item['id']} ویرایش شد.", back(f"faq_manage:{item['id']}"))
    return ConversationHandler.END


async def faq_toggle_admin(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_FAQ):
        return
    query = update.callback_query
    faq_id = query.data.split(":", 1)[1]
    try:
        item = await async_with_db(lambda db: toggle_faq(db, faq_id))
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    await async_with_db(lambda db: audit(db, query.from_user.id, "faq_toggle", f"{faq_id}:{item.get('active')}"))
    await query.answer("فعال شد" if item.get("active") else "غیرفعال شد")
    await faq_manage(update, context)


async def faq_delete_admin(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_FAQ):
        return
    query = update.callback_query
    faq_id = query.data.split(":", 1)[1]
    item = await async_with_db(lambda db: delete_faq(db, faq_id))
    if not item:
        await query.answer("سؤال پیدا نشد.", show_alert=True)
        return
    await query.answer("حذف شد")
    await async_with_db(lambda db: audit(db, query.from_user.id, "faq_delete", str(faq_id)))
    # Render directly to avoid answering the same callback twice.
    faqs = search_faqs((await async_snapshot()), "", active_only=False, limit=200)
    rows = [[InlineKeyboardButton("➕ افزودن سؤال متداول", callback_data="faq_add")]]
    rows.extend(
        [
            [
                InlineKeyboardButton(
                    f"{'✅' if faq.get('active', True) else '⛔️'} #{faq.get('id')} — {str(faq.get('q'))[:30]}",
                    callback_data=f"faq_manage:{faq.get('id')}",
                )
            ]
            for faq in faqs[:60]
        ]
    )
    rows += back("admin_home")
    await edit(query, f"✅ حذف شد. تعداد باقی‌مانده: <b>{len(faqs)}</b>", rows)


async def u_challenges(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Legacy route: the combined hub was removed from the flat user menu."""
    query = update.callback_query
    await query.answer()
    await edit(
        query,
        (await run_blocking(user_home_text, query.from_user, await async_snapshot())),
        (await run_blocking(main_menu, query.from_user.id)),
    )


async def u_contests(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    language = (await run_blocking(_language_for_user, query.from_user.id))
    rows = [
        [InlineKeyboardButton("🎯 Price prediction" if language == "en" else "🎯 پیش‌بینی قیمت", callback_data="contest_price")],
        [InlineKeyboardButton("📊 Chart challenge" if language == "en" else "📊 مسابقه چارت", callback_data="contest_chart")],
        [InlineKeyboardButton("🕯 Candle challenge" if language == "en" else "🕯 مسابقه کندل", callback_data="contest_candle")],
        [InlineKeyboardButton("📰 News direction" if language == "en" else "📰 جهت بازار بعد از خبر", callback_data="contest_news")],
        [InlineKeyboardButton("↩️ Main menu" if language == "en" else "↩️ منوی اصلی", callback_data="home")],
    ]
    from modules.ticket_context import competition_contexts
    for ident, contest in competition_contexts(await async_snapshot()):
        if contest.get('status') in {'active','awaiting_result'} or contest.get('active'):
            rows.insert(-1,[InlineKeyboardButton(f"🎫 پیگیری مسابقه {ident}",callback_data=f'ticket_from:competition:{ident}')])
    await edit(query, "🎯 <b>Contests</b>" if language == "en" else "🎯 <b>مسابقه‌ها</b>", rows)
    return ConversationHandler.END


async def contest_price_join(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    language = (await run_blocking(_language_for_user, query.from_user.id))
    await query.answer()
    contest = await async_with_db(get_open_price_contest)
    if not contest:
        await edit(
            query,
            "❌ There is no active price contest." if language == "en" else "❌ مسابقه قیمت فعالی وجود ندارد.",
            back("u_contests", language=language),
        )
        return ConversationHandler.END
    context.user_data["price_contest_entry_id"]=contest["id"]
    question = (
        contest.get("question_en") or contest.get("question")
        if language == "en"
        else contest.get("question") or contest.get("question_en")
    )
    caption = (
        (
            "🎯 <b>Price Prediction Contest</b>\n"
            f"{esc(question) + chr(10) if question else ''}"
            f"📌 Symbol: <b>{esc(contest.get('symbol'))}</b>\n"
            f"⏰ Ends: <b>{display_dt(contest.get('ends_at'))}</b>\n\n"
            f"The closest answer earns <b>{esc(__import__('modules.prize_delivery',fromlist=['prize_label']).prize_label(contest.get('prize_by_rank',{}).get('1') or {'points':contest.get('reward_points',5)},'en'))}</b>. Send your prediction:"
            if language == "en"
            else "🎯 <b>مسابقه پیش‌بینی قیمت</b>\n"
            f"{esc(question) + chr(10) if question else ''}"
            f"📌 نماد: <b>{esc(contest.get('symbol'))}</b>\n"
            f"⏰ پایان: <b>{display_dt(contest.get('ends_at'))}</b>\n\n"
            f"جایزه نزدیک‌ترین پاسخ: <b>{esc(__import__('modules.prize_delivery',fromlist=['prize_label']).prize_label(contest.get('prize_by_rank',{}).get('1') or {'points':contest.get('reward_points',5)}))}</b>. قیمت پیش‌بینی‌شده را ارسال کنید:"
        )
    )
    if contest.get("photo_file_id"):
        await _telegram_request_with_button_fallback(
            query.message.reply_photo, contest["photo_file_id"], caption=caption, parse_mode=ParseMode.HTML
        )
        await edit(
            query,
            "📩 Contest details sent. Now send your predicted price."
            if language == "en"
            else "📩 جزئیات مسابقه ارسال شد؛ اکنون عدد پیش‌بینی را بفرستید.",
            back("u_contests", language=language),
        )
    else:
        await edit(query, caption, back("u_contests", language=language))
    return PRICE_GUESS


async def contest_price_guess(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    language = (await run_blocking(_language_for_user, update.effective_user.id))
    if not (await run_blocking(rate_limit_allow, update.effective_user.id, "price_guess", 2)):
        await reply(update, "⏳ Please wait a moment." if language == "en" else "⏳ لطفاً کمی صبر کنید.")
        return PRICE_GUESS
    try:
        guess = parse_finite_float(update.message.text, positive=True)
    except ValueError as exc:
        await reply(update, f"❌ {esc(exc)}")
        return PRICE_GUESS
    result = await async_with_db(lambda db: add_price_guess(db, update.effective_user.id, update.message.text,contest_id=context.user_data.get("price_contest_entry_id","")))
    messages = (
        {
            "OK": f"✅ Prediction <b>{guess}</b> was saved.",
            "NO_ACTIVE": "❌ The contest is not active or has ended.",
            "NOT_ELIGIBLE": "You are not eligible for this contest.",
            "FULL": "This contest is full.",
            "ALREADY": "⚠️ You have already submitted an answer for this contest.",
        }
        if language == "en"
        else {
            "OK": f"✅ پیش‌بینی <b>{guess}</b> ثبت شد.",
            "NO_ACTIVE": "❌ مسابقه فعال نیست یا زمان آن تمام شده است.",
            "NOT_ELIGIBLE": "شرایط شرکت در این مسابقه را ندارید.",
            "FULL": "ظرفیت مسابقه تکمیل است.",
            "ALREADY": "⚠️ قبلاً در این مسابقه پاسخ ثبت کرده‌اید.",
        }
    )
    await reply(
        update,
        messages.get(result, "❌ Could not save your answer." if language == "en" else "❌ ثبت پاسخ انجام نشد."),
        back("u_contests", language=language),
    )
    return ConversationHandler.END


async def contest_chart_join(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    language = (await run_blocking(_language_for_user, query.from_user.id))
    await query.answer()
    contest = await async_with_db(get_open_chart_contest)
    if not contest:
        await edit(
            query,
            "❌ There is no active chart contest." if language == "en" else "❌ مسابقه چارت فعالی وجود ندارد.",
            back("u_contests", language=language),
        )
        return ConversationHandler.END
    rows = [
        [
            InlineKeyboardButton("📈 Bullish" if language == "en" else "📈 صعودی", callback_data=f"chart_answer:UP:{contest['id']}"),
            InlineKeyboardButton("📉 Bearish" if language == "en" else "📉 نزولی", callback_data=f"chart_answer:DOWN:{contest['id']}"),
            InlineKeyboardButton("➡️ Flat" if language == "en" else "➡️ خنثی", callback_data=f"chart_answer:FLAT:{contest['id']}"),
        ],
        back("u_contests", language=language)[0],
    ]
    question = (
        contest.get("question_en") or contest.get("question")
        if language == "en"
        else contest.get("question") or contest.get("question_en")
    )
    text = (
        (
            f"📊 <b>Chart Contest</b>\n{esc(question)}\n"
            f"⏰ Ends: {display_dt(contest.get('ends_at'))}\n"
            f"🏆 Correct-answer reward: <b>{int(contest.get('reward_points', 5))}</b> points"
            if language == "en"
            else f"📊 <b>مسابقه چارت</b>\n{esc(question)}\n"
            f"⏰ پایان: {display_dt(contest.get('ends_at'))}\n"
            f"🏆 امتیاز پاسخ صحیح: <b>{int(contest.get('reward_points', 5))}</b>"
        )
    )
    if contest.get("photo_file_id"):
        await _telegram_request_with_button_fallback(
            query.message.reply_photo,
            contest["photo_file_id"],
            caption=text,
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup(rows),
        )
        await edit(
            query,
            "📩 Contest question sent." if language == "en" else "📩 سؤال مسابقه ارسال شد.",
            back("u_contests", language=language),
        )
    else:
        await edit(query, text, rows)
    return ConversationHandler.END


async def chart_answer(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    language = (await run_blocking(_language_for_user, query.from_user.id))
    if not (await run_blocking(rate_limit_allow, query.from_user.id, "chart_answer", 2)):
        await query.answer("Please wait a moment." if language == "en" else "لطفاً کمی صبر کنید.", show_alert=False)
        return
    await query.answer()
    parts=query.data.split(":")
    choice=parts[1]
    contest_id=parts[2] if len(parts)==3 else ""
    result = await async_with_db(lambda db: add_chart_answer(db, query.from_user.id, choice,contest_id=contest_id))
    messages = (
        {
            "OK": f"✅ Answer <b>{esc(choice)}</b> was saved.",
            "ALREADY": "⚠️ You have already submitted an answer.",
            "NO_ACTIVE": "❌ The contest is not active or has ended.",
            "INVALID": "❌ Invalid answer.",
        }
        if language == "en"
        else {
            "OK": f"✅ پاسخ <b>{esc(choice)}</b> ثبت شد.",
            "ALREADY": "⚠️ قبلاً پاسخ ثبت کرده‌اید.",
            "NO_ACTIVE": "❌ مسابقه فعال نیست یا زمان آن تمام شده است.",
            "INVALID": "❌ پاسخ نامعتبر است.",
        }
    )
    await edit(
        query,
        messages.get(result, "❌ Could not save your answer." if language == "en" else "❌ ثبت پاسخ انجام نشد."),
        back("u_contests", language=language),
    )


async def contest_candle_join(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    language = (await run_blocking(_language_for_user, query.from_user.id))
    await query.answer()
    contest = await async_with_db(get_open_candle_contest)
    if not contest:
        await edit(
            query,
            "❌ There is no active candle contest." if language == "en" else "❌ مسابقه کندل فعالی وجود ندارد.",
            back("u_contests", language=language),
        )
        return ConversationHandler.END
    context.user_data["candle_contest_entry_id"]=contest["id"]
    rewards = contest.get("reward_by_rank", {"1": 10, "2": 7, "3": 5, "4": 3})
    question = str(contest.get("question") or "قیمت بسته‌شدن کندل چقدر خواهد بود؟")
    await edit(
        query,
        (
            f"🕯 <b>Candle Contest</b>\n{esc(question)}\n⏰ Ends: {display_dt(contest.get('ends_at'))}\n"
            f"🏆 Rewards: 1st {int(rewards.get('1', 10))}, 2nd {int(rewards.get('2', 7))}, 3rd {int(rewards.get('3', 5))}, ranks 4-10 each {int(rewards.get('4', 3))}\n"
            "Send the predicted closing price:"
            if language == "en"
            else f"🕯 <b>مسابقه کندل</b>\n{esc(question)}\n⏰ پایان: {display_dt(contest.get('ends_at'))}\n"
            f"🏆 امتیازها: اول {int(rewards.get('1', 10))}، دوم {int(rewards.get('2', 7))}، سوم {int(rewards.get('3', 5))}، رتبه‌های ۴ تا ۱۰ هرکدام {int(rewards.get('4', 3))}\n"
            "قیمت بسته‌شدن را ارسال کنید:"
        ),
        back("u_contests", language=language),
    )
    return CANDLE_GUESS


async def candle_guess(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    language = (await run_blocking(_language_for_user, update.effective_user.id))
    if not (await run_blocking(rate_limit_allow, update.effective_user.id, "candle_guess", 2)):
        await reply(update, "⏳ Please wait a moment." if language == "en" else "⏳ لطفاً کمی صبر کنید.")
        return CANDLE_GUESS
    try:
        guess = parse_finite_float(update.message.text, positive=True)
    except ValueError as exc:
        await reply(update, f"❌ {esc(exc)}")
        return CANDLE_GUESS
    result = await async_with_db(lambda db: add_candle_guess(db, update.effective_user.id, update.message.text,contest_id=context.user_data.get("candle_contest_entry_id","")))
    messages = (
        {
            "OK": f"✅ Prediction <b>{guess}</b> was saved.",
            "ALREADY": "⚠️ You have already submitted an answer.",
            "NO_ACTIVE": "❌ The contest is not active or has ended.",
        }
        if language == "en"
        else {
            "OK": f"✅ پیش‌بینی <b>{guess}</b> ثبت شد.",
            "ALREADY": "⚠️ قبلاً پاسخ ثبت کرده‌اید.",
            "NO_ACTIVE": "❌ مسابقه فعال نیست یا زمان آن تمام شده است.",
        }
    )
    await reply(
        update,
        messages.get(result, "❌ Could not save your answer." if language == "en" else "❌ ثبت پاسخ انجام نشد."),
        back("u_contests", language=language),
    )
    return ConversationHandler.END



async def contest_news_join(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    language = (await run_blocking(_language_for_user, query.from_user.id))
    await query.answer()
    contest = await async_with_db(get_open_news_direction_contest)
    if not contest:
        await edit(
            query,
            "❌ There is no active news contest." if language == "en" else "❌ مسابقه خبر فعالی وجود ندارد.",
            back("u_contests", language=language),
        )
        return ConversationHandler.END
    rows = [[
        InlineKeyboardButton("📈 Bullish" if language == "en" else "📈 صعودی", callback_data=f"news_answer:UP:{contest['id']}"),
        InlineKeyboardButton("📉 Bearish" if language == "en" else "📉 نزولی", callback_data=f"news_answer:DOWN:{contest['id']}"),
        InlineKeyboardButton("↔️ Range" if language == "en" else "↔️ رنج", callback_data=f"news_answer:RANGE:{contest['id']}"),
    ], back("u_contests", language=language)[0]]
    text = (
        f"📰 <b>News direction contest</b>\nNews: <b>{esc(contest.get('news_name'))}</b>\n"
        f"Predict the market direction 30 minutes after the news.\nReward: <b>{int(contest.get('reward_points', 5))}</b> points"
        if language == "en"
        else f"📰 <b>مسابقه جهت بازار بعد از خبر</b>\nخبر: <b>{esc(contest.get('news_name'))}</b>\n"
        f"جهت بازار در ۳۰ دقیقه بعد از خبر را پیش‌بینی کنید.\nجایزه پاسخ صحیح: <b>{int(contest.get('reward_points', 5))}</b> امتیاز"
    )
    await edit(query, text, rows)
    return ConversationHandler.END


async def news_answer(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    language = (await run_blocking(_language_for_user, query.from_user.id))
    await query.answer()
    parts=query.data.split(":")
    choice=parts[1]
    contest_id=parts[2] if len(parts)==3 else ""
    result = await async_with_db(lambda db: add_news_direction_answer(db, query.from_user.id, choice,contest_id=contest_id))
    messages = {
        "OK": "✅ پیش‌بینی شما ثبت شد.",
        "ALREADY": "⚠️ قبلاً در این مسابقه پاسخ ثبت کرده‌اید.",
        "NO_ACTIVE": "❌ مسابقه فعال نیست یا پایان یافته است.",
        "INVALID": "❌ پاسخ نامعتبر است.",
    }
    if language == "en":
        messages = {"OK": "✅ Your prediction was saved.", "ALREADY": "⚠️ You already answered.", "NO_ACTIVE": "❌ Contest is not active.", "INVALID": "❌ Invalid answer."}
    await edit(query, messages.get(result, "❌ ثبت پاسخ انجام نشد."), back("u_contests", language=language))

def _activity_descriptor(update: Update) -> tuple[str, str, dict[str, Any]]:
    if update.callback_query:
        data = str(update.callback_query.data or "unknown")[:120]
        return f"callback:{data}", "callback", {"callback_data": data}
    message = update.effective_message
    if not message:
        return "update:unknown", "telegram", {}
    text = str(message.text or "")
    if text.startswith("/"):
        command = text.split(maxsplit=1)[0].split("@", 1)[0][:80]
        return f"command:{command}", "command", {}
    if message.photo:
        return "message:photo", "message", {}
    if message.document:
        return "message:document", "message", {"mime_type": str(message.document.mime_type or "")[:80]}
    if message.video:
        return "message:video", "message", {}
    if message.voice:
        return "message:voice", "message", {}
    if text:
        return "message:text", "message", {"length": len(text)}
    return "message:other", "message", {}



__feature_exports__ = ('account_education', 'account_rewards', 'account_activity', 'u_score', 'u_leaderboard', 'u_referral', 'u_rewards', 'u_reward_catalog', 'u_settings', 'redeem_reward', 'u_my_rewards', 'a_user_rewards', 'a_reward_points', 'reward_points_select', 'reward_points_input', 'u_missions', 'u_challenges', 'internal_search_start', 'internal_search_input', '_categories', 'u_edu', 'edu_type', 'edu_category', 'edu_lesson', 'lesson_complete_handler', 'lesson_rate_handler', 'education_buy_start', 'education_receipt', 'education_receipt_invalid', 'education_order_review', 'a_edu_orders', 'education_order_view', '_ticket_attachment_from_message', '_ticket_body_and_attachment', '_ticket_attachment_text', '_copy_ticket_message', '_send_ticket_attachment', 'u_support', 'ticket_new_start', 'ticket_new_category', 'ticket_new_message', '_ticket_detail_text', '_ticket_user_rows', '_ticket_admin_rows', 'ticket_user_list', 'ticket_user_detail', 'ticket_user_reply_start', 'ticket_user_reply_message', 'a_tickets', 'ticket_admin_closed_list', 'ticket_admin_detail', 'ticket_priority_handler', 'ticket_assign_me_handler', 'ticket_rate_handler', 'ticket_admin_reply_start', 'ticket_admin_reply_message', 'ticket_note_start', 'ticket_note_input', 'ticket_notes_view', 'ticket_canned_panel', 'ticket_canned_add_start', 'ticket_canned_add_input', 'ticket_canned_toggle_handler', 'ticket_canned_delete_handler', 'ticket_canned_for_ticket', 'ticket_canned_use_handler', 'ticket_admin_status', 'u_faq', 'faq_search_start', 'faq_search_input', 'faq_answer', 'faq_vote_handler', 'faq_noop', 'a_faq', 'faq_manage', 'faq_add_start', 'faq_add_question', 'faq_add_answer', 'faq_edit_start', 'faq_edit_input', 'faq_toggle_admin', 'faq_delete_admin', 'u_contests', 'contest_price_join', 'contest_price_guess', 'contest_chart_join', 'chart_answer', 'contest_candle_join', 'candle_guess', 'contest_news_join', 'news_answer', '_activity_descriptor')
