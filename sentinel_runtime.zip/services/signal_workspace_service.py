"""Shared claims, private editorial notes and a single paged signal case."""
import time,re
from repositories.v2.live_signal_inbox import LiveSignalInbox,global_inbox_scope
from repositories.v2.common import json_dump,json_load,content_hash

TAGS=('WRONG_SWEEP','WRONG_WAVE','STOP_TOO_CLOSE','POC_OUTSIDE','DIRECTION_CONFLICT','GOOD_CONFLUENCE','OTHER')


def _signal(user,key):
    from services.live_signal_service import permitted
    from modules.automated_market_scope import require_global_symbol
    permitted(user);repo=LiveSignalInbox();row=repo.get(key)
    if not row:raise ValueError('LIVE_SIGNAL_NOT_FOUND')
    require_global_symbol(row['payload']['plan']['symbol'])
    return repo,row


def workspace(user,key,body=None):
    repo,row=_signal(user,key);now=int(time.time()*1000)
    if body is not None and (not isinstance(body,dict) or type(body.get('revision')) is not int or body.get('action') not in {'claim','release','note','tag'}):
        raise ValueError('SIGNAL_WORKSPACE_INVALID')
    with repo.engine.transaction(read_only=body is None) as c:
        if body is not None and repo.engine.dialect.name=='postgres':c.execute('SELECT pg_advisory_xact_lock(hashtextextended(?,0))',('signal-workspace:'+key,))
        r=c.execute('SELECT * FROM s9_signal_workspace WHERE signal_id=?',(key,)).fetchone()
        current={'revision':r['revision'],'payload':json_load(r['payload'])} if r else {'revision':0,'payload':{'claim':None,'notes':[],'tags':[]}}
        if body is None:return {**current,'tag_catalog':TAGS}
        if current['revision']!=body['revision']:raise ValueError('SIGNAL_WORKSPACE_CHANGED')
        p=current['payload'];claim=p.get('claim');action=body['action'];detail={'actor':str(user)}
        if action=='claim':
            if row['state']!='PENDING':raise ValueError('SIGNAL_NOT_PENDING')
            if claim and claim['expires_ms']>now and claim['actor']!=str(user):raise ValueError('SIGNAL_ALREADY_CLAIMED')
            p['claim']={'actor':str(user),'claimed_ms':now,'expires_ms':now+600000};detail.update(p['claim'])
        elif action=='release':
            if claim and claim['actor']!=str(user):raise PermissionError('CLAIM_OWNER_REQUIRED')
            p['claim']=None
        elif action=='note':
            text=body.get('text')
            if not isinstance(text,str) or not 1<=len(text.strip())<=2000:raise ValueError('SIGNAL_NOTE_INVALID')
            detail['text']=text.strip();p['notes']=(p.get('notes',[])+[{**detail,'at_ms':now}])[-20:]
        else:
            if body.get('tag') not in TAGS or type(body.get('enabled')) is not bool:raise ValueError('SIGNAL_TAG_INVALID')
            tags=set(p.get('tags',[]));tags.add(body['tag']) if body['enabled'] else tags.discard(body['tag'])
            p['tags']=sorted(tags);detail.update(tag=body['tag'],enabled=body['enabled'])
        revision=current['revision']+1
        c.execute('INSERT INTO s9_signal_workspace VALUES(?,?,?) ON CONFLICT(signal_id) DO UPDATE SET revision=excluded.revision,payload=excluded.payload',(key,revision,json_dump(p)))
        from repositories.v2.signal_timeline import record
        record(c,key,'ADMIN_'+action.upper(),now,detail,key=f'workspace:{revision}')
        return {'revision':revision,'payload':p,'tag_catalog':TAGS}


def timeline(user,key,*,after=None):
    repo,row=_signal(user,key)
    if after:
        if not isinstance(after,str) or not re.fullmatch('[0-9]{1,16}:[a-f0-9]{32}',after):raise ValueError('TIMELINE_CURSOR_INVALID')
        stamp,event=after.split(':');stamp=int(stamp)
    else:stamp,event=-1,''
    with repo.engine.transaction(read_only=True,repeatable_read=True) as c:
        events=c.execute('SELECT * FROM s9_signal_timeline WHERE signal_id=? AND (at_ms>? OR (at_ms=? AND id>?)) ORDER BY at_ms,id LIMIT 100',(key,stamp,stamp,event)).fetchall()
        trade=c.execute('SELECT id,run_id,state,revision FROM s9_strategy_paper_trades WHERE signal_id=?',(key,)).fetchone()
        linked=c.execute('SELECT case_id FROM s9_research_links WHERE source_key=?',(row['payload']['plan'].get('setup_id',row['payload'].get('source_id','')),)).fetchone()
    return {'signal_id':key,'plan_hash':row['payload']['plan_hash'],'state':row['state'],'paper':trade,
            'research_case_id':linked['case_id'] if linked else None,
            'items':[{**e,'payload':json_load(e['payload'])} for e in events],
            'next_after':f"{events[-1]['at_ms']}:{events[-1]['id']}" if len(events)==100 else None}


def related(user,key):
    repo,row=_signal(user,key);plan=row['payload']['plan'];scope,params=global_inbox_scope(repo.engine,'i.')
    expr="CAST(i.payload AS JSONB)->'plan'->>'symbol'" if repo.engine.dialect.name=='postgres' else "json_extract(i.payload,'$.plan.symbol')"
    with repo.engine.transaction(read_only=True) as c:
        rows=c.execute('SELECT i.id,i.engine,i.created_ms,i.state,i.payload FROM s9_signal_inbox i WHERE '+scope+' AND '+expr+'=? AND i.id!=? AND i.created_ms BETWEEN ? AND ? ORDER BY i.created_ms DESC LIMIT 100',(*params,plan['symbol'],key,row['created_ms']-3600000,row['created_ms']+3600000)).fetchall()  # nosec B608 -- fixed dialect expression and bound values
    out=[]
    from decimal import Decimal as D
    for r in rows:
        p=json_load(r.pop('payload'))['plan'];overlap=max(D(plan['zone_low']),D(p['zone_low']))<=min(D(plan['zone_high']),D(p['zone_high']))
        out.append({**r,'direction':p['direction'],'relation':'DIRECTION_CONFLICT' if p['direction']!=plan['direction'] else 'OVERLAPPING_ZONE' if overlap else 'SAME_SYMBOL',
                    'zone':{'low':p['zone_low'],'high':p['zone_high']},'entry':p['entry'],'stop':p['stop'],
                    'timeframe':p['timeframe'],'evidence':p.get('evidence',[]),'independent_plan_preserved':True})
    return {'items':out,'window_ms':3600000,'limit':100,'automatic_cancellation':False,'exposure_model':'RELATION_NOT_STATISTICAL_CORRELATION'}
