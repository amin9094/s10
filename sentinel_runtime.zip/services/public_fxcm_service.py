"""Keyless public quotes for display. Not native dated/tick-qualified evidence."""

from __future__ import annotations

import re
import time
import xml.etree.ElementTree as ET  # nosec B405 -- bounded input rejects DTD and entities before parsing

from modules.canonical_market import price

PUBLIC_RATE_URL = "https://rates.fxcm.com/RatesXML"
_CACHE = (0.0, None)


def parse_public_rates(raw, *, received_ms, http_date=None):
    if not isinstance(raw, bytes) or len(raw) > 512000 or b"\x00" in raw or b"<!DOCTYPE" in raw.upper() or b"<!ENTITY" in raw.upper():
        raise ValueError("PUBLIC_RATE_XML_UNSAFE_OR_OVERSIZED")
    try:
        # Restrict to the endpoint's UTF-8 text; UTF-16 can hide DTD tokens.
        decoded = raw.decode("utf-8-sig")
        root = ET.fromstring(decoded)  # nosec B314 -- DTD/entities rejected and length bounded above
    except (ET.ParseError, UnicodeError):
        raise ValueError("PUBLIC_RATE_XML_INVALID") from None
    from modules.automated_market_scope import CORE_MARKET_SYMBOLS
    selected=set(CORE_MARKET_SYMBOLS)
    output = []
    for row in root.findall("Rate"):
        symbol = row.attrib.get("Symbol")
        if symbol not in selected:
            continue
        bid, ask = price(row.findtext("Bid")), price(row.findtext("Ask"))
        reported = str(row.findtext("Last") or "")
        if ask < bid or not re.fullmatch(r"(?:[01]\d|2[0-3]):[0-5]\d:[0-5]\d", reported):
            raise ValueError("PUBLIC_RATE_FIELDS_INVALID")
        output.append({"symbol": symbol, "provider": "fxcm_public_xml", "venue": "fxcm",
                       "product": "cfd", "bid": str(bid), "ask": str(ask), "spread": str(ask - bid),
                       "source_time_of_day": reported, "native_event_utc_ms": None,
                       "received_ms": received_ms, "http_date": http_date, "tick_size": None,
                       "volume_kind": "unavailable", "verified_entry_eligible": False,
                       "quality_flags": ["NATIVE_FULL_UTC_TIME_UNVERIFIED", "NATIVE_PRICE_GRID_UNAVAILABLE"]})
    if not output:
        raise ValueError("PUBLIC_RATE_SYMBOLS_UNAVAILABLE")
    return {"state": "PUBLIC_DISPLAY_QUOTES", "api_key_required": False, "items": output,
            "cfd_history_state": "CURRENT_HISTORY_NOT_VERIFIED", "account_required_for_this_request": False}


async def public_quotes():
    global _CACHE
    if _CACHE[0] > time.monotonic():
        return _CACHE[1]
    from core.http_client import request

    try:
        response = await request("GET", PUBLIC_RATE_URL, retries=0, timeout_seconds=8)
    except Exception as exc:
        raise RuntimeError(f"PUBLIC_RATE_TRANSPORT_{type(exc).__name__}") from None
    result = parse_public_rates(response.content, received_ms=int(time.time() * 1000), http_date=response.headers.get("Date"))
    _CACHE = (time.monotonic() + 5, result)
    return result
