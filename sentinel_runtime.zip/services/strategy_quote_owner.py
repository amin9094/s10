"""One event-loop owner for native ordered quotes and immutable forward plans."""

import asyncio
import time
import uuid
import weakref

from core.async_runtime import run_blocking
from modules.ordered_quotes import QuoteJournal
from modules.setup_lifecycle import SetupPlan
from repositories.v2.setup_proposals import SetupRepository
from repositories.v2.strategy_live import StrategyLiveRepository

_OWNERS = weakref.WeakKeyDictionary()


def current_owner():
    return _OWNERS.get(asyncio.get_running_loop())


class StrategyQuoteOwner:
    def __init__(self, admin_ids_for, *, repository=None, live_repository=None, stream_factories=None):
        from services.quote_stream_service import stream_kraken_ordered_quotes, stream_okx_ordered_quotes
        self.repository = repository or SetupRepository()
        from repositories.v2.quote_archive import QuoteArchive
        self.archive=QuoteArchive(self.repository.engine)
        self.live = live_repository or StrategyLiveRepository(self.repository.engine)
        self.stream_factories = dict(stream_factories) if stream_factories is not None else {
            'okx':stream_okx_ordered_quotes, 'kraken':stream_kraken_ordered_quotes}
        self.admin_ids_for = admin_ids_for
        self.journals, self.tasks, self.metadata, self.active = {}, {}, {}, {}
        self.background = []
        self.closed = False
        self.connect_lock = asyncio.Lock()
        self.connect_after = 0.0

    def journal_for(self, symbol, provider):
        return self.journals.get((provider, symbol))

    def paper_frames(self,symbol,provider,after_id):
        journal=self.journal_for(symbol,provider)
        if not journal or journal.failure or not journal.rows:raise ValueError('PAPER_SOURCE_UNAVAILABLE')
        live=list(journal.rows)
        if any(f.quote.source_id==after_id for f in live):return live
        saved=self.archive.replay(provider,symbol,live[-1].epoch,after_id)
        if not saved:return live
        # Match by immutable source ID, not a native sequence value (OKX can reset it).
        overlap=next((i for i,f in enumerate(live) if f.quote.source_id==saved[-1].quote.source_id),None)
        if overlap is None:
            # More durable history than one replay batch can safely process.
            return saved
        tail=live[overlap+1:]
        if tail and tail[0].previous_sequence!=saved[-1].sequence:raise ValueError('PAPER_DURABLE_REPLAY_GAP')
        return [*saved,*tail]

    async def start(self):
        from services.admin_review_market_service import review_monitor
        review_monitor().start()
        # A new process has no continuity for old live plans. Preserve confirmed
        # entry/allocations, block further automatic observations until review.
        for row in await run_blocking(self.repository.active_tracking, timeout=10):
            await run_blocking(self.repository.require_tracking_review,row['id'],reason='QUOTE_OWNER_PROCESS_RESTART',
                               now_ms=int(time.time()*1000),timeout=5)
            await self._notice(row,'NEEDS_REVIEW','QUOTE_OWNER_PROCESS_RESTART')
        for row in await run_blocking(self.live.interrupt_pending,before_ms=int(time.time()*1000),reason='PREPARATION_PROCESS_RESTART',timeout=10):
            await self._notice(row,'NEEDS_REVIEW','PREPARATION_PROCESS_RESTART')
        self.background = [asyncio.create_task(self._maintenance(),name='strategy-quote-health')]

    async def ensure(self, symbol, provider, tick_size):
        if self.closed or provider not in self.stream_factories or not symbol.endswith('USDT'):
            return False
        from modules.canonical_market import price
        key = (provider, symbol)
        tick = price(tick_size)
        if key in self.metadata and self.metadata[key] != tick:
            await self._interrupt(key,'NATIVE_TICK_SIZE_CHANGED')
            old=self.tasks.pop(key,None)
            if old:
                old.cancel()
                await asyncio.gather(old,return_exceptions=True)
            self.metadata.pop(key,None)
        if key not in self.tasks:
            if len(self.tasks) >= 25:
                return False
            self.metadata[key] = tick
            self.tasks[key] = asyncio.create_task(self._stream(key,tick),name=f'quote-{provider}-{symbol}')
        deadline = asyncio.get_running_loop().time()+2
        while asyncio.get_running_loop().time() < deadline:
            journal = self.journals.get(key)
            if journal and len(journal.rows)>1 and not journal.failure and journal.rows[-1].quote.fresh(int(time.time()*1000)):
                return True
            await asyncio.sleep(.05)
        return False

    async def _interrupt(self, key, reason):
        provider, symbol = key
        journal = self.journals.get(key)
        if journal:
            journal.failure = reason
        rows = await run_blocking(self.repository.active_tracking,symbol=symbol,provider=provider,timeout=10)
        for row in rows:
            await run_blocking(self.repository.require_tracking_review,row['id'],reason=reason,
                               now_ms=int(time.time()*1000),timeout=5)
            await self._notice(row, 'NEEDS_REVIEW', reason)
        self.active.pop(key,None)

    async def _stream(self, key, tick):
        provider, symbol = key
        backoff = .5
        while not self.closed:
            epoch = uuid.uuid4().hex
            try:
                async with self.connect_lock:
                    wait = max(0,self.connect_after-asyncio.get_running_loop().time())
                    await asyncio.sleep(wait)
                    self.connect_after = asyncio.get_running_loop().time()+.5
                self.journals[key] = QuoteJournal()
                pending_archive=[]
                last_archive_ms=0
                async for frame in self.stream_factories[provider]({symbol:tick},epoch=epoch):
                    if (frame.quote.provider,frame.quote.symbol,frame.quote.tick_size)!=(provider,symbol,tick):
                        raise ValueError('QUOTE_SUBSCRIPTION_PROVENANCE_MISMATCH')
                    if not frame.snapshot and not frame.quote.fresh(int(time.time()*1000)):
                        raise ValueError('NATIVE_QUOTE_STALE')
                    self.journals[key].append(frame)
                    pending_archive.append(frame)
                    if len(pending_archive)>=20 or frame.quote.received_ms-last_archive_ms>=1000:
                        await run_blocking(self.archive.append,pending_archive,timeout=5)
                        pending_archive=[];last_archive_ms=frame.quote.received_ms
                    backoff = .5
                raise ValueError('NATIVE_QUOTE_STREAM_ENDED')
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                try:
                    await self._interrupt(key,f'QUOTE_STREAM_{type(exc).__name__}')
                except Exception:
                    # Journal failure blocks promotions even if the DB is down.
                    if key in self.journals:
                        self.journals[key].failure='QUOTE_STREAM_AND_STORAGE_UNAVAILABLE'
                await asyncio.sleep(backoff)
                backoff=min(30,backoff*2)

    async def _maintenance(self):
        while not self.closed:
            try:
                rows = await run_blocking(self.repository.active_tracking,timeout=10)
                for ticket in await run_blocking(self.live.interrupt_pending,before_ms=int(time.time()*1000)-60000,reason='PREPARATION_TIMEOUT',timeout=5):
                    await self._notice(ticket,'NEEDS_REVIEW','PREPARATION_TIMEOUT')
                grouped = {}
                for row in rows:
                    plan = row['payload']['plan']
                    if plan['provider'] not in self.stream_factories or row['payload']['admin_delivered_ms'] is None:
                        continue
                    grouped.setdefault((plan['provider'],plan['symbol']),[]).append(row['id'])
                    await self._replay(row)
                self.active=grouped
                for key in list(grouped):
                    journal=self.journals.get(key)
                    if not journal or journal.failure or not journal.rows or not journal.rows[-1].quote.fresh(int(time.time()*1000)):
                        await self._interrupt(key,'QUOTE_STREAM_STALE_OR_MISSING')
            except asyncio.CancelledError:
                raise
            except Exception:
                # Disallow proofs immediately; never keep certifying on DB loss.
                for journal in self.journals.values():
                    journal.failure='QUOTE_OWNER_STORAGE_UNAVAILABLE'
            await asyncio.sleep(1)

    async def _replay(self, initial):
        plan=initial['payload']['plan']
        key=(plan['provider'],plan['symbol'])
        journal=self.journals.get(key)
        if not journal or journal.failure or not journal.rows or not journal.rows[-1].quote.fresh(int(time.time()*1000)):
            await self._interrupt(key,'QUOTE_STREAM_STALE_OR_MISSING')
            return
        payload=initial['payload']
        epoch=payload['freshness_proof'].get('epoch')
        if not epoch or journal.rows[-1].epoch!=epoch:
            await self._interrupt(key,'QUOTE_TRACKING_EPOCH_CHANGED')
            return
        frames=list(journal.rows)
        last_id=payload['state'].get('last_quote_id','')
        if last_id:
            index=next((i for i,frame in enumerate(frames) if frame.quote.source_id==last_id),None)
            if index is None:
                await self._interrupt(key,'QUOTE_REPLAY_WINDOW_EXCEEDED')
                return
            frames=frames[index+1:]
        else:
            delivery=payload['admin_delivered_ms']
            if frames[0].quote.event_ms>delivery:
                await self._interrupt(key,'QUOTE_INITIAL_DELIVERY_WINDOW_MISSING')
                return
            frames=[frame for frame in frames if frame.quote.event_ms>delivery]
        if len(frames)>256:
            await self._interrupt(key,'QUOTE_REPLAY_CAPACITY_EXCEEDED')
            return
        for frame in frames:
            # Re-read under repository transactions so admin decisions/partial
            # allocations cannot be overwritten by the stream's cached state.
            row=await run_blocking(self.repository.get,initial['id'],timeout=5)
            if not row or row['payload'].get('tracking_state')=='NEEDS_REVIEW' or row['payload'].get('outcome_closed'):
                return
            phase=row['payload']['state']['phase']
            now=int(time.time()*1000)
            if phase in {'VERIFIED_ENTRY','MANUAL_ADMIN_ENTRY'}:
                found=await run_blocking(self.repository.detect_outcomes,row['id'],frame.quote,now_ms=now,sequence_ordered=True,timeout=5)
                for event_id in found:
                    await self._notice(row,event_id,'OBSERVED_TARGET_OR_STOP_REQUIRES_ADMIN_APPROVAL')
            elif phase in {'PROPOSED_PRETOUCH','FIRST_TOUCH_IN_PROGRESS'}:
                state=await run_blocking(self.repository.observe,row['id'],frame.quote,now_ms=now,sequence_ordered=True,timeout=5)
                if state.phase!=phase:
                    await self._notice(row,state.phase,state.reason)
            else:
                return

    async def _notice(self, row, event, reason):
        from repositories.v2.strategy_outbox import StrategyOutboxRepository
        from repositories.v2.strategy_reviews import StrategyReviewRepository
        p=row['payload']['plan']
        notice={'engine':p['engine'],'symbol':p['symbol'],'timeframe':p['timeframe'],'state':'NEEDS_REVIEW',
                'available_ms':int(time.time()*1000),'thesis_key':f"{row['id']}:{event}",'reason':reason,
                'setup_id':row['id'],'event_id':event,'title_fa':'رویداد سیگنال: نیازمند بررسی و تأیید ادمین'}
        ids=await run_blocking(StrategyReviewRepository(self.repository.engine).store,[notice],timeout=5)
        admins=await run_blocking(self.admin_ids_for,'signal_results',timeout=5)
        await run_blocking(StrategyOutboxRepository(self.repository.engine).enqueue,ids,admins,timeout=5)

    def pre_send_proof(self, plan, *, epoch, verified_through_ms):
        """Final synchronous gate: no yield between the latest book and send."""
        journal = self.journal_for(plan.symbol, plan.provider)
        if journal is None:
            raise ValueError('ORDERED_QUOTE_SOURCE_UNAVAILABLE')
        now = int(time.time() * 1000)
        return journal.proof(plan, epoch=epoch, start_ms=plan.evidence_cutoff_ms,
                             through_ms=verified_through_ms, now_ms=now)

    async def freshness(self, plan, *, epoch, start_ms, through_ms):
        deadline=asyncio.get_running_loop().time()+3
        while True:
            journal=self.journal_for(plan.symbol,plan.provider)
            if journal is None:
                raise ValueError('ORDERED_QUOTE_SOURCE_UNAVAILABLE')
            try:
                proof=journal.proof(plan,epoch=epoch,start_ms=start_ms,through_ms=through_ms,now_ms=int(time.time()*1000))
                break
            except ValueError as exc:
                if str(exc)!='QUOTE_WATERMARK_NOT_READY' or asyncio.get_running_loop().time()>=deadline:
                    raise
                await asyncio.sleep(.025)
        # A quote chain alone is sampled book data, not all trade prices. The
        # same native current candle must also exclude any wick in the zone.
        from services.canonical_market_service import _historical_bars
        bars=await _historical_bars(plan.symbol,plan.timeframe,limit=20,provider=plan.provider)
        rows=[b for b in bars if b.end_ms>start_ms]
        if not rows or rows[0].start_ms>start_ms or rows[-1].end_ms<through_ms or rows[-1].available_ms<through_ms:
            raise ValueError('NATIVE_CANDLE_BRIDGE_COVERAGE_MISSING')
        if any((b.symbol,b.provider,b.venue,b.product)!=(plan.symbol,plan.provider,plan.venue,plan.product) or b.quality_flags for b in rows):
            raise ValueError('NATIVE_CANDLE_BRIDGE_PROVENANCE_INVALID')
        if any(a.end_ms!=b.start_ms for a,b in zip(rows,rows[1:], strict=False)):
            raise ValueError('NATIVE_CANDLE_BRIDGE_GAP')
        if any(b.low<=plan.zone_high and b.high>=plan.zone_low for b in rows):
            raise ValueError('NATIVE_CANDLE_BRIDGE_ZONE_TOUCHED')
        # Recheck after awaiting the network: a reconnect cannot validate old work.
        if self.journal_for(plan.symbol,plan.provider) is not journal:
            raise ValueError('QUOTE_TRACKING_EPOCH_CHANGED')
        proof=journal.proof(plan,epoch=epoch,start_ms=start_ms,through_ms=through_ms,now_ms=int(time.time()*1000))
        proof['native_candle_bridge']=[b.as_dict() for b in rows]
        return proof

    async def prepare_result(self, result):
        from repositories.v2.strategy_reviews import StrategyReviewRepository
        from services.strategy_review_queue_service import _save_analysis
        result=dict(result)
        if any(r.get('plan') and (r.get('observation') or r.get('state')=='ANALYTICAL_OBSERVATION') for r in result.get('results',[])):
            raise ValueError('OBSERVATION_CANNOT_BECOME_EXECUTABLE_PLAN')
        ordinary=await run_blocking(_save_analysis,{**result,'results':[r for r in result.get('results',[]) if not r.get('plan')]},timeout=10)
        result.update({'stored_setups':[],'new_review_ids':ordinary['new_review_ids'],'publicly_approved':False})
        for candidate in result.get('results',[]):
            if not candidate.get('plan'):
                continue
            plan=SetupPlan.from_dict(candidate['plan'])
            journal=self.journal_for(plan.symbol,plan.provider)
            epoch=journal.rows[-1].epoch if journal and journal.rows and not journal.failure else ''
            ticket=await run_blocking(self.live.prepare,plan,epoch=epoch,profile_id=candidate['profile_id'],historical_proof=candidate['freshness_proof'],timeout=10)
            if ticket['duplicate']:
                continue
            try:
                if not candidate['freshness_proof'].get('untouched') or not candidate['freshness_proof'].get('complete_coverage'):
                    raise ValueError('ORIGINAL_FULL_ZONE_FRESHNESS_UNPROVEN')
                proof=await self.freshness(plan,epoch=epoch,start_ms=plan.evidence_cutoff_ms,through_ms=ticket['prepared_ms'])
                proof['historical_proof']=candidate['freshness_proof']
                saved=await run_blocking(self.repository.propose,plan,proposed_ms=ticket['prepared_ms'],freshness_proof=proof,
                                        profile_id=candidate['profile_id'],sample_kind='shadow_forward',timeout=10)
                await run_blocking(self.live.finish_preparation,plan.setup_id,'PROMOTED',{'setup_id':saved['id']},timeout=5)
                result['stored_setups'].append(saved)
                if not saved['duplicate']:
                    admins=await run_blocking(self.admin_ids_for,'signals',timeout=5)
                    for admin in admins:
                        await run_blocking(self.live.enqueue,setup_id=plan.setup_id,version=plan.plan_version,event_id='SIGNAL',
                                          audience='admin',target_id=admin,content_hash=plan.plan_hash,timeout=5)
            except (ValueError,TimeoutError,RuntimeError) as exc:
                reason=str(exc) if isinstance(exc,ValueError) else type(exc).__name__
                await run_blocking(self.live.finish_preparation,plan.setup_id,'NEEDS_REVIEW',{'reason':reason},timeout=5)
                review={'engine':plan.engine,'symbol':plan.symbol,'timeframe':plan.timeframe,'state':'NEEDS_REVIEW',
                        'available_ms':ticket['prepared_ms'],'thesis_key':plan.thesis_key,'profile_id':candidate['profile_id'],
                        'reason':reason,'draft_plan':plan.as_dict(),'title_fa':'نیازمند بررسی: تازگی یا تداوم قیمت تأیید نشده'}
                result['new_review_ids'].extend(await run_blocking(StrategyReviewRepository(self.repository.engine).store,[review],timeout=5))
        return result

    async def close(self):
        from services.admin_review_market_service import close_review_monitor
        await close_review_monitor()
        self.closed=True
        for task in [*self.tasks.values(),*self.background]:
            task.cancel()
        await asyncio.gather(*self.tasks.values(),*self.background,return_exceptions=True)
        for key in list(self.journals):
            await self._interrupt(key,'QUOTE_OWNER_SHUTDOWN')


async def start_runtime_owner(admin_ids_for):
    from core.runtime_topology import replica_count
    if replica_count()!=1:
        return None  # Current bot topology requires exactly one polling owner.
    loop=asyncio.get_running_loop()
    if loop not in _OWNERS:
        owner=StrategyQuoteOwner(admin_ids_for)
        await owner.start()
        _OWNERS[loop]=owner
    return _OWNERS[loop]


async def stop_runtime_owner():
    owner=_OWNERS.pop(asyncio.get_running_loop(),None)
    if owner:
        await owner.close()
