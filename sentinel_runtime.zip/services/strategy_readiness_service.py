"""Read-only, evidence-based predeployment checks. Never grants trade approval."""
from __future__ import annotations

import asyncio
import re
import time
from decimal import Decimal

from modules.canonical_market import TIMEFRAMES,price
from services.keyless_market_data_service import BIQUOTE_ORIGIN,_utc_ms,supported_symbols

_CACHE={}
_INFLIGHT={}


def parse_biquote_snapshot(raw,metadata,*,symbol,observed_ms):
    if not isinstance(raw,dict) or not isinstance(metadata,dict) or raw.get('symbol')!=symbol or metadata.get('name')!=symbol:
        raise ValueError('SNAPSHOT_SYMBOL_MISMATCH')
    source=raw.get('source')
    if not isinstance(source,str) or not re.fullmatch(r'MetaTrader 5 \(Broker [1-9][0-9]{0,3}\)',source) or metadata.get('source')!=source:
        raise ValueError('SNAPSHOT_SOURCE_MISMATCH')
    if raw.get('exchange')!=metadata.get('exchange') or metadata.get('type')!=('Commodity' if symbol=='XAUUSD' else 'Forex'):
        raise ValueError('SNAPSHOT_PRODUCT_MISMATCH')
    if metadata.get('currency')!=symbol[-3:] or metadata.get('isActive') is not True:
        raise ValueError('SNAPSHOT_PRODUCT_MISMATCH')
    bid,ask,tick=map(price,(raw.get('bid'),raw.get('ask'),metadata.get('tickSize')))
    spread=ask-bid
    if spread<0 or 'spread' in raw and Decimal(str(raw['spread']))!=spread:
        raise ValueError('SNAPSHOT_SPREAD_INVALID')
    if 'mid' in raw and price(raw['mid'])!=(bid+ask)/2:
        raise ValueError('SNAPSHOT_MIDPOINT_INVALID')
    stamp=_utc_ms(raw.get('timestamp'))
    if stamp>observed_ms+1000:
        raise ValueError('SNAPSHOT_FUTURE_TIME')
    if raw.get('lastQuoteAt') and _utc_ms(raw['lastQuoteAt'])!=stamp:
        raise ValueError('SNAPSHOT_TIME_MISMATCH')
    digits=metadata.get('digits')
    if type(digits) is not int or not 0<=digits<=12 or tick % (Decimal(10)**-digits):
        raise ValueError('SNAPSHOT_GRID_METADATA_INVALID')
    fresh=0<=observed_ms-stamp<=5000 and raw.get('stale') is False and raw.get('marketState')=='open'
    return {'symbol':symbol,'provider':'biquote','bid':str(bid),'ask':str(ask),'spread':str(spread),
            'event_ms':stamp,'observed_ms':observed_ms,'source_label':source,
            'reported_tick_size':str(tick),'reported_digits':digits,
            'reported_grid_consistent':bid%tick==ask%tick==0,
            'fresh_open_snapshot':fresh,'reported_market_state':raw.get('marketState','unknown'),'snapshot_only':True,'execution_eligible':False,
            'continuous_pretouch_proof':False,'native_broker_identity_verified':False}


def assess_readiness(candles,snapshot,*,symbol,timeframe,observed_ms):
    """Compare real prerequisites; a successful HTTP request is not readiness."""
    rows=list(candles)
    closed=[b for b in rows if b.is_closed]
    checks=[]
    def check(code,ok,detail):
        checks.append({'code':code,'state':'PASS' if ok else 'BLOCKED','detail_fa':detail})
    identity=bool(rows) and all((b.symbol,b.provider,b.timeframe)==(symbol,'biquote',timeframe) for b in rows)
    check('SOURCE_MATCHED_CANDLES',identity,'هویت نماد، منبع و تایم‌فریم کندل‌ها')
    check('CLOSED_CANDLE_WARMUP',len(closed)>=105,'حداقل ۱۰۵ کندل بسته برای اندیکاتورها')
    fresh=bool(closed) and 0<=observed_ms-closed[-1].end_ms<=2*TIMEFRAMES[timeframe]
    check('CURRENT_CLOSED_CANDLES',fresh,'تازگی کندل بسته؛ دادهٔ قدیمی فعال تلقی نمی‌شود')
    check('FRESH_BID_ASK_SNAPSHOT',bool(snapshot and snapshot['fresh_open_snapshot']),
          'قیمت خریدوفروشِ تازه؛ فقط snapshot و بدون اثبات تداوم')
    check('REPORTED_PRICE_GRID',bool(snapshot and snapshot['reported_grid_consistent']),
          'انطباق قیمت خریدوفروش با گام قیمت اعلام‌شده؛ گام حدس زده نمی‌شود')
    native=identity and not any(b.quality_flags for b in rows) and all(b.product!='indicative' for b in rows)
    check('NATIVE_HISTORY_PROVENANCE',native,'منشأ همان بروکر برای تمام کندل‌های موج باید تأیید شود')
    volume=bool(rows) and all(b.volume is not None and b.volume_kind in {'traded','tick_proxy'} and not b.quality_flags for b in rows)
    check('CAUSAL_WAVE_VOLUME',volume,'حجم بومی یا حجم تیک تأییدشدهٔ کل موج؛ برای POC')
    # This adapter has REST snapshots, not an integrated ordered quote owner.
    check('CONTINUOUS_QUOTE_OWNER',False,'جریان پیوستهٔ همین منبع برای اثبات پیش از لمس هنوز متصل نیست')
    common=['SOURCE_MATCHED_CANDLES','CLOSED_CANDLE_WARMUP','CURRENT_CLOSED_CANDLES',
            'FRESH_BID_ASK_SNAPSHOT','REPORTED_PRICE_GRID','NATIVE_HISTORY_PROVENANCE',
            'CONTINUOUS_QUOTE_OWNER']
    failing={c['code'] for c in checks if c['state']!='PASS'}
    engines={name:{'state':'BLOCKED' if failing.intersection(required) else 'INPUTS_AVAILABLE_NOT_SIGNAL_APPROVAL',
                   'blockers':sorted(failing.intersection(required))}
             for name,required in [('indicators',common),('sweep_fvg',common),
                                   ('order_block',[*common,'CAUSAL_WAVE_VOLUME']),('fibonacci_pullback',common)]}
    return {'state':'BLOCKED_BEFORE_DEPLOYMENT' if failing else 'INPUT_CHECKS_PASSED',
            'symbol':symbol,'timeframe':timeframe,'provider':'biquote','observed_ms':observed_ms,
            'checks':checks,'engines':engines,'snapshot':snapshot,'deployment_only_remaining':False,
            'execution_eligible':False,'production_qualified':False,'is_signal':False,
            'per_setup_runtime_requirements':['ORIGINAL_ZONE_PRETOUCH_PROOF','STRUCTURAL_LEVELS','TP1_MINIMUM_2R','EXACT_ADMIN_APPROVAL'],
            'fibonacci_role':'SHARED_OPTIONAL_CONFIRMATION','messages_sent':0,'orders_sent':0}


async def _inspect(symbol,timeframe):
    from services.canonical_market_service import _request,historical_bars
    from services.market_data_issues import safe_market_error

    responses=await asyncio.gather(
        historical_bars(symbol,timeframe,limit=300,provider='biquote'),
        _request(f'{BIQUOTE_ORIGIN}/api/{symbol}',{'allowStale':'false'}),
        _request(f'{BIQUOTE_ORIGIN}/api/symbols/{symbol}'),return_exceptions=True)
    bars,raw,metadata=responses
    errors=[]
    if isinstance(bars,BaseException):
        errors.append({'input':'candles','code':safe_market_error(bars)});bars=[]
    snapshot=None
    for name,response in [('quote',raw),('metadata',metadata)]:
        if isinstance(response,BaseException):errors.append({'input':name,'code':safe_market_error(response)})
    if not isinstance(raw,BaseException) and not isinstance(metadata,BaseException):
        try:
            snapshot=parse_biquote_snapshot(raw,metadata,symbol=symbol,observed_ms=int(time.time()*1000))
        except (ValueError,TypeError,KeyError,ArithmeticError) as exc:
            code=str(exc)
            allowed={'SNAPSHOT_SYMBOL_MISMATCH','SNAPSHOT_SOURCE_MISMATCH','SNAPSHOT_PRODUCT_MISMATCH',
                     'SNAPSHOT_SPREAD_INVALID','SNAPSHOT_MIDPOINT_INVALID','SNAPSHOT_FUTURE_TIME',
                     'SNAPSHOT_TIME_MISMATCH','SNAPSHOT_GRID_METADATA_INVALID'}
            errors.append({'input':'quote_metadata','code':code if code in allowed else 'SNAPSHOT_INVALID'})
    result=assess_readiness(bars,snapshot,symbol=symbol,timeframe=timeframe,observed_ms=int(time.time()*1000))
    result['market_session']={'reported_state':snapshot.get('reported_market_state','unknown') if snapshot else 'unknown',
        'closed_reported':bool(snapshot and snapshot.get('reported_market_state')=='closed'),
        'is_execution_permission':False}
    result['input_errors']=errors
    result['closed_candles']=sum(b.is_closed for b in bars)
    result['last_closed_ms']=max((b.end_ms for b in bars if b.is_closed),default=None)
    return result


async def inspect_market_readiness(symbol='XAUUSD',timeframe='5m'):
    symbol=str(symbol).strip().upper().replace('/','')
    if symbol not in supported_symbols() or timeframe not in {'5m','1h'}:
        raise ValueError('READINESS_MARKET_UNSUPPORTED')
    key=(symbol,timeframe)
    cached=_CACHE.get(key)
    if cached and cached[0]>time.monotonic():
        result=cached[1];snapshot=result.get('snapshot');now=int(time.time()*1000)
        quote_current=not snapshot or not snapshot['fresh_open_snapshot'] or 0<=now-snapshot['event_ms']<=5000
        closed_current=not result.get('last_closed_ms') or now-result['last_closed_ms']<=2*TIMEFRAMES[timeframe]
        if quote_current and closed_current:return result
    task_key=(asyncio.get_running_loop(),key)
    task=_INFLIGHT.get(task_key)
    if task is None:
        async def fetch():
            try:
                result=await _inspect(symbol,timeframe)
                if len(_CACHE)>=32:_CACHE.pop(next(iter(_CACHE)))
                _CACHE[key]=(time.monotonic()+30,result)
                return result
            finally:
                _INFLIGHT.pop(task_key,None)
        task=asyncio.create_task(fetch());_INFLIGHT[task_key]=task
    return await asyncio.shield(task)
