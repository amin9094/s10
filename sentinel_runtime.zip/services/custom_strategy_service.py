"""Durable optimistic admin selection; never edit a previously frozen signal."""
import time
from core.db import read_db_sections,with_db_sections
from modules.custom_strategy import CustomSettings,parse_settings,BASES,FILTERS
from modules.indicator_suite import CATALOG


def current_settings():
    from repositories.v2.strategy_paths import StrategyPaths
    active=StrategyPaths().active('custom')
    if active:return parse_settings(active['payload']['configuration'])
    stored=read_db_sections(('settings',)).get('settings',{}).get('strategyResearch',{}).get('customStrategy',{})
    return parse_settings(stored.get('config',{}))


def preset_page(user_id,*,before=None,query=None):
    from services.live_signal_service import permitted
    from repositories.v2.custom_presets import CustomPresets
    permitted(user_id)
    return CustomPresets().page(before=before,query=query)


def read_settings(user_id):
    from services.live_signal_service import permitted
    permitted(user_id)
    stored=read_db_sections(('settings',)).get('settings',{}).get('strategyResearch',{}).get('customStrategy',{})
    config=current_settings()
    from repositories.v2.custom_presets import CustomPresets
    return {'presets':CustomPresets().items(),'settings':config.dto(),'revision':stored.get('revision',0),'profile_id':config.profile_id,
            'indicators':[{'id':k,'label':v} for k,v in CATALOG.items()], 'bases':list(BASES),'filters':list(FILTERS),
            'history':stored.get('history',[]),'applies_to':'FUTURE_SIGNALS_ONLY','risk_percent':'1','starting_balance':'5000'}


def save_settings(user_id,body):
    from services.live_signal_service import permitted
    permitted(user_id)
    if not isinstance(body,dict) or set(body)!={'revision','settings'} or type(body['revision']) is not int or body['revision']<0:
        raise ValueError('CUSTOM_SETTINGS_INVALID')
    config=parse_settings(body['settings'])
    def mutate(db):
        target=db.setdefault('settings',{}).setdefault('strategyResearch',{}).setdefault('customStrategy',{})
        if target.get('revision',0)!=body['revision']:raise ValueError('CUSTOM_SETTINGS_CHANGED')
        revision=body['revision']+1
        history=[*target.get('history',[]),{'revision':revision,'profile_id':config.profile_id,
                    'config':config.dto(),'actor':str(user_id),'changed_ms':int(time.time()*1000)}][-50:]
        target.update(config=config.dto(),revision=revision,history=history)
        return {'revision':revision,'profile_id':config.profile_id,'settings':config.dto(),'applies_to':'FUTURE_SIGNALS_ONLY'}
    result=with_db_sections(('settings',),mutate)
    from core.storage.engine import normalized_engine
    with normalized_engine().transaction() as cursor:
        cursor.execute("UPDATE s9_strategy_paths SET active=0,revision=revision+1 WHERE engine='custom' AND active=1")
    return result


def preview_settings(user_id,body):
    from services.live_signal_service import permitted
    permitted(user_id)
    if not isinstance(body,dict) or set(body)!={'revision','settings'}:raise ValueError('CUSTOM_SETTINGS_INVALID')
    proposed=parse_settings(body['settings'])
    stored=read_db_sections(('settings',)).get('settings',{}).get('strategyResearch',{}).get('customStrategy',{})
    if type(body['revision']) is not int or stored.get('revision',0)!=body['revision']:raise ValueError('CUSTOM_SETTINGS_CHANGED')
    current=current_settings();old=current.dto();new=proposed.dto()
    return {'revision':body['revision'],'old_profile_id':current.profile_id,'new_profile_id':proposed.profile_id,
            'changes':[{'field':key,'before':old[key],'after':new[key]} for key in old if old[key]!=new[key]],
            'settings':new,'applies_to':'FUTURE_SIGNALS_ONLY','activated':False}


def save_preset(user_id,body):
    from services.live_signal_service import permitted
    from repositories.v2.custom_presets import CustomPresets
    permitted(user_id)
    if not isinstance(body,dict) or set(body)!={'name','settings'}:raise ValueError('CUSTOM_PRESET_INVALID')
    return CustomPresets().save(body['name'],body['settings'],user_id)
