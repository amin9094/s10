"""Private forward proposals and exact human approval, never native execution."""
import asyncio
import time

from core.async_runtime import run_blocking
from repositories.v2.strategy_reviews import StrategyReviewRepository
from repositories.v2.common import content_hash
from services.admin_review_market_service import check_review_before_entry,review_monitor


def can_publish_review(user_id):
    from core.db import read_db_sections
    from modules.admin_access import has_permission,PERMISSION_SIGNAL_PUBLISH_NOW
    return has_permission(read_db_sections(('delegated_admins','admin_shifts')),user_id,PERMISSION_SIGNAL_PUBLISH_NOW)


def validate_proposal(proposal,*,for_entry=True):
    if (proposal.get('review_kind')!='PREENTRY_PROPOSAL' or not proposal.get('draft_plan')
        or content_hash(proposal['draft_plan'])!=proposal.get('draft_hash')
        or proposal['draft_plan'].get('review_only') is not True
        or proposal['draft_plan'].get('execution_eligible') is not False):
        raise ValueError('REVIEW_PLAN_HASH_CHANGED')
    if for_entry:
        from modules.signal_plan_policy import validate_locked_signal_plan
        validate_locked_signal_plan(proposal['draft_plan'])


def proposal_text(proposal,*,private=True):
    from modules.strategy_signal_format import level_lines, priority_label
    p=proposal['draft_plan']
    lines=['پیشنهاد معامله پیش از ورود — بررسی ادمین' if private else 'سیگنال بررسی و تأییدشده توسط ادمین',
           f"{p['symbol']} · {p['timeframe']} · {p['direction']} · {p['engine']} / {p['submodel']}",
           *level_lines(p),
           f"R/R TP1: {p['rr_tp1']}",
           'طرح پیش از ورود؛ اجرای بروکر انجام نشده است.']
    if private:
        if priority_label(p):lines.append(priority_label(p))
        lines+=['محاسبات روی دقت مشاهده‌شده‌اند؛ گام اجرای بروکر باید هنگام بررسی تطبیق داده شود.',
                'برای انتشار یا لغو، بخش بررسی استراتژی همان نماد در مینی‌اپ ادمین را باز کنید.']
        if p['engine']=='order_block':lines.append('POC برآوردی از حجم تیک گزارش‌شده است؛ حجم معامله‌شده نیست.')
    return '\n'.join(lines)


async def _correct(bot,target,message_id,identifier):
    from services.strategy_delivery_service import _correct_late_message
    from types import SimpleNamespace
    return await _correct_late_message(bot,{'target_id':str(target)},{'id':identifier,'plan_version':1},
                                       SimpleNamespace(message_id=message_id))


async def _queue_notice(repo,identifier,proposal,correction,admins):
    from repositories.v2.strategy_outbox import StrategyOutboxRepository
    p=proposal['draft_plan']
    notice={'engine':p['engine'],'symbol':p['symbol'],'timeframe':p['timeframe'],'state':'NEEDS_REVIEW',
            'available_ms':int(time.time()*1000),'thesis_key':identifier+':delivery-correction',
            'reason':'REVIEW_DELIVERY_PREENTRY_UNPROVEN:'+correction,
            'title_fa':'هشدار: اعتبار ارسال سیگنال پیش از ورود تأیید نشد',
            'explanation_fa':f"پیشنهاد {identifier} معتبر ثبت نشد. وضعیت اصلاح پیام: {correction}",
            'required_action_fa':'پیام مقصد و وضعیت پیشنهاد بررسی شود؛ این هشدار سیگنال تازه نیست.'}
    identifiers=await run_blocking(repo.store,[notice],timeout=5)
    await run_blocking(StrategyOutboxRepository(repo.engine).enqueue,identifiers,admins,timeout=5)


async def deliver_private_proposal(bot,intent,outbox,*,reviews=None):
    reviews=reviews or StrategyReviewRepository()
    row=await run_blocking(reviews.get,intent['review_id'],timeout=5)
    transmitted=False
    try:
        if not row or row['state']!='NEEDS_REVIEW':raise ValueError('REVIEW_NOT_PENDING')
        p=row['payload'];validate_proposal(p)
        await check_review_before_entry(p)
        review_monitor().check(p,int(time.time()*1000))
        await run_blocking(outbox.start,intent['id'],intent['payload'].get('claim_token'),timeout=5)
        review_monitor().check(p,int(time.time()*1000))
        async with asyncio.timeout(10):
            transmitted=True;message=await bot.send_message(chat_id=int(intent['admin_id']),text=proposal_text(p))
        receipt=int(time.time()*1000)
    except asyncio.CancelledError:raise
    except Exception as exc:
        from telegram.error import RetryAfter,BadRequest,Forbidden
        retry=getattr(exc,'retry_after',0);retry=retry.total_seconds() if hasattr(retry,'total_seconds') else retry
        state='PENDING' if isinstance(exc,RetryAfter) else 'FAILED' if isinstance(exc,(BadRequest,Forbidden)) else 'UNCERTAIN' if transmitted else 'REVOKED'
        await run_blocking(outbox.finish,intent['id'],state,retry_seconds=retry,detail=type(exc).__name__,timeout=5,claim_token=intent['payload'].get('claim_token'))
        if isinstance(exc,ValueError):await run_blocking(reviews.expire,intent['review_id'],str(exc),timeout=5)
        return

    async def complete():
        detail='DELIVERED_FOR_ADMIN_REVIEW';verification=None;correction=None
        try:
            verification=await check_review_before_entry(p)
            await run_blocking(reviews.mark_review_receipt,row['id'],receipt_ms=receipt,verification=verification,timeout=5)
        except Exception:
            detail='DELIVERED_BUT_REVIEW_PREENTRY_UNPROVEN'
            correction=await _correct(bot,intent['admin_id'],message.message_id,row['id'])
            verification={'notification_correction':correction,'delivery_qualified':False}
            await run_blocking(reviews.expire,row['id'],detail+':'+correction,timeout=5)
        await run_blocking(outbox.finish,intent['id'],'SENT',message_id=message.message_id,
                           detail=detail,verification=verification,timeout=5,claim_token=intent['payload'].get('claim_token'))
        if correction=='INVALID_NOTICE_CORRECTION_FAILED':
            await _queue_notice(reviews,row['id'],p,correction,[intent['admin_id']])
    task=asyncio.create_task(complete())
    try:await asyncio.shield(task)
    except asyncio.CancelledError:await task;raise


async def decide_review(user_id,identifier,body):
    from services.setup_review_service import can_review_setups
    from core.miniapp_server import _run_on_telegram_loop
    if not await run_blocking(can_review_setups,user_id,timeout=5):raise PermissionError('FORBIDDEN')
    if body['action']=='publish' and not await run_blocking(can_publish_review,user_id,timeout=5):
        raise PermissionError('FORBIDDEN')
    async def work():
        repo=StrategyReviewRepository();row=await run_blocking(repo.get,identifier,timeout=5)
        if not row:raise ValueError('REVIEW_NOT_FOUND')
        validate_proposal(row['payload'],for_entry=body['action']=='publish')
        if row['state']!='NEEDS_REVIEW' or row['payload']['draft_hash']!=body['draft_hash']:
            raise ValueError('REVIEW_NOT_PENDING_OR_PLAN_CHANGED')
        if body['action']=='publish':
            try:await check_review_before_entry(row['payload'])
            except ValueError as exc:
                await run_blocking(repo.expire,identifier,str(exc),timeout=5)
                raise
        return await run_blocking(repo.decide,identifier,actor=user_id,action=body['action'],
            draft_hash=body['draft_hash'],audience=body.get('audience'),timeout=5)
    result=await _run_on_telegram_loop(work())
    return result if result is not None else await work()


async def deliver_approved_review(bot,intent,live,*,reviews=None):
    from services.setup_review_service import can_review_setups
    from services.strategy_delivery_service import channel_target
    repo=reviews or StrategyReviewRepository(live.engine);transmitted=False
    try:
        row=await run_blocking(repo.get,intent['setup_id'],timeout=5)
        if not row or row['state']!='NEEDS_REVIEW':raise ValueError('REVIEW_NOT_PENDING')
        p=row['payload'];validate_proposal(p)
        approval=p.get('approvals',{}).get(intent['audience'],{})
        if (approval.get('draft_hash')!=intent['content_hash'] or p['draft_hash']!=intent['content_hash']
            or approval.get('actor')!=intent['payload'].get('actor')
            or not await run_blocking(can_review_setups,int(approval['actor']),timeout=5)
            or not await run_blocking(can_publish_review,int(approval['actor']),timeout=5)
            or channel_target(intent['audience'])!=intent['target_id']):raise ValueError('REVIEW_APPROVAL_REVOKED')
        await check_review_before_entry(p);review_monitor().check(p,int(time.time()*1000))
        await run_blocking(live.start_delivery,intent['id'],intent['payload'].get('claim_token'),timeout=5)
        async with asyncio.timeout(10):
            transmitted=True;message=await bot.send_message(chat_id=int(intent['target_id']),text=proposal_text(p,private=False))
    except asyncio.CancelledError:raise
    except Exception as exc:
        from telegram.error import RetryAfter,BadRequest,Forbidden
        retry=getattr(exc,'retry_after',0);retry=retry.total_seconds() if hasattr(retry,'total_seconds') else retry
        state='PENDING' if isinstance(exc,RetryAfter) else 'FAILED' if isinstance(exc,(BadRequest,Forbidden)) else 'UNCERTAIN' if transmitted else 'REVOKED'
        await run_blocking(live.finish_delivery,intent['id'],state,retry_seconds=retry,detail=type(exc).__name__,timeout=5,claim_token=intent['payload'].get('claim_token'))
        return
    async def complete():
        detail='ADMIN_REVIEWED_SIGNAL_DELIVERED';proof=None;correction=None
        try:proof=await check_review_before_entry(p)
        except Exception:
            detail='DELIVERED_BUT_REVIEW_PREENTRY_UNPROVEN'
            correction=await _correct(bot,intent['target_id'],message.message_id,row['id'])
            proof={'notification_correction':correction,'delivery_qualified':False}
            await run_blocking(repo.expire,row['id'],detail+':'+correction,timeout=5)
        await run_blocking(live.finish_delivery,intent['id'],'SENT',message_id=message.message_id,detail=detail,verification=proof,timeout=5,claim_token=intent['payload'].get('claim_token'))
        if correction:await _queue_notice(repo,row['id'],p,correction,[approval['actor']])
    task=asyncio.create_task(complete())
    try:await asyncio.shield(task)
    except asyncio.CancelledError:await task;raise
