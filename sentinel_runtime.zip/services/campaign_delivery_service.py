from __future__ import annotations

from typing import Any

from telegram import Bot
from telegram.error import TelegramError, TimedOut, NetworkError

from config import SETTINGS
from core.async_runtime import run_blocking
from core.async_db import (
    async_read_db_record,
    async_read_db_section,
    async_with_db,
)
from modules.admin_access import PERMISSION_ANNOUNCEMENTS, PERMISSION_CAMPAIGNS, has_permission
from modules.announcements import record_announcement
from modules.broadcast_queue import enqueue_broadcast
from modules.campaign_studio import (
    campaign_delivery_text,
    campaign_delivery_checkpoint,
    campaign_snapshot_members,
    claim_campaign_dispatch,
    complete_campaign_dispatch,
    mark_campaign_dispatched,
)
from modules.discount_campaigns import register_discount_distribution
from modules.incident_center import record_incident
from modules.runtime_safety import publication_allowed, runtime_safety


def clear_rejected_channel(db,campaign_id,key,token,channel):
    campaign=db.get('marketing_campaigns',{}).get(campaign_id,{})
    claim=campaign.get('dispatch_claims',{}).get(key,{})
    if claim.get('token')==token and claim.get('status')=='in_progress':
        started=claim.get('delivery_started_channels',[])
        if channel in started:started.remove(channel)


async def _record_announcement_projection(
    campaign: dict[str, Any],
    campaign_id: str,
    actor_id: int,
    results: dict[str, Any],
) -> dict[str, Any] | None:
    """Mirror a delivered announcement campaign into the shared channel feed once."""
    if str(campaign.get("category") or "").lower() != "announcement":
        return None
    channels = dict(results.get("channels") or {})
    if not channels:
        return None
    errors = [str(item) for item in results.get("errors") or []]

    def mutate(db: dict[str, Any]) -> dict[str, Any]:
        rows = db.setdefault("announcements", [])
        if not isinstance(rows, list):
            rows = []
            db["announcements"] = rows
        for row in rows:
            if isinstance(row, dict) and str(row.get("campaign_id") or "") == str(campaign_id):
                return dict(row)
        deliveries = [
            {"channel": str(channel), "message_id": int(message_id), "type": "text"}
            for channel, message_id in channels.items()
            if str(message_id).isdigit()
        ]
        return record_announcement(
            db,
            admin_id=actor_id,
            topic="important",
            title=str(campaign.get("name") or "اعلان کانال"),
            destination=str(campaign.get("delivery") or "public"),
            content_type="text",
            source_chat_id=None,
            source_message_id=None,
            text=str(campaign.get("message") or ""),
            deliveries=deliveries,
            errors=errors,
            campaign_id=campaign_id,
        )

    row = await async_with_db(mutate)
    try:
        from repositories.v2.events import EventRepository

        await run_blocking(
            EventRepository().append,
            "*",
            "channel.announcement",
            {
                "announcement_id": str(row.get("id") or ""),
                "campaign_id": str(campaign_id),
                "title": row.get("title"),
                "status": row.get("status"),
                "destination": str(row.get("destination") or "public"),
                "access_tier": (
                    "vip" if str(row.get("destination") or "").lower() == "private" else "public"
                ),
            },
            entity_type="announcement",
            entity_id=str(row.get("id") or ""),
            timeout=10,
        )
    except Exception:
        # The durable database projection is authoritative; the event stream is best effort.
        import logging
        logging.getLogger(__name__).exception(
            "Campaign announcement event projection failed campaign_id=%s", campaign_id
        )
    return row


async def dispatch_marketing_campaign(
    bot: Bot,
    campaign_id: str,
    actor_id: int,
    *,
    bot_username: str = "",
) -> dict[str, Any]:
    """Publish one campaign version once, even when an admin taps repeatedly."""
    campaign = await async_read_db_record("marketing_campaigns", campaign_id)
    initial = {
        "delegated_admins": await async_read_db_section("delegated_admins"),
        "runtime_safety": await async_read_db_section("runtime_safety"),
    }
    if campaign is None:
        raise ValueError("کمپین پیدا نشد.")
    required_permission = (
        PERMISSION_ANNOUNCEMENTS
        if str(campaign.get("category") or "").lower() == "announcement"
        else PERMISSION_CAMPAIGNS
    )
    if not has_permission(initial, actor_id, required_permission):
        raise PermissionError(
            "Campaign creator no longer has the required publishing permission."
        )
    allowed, reason = publication_allowed(initial)
    if not allowed:
        raise ValueError(f"انتشار در حالت فعلی مجاز نیست: {reason}")

    reservation = await async_with_db(
        lambda db: claim_campaign_dispatch(db, campaign_id, actor_id=actor_id)
    )
    if not reservation.get("claimed"):
        return {
            "duplicate": True,
            "duplicate_reason": str(reservation.get("reason") or "already_dispatched"),
            "dispatch_key": str(reservation.get("key") or ""),
            "direct_job": "",
            "channels": {},
            "errors": [],
        }

    dispatch_key = str(reservation["key"])
    claim_token=reservation["claim"]["token"]
    campaign = await async_read_db_record("marketing_campaigns", campaign_id)
    if campaign is None:
        raise ValueError("کمپین پس از رزرو انتشار پیدا نشد.")
    dispatch_snapshot = await async_read_db_record(
        "campaign_audience_snapshots",
        dispatch_key,
    )
    discount_code = str(campaign.get("discount_code") or "")
    discount = (
        await async_read_db_record("discount_codes", discount_code)
        if discount_code
        else None
    )
    db = {
        "marketing_campaigns": {campaign_id: campaign},
        "campaign_audience_snapshots": (
            {dispatch_key: dispatch_snapshot}
            if isinstance(dispatch_snapshot, dict)
            else {}
        ),
        "discount_codes": (
            {discount_code: discount}
            if discount_code and isinstance(discount, dict)
            else {}
        ),
        "runtime_safety": await async_read_db_section("runtime_safety"),
    }
    delivery = str(campaign.get("delivery") or "draft")
    text = campaign_delivery_text(db, campaign_id)
    previous_result = dict(reservation.get("previous_result") or {})
    results: dict[str, Any] = {
        "duplicate": False,
        "uncertain_channels": [],
        "dispatch_key": dispatch_key,
        "direct_job": str(previous_result.get("direct_job") or ""),
        "channels": dict(previous_result.get("channels") or {}),
        "errors": [],
    }

    try:
        if delivery in {"direct", "direct_public"} and not results["direct_job"]:
            recipients = campaign_snapshot_members(db, campaign_id, dispatch_key)
            if not recipients:
                if delivery == "direct":
                    raise ValueError("در گروه انتخاب‌شده کاربری برای ارسال مستقیم وجود ندارد.")
                results["errors"].append("گروه ارسال مستقیم خالی بود")
            else:

                def queue_direct(target_db: dict[str, Any]) -> str:
                    campaign_delivery_checkpoint(target_db,campaign_id,dispatch_key,claim_token,"direct")
                    buttons: list[dict[str, str]] = []
                    if bot_username:
                        compact_id = campaign_id.split("-")[-1].lstrip("0") or "0"
                        buttons.append(
                            {
                                "label": "مشاهده در ربات",
                                "url": f"https://t.me/{bot_username}?start=cmp_{compact_id}",
                            }
                        )
                    creative = campaign.get("creative") if isinstance(campaign.get("creative"), dict) else {}
                    if str(creative.get("type") or "") == "photo" and creative.get("file_path"):
                        content = {
                            "type": "photo",
                            "file_path": str(creative.get("file_path")),
                            "caption": text[:1024],
                            "buttons": buttons,
                        }
                    else:
                        content = {"type": "text", "text": text, "buttons": buttons}
                    job = enqueue_broadcast(
                        target_db,
                        admin_id=actor_id,
                        segment=f"campaign:{campaign.get('audience')}",
                        recipients=recipients,
                        content=content,
                        priority="low",
                    )
                    code = str(campaign.get("discount_code") or "")
                    if code:
                        register_discount_distribution(
                            target_db,
                            code,
                            recipients,
                            segment=str(campaign.get("audience") or "all"),
                            campaign_job_id=str(job["id"]),
                        )
                    mark_campaign_dispatched(
                        target_db,
                        campaign_id,
                        actor_id=actor_id,
                        broadcast_job_id=str(job["id"]),
                    )
                    campaign_delivery_checkpoint(target_db,campaign_id,dispatch_key,claim_token,"direct",job_id=str(job["id"]))
                    return str(job["id"])

                results["direct_job"] = await async_with_db(queue_direct)

        channel_destinations: list[tuple[str, int]] = []
        runtime = runtime_safety(db)
        if delivery in {"public", "direct_public"}:
            chat_id = (
                SETTINGS.staging_public_channel_id
                if runtime.get("mode") == "staging"
                else SETTINGS.public_channel_id
            )
            if chat_id:
                channel_destinations.append(("public", int(chat_id)))
            else:
                results["errors"].append("کانال عمومی تنظیم نشده است")
        if delivery == "private":
            chat_id = (
                SETTINGS.staging_private_channel_id
                if runtime.get("mode") == "staging"
                else SETTINGS.private_channel_id
            )
            if chat_id:
                channel_destinations.append(("private", int(chat_id)))
            else:
                results["errors"].append("کانال خصوصی تنظیم نشده است")

        for channel, chat_id in channel_destinations:
            if channel in results["channels"]:
                continue
            try:
                await async_with_db(lambda target_db,ch=channel:campaign_delivery_checkpoint(target_db,campaign_id,dispatch_key,claim_token,ch))
                creative = campaign.get("creative") if isinstance(campaign.get("creative"), dict) else {}
                if str(creative.get("type") or "") == "photo" and creative.get("file_path"):
                    from modules.broadcast_queue import trusted_local_media_path
                    safe_path = trusted_local_media_path(str(creative.get("file_path")))
                    with open(safe_path, "rb") as media_handle:
                        message = await bot.send_photo(
                            chat_id=chat_id,
                            photo=media_handle,
                            caption=text[:1024],
                        )
                else:
                    message = await bot.send_message(
                        chat_id=chat_id,
                        text=text,
                        disable_web_page_preview=True,
                    )
                results["channels"][channel] = message.message_id
                await async_with_db(lambda target_db,ch=channel,mid=message.message_id:campaign_delivery_checkpoint(target_db,campaign_id,dispatch_key,claim_token,ch,message_id=mid))
                await async_with_db(
                    lambda target_db, ch=channel, mid=message.message_id: mark_campaign_dispatched(
                        target_db,
                        campaign_id,
                        actor_id=actor_id,
                        channel=ch,
                        message_id=mid,
                    )
                )
            except TelegramError as exc:
                if isinstance(exc,(TimedOut,NetworkError)):
                    results["uncertain_channels"].append(channel)
                else:
                    # A definite Telegram rejection permits a controlled retry.
                    await async_with_db(lambda target_db,ch=channel:clear_rejected_channel(target_db,campaign_id,dispatch_key,claim_token,ch))
                results["errors"].append(f"{channel}: {exc.__class__.__name__}")
                await async_with_db(
                    lambda target_db, ch=channel, error=exc: record_incident(
                        target_db,
                        source="campaigns",
                        kind="channel_delivery_failed",
                        detail=f"{campaign_id}/{ch}: {error}",
                        severity="warning",
                        metadata={
                            "campaign_id": campaign_id,
                            "channel": ch,
                            "dispatch_key": dispatch_key,
                        },
                    )
                )

        if not results["direct_job"] and not results["channels"]:
            raise ValueError("هیچ مقصد معتبری برای انتشار کمپین در دسترس نیست.")
    except Exception as exc:
        if not results["errors"]:
            results["errors"].append(f"{exc.__class__.__name__}: {exc}")
        await async_with_db(
            lambda target_db: complete_campaign_dispatch(
                target_db,
                campaign_id,
                dispatch_key,
                actor_id=actor_id,
                results=results,
                claim_token=claim_token,
            )
        )
        raise

    await async_with_db(
        lambda target_db: complete_campaign_dispatch(
            target_db,
            campaign_id,
            dispatch_key,
            actor_id=actor_id,
            results=results,
            claim_token=claim_token,
        )
    )
    projected = await _record_announcement_projection(campaign, campaign_id, actor_id, results)
    if projected is not None:
        results["announcement_id"] = str(projected.get("id") or "")
    return results
