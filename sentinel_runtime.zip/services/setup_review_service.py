"""Server-side authorization for immutable strategy plans and individual events."""

from __future__ import annotations

from core.db import read_db_sections
from modules.admin_access import has_permission


def can_review_setups(user_id):
    db = read_db_sections(("delegated_admins", "admin_shifts"))
    return has_permission(db, user_id, "signals")


def approve_setup_event(user_id, setup_id, body):
    if body.get('audience') in {'telegram_public','telegram_private'}:
        from services.strategy_delivery_service import authorize_telegram_event
        return authorize_telegram_event(user_id,setup_id,body)
    permission = "signals" if body.get("event_id", "SIGNAL") == "SIGNAL" else "signal_results"
    db = read_db_sections(("delegated_admins", "admin_shifts"))
    if not has_permission(db, user_id, permission):
        raise PermissionError("FORBIDDEN")
    if body.get("audience", "miniapp") != "miniapp":
        raise ValueError("AUDIENCE_UNSUPPORTED")
    from repositories.v2.setup_proposals import SetupRepository
    if body.get('event_id','SIGNAL')=='SIGNAL':
        from modules.signal_plan_policy import validate_locked_signal_plan
        row=SetupRepository().get(setup_id)
        if row:validate_locked_signal_plan(row['payload']['plan'])
    approval = SetupRepository().approve(
        setup_id,
        version=int(body["version"]),
        actor=user_id,
        audience="miniapp",
        event_id=str(body.get("event_id") or "SIGNAL"),
    )
    return {"approval_id": approval, "audience": "miniapp"}


async def approve_setup_event_live(user_id, setup_id, body):
    from core.async_runtime import run_blocking
    from core.miniapp_server import _run_on_telegram_loop
    permission='signals' if body.get('event_id','SIGNAL')=='SIGNAL' else 'signal_results'
    db=await run_blocking(read_db_sections,('delegated_admins','admin_shifts'),timeout=5)
    if not has_permission(db,user_id,permission):
        raise PermissionError('FORBIDDEN')

    async def work():
        from repositories.v2.setup_proposals import SetupRepository
        from modules.setup_lifecycle import CURRENT_RULE_VERSION,SetupPlan
        from services.strategy_quote_owner import current_owner
        repository=SetupRepository()
        row=await run_blocking(repository.get,setup_id,timeout=5)
        if row and body.get('event_id','SIGNAL')=='SIGNAL' and body.get('audience','miniapp')=='miniapp':
            plan=SetupPlan.from_dict(row['payload']['plan'])
            if plan.rule_version==CURRENT_RULE_VERSION:
                owner=current_owner()
                if owner is None:
                    raise ValueError('QUOTE_OWNER_REQUIRED_FOR_LIVE_PUBLICATION')
                import time
                await owner.freshness(plan,epoch=row['payload']['freshness_proof'].get('epoch',''),
                                      start_ms=plan.evidence_cutoff_ms,through_ms=int(time.time()*1000))
                await owner._replay(row)
        return await run_blocking(approve_setup_event,user_id,setup_id,body,timeout=10)
    result=await _run_on_telegram_loop(work())
    return result if result is not None else await work()


def can_publish_approved_delivery(intent):
    """Recheck the exact approver, version, event and hash at delivery time."""
    from repositories.v2.setup_proposals import SetupRepository
    actor=intent['payload'].get('actor')
    permission='signals' if intent['event_id']=='SIGNAL' else 'signal_results'
    if not actor or not has_permission(read_db_sections(('delegated_admins','admin_shifts')),actor,permission):
        return False
    repository=SetupRepository()
    with repository.engine.transaction(read_only=True) as cursor:
        row=cursor.execute('SELECT actor,content_hash FROM s9_approvals WHERE setup_id=? AND plan_version=? AND event_id=? AND audience=?',
                           (intent['setup_id'],intent['plan_version'],intent['event_id'],intent['audience'])).fetchone()
    return bool(row and row['content_hash']==intent['content_hash'] and str(row['actor'])==str(actor))


def record_setup_exit(user_id, setup_id, body):
    import time
    from repositories.v2.setup_proposals import SetupRepository

    db = read_db_sections(("delegated_admins", "admin_shifts"))
    if not has_permission(db, user_id, "signal_results"):
        raise PermissionError("FORBIDDEN")
    event = SetupRepository().record_admin_exit(setup_id, version=body["version"], actor=user_id,
            percentage_original=body["percentage_original"], reference_price=body["reference_price"],
            reason=body["reason"], request_id=body["request_id"], confirmed_ms=int(time.time() * 1000),
            cost_in_initial_r=body.get("cost_in_initial_r"))
    return {"event_id": event, "is_broker_execution": False, "publicly_approved": False}


def cancel_pending_setup(user_id, setup_id, body):
    import time
    if not has_permission(read_db_sections(('delegated_admins','admin_shifts')),user_id,'signal_results'):
        raise PermissionError('FORBIDDEN')
    from repositories.v2.setup_proposals import SetupRepository
    event=SetupRepository().cancel_pending(setup_id,version=body['version'],actor=user_id,reason=body['reason'],
              request_id=body['request_id'],confirmed_ms=int(time.time()*1000))
    return {'event_id':event,'publicly_approved':False,'is_broker_execution':False}
