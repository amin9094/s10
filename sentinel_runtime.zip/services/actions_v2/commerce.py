from __future__ import annotations

from typing import Any

import logging
import re

from core.db import read_db_sections, with_db
from modules.miniapp_product import create_checkout_quote
from modules.admin_access import (
    PERMISSION_PAYMENT_RECEIPT_APPROVE, PERMISSION_PAYMENT_RECEIPT_REJECT,
    PERMISSION_PAYMENT_VIP_ACTIVATE, PERMISSION_VIP_PLAN_CREATE, PERMISSION_VIP_PLAN_EDIT,
    PERMISSION_VIP_PLAN_ACTIVATE, PERMISSION_VIP_PLAN_ARCHIVE, PERMISSION_VIP_PLAN_DELETE,
    PERMISSION_VIP_SETTINGS,
    has_permission,
)
from modules.sales_growth import create_vip_plan, delete_vip_plan, get_vip_plan, toggle_vip_plan, update_vip_plan
from services.actions_v2.context import ActionContext
from services.actions_v2.registry import action
from services.vip_order_projection import project_normalized_order_to_legacy
from services.vip_discount_bridge import reserve_normalized_order_discount, release_normalized_order_discount
from repositories.v2.common import new_id
from core.utils import utc_iso

logger = logging.getLogger(__name__)

def _require_human_permission(ctx: ActionContext, *permissions: str) -> None:
    snapshot = read_db_sections(("delegated_admins", "admin_shifts", "users"))
    if not any(has_permission(snapshot, ctx.user_id, permission) for permission in permissions):
        raise PermissionError("ADMIN_PERMISSION_REQUIRED")


def _require_all_human_permissions(ctx: ActionContext, *permissions: str) -> None:
    snapshot = read_db_sections(("delegated_admins", "admin_shifts", "users"))
    if not all(has_permission(snapshot, ctx.user_id, permission) for permission in permissions):
        raise PermissionError("ADMIN_PERMISSION_REQUIRED")


def _audit_plan(db: dict[str, Any], actor_id: str, action_name: str, plan: dict[str, Any] | None, plan_id: Any) -> None:
    db.setdefault("admin_logs", []).append({
        "admin_id": str(actor_id), "action": action_name, "target": str(plan_id),
        "detail": {"plan": dict(plan or {})}, "created_at": utc_iso(),
    })
    db["admin_logs"] = db["admin_logs"][-10000:]


_QUOTE_SECTIONS = (
    "vip_settings", "vip_plans", "vip_users", "vip_orders", "discount_codes", "discount_history",
    "discount_events", "discount_security", "discount_security_settings", "checkout_quotes", "settings", "next_ids",
)


@action("checkout_quote_create")
def checkout_quote_create(ctx: ActionContext) -> dict[str, Any]:
    snapshot = read_db_sections(_QUOTE_SECTIONS)
    quote = create_checkout_quote(
        snapshot,
        ctx.user_id,
        plan_id=ctx.payload.get("plan_id"),
        payment_method=str(ctx.payload.get("payment_method") or ""),
        coupon=str(ctx.payload.get("coupon") or ""),
    )
    return ctx.commerce.create_quote(ctx.user_id, quote)


@action("vip_order_submit")
def vip_order_submit(ctx: ActionContext) -> dict[str, Any]:
    quote_id = str(ctx.payload.get("quote_id") or "")
    quote = ctx.commerce.get_quote(ctx.user_id, quote_id, require_active=True)
    planned_order_id = new_id("ord")
    reserved = reserve_normalized_order_discount(planned_order_id, ctx.user_id, quote)
    try:
        order = ctx.commerce.submit_order_from_quote(
            ctx.user_id,
            quote_id=quote_id,
            receipt_id=str(ctx.payload.get("receipt_id") or ""),
            transaction_hash=str(ctx.payload.get("transaction_hash") or "").strip(),
            profile={"username": ctx.identity.username, "first_name": ctx.identity.first_name},
            order_id=planned_order_id,
        )
    except Exception:
        if reserved:
            release_normalized_order_discount({**quote, "id": planned_order_id, "user_id": ctx.user_id})
        raise
    try:
        project_normalized_order_to_legacy(order["id"])
    except Exception:
        logger.exception("VIP order projection deferred order_id=%s", order.get("id"))
        order["projection_pending"] = True
    return order


@action("vip_order_cancel")
def vip_order_cancel(ctx: ActionContext) -> dict[str, Any]:
    order = ctx.commerce.get(ctx.payload.get("order_id"), user_id=ctx.user_id)
    if not order:
        raise PermissionError("ORDER_NOT_OWNED")
    if str(order.get("status")) not in {"pending", "needs_receipt"}:
        raise ValueError("ORDER_CANNOT_BE_CANCELLED")
    cancelled = ctx.commerce.update_status(order["id"], status="cancelled", actor_id=ctx.user_id,
                                           payload={"cancel_reason": str(ctx.payload.get("reason") or "")[:500]})
    release_normalized_order_discount(cancelled)
    project_normalized_order_to_legacy(cancelled["id"])
    return cancelled


@action("vip_order_resubmit")
def vip_order_resubmit(ctx: ActionContext) -> dict[str, Any]:
    existing = ctx.commerce.get(ctx.payload.get("order_id"), user_id=ctx.user_id)
    if not existing:
        raise PermissionError("ORDER_NOT_OWNED")
    reserved = reserve_normalized_order_discount(str(existing["id"]), ctx.user_id, existing)
    try:
        order = ctx.commerce.resubmit_order(
            ctx.user_id,
            existing["id"],
            receipt_id=str(ctx.payload.get("receipt_id") or ""),
            transaction_hash=str(ctx.payload.get("transaction_hash") or "").strip(),
        )
    except Exception:
        if reserved:
            release_normalized_order_discount(existing)
        raise
    try:
        project_normalized_order_to_legacy(order["id"])
    except Exception:
        logger.exception("VIP order projection deferred order_id=%s", order.get("id"))
        order["projection_pending"] = True
    return order


@action("payment_approve", admin_only=True)
def payment_approve(ctx: ActionContext) -> dict[str, Any]:
    _require_all_human_permissions(ctx, PERMISSION_PAYMENT_RECEIPT_APPROVE, PERMISSION_PAYMENT_VIP_ACTIVATE)
    order = ctx.commerce.get(ctx.payload.get("order_id"))
    if not order:
        raise ValueError("ORDER_NOT_FOUND")
    # The synchronous action atomically claims the order. The HTTP post-action
    # hook runs the shared async Telegram invite/entitlement orchestrator and
    # replaces this intermediate result with the finalized order.
    return ctx.commerce.claim_order_for_approval(order["id"], actor_id=ctx.user_id)


@action("payment_reject", admin_only=True)
def payment_reject(ctx: ActionContext) -> dict[str, Any]:
    _require_human_permission(ctx, PERMISSION_PAYMENT_RECEIPT_REJECT)
    order = ctx.commerce.get(ctx.payload.get("order_id"))
    if not order:
        raise ValueError("ORDER_NOT_FOUND")
    rejected = ctx.commerce.reject_order(
        order["id"],
        actor_id=ctx.user_id,
        reason=str(ctx.payload.get("reason") or "")[:1000],
    )
    release_normalized_order_discount(rejected)
    try:
        project_normalized_order_to_legacy(rejected["id"])
    except Exception:
        logger.exception("VIP rejection projection deferred order_id=%s", rejected.get("id"))
        rejected["projection_pending"] = True
    return rejected


@action("admin_vip_settings_update", admin_only=True, permission=PERMISSION_VIP_SETTINGS)
def admin_vip_settings_update(ctx: ActionContext) -> dict[str, Any]:
    allowed = {"card_number", "owner_name", "price", "duration_days"}
    field = str(ctx.payload.get("field") or "").strip()
    if field not in allowed:
        raise ValueError("VIP_SETTING_FIELD_INVALID")
    raw = ctx.payload.get("value")
    if field == "card_number":
        value: Any = re.sub(r"\D", "", str(raw or ""))
        if len(value) != 16:
            raise ValueError("CARD_NUMBER_INVALID")
    elif field == "owner_name":
        value = str(raw or "").strip()
        if not 2 <= len(value) <= 60 or any(ord(ch) < 32 for ch in value):
            raise ValueError("CARD_OWNER_INVALID")
    elif field == "price":
        value = int(raw or 0)
        if value < 0 or value > 10_000_000_000:
            raise ValueError("VIP_PRICE_INVALID")
    else:
        value = int(raw or 0)
        if value < 1 or value > 3650:
            raise ValueError("VIP_DURATION_INVALID")

    def mutate(db: dict[str, Any]) -> dict[str, Any]:
        settings = db.setdefault("vip_settings", {})
        settings[field] = value
        settings["updated_at"] = utc_iso()
        settings["updated_by"] = str(ctx.user_id)
        db.setdefault("admin_logs", []).append({
            "admin_id": str(ctx.user_id), "action": "vip_settings_update",
            "target": field, "detail": {"field": field, "value": "updated" if field in {"card_number", "owner_name"} else value},
            "created_at": utc_iso(),
        })
        db["admin_logs"] = db["admin_logs"][-10000:]
        return {
            "card_number": str(settings.get("card_number") or ""),
            "owner_name": str(settings.get("owner_name") or ""),
            "price": int(settings.get("price", 0) or 0),
            "duration_days": int(settings.get("duration_days", 30) or 30),
            "updated_at": settings.get("updated_at"),
        }
    return with_db(mutate)


@action("admin_vip_plan_create", admin_only=True, permission=PERMISSION_VIP_PLAN_CREATE)
def admin_vip_plan_create(ctx: ActionContext) -> dict[str, Any]:
    def mutate(db: dict[str, Any]) -> dict[str, Any]:
        row = create_vip_plan(
            db,
            name=str(ctx.payload.get("name") or ""),
            price=int(ctx.payload.get("price") or 0),
            duration_days=int(ctx.payload.get("duration_days") or 30),
            description=str(ctx.payload.get("description") or ""),
            original_price=int(ctx.payload.get("original_price") or 0),
            features=[str(item) for item in (ctx.payload.get("features") or [])] if isinstance(ctx.payload.get("features"), list) else [],
            audience=str(ctx.payload.get("audience") or "all"),
            highlight=bool(ctx.payload.get("highlight", False)),
            sales_limit=int(ctx.payload.get("sales_limit") or 0),
            starts_at=ctx.payload.get("starts_at") or None,
            ends_at=ctx.payload.get("ends_at") or None,
            created_by=ctx.user_id,
        )
        _audit_plan(db, ctx.user_id, "vip_plan_create", row, row.get("id"))
        return dict(row)
    return with_db(mutate)


@action("admin_vip_plan_update", admin_only=True, permission=PERMISSION_VIP_PLAN_EDIT)
def admin_vip_plan_update(ctx: ActionContext) -> dict[str, Any]:
    plan_id = ctx.payload.get("plan_id")
    field = str(ctx.payload.get("field") or "")
    if field in {"active", "archived"}:
        raise ValueError("USE_PLAN_STATUS_ACTION")
    def mutate(db: dict[str, Any]) -> dict[str, Any]:
        row = update_vip_plan(db, plan_id, field, ctx.payload.get("value"))
        _audit_plan(db, ctx.user_id, "vip_plan_update", row, plan_id)
        return dict(row)
    return with_db(mutate)


@action("admin_vip_plan_toggle", admin_only=True)
def admin_vip_plan_toggle_action(ctx: ActionContext) -> dict[str, Any]:
    plan_id = ctx.payload.get("plan_id")
    mode = str(ctx.payload.get("mode") or "toggle").lower()
    required_permission = {
        "activate": PERMISSION_VIP_PLAN_ACTIVATE,
        "deactivate": PERMISSION_VIP_PLAN_ACTIVATE,
        "toggle": PERMISSION_VIP_PLAN_ACTIVATE,
        "archive": PERMISSION_VIP_PLAN_ARCHIVE,
    }.get(mode)
    if not required_permission:
        raise ValueError("VIP_PLAN_STATUS_MODE_INVALID")
    _require_human_permission(ctx, required_permission)
    def mutate(db: dict[str, Any]) -> dict[str, Any]:
        row = get_vip_plan(db, plan_id)
        if not row:
            raise ValueError("VIP_PLAN_NOT_FOUND")
        if mode == "archive":
            row["active"] = False
            row["archived"] = True
            row["archived_by"] = str(ctx.user_id)
            row["archived_at"] = utc_iso()
        elif mode == "activate":
            row["active"] = True
            row["archived"] = False
            row.pop("archived_at", None)
            row.pop("archived_by", None)
        elif mode == "deactivate":
            row["active"] = False
        else:
            row = toggle_vip_plan(db, plan_id)
        row["updated_at"] = utc_iso()
        _audit_plan(db, ctx.user_id, f"vip_plan_{mode}", row, plan_id)
        return dict(row)
    return with_db(mutate)


@action("admin_vip_plan_delete", admin_only=True, permission=PERMISSION_VIP_PLAN_DELETE)
def admin_vip_plan_delete_action(ctx: ActionContext) -> dict[str, Any]:
    plan_id = ctx.payload.get("plan_id")
    def mutate(db: dict[str, Any]) -> dict[str, Any]:
        target = get_vip_plan(db, plan_id)
        if not target:
            raise ValueError("VIP_PLAN_NOT_FOUND")
        if int(target.get("sales_count", 0) or 0) > 0 or any(
            isinstance(order, dict) and str(order.get("plan_id")) == str(plan_id)
            for order in db.get("vip_orders", [])
        ):
            raise ValueError("VIP_PLAN_HAS_HISTORY_ARCHIVE_REQUIRED")
        removed = delete_vip_plan(db, plan_id)
        if not removed:
            raise ValueError("VIP_PLAN_DELETE_FAILED")
        _audit_plan(db, ctx.user_id, "vip_plan_delete", target, plan_id)
        return {"deleted": True, "plan_id": plan_id}
    return with_db(mutate)
