from __future__ import annotations

from services.actions_v2.context import ActionContext
from services.actions_v2.registry import action
from services.unified_support_service import (
    create_user_ticket, reply_user_ticket, user_ticket_satisfaction, user_ticket_status,
)


@action("ticket_create")
def ticket_create(ctx: ActionContext):
    return create_user_ticket(
        ctx.user_id,
        subject=str(ctx.payload.get("subject") or "پشتیبانی"),
        body=str(ctx.payload.get("text") or ctx.payload.get("body") or ""),
        category=str(ctx.payload.get("category") or "general"),
        priority=str(ctx.payload.get("priority") or "normal"),
        attachment=ctx.payload.get("attachment") if isinstance(ctx.payload.get("attachment"), dict) else None,
        technical_context=__import__('modules.support_technical_context',fromlist=['sanitize']).sanitize(
            ctx.payload.get('technical_context_opt_in'),ctx.payload.get('technical_context')),
    )


@action("ticket_reply")
def ticket_reply(ctx: ActionContext):
    return reply_user_ticket(
        ctx.user_id, ctx.payload.get("ticket_id"),
        str(ctx.payload.get("text") or ctx.payload.get("body") or ""),
        attachment=ctx.payload.get("attachment") if isinstance(ctx.payload.get("attachment"), dict) else None,
    )


@action("ticket_status_update")
def ticket_status_update(ctx: ActionContext):
    return user_ticket_status(ctx.user_id, ctx.payload.get("ticket_id"), str(ctx.payload.get("status") or "closed"))


@action("ticket_satisfaction")
def ticket_satisfaction(ctx: ActionContext):
    score = int(ctx.payload.get("score") or 0)
    if not 1 <= score <= 5:
        raise ValueError("INVALID_SATISFACTION_SCORE")
    return user_ticket_satisfaction(ctx.user_id, ctx.payload.get("ticket_id"), score)
