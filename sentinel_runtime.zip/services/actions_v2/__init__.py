"""SENTINEL v8 Mini App action registry.

Importing this package registers every modular handler. Business logic lives in
feature files rather than one conditional dispatcher.
"""
from services.actions_v2 import admin as _admin  # noqa: F401
from services.actions_v2 import ai as _ai  # noqa: F401
from services.actions_v2 import commerce as _commerce  # noqa: F401
from services.actions_v2 import rewards as _rewards  # noqa: F401
from services.actions_v2 import contests as _contests  # noqa: F401
from services.actions_v2 import journal as _journal  # noqa: F401
from services.actions_v2 import mt5 as _mt5  # noqa: F401
from services.actions_v2 import preferences as _preferences  # noqa: F401
from services.actions_v2 import support as _support  # noqa: F401
from services.actions_v2 import trading as _trading  # noqa: F401
from services.actions_v2 import expansion as _expansion  # noqa: F401
from services.actions_v2.registry import action_specs, get_action

__all__ = ["action_specs", "get_action"]
