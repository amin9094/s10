from __future__ import annotations

import hashlib
import math
from typing import Any

from modules.calculator import calculate_crypto_position_size, calculate_position_size
from modules.market_scope import classify_market_symbol
from modules.signal_status import signal_is_final
from repositories.v2.common import utc_iso
from services.actions_v2.context import ActionContext
from services.actions_v2.registry import action
from services.unified_journal_service import (
    mirror_normalized_journal_archive,
    mirror_normalized_journal_create,
    mirror_normalized_journal_partial,
    mirror_normalized_journal_result,
)


def _volume_for_execution(ctx: ActionContext, account: dict[str, Any], signal: dict[str, Any], execution: dict[str, Any], risk_percent: float) -> tuple[float, float]:
    balance = float(account.get("equity") if account.get("equity") is not None else account.get("balance") or 0)
    if not math.isfinite(balance) or balance <= 0:
        raise ValueError("ACCOUNT_BALANCE_REQUIRED")
    # These estimators are denominated in USD. Unsupported conversions fail closed.
    if str(account.get("currency") or "USD").upper() not in {"USD", "USDT"}:
        raise ValueError("ACCOUNT_CURRENCY_CONVERSION_REQUIRED")
    entry = float(execution.get("actual_entry") or 0)
    stop = float(execution.get("actual_stop") or 0)
    raw = execution.get("volume") if execution.get("volume") is not None else execution.get("actual_volume")
    supplied = float(raw) if raw is not None else 0
    if not math.isfinite(supplied) or supplied < 0:
        raise ValueError("INVALID_EXECUTION_VOLUME")
    symbol = str(signal.get("symbol") or "")
    if classify_market_symbol(symbol) == "crypto":
        result = calculate_crypto_position_size(balance_usd=balance, risk_percent=risk_percent,
            entry_price=entry, stop_price=stop, leverage=float(account.get("leverage") or 1))
        calculated = float(result["quantity"])
        loss_per_unit = float(result["loss_per_unit"])
    else:
        result = calculate_position_size(symbol=symbol, balance_usd=balance, risk_percent=risk_percent,
            entry_price=entry, stop_price=stop, current_price=entry,
            leverage=float(account.get("leverage") or 1))
        calculated = float(result["lot"])
        loss_per_unit = float(result["loss_per_lot"])
    volume = supplied or calculated
    if volume <= 0:
        raise ValueError("POSITION_SIZE_BELOW_MINIMUM")
    risk_money = volume * loss_per_unit
    if not math.isfinite(risk_money) or risk_money <= 0:
        raise ValueError("INVALID_EXECUTION_RISK")
    if risk_money > balance * risk_percent / 100 + 1e-8:
        raise ValueError("EXECUTION_VOLUME_EXCEEDS_RISK_BUDGET")
    return volume, risk_money


@action("risk_calculate", mutation=False, idempotency_required=False)
def risk_calculate(ctx: ActionContext) -> dict[str, Any]:
    symbol = str(ctx.payload.get("symbol") or "").strip().upper().replace("/", "")
    balance = float(ctx.payload.get("balance") or 0)
    risk_percent = float(ctx.payload.get("risk_percent") or 0)
    entry = float(ctx.payload.get("entry") or 0)
    stop = float(ctx.payload.get("stop") or 0)
    leverage = float(ctx.payload.get("leverage") or 1)
    if not symbol:
        raise ValueError("SYMBOL_REQUIRED")
    market = str(ctx.payload.get("market") or classify_market_symbol(symbol)).strip().lower()
    if market == "crypto":
        result = calculate_crypto_position_size(
            balance_usd=balance,
            risk_percent=risk_percent,
            entry_price=entry,
            stop_price=stop,
            leverage=leverage,
            fee_percent_round_trip=float(ctx.payload.get("fee_percent") or 0),
            quantity_step=ctx.payload.get("quantity_step"),
            min_quantity=ctx.payload.get("min_quantity"),
            min_notional=ctx.payload.get("min_notional"),
            available_margin_usd=ctx.payload.get("available_margin"),
        )
    else:
        result = calculate_position_size(
            symbol=symbol,
            balance_usd=balance,
            risk_percent=risk_percent,
            entry_price=entry,
            stop_price=stop,
            current_price=float(ctx.payload.get("current_price") or entry),
            cross_rate=ctx.payload.get("cross_rate"),
            contract_size=ctx.payload.get("contract_size"),
            min_lot=ctx.payload.get("min_lot"),
            lot_step=ctx.payload.get("lot_step"),
            max_lot=ctx.payload.get("max_lot"),
            leverage=leverage,
            available_margin_usd=ctx.payload.get("available_margin"),
        )
    return {
        "market": market,
        "symbol": symbol,
        "balance": balance,
        "risk_percent": risk_percent,
        "result": result,
        "disclaimer": "POSITION_SIZE_ESTIMATE_VERIFY_BROKER_SPECIFICATIONS",
    }


@action("risk_profile_update")
def risk_profile_update(ctx: ActionContext) -> dict[str, Any]:
    with ctx.engine.atomic():
        return _risk_profile_update(ctx)

def _risk_profile_update(ctx: ActionContext) -> dict[str, Any]:
    account = ctx.accounts.get(ctx.user_id, ctx.payload.get("account_id"))
    if ctx.payload.get("account_id") is not None and account is None:
        raise ValueError("TRADING_ACCOUNT_NOT_FOUND")
    profile = ctx.preferences.patch(ctx.user_id, "personal_risk_profiles", ctx.payload)
    if account:
        mapped = {key: ctx.payload[key] for key in (
            "balance", "equity", "starting_balance", "timezone", "default_risk_percent",
            "max_daily_risk_percent", "max_open_risk_percent", "max_open_trades",
        ) if key in ctx.payload}
        if mapped:
            original = ctx.payload
            try:
                ctx.payload = {**mapped, "account_id": account["id"]}
                account = _account_upsert(ctx)
            finally:
                ctx.payload = original
    return {"profile": profile, "account": account}


@action("account_upsert")
def account_upsert(ctx: ActionContext) -> dict[str, Any]:
    with ctx.engine.atomic():
        return _account_upsert(ctx)

def _account_upsert(ctx: ActionContext) -> dict[str, Any]:
    if ctx.payload.get("data_observed_at") is not None:
        # Validate legacy input for compatibility, then use the server timestamp.
        ctx.accounts._local_date(str(ctx.payload["data_observed_at"]), "UTC")
    current = ctx.accounts.get(ctx.user_id, ctx.payload["account_id"]) if ctx.payload.get("account_id") is not None else None
    if ctx.payload.get("account_id") is not None and current is None:
        raise ValueError("TRADING_ACCOUNT_NOT_FOUND")
    current = current or {}
    account_type = str(ctx.payload.get("type") or ctx.payload.get("account_type") or current.get("type") or "personal").strip().lower()
    default_template = "prop-static-5-10" if account_type in {"prop_challenge", "prop_funded"} else "personal-standard"
    template_id = str(ctx.payload.get("rule_template_id") or (
        current.get("rule_template_id") if not ("type" in ctx.payload or "account_type" in ctx.payload) else None
    ) or default_template).strip()
    # Reject stale or forged template ids before creating the account. This
    # keeps every saved account immediately evaluable by the risk engine.
    ctx.prop_rules.get_template(template_id)
    if ctx.payload.get("account_id") is not None and ctx.accounts.get(ctx.user_id, ctx.payload["account_id"]) is None:
        raise ValueError("TRADING_ACCOUNT_NOT_FOUND")
    # Connector identity and provider provenance are server-owned. Manual
    # edits must never masquerade as a verified broker snapshot.
    values = {key: value for key, value in ctx.payload.items()
              if key not in {"mt5_server", "mt5_connector_id", "data_source", "data_confidence", "provider", "broker_account_reference"}}
    values.pop("data_observed_at", None)
    values["rule_template_id"] = template_id
    if any(key in ctx.payload for key in ("balance", "equity", "starting_balance", "high_water_mark", "floating_pnl")):
        values.update(data_source="manual", data_confidence=0.5, provider="")
    row = ctx.accounts.upsert(ctx.user_id, values, account_id=ctx.payload.get("account_id"))
    observed_at = utc_iso()
    source = "manual"
    confidence = 0.5
    if any(field in ctx.payload for field in ("balance", "equity", "floating_pnl")):
        ctx.accounts.record_equity(
            ctx.user_id, row["id"], balance=float(row.get("balance") or 0),
            equity=float(row["equity"]),
            floating_pnl=float(row.get("floating_pnl") or 0), source=source,
            confidence=confidence, observed_at=observed_at,
            payload={"request_id": ctx.request_id, "provider": ""},
        )
        row = ctx.accounts.get(ctx.user_id, row["id"]) or row
    for field in ("balance", "equity", "starting_balance", "high_water_mark", "floating_pnl"):
        if field in ctx.payload:
            ctx.confidence.record(
                entity_type="trading_account", entity_id=row["id"], field_name=field,
                value=row[field], source=source, provider="",
                observed_at=observed_at, ttl_seconds=900, confidence=confidence,
            )
    return row


@action("account_archive")
def account_archive(ctx: ActionContext) -> dict[str, Any]:
    active = ctx.positions.list_for_user(ctx.user_id, account_id=ctx.payload.get("account_id"), status="active", limit=1)
    if active["items"]:
        raise ValueError("ACCOUNT_HAS_ACTIVE_POSITIONS")
    return ctx.accounts.archive(ctx.user_id, ctx.payload.get("account_id"))


def _ensure_position_journal(ctx, position, signal=None):
    existing = ctx.journal.get_by_position(ctx.user_id, position["id"])
    if existing:
        return existing
    signal = signal or {}
    # Repair incomplete records from earlier releases without reopening a trade.
    return ctx.journal.add(ctx.user_id, {
        "id": "jnl_pos_" + hashlib.sha256(str(position["id"]).encode()).hexdigest()[:24],
        "account_id": position["account_id"], "position_id": position["id"],
        "signal_id": position.get("signal_id"), "symbol": position["symbol"],
        "side": position["side"], "status": position["status"],
        "entry_price": position["actual_entry"], "stop_loss": position["actual_stop"],
        "volume": position["actual_volume"], "remaining_volume": position["remaining_volume"],
        "risk_percent": position["risk_percent"], "risk_money": position["risk_money"],
        "pnl_amount": position.get("realized_pnl", 0), "opened_at": position["opened_at"],
        "closed_at": position.get("closed_at"), "source": "channel_signal" if position.get("signal_id") else "position",
        "targets": signal.get("targets") or [], "note": "Repaired missing position journal",
    })


@action("signal_choice_update")
def signal_choice_update(ctx: ActionContext) -> dict[str, Any]:
    with ctx.engine.atomic():
        return _signal_choice_update(ctx)

def _signal_choice_update(ctx: ActionContext) -> dict[str, Any]:
    signal_id = str(ctx.payload.get("signal_id") or "")
    signal = ctx.signals.get(signal_id)
    if not signal:
        raise ValueError("SIGNAL_NOT_FOUND")
    if signal.get('publication_valid') is False or signal.get('status')=='needs_review':
        raise ValueError('SIGNAL_PUBLICATION_INVALID')
    choice = str(ctx.payload.get("choice") or "").lower()
    if choice not in {"taken", "skipped"}:
        raise ValueError("INVALID_SIGNAL_CHOICE")
    choices = ctx.preferences.get(ctx.user_id, "user_signal_choices", {})
    if not isinstance(choices, dict):
        choices = {}
    previous = choices.get(signal_id) if isinstance(choices.get(signal_id), dict) else {}
    previous_choice = str(previous.get("choice") or "").lower()
    if previous_choice in {"taken", "skipped"}:
        if choice != previous_choice:
            raise ValueError("SIGNAL_DECISION_LOCKED")
        existing_positions = ctx.positions.active_for_signal(ctx.user_id, signal_id)
        existing_position = existing_positions[0] if existing_positions else (ctx.positions.get(ctx.user_id, previous["position_id"]) if previous.get("position_id") else None)
        existing_journal = None
        if existing_position:
            existing_journal = _ensure_position_journal(ctx, existing_position, signal)
        return {
            "choice": previous,
            "position": existing_position,
            "journal": existing_journal,
            "idempotent": True,
            "decision_locked": True,
        }
    choice_row = {
        "signal_id": signal_id,
        "choice": choice,
        "selected_at": previous.get("selected_at") or utc_iso(),
        "updated_at": utc_iso(),
    }
    # A response submitted after Telegram closed the signal is retrospective:
    # it records whether the user took the idea, but must never open/cancel a
    # live position or create a misleading execution journal entry.
    if signal_is_final(signal):
        choice_row.update({
            "retrospective": True,
            "signal_status": str(signal.get("status") or "closed"),
        })
        choices[signal_id] = choice_row
        ctx.preferences.set(ctx.user_id, "user_signal_choices", choices)
        return {
            "choice": choice_row,
            "position": None,
            "journal": None,
            "retrospective": True,
            "decision_locked": True,
        }
    if choice == "taken":
        execution = ctx.payload.get("execution") if isinstance(ctx.payload.get("execution"), dict) else {}
        if not execution.get("confirmation"):
            raise ValueError("EXECUTION_CONFIRMATION_REQUIRED")
        account = ctx.accounts.get(ctx.user_id, execution.get("account_id"))
        if not account:
            raise ValueError("TRADING_ACCOUNT_NOT_FOUND")
        existing_positions = ctx.positions.active_for_signal(ctx.user_id, signal_id)
        if existing_positions:
            existing_position = existing_positions[0]
            existing_journal = _ensure_position_journal(ctx, existing_position, signal)
            choice_row.update({
                "choice": "taken",
                "position_id": existing_position["id"],
                "journal_id": existing_journal.get("id") if existing_journal else None,
                "account_id": existing_position.get("account_id"),
            })
            choices[signal_id] = choice_row
            ctx.preferences.set(ctx.user_id, "user_signal_choices", choices)
            return {
                "choice": choice_row,
                "position": existing_position,
                "journal": existing_journal,
                "idempotent": True,
                "decision_locked": True,
            }
        risk_percent = float(execution.get("risk_percent") or account.get("default_risk_percent") or 1)
        volume, risk_money = _volume_for_execution(ctx, account, signal, execution, risk_percent)
        risk_percent = risk_money / float(account["equity"]) * 100
        candidate = {
            "signal_status": str(signal.get("status") or "open").lower(),
            "symbol": signal.get("symbol"),
            "side": signal.get("side"),
            "actual_entry": execution.get("actual_entry"),
            "actual_stop": execution.get("actual_stop"),
            "risk_percent": risk_percent,
        }
        decision = ctx.prop_rules.evaluate(
            user_id=ctx.user_id,
            account_id=account["id"],
            candidate=candidate,
            news_events=ctx.payload.get("news_events") if isinstance(ctx.payload.get("news_events"), list) else [],
        )
        if not decision.allowed:
            raise ValueError("PRETRADE_HARD_BLOCK:" + ",".join(item["code"] for item in decision.hard_blocks))
        position_id = "pos_sig_" + hashlib.sha256(f"{ctx.user_id}:{signal_id}".encode("utf-8")).hexdigest()[:24]
        historical_position = ctx.positions.get(ctx.user_id, position_id)
        if historical_position:
            historical_journal = _ensure_position_journal(ctx, historical_position, signal)
            choice_row.update({
                "choice": "taken",
                "position_id": historical_position["id"],
                "journal_id": historical_journal.get("id") if historical_journal else None,
                "account_id": historical_position.get("account_id"),
            })
            choices[signal_id] = choice_row
            ctx.preferences.set(ctx.user_id, "user_signal_choices", choices)
            return {
                "choice": choice_row,
                "position": historical_position,
                "journal": historical_journal,
                "idempotent": True,
                "decision_locked": True,
            }
        position = ctx.positions.open({
            "id": position_id,
            "user_id": ctx.user_id,
            "account_id": account["id"],
            "signal_id": signal_id,
            "symbol": signal.get("symbol"),
            "side": signal.get("side"),
            "actual_entry": float(execution.get("actual_entry")),
            "actual_stop": float(execution.get("actual_stop")),
            "actual_volume": volume,
            "risk_percent": risk_percent,
            "risk_money": risk_money,
            "opening_equity": float(account["equity"]),
            "data_source": "manual",
            "data_confidence": 0.5,
            "gate": {"decision": decision.decision, "warnings": list(decision.warnings), "metrics": decision.metrics},
        })
        journal = ctx.journal.add(ctx.user_id, {
            "account_id": account["id"], "position_id": position["id"], "signal_id": signal_id,
            "symbol": signal.get("symbol"), "side": signal.get("side"), "status": "open",
            "entry_price": position["actual_entry"], "volume": position["actual_volume"],
            "remaining_volume": position["remaining_volume"], "opened_at": position["opened_at"],
            "source": "channel_signal", "entry_reason_type": "channel_signal",
            "entry_reason": f"SENTINEL channel signal #{signal.get('display_number') or signal_id}",
            "risk_percent": risk_percent, "risk_money": risk_money,
            "stop_loss": position.get("actual_stop"), "actual_stop": position.get("actual_stop"),
            "targets": signal.get("targets") or signal.get("take_profits") or [],
            "setup": f"SENTINEL signal #{signal.get('display_number') or signal_id}",
            "note": str(signal.get("note") or signal.get("analysis") or "")[:2000],
            "gate": {"decision": decision.decision, "warnings": list(decision.warnings), "metrics": decision.metrics},
        })
        legacy_journal = mirror_normalized_journal_create(ctx.user_id, journal)
        journal = ctx.journal.update(ctx.user_id, journal["id"], {"legacy_journal_id": legacy_journal.get("id")})
        skipped = ctx.journal.get_by_signal(ctx.user_id, signal_id, source="signal_skipped")
        if skipped and skipped.get("status") != "archived":
            mirror_normalized_journal_archive(ctx.user_id, skipped)
            ctx.journal.archive(ctx.user_id, skipped["id"])
        choice_row.update({
            "position_id": position["id"], "journal_id": journal["id"],
            "account_id": account["id"], "risk_percent": risk_percent, "risk_money": risk_money,
            "actual_entry": position.get("actual_entry"), "actual_stop": position.get("actual_stop"),
            "actual_volume": position.get("actual_volume"),
        })
        data = {"choice": choice_row, "position": position, "journal": journal, "gate": {
            "decision": decision.decision, "warnings": list(decision.warnings), "metrics": decision.metrics,
        }}
    else:
        # A skipped signal is a decision, not a trade. It must never create a
        # position or a journal row. Clean up old placeholder rows produced by
        # previous releases so one signal stays one logical item for the user.
        cancelled: list[dict[str, Any]] = []
        for position in ctx.positions.active_for_signal(ctx.user_id, signal_id):
            cancelled.append(ctx.positions.cancel(ctx.user_id, position["id"], reason="signal_choice:skipped"))
            journal = ctx.journal.get_by_position(ctx.user_id, position["id"])
            if journal:
                cancelled_journal = ctx.journal.update(
                    ctx.user_id,
                    journal["id"],
                    {"status": "cancelled", "closed_at": utc_iso()},
                )
                mirror_normalized_journal_archive(ctx.user_id, cancelled_journal)
        legacy_skipped = ctx.journal.get_by_signal(ctx.user_id, signal_id, source="signal_skipped")
        if legacy_skipped and legacy_skipped.get("status") != "archived":
            mirror_normalized_journal_archive(ctx.user_id, legacy_skipped)
            ctx.journal.archive(ctx.user_id, legacy_skipped["id"])
        choice_row["reason"] = str(ctx.payload.get("reason") or "")[:500]
        data = {
            "choice": choice_row,
            "cancelled_positions": cancelled,
            "journal": None,
            "decision_locked": True,
        }
    choices[signal_id] = choice_row
    ctx.preferences.set(ctx.user_id, "user_signal_choices", choices)
    return data


@action("position_close")
def position_close(ctx: ActionContext) -> dict[str, Any]:
    with ctx.engine.atomic():
        return _position_close(ctx)

def _position_close(ctx: ActionContext) -> dict[str, Any]:
    position = ctx.positions.get(ctx.user_id, ctx.payload.get("position_id"))
    if not position:
        raise ValueError("POSITION_NOT_FOUND")
    _ensure_position_journal(ctx, position)
    close_volume = ctx.payload.get("close_volume")
    if close_volume is None:
        fraction = float(ctx.payload["close_fraction"] if ctx.payload.get("close_fraction") is not None else 1)
        if not math.isfinite(fraction) or not 0 < fraction <= 1:
            raise ValueError("INVALID_CLOSE_FRACTION")
        close_volume = float(position["remaining_volume"]) * fraction
    # Percentage is gross P&L relative to the opening account equity.
    # Amount, including an explicit zero, takes precedence when both are sent.
    pnl = ctx.payload.get("pnl_amount")
    if pnl is None and ctx.payload.get("pnl_percent") is not None:
        basis = position.get("opening_equity")
        if basis is None:
            initial_percent = float(position.get("risk_percent") or 0)
            if initial_percent <= 0:
                raise ValueError("POSITION_PNL_BASIS_REQUIRED")
            basis = float(position.get("risk_money") or 0) / initial_percent * 100
        pnl = float(basis) * float(ctx.payload["pnl_percent"]) / 100
    pnl = float(pnl or 0)
    if not math.isfinite(pnl):
        raise ValueError("INVALID_PNL")
    updated = ctx.positions.close(
        ctx.user_id,
        position["id"],
        close_volume=float(close_volume),
        realized_pnl=pnl,
        exit_price=float(ctx.payload.get("exit_price") or 0),
        commission=float(ctx.payload.get("commission") or 0),
        swap=float(ctx.payload.get("swap") or 0),
        fees=float(ctx.payload.get("fees") or 0),
        note=str(ctx.payload.get("note") or ""),
    )
    journal = ctx.journal.get_by_position(ctx.user_id, position["id"])
    if journal:
        status = "closed" if updated.get("status") == "closed" else "partial"
        synced_journal = ctx.journal.update(ctx.user_id, journal["id"], {
            "status": status,
            "remaining_volume": updated.get("remaining_volume"),
            "pnl_amount": updated.get("realized_pnl"),
            "pnl_percent": float(updated.get("realized_pnl") or 0) / max(float(position.get("opening_equity") or (float(position.get("risk_money") or 0) / max(float(position.get("risk_percent") or 0),1e-9) * 100)),1e-9) * 100,
            "exit_price": ctx.payload.get("exit_price"),
            "closed_at": updated.get("closed_at"),
        })
        if status == "closed":
            mirror_normalized_journal_result(ctx.user_id, synced_journal)
        else:
            closed_volume = max(0.0, float(position.get("remaining_volume") or 0) - float(updated.get("remaining_volume") or 0))
            if closed_volume > 0:
                mirror_normalized_journal_partial(ctx.user_id, synced_journal, volume=closed_volume, exit_price=float(ctx.payload.get("exit_price") or 0), pnl_amount=pnl)
    return updated


@action("revision_ack")
def revision_ack(ctx: ActionContext) -> dict[str, Any]:
    values = ctx.preferences.get(ctx.user_id, "signal_revision_acknowledgements", {})
    if not isinstance(values, dict):
        values = {}
    key = str(ctx.payload.get("signal_id") or "")
    values[key] = {"revision": ctx.payload.get("revision"), "acknowledged_at": utc_iso()}
    ctx.preferences.set(ctx.user_id, "signal_revision_acknowledgements", values)
    return values[key]


@action("broker_snapshot_sync")
def broker_snapshot_sync(ctx: ActionContext) -> dict[str, Any]:
    """Synchronize a read-only broker snapshot into risk data.

    The adapter contract has no order-placement operation. The snapshot updates
    account balances/provenance and is retained for audit, but never creates or
    modifies a broker order.
    """
    from modules.broker_readonly import HttpBrokerSnapshotAdapter

    account_id = str(ctx.payload.get("account_id") or "").strip()
    from modules.broker_readonly import authorized_account_reference

    account_reference = authorized_account_reference(ctx.user_id, account_id)
    account = ctx.accounts.get(ctx.user_id, account_id)
    if not account:
        raise ValueError("TRADING_ACCOUNT_NOT_FOUND")
    requested_reference = str(ctx.payload.get("account_reference") or "").strip()
    if requested_reference and requested_reference != account_reference:
        raise ValueError("BROKER_ACCOUNT_REFERENCE_FORBIDDEN")
    snapshot = HttpBrokerSnapshotAdapter().fetch_snapshot(account_reference, user_id=ctx.user_id)
    if snapshot.account_reference != account_reference:
        raise ValueError("BROKER_ACCOUNT_REFERENCE_MISMATCH")
    with ctx.engine.atomic():
        return _save_broker_snapshot(ctx, account, account_id, account_reference, snapshot)


def _save_broker_snapshot(ctx, account, account_id, account_reference, snapshot):
    from modules.broker_readonly import record_broker_snapshot
    from repositories.v2.common import content_hash, json_dump, new_id

    updated = ctx.accounts.upsert(
        ctx.user_id,
        {
            "balance": snapshot.balance,
            "equity": snapshot.equity,
            "floating_pnl": snapshot.floating_pnl,
            "high_water_mark": max(float(account.get("high_water_mark") or 0), snapshot.equity),
            "data_source": "broker",
            "data_confidence": snapshot.confidence,
            "data_observed_at": snapshot.observed_at,
            "provider": snapshot.provider,
            "broker_account_reference": account_reference,
        },
        account_id=account_id,
    )
    ctx.accounts.record_equity(
        ctx.user_id,
        account_id,
        balance=snapshot.balance,
        equity=snapshot.equity,
        floating_pnl=snapshot.floating_pnl,
        source="broker",
        confidence=snapshot.confidence,
        observed_at=snapshot.observed_at,
        payload={"provider": snapshot.provider, "request_id": ctx.request_id},
    )
    record_broker_snapshot(account_id, snapshot, ctx.confidence)
    snapshot_payload = {
        "provider": snapshot.provider,
        "account_reference": account_reference,
        "balance": snapshot.balance,
        "equity": snapshot.equity,
        "floating_pnl": snapshot.floating_pnl,
        "positions": list(snapshot.positions),
        "observed_at": snapshot.observed_at,
        "confidence": snapshot.confidence,
    }
    with ctx.engine.transaction() as cursor:
        cursor.execute(
            """INSERT INTO v8_broker_snapshots(id,user_id,account_id,provider,account_reference,observed_at,confidence,checksum,payload)
               VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(account_id,observed_at) DO UPDATE SET
               provider=excluded.provider,confidence=excluded.confidence,checksum=excluded.checksum,payload=excluded.payload""",
            (
                new_id("broker"), ctx.user_id, account_id, snapshot.provider, account_reference,
                snapshot.observed_at, snapshot.confidence, content_hash(snapshot_payload), json_dump(snapshot_payload),
            ),
        )
    return {"account": updated, "snapshot": snapshot_payload, "read_only": True}
