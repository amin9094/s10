from __future__ import annotations

import csv
import io
import math
from typing import Any

from modules.broker_import import parse_broker_statement
from modules.portfolio import calculate_r_multiple, normalize_journal_reason
from repositories.v2.common import utc_iso
from services.actions_v2.context import ActionContext
from services.actions_v2.registry import action
from services.unified_journal_service import (mirror_normalized_journal_archive, mirror_normalized_journal_create, mirror_normalized_journal_partial, mirror_normalized_journal_result)


@action("journal_add")
def journal_add(ctx: ActionContext) -> dict[str, Any]:
    payload = dict(ctx.payload)
    reason_type, reason = normalize_journal_reason(
        str(payload.get("entry_reason_type") or payload.get("source") or ""),
        str(payload.get("entry_reason") or ""),
        signal_id=payload.get("signal_id"),
    )
    payload["entry_reason_type"] = reason_type
    payload["entry_reason"] = reason
    payload.setdefault("source", "channel_signal" if reason_type == "channel_signal" else "manual")
    if payload.get("actual_stop") is not None:
        payload.setdefault("stop_loss", payload.get("actual_stop"))
    row = ctx.journal.add(ctx.user_id, payload)
    legacy = mirror_normalized_journal_create(ctx.user_id, row)
    return ctx.journal.update(ctx.user_id, row["id"], {"legacy_journal_id": legacy.get("id")})


@action("journal_delete")
def journal_delete(ctx: ActionContext) -> dict[str, Any]:
    row = ctx.journal.get(ctx.user_id, ctx.payload.get("id"))
    if not row:
        raise ValueError("JOURNAL_ENTRY_NOT_FOUND")
    mirror_normalized_journal_archive(ctx.user_id, row)
    return ctx.journal.archive(ctx.user_id, row["id"])


@action("journal_result_update")
def journal_result_update(ctx: ActionContext) -> dict[str, Any]:
    with ctx.engine.atomic():
        return _journal_result_update(ctx)


def _locked_entry(ctx: ActionContext) -> dict[str, Any] | None:
    entry = ctx.journal.get(ctx.user_id, ctx.payload.get("id"))
    if not entry:
        return None
    # All trading paths take position -> journal locks. Reversing that order
    # here could deadlock with position_close on PostgreSQL.
    if entry.get("position_id"):
        ctx.positions.get(ctx.user_id, entry["position_id"])
    return ctx.journal.get(ctx.user_id, entry["id"], for_update=True)


def _journal_result_update(ctx: ActionContext) -> dict[str, Any]:
    entry = _locked_entry(ctx)
    if not entry:
        raise ValueError("JOURNAL_ENTRY_NOT_FOUND")
    result_r = ctx.payload.get("result_r")
    if result_r in {None, ""}:
        result_r = calculate_r_multiple(
            str(entry.get("side") or ""),
            entry.get("entry_price") or entry.get("actual_entry"),
            entry.get("actual_stop") or entry.get("stop_loss"),
            ctx.payload.get("exit_price"),
        )
    values = {
        "pnl_percent": float(ctx.payload.get("pnl_percent") or 0),
        "result_r": None if result_r in {None, ""} else round(float(result_r), 6),
        "pnl_amount": float(ctx.payload.get("pnl_amount") or 0),
        "exit_price": ctx.payload.get("exit_price"),
        "status": "closed",
        "closed_at": utc_iso(),
        "note": str(ctx.payload.get("note") or entry.get("note") or "")[:2000],
        "fees": float(ctx.payload.get("fees") or 0),
        "commission": float(ctx.payload.get("commission") or 0),
        "swap": float(ctx.payload.get("swap") or 0),
    }
    if entry.get("position_id"):
        position = ctx.positions.get(ctx.user_id, entry["position_id"])
        if position and position.get("status") in {"open", "partial", "planned"}:
            updated = ctx.positions.close(
                ctx.user_id, position["id"], close_volume=float(position["remaining_volume"]),
                realized_pnl=values["pnl_amount"], exit_price=float(values["exit_price"] or 0),
                commission=values["commission"], swap=values["swap"], fees=values["fees"],
                note=values["note"],
            )
            values["position"] = updated
            values["remaining_volume"] = updated["remaining_volume"]
            values["pnl_amount"] = updated["realized_pnl"]
    updated = ctx.journal.update(ctx.user_id, entry["id"], values)
    mirror_normalized_journal_result(ctx.user_id, updated)
    return updated


@action("journal_partial_close")
def journal_partial_close(ctx: ActionContext) -> dict[str, Any]:
    with ctx.engine.atomic():
        return _journal_partial_close(ctx)

def _journal_partial_close(ctx: ActionContext) -> dict[str, Any]:
    entry = _locked_entry(ctx)
    if not entry:
        raise ValueError("JOURNAL_ENTRY_NOT_FOUND")
    volume = float(ctx.payload.get("volume") or 0)
    if not math.isfinite(volume) or volume <= 0:
        raise ValueError("INVALID_CLOSE_VOLUME")
    if entry.get("status") not in {"open", "partial", "planned"}:
        raise ValueError("JOURNAL_ENTRY_NOT_ACTIVE")
    numbers = {key: float(ctx.payload.get(key) or 0) for key in
               ("pnl_amount", "exit_price", "commission", "swap", "fees")}
    if any(not math.isfinite(value) for value in numbers.values()):
        raise ValueError("INVALID_PNL")
    if numbers["exit_price"] <= 0:
        raise ValueError("INVALID_EXIT_PRICE")
    if numbers["commission"] < 0 or numbers["fees"] < 0:
        raise ValueError("INVALID_TRADING_COST")
    result: dict[str, Any] = {}
    if entry.get("position_id"):
        result["position"] = ctx.positions.close(
            ctx.user_id, entry["position_id"], close_volume=volume,
            realized_pnl=numbers["pnl_amount"], exit_price=numbers["exit_price"],
            commission=numbers["commission"], swap=numbers["swap"],
            fees=numbers["fees"], note=str(ctx.payload.get("note") or ""),
        )
        remaining = float(result["position"].get("remaining_volume") or 0)
        status = "closed" if result["position"].get("status") == "closed" else "partial"
    else:
        current = entry.get("remaining_volume")
        current = float(entry.get("volume") or 0) if current is None else float(current)
        if not math.isfinite(current) or current <= 0 or volume > current + 1e-12:
            raise ValueError("INVALID_CLOSE_VOLUME")
        remaining = max(0.0, current - volume)
        status = "closed" if remaining <= 1e-12 else "partial"
    occurred = utc_iso()
    history = list(entry.get("partial_close_history") or [])
    history.append({"volume": volume, **numbers, "occurred_at": occurred,
                    "request_id": str(getattr(ctx, "request_id", ""))})
    result["journal"] = ctx.journal.update(ctx.user_id, entry["id"], {
        "remaining_volume": remaining,
        "status": status,
        "pnl_amount": float(result["position"]["realized_pnl"]) if result.get("position") else float(entry.get("pnl_amount") or 0) + numbers["pnl_amount"] - numbers["commission"] - numbers["swap"] - numbers["fees"],
        "closed_at": occurred if status == "closed" else None,
        "partial_close_history": history,
    })
    mirror_normalized_journal_partial(
        ctx.user_id, result["journal"], volume=volume,
        exit_price=float(ctx.payload.get("exit_price") or 0), pnl_amount=float(ctx.payload.get("pnl_amount") or 0),
    )
    return result


def _import_rows(ctx: ActionContext, rows: list[dict[str, Any]], *, source: str) -> dict[str, Any]:
    imported = 0
    errors: list[str] = []
    for row in rows[:5000]:
        try:
            created = ctx.journal.add(ctx.user_id, {**row, "source": source})
            legacy = mirror_normalized_journal_create(ctx.user_id, created)
            ctx.journal.update(ctx.user_id, created["id"], {"legacy_journal_id": legacy.get("id")})
            imported += 1
        except Exception as exc:
            errors.append(str(exc))
    return {"imported": imported, "parsed": len(rows), "errors": errors[:100]}


@action("journal_import_csv")
def journal_import_csv(ctx: ActionContext) -> dict[str, Any]:
    content = str(ctx.payload.get("content") or "")
    if len(content.encode("utf-8")) > 5_000_000:
        raise ValueError("IMPORT_TOO_LARGE")
    reader = csv.DictReader(io.StringIO(content))
    rows = [dict(row) for row in reader]
    return _import_rows(ctx, rows, source="csv_import")


@action("broker_import")
def broker_import(ctx: ActionContext) -> dict[str, Any]:
    content = str(ctx.payload.get("content") or "")
    if len(content.encode("utf-8")) > 5_000_000:
        raise ValueError("IMPORT_TOO_LARGE")
    rows = parse_broker_statement(content, filename=str(ctx.payload.get("filename") or "statement.csv"))
    return {**_import_rows(ctx, rows, source="broker_import"), "broker": str(ctx.payload.get("broker") or "MT5")}
