from __future__ import annotations

import hashlib
import json
import logging
from typing import Any

from config import SETTINGS
from core.db import read_db_sections
from core.rate_limit import allow as rate_limit_allow
from core.webapp_auth import TelegramWebAppIdentity
from modules.admin_access import is_any_admin
from modules.i18n import user_language
from modules.rules import current_rules, user_has_accepted_rules
from repositories.v2.idempotency import IdempotencyRepository
from services.access_policy import ActionPolicy, enforce_action_policy
from services.actions_v2 import get_action
from services.actions_v2.context import create_context

logger = logging.getLogger(__name__)

# Compatibility policy snapshot. Shared preferences use the same authority as Telegram.
_POLICY_SECTIONS = (
    "admin_control_center", "rules", "rules_settings", "rules_acceptances",
    "delegated_admins", "admin_shifts", "users", "settings", "admin_users",
    "admins", "management_suite", "user_profiles", "runtime_safety",
)

_ACTION_MODULE: dict[str, str] = {
    "risk_profile_update": "risk", "risk_calculate": "risk", "account_upsert": "risk", "account_archive": "risk", "broker_snapshot_sync": "risk",
    "position_close": "risk", "revision_ack": "signals", "signal_choice_update": "signals",
    "watchlist_toggle": "watchlists", "watchlist_remove": "watchlists", "watchlist_alerts": "watchlists",
    "journal_add": "journal", "journal_delete": "journal", "journal_result_update": "journal",
    "journal_partial_close": "journal", "journal_import_csv": "journal", "broker_import": "journal",
    "ticket_create": "support", "ticket_reply": "support", "ticket_status_update": "support",
    "ticket_satisfaction": "support", "notification_preferences_update": "account",
    "calendar_preferences_update": "calendar", "checkout_quote_create": "subscriptions",
    "vip_order_submit": "subscriptions", "vip_order_cancel": "subscriptions", "vip_order_resubmit": "subscriptions",
    "payment_approve": "subscriptions", "payment_reject": "subscriptions", "language_update": "account",
    "rules_accept": "account", "onboarding_update": "account",
    "contest_submit": "contests", "reward_claim": "rewards", "reward_seen": "rewards",
    "runtime_mode_update": "runtime", "miniapp_runtime_toggle": "runtime", "integration_reconcile": "runtime", "mission_control_refresh": "dashboard", "action_inbox_refresh": "dashboard",
    "control_change": "governance", "control_reset": "governance", "control_preset": "governance",
    "governance_request_approve": "governance", "governance_request_reject": "governance",
    "governance_request_apply": "governance", "governance_request_retry": "governance",
    "incident_status_update": "incidents", "campaign_status_update": "campaigns",
    "campaign_create": "campaigns", "campaign_delivery_update": "campaigns",
    "campaign_schedule": "campaigns",
    "miniapp_signal_publish": "signals", "ai_signal_draft_create": "signals",
    "signal_team_rules_update": "signals", "ai_signal_lab_strategy_create": "signals",
    "ai_signal_lab_scan_queue": "signals", "ai_signal_lab_candidate_to_review": "signals",
    "admin_ai_undo_restore": "copilot", "signal_job_retry": "signals",
    "signal_cycle_rollover": "signals", "signal_cycle_close": "signals",
    "signal_cycle_start": "signals", "signal_cycle_rename": "signals",
    "signal_job_cancel": "signals", "signal_job_update": "signals",
    "miniapp_announcement_publish": "campaigns",
    "automation_retry": "automations", "ticket_admin_reply": "support",
    "ticket_admin_status_update": "support", "shift_handoff_create": "admin_shifts",
    "shift_handoff_status_update": "admin_shifts", "experiment_create": "campaigns",
    "experiment_status_update": "campaigns", "prop_template_create": "risk",
    "copilot_query": "copilot", "risk_coach_refresh": "risk_coach",
    "paper_arena_refresh": "paper_trading", "paper_account_create": "paper_trading",
    "paper_trade_open": "paper_trading", "paper_trade_close": "paper_trading", "paper_trade_action": "paper_trading",
    "prop_challenge_configure": "prop_guardian", "prop_guardian_refresh": "prop_guardian",
    "market_intelligence_v2_refresh": "market_v2",
    "device_state_update": "miniapp_next", "business_message_classify": "business_inbox",
    "platform_dashboard_refresh": "runtime", "publisher_channel_upsert": "publisher",
    "publication_enqueue": "publisher", "publication_status_update": "publisher",
    "partner_create": "partners", "partner_dashboard_refresh": "partners",
    "public_performance_snapshot": "performance", "content_render": "content_factory",
    "business_inbox_admin_classify": "business_inbox", "webhook_register": "developer_api",
    "workspace_create": "workspaces",
    "mt5_pairing_create": "risk", "mt5_connector_revoke": "risk", "mt5_connector_rename": "risk",
    "prop_pretrade_assess": "prop_guardian", "prop_guardian_refresh_v2": "prop_guardian",
    "risk_daily_plan_refresh": "risk_coach", "risk_daily_plan_update": "risk_coach",
    "risk_daily_plan_accept": "risk_coach", "risk_checkin_create": "risk_coach", "risk_coach_refresh_v2": "risk_coach",
    "user_ai_query": "copilot", "user_ai_review": "copilot", "admin_ai_query": "copilot",
    "admin_ai_health_test": "copilot", "admin_ai_user_access_toggle": "copilot",
    "admin_ai_daily_report": "copilot", "ai_idea_create": "copilot",
    "admin_ai_proposal_approve": "copilot", "admin_ai_proposal_reject": "copilot",
    "admin_ai_execution_toggle": "copilot", "admin_ai_command_approve": "copilot", "admin_ai_command_reject": "copilot",
    "delegated_admin_approve": "runtime", "delegated_admin_reject": "runtime",
    "ai_signal_template_apply_asset": "signals", "ai_signal_template_layout_update": "signals",
    "ai_signal_template_reset": "signals", "ai_signal_refresh_channel": "signals",
    "ai_lesson_create": "edu", "ai_lesson_update": "edu", "ai_lesson_status": "edu", "ai_lesson_delete": "edu",
    "ai_mission_create": "missions", "ai_mission_update": "missions", "ai_mission_toggle": "missions", "ai_mission_delete": "missions",
    "ai_contest_start": "contests", "ai_contest_end": "contests",
    "ai_channel_message_operation": "publisher",
    "admin_vip_plan_create": "subscriptions", "admin_vip_plan_update": "subscriptions",
    "admin_vip_plan_toggle": "subscriptions", "admin_vip_plan_delete": "subscriptions",
}

_COOLDOWNS: dict[str, float] = {
    "ticket_create": 3.0, "vip_order_submit": 4.0, "checkout_quote_create": 1.5,
    "contest_submit": 0.5,
    "journal_import_csv": 5.0, "broker_import": 8.0, "shift_handoff_create": 2.0,
    "experiment_create": 3.0,
    "copilot_query": 1.0, "risk_coach_refresh": 1.0, "paper_account_create": 2.0,
    "paper_trade_open": 1.0, "paper_trade_close": 1.0, "paper_trade_action": 0.5, "publication_enqueue": 2.0,
    "partner_create": 2.0, "webhook_register": 3.0, "workspace_create": 3.0,
    "mt5_pairing_create": 2.0, "mt5_connector_revoke": 1.0, "mt5_connector_rename": 1.0,
    "risk_daily_plan_update": 1.0, "risk_daily_plan_accept": 1.0, "risk_checkin_create": 1.0,
    "user_ai_query": 2.0, "user_ai_review": 2.0, "admin_ai_query": 2.0,
    "admin_ai_health_test": 5.0, "admin_ai_user_access_toggle": 1.0, "admin_ai_daily_report": 5.0, "ai_idea_create": 0.5,
    "admin_ai_proposal_approve": 1.0, "admin_ai_proposal_reject": 1.0,
    "admin_ai_execution_toggle": 1.0, "admin_ai_command_approve": 1.0, "admin_ai_command_reject": 1.0,
    "delegated_admin_approve": 1.0, "delegated_admin_reject": 1.0,
    "ai_signal_template_apply_asset": 1.0, "ai_signal_template_layout_update": 0.5,
    "ai_signal_template_reset": 1.0, "ai_signal_refresh_channel": 1.0, "ai_signal_draft_create": 1.0,
    "signal_team_rules_update": 1.0, "ai_signal_lab_strategy_create": 1.0,
    "ai_signal_lab_scan_queue": 2.0, "ai_signal_lab_candidate_to_review": 1.0,
    "admin_ai_undo_restore": 2.0, "ai_channel_message_operation": 1.0,
    "ai_lesson_create": 1.0, "ai_lesson_update": 0.5, "ai_lesson_status": 0.5, "ai_lesson_delete": 1.0,
    "ai_mission_create": 1.0, "ai_mission_update": 0.5, "ai_mission_toggle": 0.5, "ai_mission_delete": 1.0,
    "ai_contest_start": 1.0, "ai_contest_end": 1.0,
    "admin_vip_plan_create": 1.0, "admin_vip_plan_update": 0.7,
    "admin_vip_plan_toggle": 0.7, "admin_vip_plan_delete": 1.0,
}


def _valid_request_id(value: str) -> bool:
    return bool(value) and len(value) <= 100 and all(ch.isalnum() or ch in "-_:." for ch in value)


def _fingerprint(action: str, payload: dict[str, Any]) -> str:
    material = json.dumps({"action": action, "payload": payload}, sort_keys=True, ensure_ascii=False, default=str)
    return hashlib.sha256(material.encode("utf-8")).hexdigest()


def _policy_for(action: str, *, admin_only: bool, permission: str) -> ActionPolicy:
    return ActionPolicy(
        _ACTION_MODULE.get(action, "account"),
        permission=permission or None,
        admin_only=admin_only,
        rules_required=action not in {"language_update", "rules_accept", "mission_control_refresh", "action_inbox_refresh"},
    )


def _rules_snapshot(db: dict[str, Any], user_id: int | str) -> tuple[str, dict[str, Any]]:
    language = user_language(db, str(user_id)) or "fa"
    return language, current_rules(db, language)


def _normalized_rules_accepted(db: dict[str, Any], user_id: int | str) -> bool:
    language, rules = _rules_snapshot(db, user_id)
    if not bool(rules.get("enabled", True)) or int(rules.get("version", 0) or 0) <= 0 or not rules.get("text"):
        return True
    return user_has_accepted_rules(db, user_id, language)


def _event_type(action: str, data: Any) -> str:
    if action == "signal_choice_update":
        choice = ""
        if isinstance(data, dict) and isinstance(data.get("choice"), dict):
            choice = str(data["choice"].get("choice") or "")
        opened = isinstance(data, dict) and isinstance(data.get("position"), dict)
        return "position.opened" if choice == "taken" and opened else "signal.choice_updated"
    if action == "position_close":
        return "position.closed" if isinstance(data, dict) and data.get("status") == "closed" else "position.risk_changed"
    if action == "contest_submit":
        return "contests.joined" if isinstance(data, dict) and data.get("accepted") else "contests.entry_rejected"
    mapping = {
        "account_upsert": "account.updated", "account_archive": "account.archived",
        "broker_snapshot_sync": "account.updated", "prop_template_create": "risk.template_updated",
        "checkout_quote_create": "quote.created", "vip_order_submit": "order.status_changed",
        "vip_order_cancel": "order.status_changed", "vip_order_resubmit": "order.status_changed",
        "payment_approve": "order.status_changed", "payment_reject": "order.status_changed",
        "ticket_create": "ticket.message_added", "ticket_reply": "ticket.message_added",
        "ticket_admin_reply": "ticket.message_added", "ticket_status_update": "ticket.status_changed",
        "ticket_admin_status_update": "ticket.status_changed",
        "ticket_admin_assign": "ticket.status_changed", "ticket_admin_priority_update": "ticket.status_changed",
        "ticket_admin_internal_note": "ticket.internal_note_added",
        "signal_job_retry": "signal.queued", "signal_job_cancel": "signal.queue_cancelled",
        "signal_job_update": "signal.queue_updated", "signal_edit": "signal.revised",
        "signal_result_set": "signal.closed", "signal_result_reset": "signal.revised",
        "signal_delete": "signal.deleted", "admin_user_ban": "admin.user_updated",
        "admin_user_unban": "admin.user_updated", "delegated_admin_upsert": "admin.access_updated",
        "delegated_admin_permissions_set": "admin.access_updated", "delegated_admin_remove": "admin.access_updated",
        "signal_cycle_rollover": "signal.cycle_changed",
        "signal_cycle_close": "signal.cycle_changed", "signal_cycle_start": "signal.cycle_changed",
        "signal_cycle_rename": "signal.cycle_changed", "journal_add": "journal.updated",
        "journal_result_update": "journal.updated", "journal_partial_close": "journal.updated",
        "journal_delete": "journal.updated", "miniapp_signal_publish": "signal.queued",
        "control_change": "admin.control_updated", "control_reset": "admin.control_updated",
        "control_preset": "admin.governance_updated", "governance_request_approve": "admin.governance_updated",
        "governance_request_reject": "admin.governance_updated", "governance_request_apply": "admin.control_updated",
        "governance_request_retry": "admin.governance_updated",
        "miniapp_announcement_publish": "announcement.queued", "rules_accept": "preferences.updated",
        "language_update": "preferences.updated", "notification_preferences_update": "preferences.updated",
        "mt5_pairing_create": "mt5.pairing_created", "mt5_connector_revoke": "mt5.connector_revoked",
        "mt5_connector_rename": "mt5.connector_updated", "risk_daily_plan_update": "risk.plan_updated",
        "risk_daily_plan_accept": "risk.plan_accepted", "risk_checkin_create": "risk.checkin_created",
        "user_ai_query": "ai.user_response", "user_ai_review": "ai.user_response",
        "admin_ai_query": "ai.admin_response", "admin_ai_health_test": "ai.health_checked",
        "admin_ai_user_access_toggle": "ai.user_access_changed", "admin_ai_daily_report": "ai.daily_report_created", "ai_idea_create": "ai.idea_created",
        "admin_ai_proposal_approve": "ai.proposal_approved", "admin_ai_proposal_reject": "ai.proposal_rejected",
        "admin_ai_execution_toggle": "ai.execution_changed", "admin_ai_command_approve": "ai.command_approved",
        "admin_ai_command_reject": "ai.command_rejected", "delegated_admin_approve": "admin.access_updated",
        "delegated_admin_reject": "admin.access_updated", "ai_signal_template_apply_asset": "signal.template_updated",
        "ai_signal_template_layout_update": "signal.template_updated", "ai_signal_template_reset": "signal.template_updated",
        "ai_lesson_create": "education.updated", "ai_lesson_update": "education.updated", "ai_lesson_status": "education.updated", "ai_lesson_delete": "education.updated",
        "reward_claim": "rewards.updated",
        "reward_seen": "rewards.updated",
        "ai_mission_create": "missions.updated", "ai_mission_update": "missions.updated", "ai_mission_toggle": "missions.updated", "ai_mission_delete": "missions.updated",
        "ai_contest_start": "contests.updated", "ai_contest_end": "contests.updated",
        "ai_signal_refresh_channel": "signal.revised", "ai_signal_draft_create": "signal.ai_draft_created",
    "signal_team_rules_update": "signal.rules_updated",
        "ai_signal_lab_strategy_create": "signal.lab_strategy_created",
        "ai_signal_lab_scan_queue": "signal.lab_scan_queued",
        "ai_signal_lab_candidate_to_review": "signal.ai_draft_created",
        "admin_ai_undo_restore": "ai.undo_restored",
        "ai_channel_message_operation": "publisher.queued",
        "admin_vip_plan_create": "vip.plan_changed", "admin_vip_plan_update": "vip.plan_changed",
        "admin_vip_plan_toggle": "vip.plan_changed", "admin_vip_plan_delete": "vip.plan_changed",
    }
    return mapping.get(action, f"action.{action}.completed")


def handle_miniapp_action_for_identity_v2(
    identity: TelegramWebAppIdentity,
    body: dict[str, Any],
    *,
    transport_request_id: str = "",
    transport_context: dict[str, Any] | None = None,
) -> dict[str, Any]:
    action_name = str(body.get("action") or "").strip()
    payload = dict(body.get("payload")) if isinstance(body.get("payload"), dict) else {}
    spec = get_action(action_name)
    transport_request_id = str(transport_request_id or body.get("_transport_request_id") or "").strip()
    if transport_context is None and isinstance(body.get("_transport_context"), dict):
        transport_context = dict(body["_transport_context"])

    # The server request id is observability metadata, not a client
    # idempotency key. Mutations must carry an explicit stable key so a retry
    # cannot silently execute twice under a newly generated HTTP request id.
    supplied_request_id = str(body.get("request_id") or "").strip()
    if spec.mutation and spec.idempotency_required and not supplied_request_id:
        raise ValueError("IDEMPOTENCY_KEY_REQUIRED")
    if supplied_request_id and not _valid_request_id(supplied_request_id):
        raise ValueError("INVALID_REQUEST_ID")

    policy_snapshot = read_db_sections(_POLICY_SECTIONS)
    safety = policy_snapshot.get("runtime_safety") if isinstance(policy_snapshot.get("runtime_safety"), dict) else {}
    if spec.mutation and action_name != "runtime_mode_update" and (
        bool(safety.get("disaster_mode")) or bool(safety.get("read_only"))
    ):
        raise PermissionError("SYSTEM_READ_ONLY")
    policy = _policy_for(action_name, admin_only=spec.admin_only, permission=spec.permission)
    # Module/admin/shift/permission checks remain shared with Telegram. Rules
    # acceptance is checked independently against normalized Mini App storage.
    enforce_action_policy(
        policy_snapshot,
        identity.user_id,
        ActionPolicy(
            policy.module,
            permission=policy.permission,
            admin_only=policy.admin_only,
            owner_only=policy.owner_only,
            rules_required=False,
        ),
        owner_id=SETTINGS.admin_ids[0] if SETTINGS.admin_ids else None,
    )
    if policy.rules_required and not is_any_admin(policy_snapshot, identity.user_id):
        if not _normalized_rules_accepted(policy_snapshot, identity.user_id):
            raise PermissionError("RULES_ACCEPTANCE_REQUIRED")
    if action_name == "rules_accept":
        language, rules = _rules_snapshot(policy_snapshot, identity.user_id)
        payload["language"] = language
        payload["version"] = int(rules.get("version", 0) or 0)
        payload["content_hash"] = str(rules.get("content_hash") or "")

    if not rate_limit_allow(identity.user_id, f"miniapp:v8:{action_name}", _COOLDOWNS.get(action_name, 0.7)):
        raise ValueError("RATE_LIMITED")

    idempotency = IdempotencyRepository()
    reservation_token: str | None = None
    if supplied_request_id:
        reservation = idempotency.reserve(
            identity.user_id,
            supplied_request_id,
            action=action_name,
            fingerprint=_fingerprint(action_name, payload),
            ttl_seconds=86_400,
        )
        if reservation.state == "conflict":
            raise ValueError("IDEMPOTENCY_CONFLICT")
        if reservation.state == "in_progress":
            raise ValueError("REQUEST_IN_PROGRESS")
        if reservation.state == "replay":
            return dict(reservation.response or {})
        reservation_token = reservation.token

    context = create_context(
        identity,
        request_id=supplied_request_id,
        action=action_name,
        payload=payload,
        transport=transport_context,
    )
    mutation_succeeded = False
    try:
        def execute_and_complete():
            data = spec.handler(context)
            result = {"action": action_name, "data": data, "request_id": supplied_request_id}
            if supplied_request_id:
                idempotency.complete(identity.user_id, supplied_request_id,
                    token=reservation_token or "", response=result)
            return data, result
        if action_name in {"signal_choice_update", "position_close", "journal_result_update", "journal_partial_close"}:
            # Position, journal, user choice and the replay receipt commit together.
            with context.engine.atomic():
                data, result = execute_and_complete()
        else:
            data = spec.handler(context)
            mutation_succeeded = True
            result = {"action": action_name, "data": data, "request_id": supplied_request_id}
            if supplied_request_id:
                idempotency.complete(identity.user_id, supplied_request_id,
                    token=reservation_token or "", response=result)
        mutation_succeeded = True
        try:
            event = context.events.append(
                user_id=identity.user_id,
                event_type=_event_type(action_name, data),
                payload={"request_id": supplied_request_id, "entity": data if isinstance(data, dict) else {}},
            )
            result["event_id"] = event.get("id")
            if supplied_request_id:
                idempotency.replace_completed_response(
                    identity.user_id, supplied_request_id, response=result,
                )
        except Exception as exc:
            logger.exception("Action event persistence deferred action=%s request_id=%s", action_name, supplied_request_id)
            result["event_pending"] = True
            result["event_error"] = exc.__class__.__name__
            if supplied_request_id:
                try:
                    idempotency.replace_completed_response(
                        identity.user_id, supplied_request_id, response=result,
                    )
                except Exception:
                    logger.exception("Could not persist event-pending action response action=%s", action_name)
        return result
    except Exception:
        if not mutation_succeeded and supplied_request_id and reservation_token:
            idempotency.abort(identity.user_id, supplied_request_id, token=reservation_token)
        raise


# Compatibility import used by the FastAPI route and older tests.
handle_miniapp_action_for_identity = handle_miniapp_action_for_identity_v2
