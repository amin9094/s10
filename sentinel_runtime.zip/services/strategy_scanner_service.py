"""Bounded recurring research discovery and private admin notifications."""

from __future__ import annotations

import asyncio
import time
from weakref import WeakKeyDictionary

from core.async_runtime import run_blocking
from repositories.v2.strategy_outbox import StrategyOutboxRepository
from services.canonical_market_service import universe
from services.strategy_analysis_service import research_analysis
from services.strategy_review_queue_service import _save_analysis

_SCAN_DUE = WeakKeyDictionary()


def due_markets(symbols, profiles, cursor, now):
    """Closed-bar cadence; gold/FX first, indices every 30 min M5 / 4 h H1."""
    from modules.automated_market_scope import global_symbol_allowed
    symbols=[s for s in symbols if global_symbol_allowed(s)]
    if not symbols:return []
    due = _SCAN_DUE.setdefault(asyncio.get_running_loop(),{})
    profile_key = tuple((name,p.profile_id) for name,p in profiles)
    # Same Nasdaq cash chart alias must not consume two automatic requests.
    symbols = [symbol for symbol in symbols if symbol!='NAS100' or 'US100' not in symbols]
    indices = {'US30','US100','NAS100'}
    def priority(symbol):
        return 0 if symbol=='XAUUSD' else 3 if symbol in indices else 2 if symbol.endswith('USDT') else 1
    rotated = symbols[cursor%len(symbols):]+symbols[:cursor%len(symbols)]
    ordered = sorted(rotated,key=priority)
    selected = []
    for tf,capacity in [('5m',3),('1h',1)]:
        for symbol in ordered:
            key = (symbol,tf,profile_key)
            if due.get(key,0)>now:
                continue
            period = (1800 if tf=='5m' else 14400) if symbol in indices else (300 if tf=='5m' else 3600)
            due[key] = (int(now)//period+1)*period+15
            selected.append((symbol,tf))
            capacity -= 1
            if capacity==0:
                break
    return selected


def review_message(review):
    title = review.get("title_fa") or "نیازمند بررسی ادمین"
    lines = [title, f"{review.get('symbol', '')} · {review.get('timeframe', '')} · {review.get('engine', '')}"]
    if review.get("original_zone"):
        lines.append("محدودهٔ اصلی: " + " — ".join(review["original_zone"]))
    if review.get("poc"):
        poc = review["poc"]
        lines.append(f"POC: {poc.get('price', '—')} · {poc.get('proxy_label_fa', poc.get('volume_kind', ''))}")
    if review.get("fib_061"):
        lines.append(f"فیبوناچی ۰٫۶۱: {review['fib_061']}")
    if review.get("explanation_fa"):
        lines.append(review["explanation_fa"])
    if review.get('required_action_fa'):
        lines.append('اقدام لازم: ' + review['required_action_fa'])
    if review.get('observation'):
        subject=review['observation']
        lines.append(f"منبع: {subject['provider']} · {subject['venue']} · {subject['product']}")
        lines.append('جهت مشاهده: ' + subject['direction'])
        lines.append('این محدوده سیگنال ورود نیست؛ Bid/Ask، تازگی کامل و مدیریت ریسک هنوز تأیید نشده‌اند.')
        factors=review.get('fibonacci_confirmation',{}).get('confirmations',[])
        lines.append('تأییدهای هندسی فیبوناچی: ' + str(len(factors)))
    if review.get("draft_plan"):
        p = review["draft_plan"]
        lines.append(f"پیشنهاد پژوهشی: Entry {p['entry']} · SL {p['stop']} · TP1 {p['tp1']} · TP2 {p['tp2']}")
    lines.append("این مورد برای بررسی است؛ انتشار عمومی یا اجرای معامله انجام نشده است.")
    return "\n".join(lines)[:3500]


async def deliver_reviews(bot, admin_ids):
    """Drain legacy notices into the desk; never push analysis to Telegram."""
    repository = StrategyOutboxRepository()
    allowed = {str(int(value)) for value in admin_ids}
    rows = await run_blocking(repository.claim, timeout=5)
    for row in rows:
        if row['admin_id'] not in allowed:
            await run_blocking(repository.finish,row['id'],'REVOKED',timeout=5)
            continue
        if row['payload']['review'].get('review_kind')=='PREENTRY_PROPOSAL':
            from services.live_signal_service import stage_results
            from services.strategy_quote_owner import current_owner
            await stage_results({'new_review_ids':[row['review_id']]},current_owner())
        await run_blocking(repository.finish,row['id'],'SENT',detail='STORED_IN_PRIVATE_DESK_NO_PUSH',timeout=5)
    return len(rows)


async def scan_cycle(bot, admin_ids, *, cursor=0, settings=None):
    settings = settings or {}
    if not settings.get("enabled", True) or not admin_ids:
        return {"cursor": cursor, "state": "PAUSED", "analyzed": 0}
    directory = await universe()
    symbols = list(dict.fromkeys([*directory["core_symbols"], *[row["symbol"] for row in directory["crypto_top20"]]]))
    if not settings.get('indices_enabled',False):
        symbols=[s for s in symbols if s not in {'US30','US100','NAS100'}]
    if not symbols:
        return {"cursor": cursor, "state": "MARKET_UNIVERSE_UNAVAILABLE", "analyzed": 0}
    from services.live_signal_service import scanner_parameters
    profiles = scanner_parameters(settings)
    selected = due_markets(symbols,profiles,cursor,time.time())
    semaphore = asyncio.Semaphore(2)

    async def analyze(symbol, timeframe):
        async with semaphore:
            try:
                from services.market_data_issues import automatic_source_block
                result = automatic_source_block(symbol,timeframe)
                if result is None:
                    async with asyncio.timeout(20):
                        from services.keyless_market_data_service import supported_symbols
                        review={'admin_review':True} if symbol in supported_symbols() and settings.get('admin_review_proposals',True) else {}
                        result = await research_analysis(symbol, timeframe, engine_parameters=profiles,**review)
            except Exception as exc:
                from services.market_data_issues import data_block, safe_market_error
                result = data_block(safe_market_error(exc))
            from repositories.v2.strategy_paths import strategy_enabled
            result['results']=[r for r in result.get('results',[]) if r.get('engine') not in {'indicators','sweep_fvg','order_block','fibonacci_pullback','custom'} or await run_blocking(strategy_enabled,r['engine'],timeout=5)]
            blocked = not result.get('results') and result.get('state') in {'NEEDS_REVIEW','UNAVAILABLE'}
            if blocked:
                result["results"] = [{"engine": "market_data", "symbol": symbol, "timeframe": timeframe,
                                       "state": "NEEDS_REVIEW", "reason": result.get("reason", "MARKET_DATA_UNAVAILABLE"),
                                       "title_fa": "نیازمند بررسی: اتصال دادهٔ این بازار کامل نیست",
                                       "available_ms": int(time.time() * 1000),
                                       **{key:result[key] for key in ('explanation_fa','required_action_fa','provider','product','data_gap') if key in result}}]
            from repositories.v2.desk_insights import record_scan
            from core.storage.engine import normalized_engine
            await run_blocking(record_scan,normalized_engine(),symbol,timeframe,result,timeout=5)
            from services.strategy_quote_owner import current_owner
            owner=current_owner()
            saved = await owner.prepare_result(result) if owner else await run_blocking(_save_analysis,result,timeout=10)
            from services.live_signal_service import stage_results
            await stage_results(saved,owner)
            return {'symbol':symbol,'timeframe':timeframe,'blocked':blocked,
                    'automatic_request_skipped':result.get('automatic_request_skipped',False),
                    'reason':result.get('reason','') if blocked else ''}

    outcomes = await asyncio.gather(*(analyze(*case) for case in selected))
    await deliver_reviews(bot, admin_ids)
    gaps=[row for row in outcomes if row['blocked']]
    # A transient source failure should be retried within the same candle,
    # while provider cooldown/budget gates still prevent a request storm.
    due=_SCAN_DUE.setdefault(asyncio.get_running_loop(),{})
    profile_key=tuple((name,p.profile_id) for name,p in profiles)
    for row in gaps:
        key=(row['symbol'],row['timeframe'],profile_key)
        due[key]=min(due.get(key,float('inf')),time.time()+30)
    skipped=sum(row['automatic_request_skipped'] for row in outcomes)
    return {"cursor": cursor + max(1,len(selected)), "state": "RESEARCH_SCANNING_WITH_DATA_GAPS" if gaps else "RESEARCH_SCANNING", "analyzed": len(selected)-skipped,
            'attempted':len(selected),'completed_analyses':len(selected)-len(gaps),'blocked_markets':gaps,
            'skipped_missing_live_source':skipped,
            "production_qualified": False, "public_auto_publish": False}
