"""Private, source-exact signal chart previews; never fetch another market."""
from base64 import b64encode

from modules.signal_chart import freeze, render_png
from repositories.v2.common import content_hash
from repositories.v2.live_signal_inbox import LiveSignalInbox
from repositories.v2.market_evidence import MarketEvidenceRepository


def capture(plan, engine=None):
    if type(plan.get('evidence_cutoff_ms')) is not int or not plan.get('source_ids'):
        return {'state': 'EXACT_CANDLES_UNAVAILABLE'}
    repository = MarketEvidenceRepository(engine)
    bars = repository.candles(plan['symbol'], plan['provider'], plan['timeframe'],
                              before_ms=plan['evidence_cutoff_ms'], limit=500)
    try:
        return {'state': 'READY', 'snapshot': freeze(plan, bars)}
    except (ValueError, KeyError):
        return {'state': 'EXACT_CANDLES_UNAVAILABLE'}


def preview(user_id, identifier, plan_hash):
    from services.live_signal_service import permitted
    from modules.automated_market_scope import require_global_symbol
    permitted(user_id)
    inbox = LiveSignalInbox()
    row = inbox.get(identifier)
    if not row or row['state'] == 'STAGING':
        raise ValueError('LIVE_SIGNAL_NOT_FOUND')
    payload = row['payload']
    plan = payload['plan']
    require_global_symbol(plan['symbol'])
    if payload['plan_hash'] != plan_hash or content_hash(plan) != plan_hash:
        raise ValueError('SIGNAL_PLAN_CHANGED')
    captured = payload.get('chart_snapshot') or capture(plan, inbox.engine)
    if captured.get('state') != 'READY':
        return {'state': 'EXACT_CANDLES_UNAVAILABLE', 'plan_hash': plan_hash}
    snapshot = captured['snapshot']
    png = render_png(plan, snapshot)
    return {'state': 'READY', 'plan_hash': plan_hash, 'snapshot_hash': snapshot['snapshot_hash'],
            'cutoff_ms': snapshot['cutoff_ms'], 'bar_count': len(snapshot['bars']),
            'image': 'data:image/png;base64,'+b64encode(png).decode('ascii'), 'is_live': False}


def publication_chart(identifier, plan_hash, engine=None):
    """Render only the exact frozen proposal's candles for channel publication."""
    inbox=LiveSignalInbox(engine)
    row=inbox.get(identifier)
    if not row or row['payload']['plan_hash']!=plan_hash:raise ValueError('SIGNAL_PLAN_CHANGED')
    plan=row['payload']['plan']
    if content_hash(plan)!=plan_hash:raise ValueError('SIGNAL_PLAN_CHANGED')
    captured=row['payload'].get('chart_snapshot') or capture(plan,inbox.engine)
    if captured.get('state')!='READY':raise ValueError('LIVE_SIGNAL_CHART_REQUIRED')
    return render_png(plan,captured['snapshot'],public=True)
