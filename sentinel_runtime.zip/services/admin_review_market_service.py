"""Source-bound indicative review input and continuous received-price monitoring.

This tape never enters native QuoteJournal, never fabricates a broker grid,
and never certifies all ticks or broker execution.
"""
from __future__ import annotations
import asyncio
import json
import time
import weakref
from collections import deque
from decimal import Decimal as D

from services.keyless_market_data_service import BIQUOTE_ORIGIN, parse_biquote_history, supported_symbols

_MONITORS=weakref.WeakKeyDictionary()


class ReviewPriceMonitor:
    def __init__(self):
        self.latest={};self.rows={};self.epoch=0;self.task=None;self.failure='NOT_CONNECTED'
        self.proposals={}

    def start(self):
        if self.task is None or self.task.done():self.task=asyncio.create_task(self._run(),name='admin-review-indicative-prices')

    def watch(self,proposal):
        key=proposal['draft_hash']
        if key not in self.proposals:
            if len(self.proposals)>=2000:self.proposals.pop(next(iter(self.proposals)))
            self.proposals[key]={'plan':proposal['draft_plan'],'from_ms':proposal['draft_plan']['evidence_cutoff_ms'],'touched':False,'epoch':self.epoch}
            for tick in list(self.rows.get(proposal['draft_plan']['symbol'],())):
                self.accept_watch(self.proposals[key],tick)

    @staticmethod
    def accept_watch(item,tick):
        p=item['plan']
        if tick['event_ms']<item['from_ms']:return
        if D(tick['bid'])<=D(p['zone_high']) and D(tick['ask'])>=D(p['zone_low']):item['touched']=True
        sign=1 if p['direction']=='BUY' else -1
        if sign*(D(tick['bid'] if sign==1 else tick['ask'])-D(p['stop']))<=0:item['touched']=True

    def accept(self,symbol,tick):
        self.latest[symbol]=tick
        self.rows.setdefault(symbol,deque(maxlen=10000)).append(tick)
        for item in self.proposals.values():
            p=item['plan']
            if p['symbol']==symbol and tick['event_ms']>=item['from_ms']:
                self.accept_watch(item,tick)

    def check(self,proposal,now_ms):
        p=proposal['draft_plan'];tick=self.latest.get(p['symbol'])
        if self.failure or not tick or not 0<=now_ms-tick['event_ms']<=5000:
            raise ValueError('REVIEW_PRICE_STREAM_NOT_FRESH')
        item=self.proposals.get(proposal['draft_hash'])
        if not item or item['epoch']!=self.epoch:raise ValueError('REVIEW_STREAM_CONTINUITY_LOST')
        if item['touched']:raise ValueError('REVIEW_ZONE_ALREADY_TOUCHED')
        above=(p['direction']=='BUY')!=(p['submodel']=='range_breakout')
        if not (D(tick['bid'])>D(p['zone_high']) if above else D(tick['ask'])<D(p['zone_low'])):
            raise ValueError('REVIEW_ZONE_NO_LONGER_AHEAD')
        return tick

    async def close(self):
        if self.task:
            self.task.cancel();await asyncio.gather(self.task,return_exceptions=True)
        self.failure='CLOSED'

    async def _run(self):
        from services.biquote_stream_check import StreamCheck,HUB
        from services.canonical_market_service import _request
        from websockets.asyncio.client import connect
        backoff=1
        while True:
            self.failure='CONNECTING';self.epoch+=1;self.latest.clear();self.rows.clear()
            try:
                symbols=sorted(supported_symbols())
                sem=asyncio.Semaphore(3)
                async def metadata(s):
                    async with sem:return StreamCheck(s,await _request(f'{BIQUOTE_ORIGIN}/api/symbols/{s}'))
                results=await asyncio.gather(*(metadata(s) for s in symbols),return_exceptions=True)
                checks={s:r for s,r in zip(symbols,results) if not isinstance(r,BaseException)}
                if not checks:raise ValueError('REVIEW_METADATA_UNAVAILABLE')
                symbols=sorted(checks)
                async with connect(HUB,open_timeout=8,close_timeout=1,max_size=256000,max_queue=32,ping_interval=10,ping_timeout=5) as socket:
                    await socket.send('{"protocol":"json","version":1}\x1e')
                    if await asyncio.wait_for(socket.recv(),6)!='{}\x1e':raise ValueError('REVIEW_STREAM_HANDSHAKE')
                    await socket.send(json.dumps({'type':1,'invocationId':'1','target':'Subscribe','arguments':[symbols]})+'\x1e')
                    buffer=''
                    while True:
                        raw=await asyncio.wait_for(socket.recv(),20)
                        if not isinstance(raw,str) or len(raw)+len(buffer)>256000:raise ValueError('REVIEW_FRAME_INVALID')
                        parts=(buffer+raw).split('\x1e');buffer=parts.pop()
                        for part in parts:
                            event=json.loads(part,parse_float=D)
                            kind=event.get('type');target=event.get('target')
                            if kind==7:raise ValueError('REVIEW_STREAM_CLOSED')
                            if kind==3:
                                for check in checks.values():check.receive(part+'\x1e',int(time.time()*1000))
                            elif kind==1 and target=='ReceiveSubscriptionState':
                                for state in event['arguments'][0]:
                                    check=checks.get(state.get('symbol'))
                                    if check is None:raise ValueError('REVIEW_SYMBOL_MISMATCH')
                                    check.receive(json.dumps({**event,'arguments':[[state]]})+'\x1e',int(time.time()*1000))
                            elif kind==1 and target=='ReceiveTick':
                                tick=event['arguments'][0];check=checks.get(tick.get('symbol'))
                                if check is None:raise ValueError('REVIEW_SYMBOL_MISMATCH')
                                prior=check.updates;now=int(time.time()*1000)
                                check.receive(part+'\x1e',now)
                                # Once a genuinely advancing update established
                                # the live session, keep changes sharing the same
                                # source timestamp too. They may include a touch.
                                if check.updates>0 and check.ack and check.seeded:
                                    self.failure='';backoff=1
                                    self.accept(check.symbol,{'bid':str(tick['bid']),'ask':str(tick['ask']),
                                        'event_ms':check.last,'received_ms':now,'source':check.source,'exchange':check.exchange,
                                        'provider':'biquote','native_sequence_verified':False})
            except asyncio.CancelledError:raise
            except Exception:
                self.failure='DISCONNECTED_OR_INVALID'
                await asyncio.sleep(backoff);backoff=min(30,backoff*2)


def review_monitor():
    loop=asyncio.get_running_loop()
    if loop not in _MONITORS:_MONITORS[loop]=ReviewPriceMonitor()
    return _MONITORS[loop]


async def close_review_monitor():
    monitor=_MONITORS.get(asyncio.get_running_loop())
    if monitor is not None:await monitor.close()


async def reported_history(symbol,timeframe,limit=300):
    from services.canonical_market_service import _request
    raw=await _request(f'{BIQUOTE_ORIGIN}/api/{symbol}/ohlc',{'interval':timeframe,'limit':limit})
    return parse_biquote_history(raw,symbol=symbol,timeframe=timeframe,observed_ms=int(time.time()*1000),
                                limit=limit,review_volume=True)


async def analyze_admin_review(symbol,timeframe,*,parameters=None,engine_parameters=()):
    from modules.admin_review_proposals import AdminReviewContext,evaluate_review_proposals
    from modules.canonical_market import Quote
    from modules.strategies.common import Parameters
    from core.async_runtime import run_blocking
    monitor=review_monitor();monitor.start()
    bars=await reported_history(symbol,timeframe)
    deadline=asyncio.get_running_loop().time()+3
    while (monitor.failure or symbol not in monitor.latest) and asyncio.get_running_loop().time()<deadline:
        await asyncio.sleep(.05)
    now=int(time.time()*1000);tick=monitor.latest.get(symbol)
    if monitor.failure or not tick or not 0<=now-tick['event_ms']<=5000:
        raise ValueError('REVIEW_PRICE_STREAM_NOT_FRESH')
    # Once the stream is warm, take a new candle receipt rather than advancing
    # the old candle's timestamp to fit a newer quote.
    bars=await reported_history(symbol,timeframe)
    now=bars[-1].available_ms;tick=monitor.latest.get(symbol)
    if not tick or not 0<=now-tick['event_ms']<=5000:raise ValueError('REVIEW_PRICE_STREAM_NOT_FRESH')
    quantum=D(10)**min(v.normalize().as_tuple().exponent for b in bars for v in (b.open,b.high,b.low,b.close))
    quantum=min(quantum,D(10)**D(tick['bid']).normalize().as_tuple().exponent,D(10)**D(tick['ask']).normalize().as_tuple().exponent)
    quote=Quote(symbol,'biquote',bars[-1].venue,'indicative',tick['event_ms'],tick['received_ms'],
                D(tick['bid']),D(tick['ask']),quantum,'review-indicative:'+str(tick['event_ms']),('REVIEW_ONLY',))
    context=AdminReviewContext(tuple(bars),now,quantum,quote.ask-quote.bid,parameters or Parameters(),
                               profile_candles=tuple(bars),current_quote=quote,
                               pip_size=D('.01') if symbol.endswith('JPY') else D('.0001') if symbol!='XAUUSD' else None,
                               engine_parameters=tuple(engine_parameters))
    from dataclasses import replace
    from services.goldbach_settings_service import settings_for
    from services.custom_strategy_service import current_settings
    context=replace(context,goldbach_settings=await run_blocking(settings_for,symbol,timeout=5),
                    custom_settings=await run_blocking(current_settings,timeout=5))
    result=await run_blocking(evaluate_review_proposals,context,timeout=15)
    from repositories.v2.market_evidence import MarketEvidenceRepository
    await run_blocking(MarketEvidenceRepository().save_candles,bars,timeout=15)
    try:
        from services.custom_shadow_service import compare as compare_shadow
        result['shadow_comparison']=await run_blocking(compare_shadow,context,result,timeout=10)
    except Exception:
        result['shadow_comparison']={'state':'COMPARISON_UNAVAILABLE'}
    for row in result['results']:
        if row.get('draft_plan'):monitor.watch(row)
    try:
        from repositories.v2.research_cases import ResearchCases
        result['research_capture']=await run_blocking(ResearchCases(MarketEvidenceRepository().engine).capture,
            context,result,quote_epoch=str(monitor.epoch),timeout=10)
    except Exception:result['research_capture']={'state':'INPUT_CAPTURE_UNAVAILABLE'}
    return result


async def check_review_before_entry(proposal):
    from modules.signal_plan_policy import validate_locked_signal_plan
    validate_locked_signal_plan(proposal['draft_plan'])
    from modules.canonical_market import TIMEFRAMES
    monitor=review_monitor();monitor.start();p=proposal['draft_plan']
    now=int(time.time()*1000);monitor.check(proposal,now)
    needed=min(500,max(300,(now-p['fresh_after_ms'])//TIMEFRAMES[p['timeframe']]+2))
    bars=await reported_history(p['symbol'],p['timeframe'],needed)
    window=[b for b in bars if b.end_ms>p['fresh_after_ms']]
    if not window or window[0].start_ms>p['fresh_after_ms'] or window[-1].end_ms<now:
        raise ValueError('REVIEW_CANDLE_COVERAGE_MISSING')
    if any(a.end_ms!=b.start_ms for a,b in zip(window,window[1:])):raise ValueError('REVIEW_CANDLE_GAP')
    if any(b.low<=D(p['zone_high']) and b.high>=D(p['zone_low']) for b in window):
        monitor.proposals[proposal['draft_hash']]['touched']=True
        raise ValueError('REVIEW_ZONE_ALREADY_TOUCHED')
    sign=1 if p['direction']=='BUY' else -1
    if any((b.low<=D(p['stop']) if sign==1 else b.high>=D(p['stop'])) for b in window):
        raise ValueError('REVIEW_STRUCTURAL_STOP_BREACHED')
    closed=[b for b in bars if b.is_closed]
    from modules.strategies.liquidity import assert_plan_direction
    received = monitor.check(proposal,int(time.time()*1000))
    assert_plan_direction(p,closed,D(received['ask'])-D(received['bid']))
    from modules.signal_plan_policy import assert_current_stop
    assert_current_stop(p,closed,D(received['ask'])-D(received['bid']))
    if p['engine']=='indicators':
        from modules.indicator_suite import revalidate_plan
        revalidate_plan(p,closed)
    if p['engine']=='custom':
        from modules.custom_strategy import revalidate_plan
        revalidate_plan(p,bars,int(time.time()*1000),D(received['ask'])-D(received['bid']))
    protected=[f['detail']['protected_price'] for f in p['evidence']
               if f['kind']=='closed_choch' and 'protected_price' in f.get('detail',{})]
    if protected and any(b.end_ms>p['evidence_cutoff_ms'] and sign*(b.close-D(protected[0]))<0 for b in closed):
        raise ValueError('REVIEW_CHOCH_PREMISE_INVALIDATED')
    tick=monitor.check(proposal,int(time.time()*1000))
    return {'checked_ms':int(time.time()*1000),'quote_event_ms':tick['event_ms'],
            'scope':'INDICATIVE_RECEIVED_QUOTES_AND_REPORTED_CANDLES','native_first_visit_proven':False,
            'execution_eligible':False}
