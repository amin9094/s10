"""Admin annotations are opinions; blind reviews reveal only after a saved vote."""
import time
from repositories.v2.research_cases import ResearchCases
from repositories.v2.common import json_dump,json_load
from services.signal_workspace_service import TAGS


def review(user,key,body=None):
    from services.live_signal_service import permitted
    permitted(user);repo=ResearchCases();case=repo.get(key)
    if not case:raise ValueError('RESEARCH_CASE_NOT_FOUND')
    with repo.engine.transaction(read_only=body is None) as c:
        if body is not None and repo.engine.dialect.name=='postgres':c.execute('SELECT pg_advisory_xact_lock(hashtextextended(?,0))',('case-review:'+key+':'+str(user),))
        r=c.execute('SELECT * FROM s9_case_reviews WHERE case_id=? AND admin_id=?',(key,str(user))).fetchone()
        v={'revision':r['revision'],'payload':json_load(r['payload'])} if r else {'revision':0,'payload':{'history':[],'revealed':False}}
        if body is None:return v
        if (not isinstance(body,dict) or set(body)-{'revision','action','tags','note','vote'} or type(body.get('revision')) is not int or body['revision']!=v['revision']):raise ValueError('CASE_REVIEW_CHANGED')
        if body.get('action')=='reveal':
            if v['payload'].get('vote') not in {'ACCEPT','REJECT','UNSURE'}:raise ValueError('BLIND_VOTE_REQUIRED')
            v['payload']['revealed']=True
        elif body.get('action')=='save':
            if body.get('vote') not in {'ACCEPT','REJECT','UNSURE'} or not isinstance(body.get('tags'),list) or set(body['tags'])-set(TAGS):raise ValueError('CASE_REVIEW_INVALID')
            if not isinstance(body.get('note'),str) or len(body['note'])>2000:raise ValueError('CASE_REVIEW_INVALID')
            v['payload'].update(vote=body['vote'],tags=body['tags'],note=body['note'])
        else:raise ValueError('CASE_REVIEW_INVALID')
        v['revision']+=1;v['payload']['history']=(v['payload']['history']+[{'revision':v['revision'],'at_ms':int(time.time()*1000),**body}])[-50:]
        c.execute('INSERT INTO s9_case_reviews VALUES(?,?,?,?) ON CONFLICT(case_id,admin_id) DO UPDATE SET revision=excluded.revision,payload=excluded.payload',(key,str(user),v['revision'],json_dump(v['payload'])))
        return v


def revealed(user,key):
    v=review(user,key)
    if not v['payload'].get('revealed'):raise PermissionError('BLIND_VOTE_AND_REVEAL_REQUIRED')
    from services.strategy_lab_service import _native_samples
    case=ResearchCases().get(key)
    if case['payload']['bundle']['context_type']=='review':return {'state':'REVIEW_TAPE_NOT_DURABLE','items':[]}
    ticks=_native_samples(case['payload'])
    return {'state':'RECORDED_QUOTES' if ticks else 'TAPE_UNAVAILABLE','items':ticks,'synthetic_continuation':False}


def redundancy(user):
    from services.live_signal_service import permitted
    permitted(user);repo=ResearchCases();page=repo.page();votes=[]
    for row in page['items']:
        p=repo.get(row['id'])['payload']
        captured=p.get('indicator_observations',[])
        if captured:
            votes.extend(r['votes'] for r in captured);continue
        for result in p['original_results']['results']:
            plan=result.get('plan') or result.get('draft_plan') or {}
            evidence={e['kind']:e.get('detail') or {} for e in plan.get('evidence',[])}
            vote=evidence.get('all_directional_indicators',{}).get('directional_agreement')
            if vote:votes.append(vote)
    keys=sorted({k for vote in votes for k in vote});pairs=[]
    for i,a in enumerate(keys):
        for b in keys[i+1:]:
            samples=[(v[a],v[b]) for v in votes if a in v and b in v];n=len(samples)
            pairs.append({'a':a,'b':b,'samples':n,'agreement':sum(x==y for x,y in samples)/n if n else None,
                          'discordant':sum(x!=y for x,y in samples)})
    return {'case_sample_limit':40,'case_samples':len(page['items']),'vote_samples':len(votes),'pairs':pairs,
            'selection_bias':'CAPTURED_CASES_AND_NEAR_MISSES_NOT_ALL_MARKET_BARS',
            'incremental_value_status':'USE_RESEARCH_ABLATION_AND_HELD_OUT_EVALUATION','main_engine_rule_changed':False}
