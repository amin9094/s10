"""Private, bounded observations of stored evidence; no trading permission."""
import time
from core.storage.engine import normalized_engine
from repositories.v2.market_evidence import MarketEvidenceRepository
from modules.canonical_market import TIMEFRAMES


def snapshot(user_id,symbol='XAUUSD',*,engine=None,now_ms=None):
    from services.live_signal_service import permitted
    from modules.automated_market_scope import require_global_symbol
    permitted(user_id);require_global_symbol(symbol)
    engine=engine or normalized_engine();now=now_ms if now_ms is not None else int(time.time()*1000)
    repo=MarketEvidenceRepository(engine)
    with engine.transaction(read_only=True,repeatable_read=True) as c:
        groups=c.execute('SELECT provider,timeframe,COUNT(*) AS count FROM s9_candles WHERE symbol=? GROUP BY provider,timeframe',(symbol,)).fetchall()
        revisions=c.execute("SELECT COUNT(*) AS n FROM s9_candle_revisions WHERE symbol=? AND state='PENDING'",(symbol,)).fetchone()['n']
        quote=c.execute('SELECT provider,MAX(received_ms) AS received_ms,MAX(event_ms) AS event_ms FROM s9_quote_archive WHERE symbol=? GROUP BY provider',(symbol,)).fetchall()
    items=[]
    for g in groups:
        rows=repo.candles(symbol,g['provider'],g['timeframe'],limit=150)
        closed=[b for b in rows if b.is_closed and b.available_ms<=now]
        age=now-closed[-1].end_ms if closed else None
        gaps=sum(a.end_ms!=b.start_ms for a,b in zip(closed,closed[1:]))
        items.append({'provider':g['provider'],'timeframe':g['timeframe'],'stored_count':g['count'],
            'sample_closed':len(closed),'sample_limit':150,'coverage_gaps_in_sample':gaps,
            'last_closed_ms':closed[-1].end_ms if closed else None,'closed_age_ms':age,
            'state':'NO_CLOSED_DATA' if not closed else 'COVERAGE_GAP' if gaps else 'CURRENT_SAMPLE' if 0<=age<=2*TIMEFRAMES[g['timeframe']] else 'STALE_OR_SESSION_CLOSED',
            'volume_kinds':sorted({b.volume_kind for b in rows}),
            'quality_flags':sorted({flag for b in rows for flag in b.quality_flags}),
            'warmup_105_available':len(closed)>=105})
    return {'symbol':symbol,'observed_ms':now,'items':items,'pending_revisions':revisions,
            'quotes':quote,'is_execution_permission':False,'empty':not bool(items),
            'note_fa':'این صفحه وضعیت شواهد ذخیره‌شده است؛ سلامت اتصال و اجازهٔ ورود هر ستاپ جدا بررسی می‌شود.'}
