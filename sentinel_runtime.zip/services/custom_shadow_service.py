"""Opt-in prospective comparisons on one frozen input; no account writes."""
from copy import deepcopy
from dataclasses import replace
import time

from core.db import read_db_sections, with_db_sections
from core.storage.engine import normalized_engine
from modules.custom_strategy import parse_settings, evaluate
from repositories.v2.common import content_hash, json_dump, json_load


def _stored():
    return read_db_sections(('settings',)).get('settings', {}).get('strategyResearch', {}).get('customStrategy', {})


def configure(user, body):
    from services.live_signal_service import permitted
    permitted(user)
    if not isinstance(body, dict) or set(body) != {'revision', 'shadow_revision', 'settings'}:
        raise ValueError('SHADOW_SETTINGS_INVALID')
    config = parse_settings(body['settings']) if body['settings'] is not None else None
    if any(type(body[k]) is not int or body[k] < 0 for k in ('revision', 'shadow_revision')):
        raise ValueError('SHADOW_SETTINGS_INVALID')

    def save(db):
        target = db.setdefault('settings', {}).setdefault('strategyResearch', {}).setdefault('customStrategy', {})
        shadow = target.get('shadow', {})
        if target.get('revision', 0) != body['revision'] or shadow.get('revision', 0) != body['shadow_revision']:
            raise ValueError('CUSTOM_SETTINGS_CHANGED')
        value = {'revision': body['shadow_revision']+1, 'config': config.dto() if config else None,
                 'profile_id': config.profile_id if config else None, 'actor': str(user),
                 'started_ms': int(time.time()*1000), 'active_revision': body['revision']}
        target['shadow'] = value
        return {**value, 'activated': False, 'scope': 'FUTURE_MATCHED_INPUTS_ONLY'}
    return with_db_sections(('settings',), save)


def compare(context, result, engine=None):
    shadow = _stored().get('shadow', {})
    if not shadow.get('config'):
        return {'state': 'DISABLED'}
    if context.cutoff_ms < shadow.get('started_ms',0):
        return {'state':'INPUT_PREDATES_SHADOW_CONFIGURATION'}
    proposed = parse_settings(shadow['config'])
    active = context.custom_settings or parse_settings({})
    from modules.research_context import encode
    encoded = encode(context)
    input_hash = content_hash(encoded)
    # Use the same base-engine proposals and the same closed candles/quote.
    rows = [r for r in result.get('results', []) if r.get('engine') != 'custom']
    profiles = dict(context.engine_parameters)
    def evaluate_config(config):
        selected = replace(context, custom_settings=config,
                           parameters=profiles.get(config.base, context.parameters),
                           liquidity_parameters=profiles.get('sweep_fvg', context.parameters))
        outputs = evaluate(selected, deepcopy(rows))
        return [{'state': r.get('state'), 'plan_hash': content_hash(r.get('plan') or r.get('draft_plan')),
                 'direction': (r.get('plan') or r.get('draft_plan'))['direction'],
                 'entry': (r.get('plan') or r.get('draft_plan'))['entry']}
                for r in outputs if r.get('plan') or r.get('draft_plan')]
    payload = {'input_hash': input_hash, 'symbol': context.candles[-1].symbol,
               'timeframe': context.candles[-1].timeframe, 'cutoff_ms': context.cutoff_ms,
               'active': evaluate_config(active), 'shadow': evaluate_config(proposed),
               'shadow_revision': shadow['revision'], 'automatic_activation': False,
               'outcome_or_profit_estimate': None}
    key = content_hash([input_hash, active.profile_id, proposed.profile_id, shadow['revision']])[:32]
    engine = engine or normalized_engine(); now = int(time.time()*1000)
    with engine.transaction() as c:
        c.execute('INSERT INTO s9_shadow_comparisons VALUES(?,?,?,?,?) ON CONFLICT DO NOTHING',
                  (key, now, active.profile_id, proposed.profile_id, json_dump(payload)))
        c.execute('DELETE FROM s9_shadow_comparisons WHERE at_ms<?', (now-30*86400000,))
    return {'state': 'RECORDED', 'id': key}


def report(user):
    from services.live_signal_service import permitted
    permitted(user); stored = _stored(); shadow = stored.get('shadow', {})
    active = parse_settings(stored.get('config', {}))
    with normalized_engine().transaction(read_only=True) as c:
        rows = c.execute('SELECT * FROM s9_shadow_comparisons WHERE active_profile=? AND shadow_profile=? AND at_ms>=? ORDER BY at_ms DESC,id DESC LIMIT 100',
                         (active.profile_id, shadow.get('profile_id', ''), shadow.get('started_ms', 0))).fetchall()
    return {'revision': stored.get('revision', 0), 'shadow': shadow, 'active_profile': active.profile_id,
            'items': [{**r, 'payload': json_load(r['payload'])} for r in rows],
            'scope': 'PROSPECTIVE_PROPOSAL_AGREEMENT_NOT_PROFITABILITY',
            'limit': 100, 'automatic_activation': False, 'active_settings_changed': False}
