"""Manual reconciliation of ambiguous sends, with permissions and stale-form fencing."""
import re
import time
from core.storage.engine import normalized_engine
from repositories.v2.common import json_load,json_dump,content_hash
from repositories.v2.live_signal_inbox import LiveSignalInbox
from core.error_explanations import explain_error


def recovery_snapshot(user):
    from services.live_signal_service import permitted
    permitted(user,True)
    engine=normalized_engine()
    with engine.transaction(read_only=True) as c:
        rows=c.execute("SELECT * FROM s9_deliveries WHERE state IN ('UNCERTAIN','FAILED') ORDER BY ready_ms,id LIMIT 50").fetchall()
    items=[]
    for row in rows:
        payload=json_load(row['payload']);items.append({**row,'payload':payload,'revision':content_hash(row),
            'diagnostic':explain_error(payload.get('detail') or row['state'],source='signal_delivery')})
    return {'items':items,'automatic_retry':False}


def resolve_delivery(user,identifier,body):
    from services.live_signal_service import permitted
    permitted(user,True)
    if (not re.fullmatch('[a-f0-9]{32}',str(identifier)) or not isinstance(body,dict)
        or set(body)-{'revision','decision','message_id'} or body.get('decision') not in {'not_sent','receipt'}
        or not isinstance(body.get('revision'),str)):
        raise ValueError('INVALID_REQUEST')
    if body['decision']=='receipt' and (type(body.get('message_id')) is not int or body['message_id']<=0):
        raise ValueError('DELIVERY_RECEIPT_REQUIRED')
    engine=normalized_engine();inbox=LiveSignalInbox(engine)
    with engine.atomic() as c:
        sql='SELECT * FROM s9_deliveries WHERE id=?'
        if engine.dialect.name=='postgres':sql+=' FOR UPDATE'
        row=c.execute(sql,(identifier,)).fetchone()
        if not row or row['state'] not in {'UNCERTAIN','FAILED'} or content_hash(row)!=body['revision']:
            raise ValueError('DELIVERY_RECONCILIATION_CHANGED')
        p=json_load(row['payload']);decision=body['decision'];p.update(reconciled_by=str(user),reconciled_ms=int(time.time()*1000),
            resolution=decision,claim_token=None)
        if decision=='receipt':p.update(message_id=body['message_id'],detail='MANUAL_RECEIPT_PREENTRY_NOT_PROVEN')
        c.execute('UPDATE s9_deliveries SET state=?,payload=? WHERE id=?',('SENT' if decision=='receipt' else 'REVOKED',json_dump(p),identifier))
        card=inbox.get(row['setup_id'])
        if card:
            payload=card['payload'];pubs=payload.setdefault('publications',{})
            if pubs.get(row['audience'],{}).get('delivery_id')==identifier:
                if decision=='not_sent':pubs.pop(row['audience'],None)
                else:pubs[row['audience']].update(state='NEEDS_REVIEW',manual_message_id=body['message_id'],preentry_verified=False)
                state='NEEDS_REVIEW' if decision=='receipt' else 'PUBLISHED' if any(v.get('state')=='PUBLISHED' for v in pubs.values()) else 'PENDING'
                inbox.update(card,state,{**payload,'status_reason':'MANUAL_DELIVERY_RECONCILIATION'})
    if body['decision']=='receipt':
        from core.db import read_db_sections
        from services.signal_projection_service import invalidate_publication
        checkpoint=read_db_sections(('signal_delivery_checkpoints',)).get('signal_delivery_checkpoints',{}).get('live-desk:'+identifier,{})
        record=checkpoint.get('record_payload')
        if record:
            invalidate_publication(record,delivery_id='manual:'+identifier,
                reason='MANUAL_RECEIPT_PREENTRY_NOT_PROVEN',corrections=['MANUAL_RECEIPT_REQUIRES_ADMIN_REVIEW'],engine=engine)
    if body['decision']=='not_sent':
        from core.db import with_db
        from modules.signal_portal import release_reserved_signal_number
        def release(db):
            checkpoint=db.get('signal_delivery_checkpoints',{}).get('live-desk:'+identifier)
            if checkpoint and not checkpoint.get('delivered_channels'):
                identity=checkpoint.get('identity')
                checkpoint.update(status='failed',resolved_by=str(user),resolution='CONFIRMED_NOT_SENT')
                if identity:release_reserved_signal_number(db,identity,before_send=True)
        with_db(release)
    return {'state':'RECONCILED','decision':body['decision'],'automatic_retry':False,'preentry_verified':False}
