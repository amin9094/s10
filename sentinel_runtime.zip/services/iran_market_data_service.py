"""Iranian sources with distinct history and reference-only capabilities.

StreamData's documented history requires an owner-supplied token. No account,
token, native volume interpretation, broker product or bid/ask is invented.
"""
from __future__ import annotations

import json
import os
import re
import time
from datetime import UTC,datetime
from decimal import Decimal
from urllib.parse import quote

from core.async_runtime import run_blocking
from modules.canonical_market import Candle,TIMEFRAMES,validate_series

IRAN_GOLD_REFERENCE_URL = 'https://goldpricetoday.ir/prices.json'
IRAN_GOLD_SOURCE_PAGE = 'https://goldpricetoday.ir/commodities/xau-usd/'
STREAMDATA_ORIGIN = 'https://v6.streamdata.ir'


def streamdata_symbols():
    # Only the gold alias is explicitly published in the documentation. FX
    # aliases must come from the operator's own provider symbol list.
    raw = os.getenv('STREAMDATA_SYMBOLS_JSON','{"XAUUSD":"FX_XAUUSD"}')
    aliases = json.loads(raw)
    from services.canonical_market_service import FX_TICKERS
    if not isinstance(aliases,dict) or set(aliases)-{'XAUUSD',*FX_TICKERS}:
        raise ValueError('STREAMDATA_SYMBOL_MAP_INVALID')
    if any(not isinstance(value,str) or not re.fullmatch(r'FX_[A-Z0-9_]{3,24}',value) for value in aliases.values()):
        raise ValueError('STREAMDATA_SYMBOL_MAP_INVALID')
    return aliases


def parse_streamdata_history(raw,*,symbol,native_symbol,timeframe,observed_ms,before_ms=None,limit=300):
    from services.canonical_market_service import MarketUnavailable
    if not isinstance(raw,dict) or raw.get('s')!='ok':
        code = raw.get('code') or raw.get('errmsg') if isinstance(raw,dict) else None
        if not isinstance(code,str):code=''
        reasons = {'invalid_token':'STREAMDATA_TOKEN_REJECTED','invalid_symbol':'STREAMDATA_SYMBOL_UNAVAILABLE',
                   'symbol_not_found':'STREAMDATA_SYMBOL_UNAVAILABLE','rate_limit_exceeded':'PROVIDER_ERROR_429'}
        raise MarketUnavailable(reasons.get(code,'STREAMDATA_HISTORY_UNAVAILABLE'))
    if raw.get('symbol',native_symbol)!=native_symbol:
        raise MarketUnavailable('STREAMDATA_SYMBOL_UNAVAILABLE')
    names = ('t','o','h','l','c')
    if any(not isinstance(raw.get(name),list) for name in names) or len({len(raw[name]) for name in names})!=1:
        raise MarketUnavailable('STREAMDATA_CANDLE_ARRAYS_INVALID')
    if not raw['t']:
        raise MarketUnavailable('MARKET_BARS_EMPTY')
    rows=[]
    for i,stamp in enumerate(raw['t']):
        # History is seconds, unlike getLive milliseconds. Never guess units,
        # shift session boundaries or round off-grid timestamps into candles.
        if isinstance(stamp,bool) or not isinstance(stamp,int):
            raise MarketUnavailable('STREAMDATA_CANDLE_TIME_INVALID')
        start=stamp*1000
        if before_ms and start>=before_ms:
            continue
        end=start+TIMEFRAMES[timeframe]
        rows.append(Candle(symbol,'streamdata','streamdata_indicative_fx','spot',timeframe,start,end,
                           *(raw[name][i] for name in ('o','h','l','c')),None,'unavailable',
                           end<=observed_ms,observed_ms,f'streamdata:{native_symbol}:{timeframe}:{start}',
                           ('INDICATIVE_FX_NO_EXECUTION_QUOTE','REPORTED_VOLUME_UNVERIFIED')))
    validate_series(rows,now_ms=observed_ms)
    return rows[-limit:]


async def streamdata_history(symbol,timeframe,limit,before_ms):
    from services.canonical_market_service import MarketUnavailable,_request
    if timeframe not in {'1m','5m','15m','30m','1h','4h','1d'}:
        raise MarketUnavailable('MARKET_PROVIDER_MISMATCH')
    secret=os.getenv('STREAMDATA_API_TOKEN','').strip()
    if not secret:
        raise MarketUnavailable('STREAMDATA_API_TOKEN_MISSING')
    try:
        native_symbol=streamdata_symbols().get(symbol)
    except (ValueError,TypeError):
        raise MarketUnavailable('STREAMDATA_SYMBOL_MAP_INVALID') from None
    if not native_symbol:
        raise MarketUnavailable('STREAMDATA_SYMBOL_NOT_CONFIGURED')
    from repositories.v2.provider_budget import ProviderBudgetExceeded,reserve_streamdata
    try:
        await run_blocking(reserve_streamdata,secret,timeout=5)
    except ProviderBudgetExceeded as exc:
        raise MarketUnavailable(str(exc)) from None
    except Exception:
        raise MarketUnavailable('STREAMDATA_BUDGET_STORAGE_UNAVAILABLE') from None
    now=int(time.time()*1000)
    until=int(before_ms or now)//1000-1
    resolution={'1m':'1','5m':'5','15m':'15','30m':'30','1h':'60','4h':'240','1d':'1D'}[timeframe]
    params={'symbol':native_symbol,'resolution':resolution,'from':max(0,until-limit*TIMEFRAMES[timeframe]//1000*3),
            'to':until,'countback':limit}
    raw=await _request(f'{STREAMDATA_ORIGIN}/api/chart/v1/{quote(secret,safe="")}/history',params)
    return parse_streamdata_history(raw,symbol=symbol,native_symbol=native_symbol,timeframe=timeframe,
                                   observed_ms=int(time.time()*1000),before_ms=before_ms,limit=limit)


def parse_iran_gold_reference(raw,*,symbol,observed_ms):
    if symbol not in {'XAUUSD','XAGUSD'} or not isinstance(raw,dict):
        raise ValueError('REFERENCE_SYMBOL_UNSUPPORTED')
    key='gp:ounce' if symbol=='XAUUSD' else 'cm:silver'
    row=(raw.get('items') or {}).get(key)
    if not isinstance(row,dict) or row.get('u')!='دلار':
        raise ValueError('REFERENCE_IDENTITY_MISMATCH')
    expected='انس طلا' if symbol=='XAUUSD' else 'انس جهانی نقره'
    if row.get('n')!=expected:
        raise ValueError('REFERENCE_IDENTITY_MISMATCH')
    value=Decimal(str(row['p']))
    if not value.is_finite() or value<=0:
        raise ValueError('REFERENCE_PRICE_INVALID')
    stamp=raw.get('updated')
    if isinstance(stamp,bool) or not isinstance(stamp,int) or stamp<946684800000 or stamp>observed_ms+1000:
        raise ValueError('REFERENCE_TIMESTAMP_UNVERIFIED')
    # `updated` belongs to the whole snapshot, not necessarily this asset.
    return {'symbol':symbol,'provider':'goldpricetoday_ir','price':str(value),'currency':'USD',
            'event_ms':None,'snapshot_ms':stamp,'observed_ms':observed_ms,
            'updated_at':datetime.fromtimestamp(stamp/1000,UTC).isoformat(),
            'timestamp_kind':'SNAPSHOT_BUILD_TIME_NOT_NATIVE_ASSET_TIME',
            'kind':'INDEPENDENT_REFERENCE_ONLY','execution_eligible':False,
            'source_url':IRAN_GOLD_SOURCE_PAGE if symbol=='XAUUSD' else IRAN_GOLD_REFERENCE_URL,'attribution':'GoldPriceToday.ir',
            'state':'REFERENCE_TIME_UNVERIFIED' if observed_ms-stamp<=120000 else 'STALE_OR_SESSION_CLOSED'}
