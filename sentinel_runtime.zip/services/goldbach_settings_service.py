"""Small explicit per-market Goldbach settings; independent of strategy profiles."""
from decimal import Decimal as D
from dataclasses import asdict
from core.db import read_db_sections,with_db_sections
from modules.goldbach_confirmation import GoldbachSettings
from repositories.v2.live_signal_inbox import MARKETS,market_for


def parse_settings(body):
    if not isinstance(body,dict) or set(body)-{'enabled','po3','shift','price_unit','scan_adjacent','shift_radius','half_steps'}:raise ValueError('GOLDBACH_SETTINGS_INVALID')
    try:
        if isinstance(body.get('shift'),bool) or isinstance(body.get('price_unit'),bool):raise ValueError()
        c=GoldbachSettings(enabled=body.get('enabled',True),po3=body.get('po3',9),
            shift=D(str(body.get('shift','0'))),price_unit=D(str(body['price_unit'])) if body.get('price_unit') is not None else None,
            scan_adjacent=body.get('scan_adjacent',True),shift_radius=body.get('shift_radius',1),half_steps=body.get('half_steps',True))
        c.validate();return c
    except (ValueError,TypeError,ArithmeticError):raise ValueError('GOLDBACH_SETTINGS_INVALID') from None


def settings_for(symbol):
    stored=read_db_sections(('settings',)).get('settings',{}).get('strategyResearch',{}).get('goldbach',{})
    return parse_settings(stored.get(market_for(symbol),{}))


def read_settings(user_id):
    from services.live_signal_service import permitted
    permitted(user_id)
    stored=read_db_sections(('settings',)).get('settings',{}).get('strategyResearch',{}).get('goldbach',{})
    return {'markets':[{'id':m,'label':label,'settings':dto(parse_settings(stored.get(m,{})))} for m,label in MARKETS.items()],
            'protected_script_replica':False,'required_for_entry':False}


def dto(config):
    return {k:str(v) if isinstance(v,D) else v for k,v in asdict(config).items()}


def save_settings(user_id,market,body):
    from services.live_signal_service import permitted
    permitted(user_id)
    if market not in MARKETS:raise ValueError('GOLDBACH_MARKET_INVALID')
    config=parse_settings(body)
    def mutate(db):
        research=db.setdefault('settings',{}).setdefault('strategyResearch',{})
        research.setdefault('goldbach',{})[market]=dto(config)
        research['goldbach_changed_by']=str(user_id)
    with_db_sections(('settings',),mutate)
    return {'market':market,'settings':dto(config),'applies_to':'FUTURE_PROPOSALS_ONLY'}
