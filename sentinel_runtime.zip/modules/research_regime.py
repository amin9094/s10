"""Causal descriptive labels; not an extra signal gate or a forecast."""
from decimal import Decimal as D


def classify(bars):
    if len(bars)<105:return {'version':1,'state':'INSUFFICIENT_HISTORY','is_entry_filter':False}
    from modules.strategies.common import indicators
    stats=indicators(bars)
    atr=stats['atr'];adx=stats.get('adx')
    reference=sum((b.high-b.low for b in bars[-100:]),D(0))/100
    regime='HIGH_VOLATILITY' if reference and atr>reference*D('1.5') else 'TREND' if adx is not None and adx>=25 else 'RANGE'
    return {'version':1,'state':regime,'available_ms':max(b.available_ms for b in bars),
            'last_bar_end_ms':bars[-1].end_ms,'atr':str(atr),'adx':str(adx) if adx is not None else None,
            'rule':'ATR_GT_1_5_MEAN_100_RANGE_ELSE_ADX_GE_25_V1','is_entry_filter':False}
