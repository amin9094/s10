from __future__ import annotations

import copy
import secrets
from datetime import timedelta
from typing import Any

from core.db import with_db
from core.utils import parse_dt, utc_iso, utc_now
from modules.security_audit import append_security_audit

_FAMILY_SECTIONS: dict[str, tuple[str, ...]] = {
    "admin": ("delegated_admins", "admin_shifts"),
    "signal": ("signals", "signal_archive", "scheduled_signals", "signal_approvals", "signal_template_backgrounds", "signal_versions", "signal_revisions", "signal_team_rules"),
    "channel": ("announcements", "publisher_channels", "publication_queue", "marketing_campaigns", "campaign_events", "signal_live_cards"),
    "ticket": ("tickets", "support_tickets", "ticket_messages", "admin_shift_handoffs"),
    "user": ("users", "user_bans", "user_activity", "user_profiles"),
    "crm": ("marketing_campaigns", "campaign_events", "campaign_audience_snapshots", "experiments", "business_inbox"),
    "education": ("lessons", "missions", "user_missions", "contests", "contest_history", "chart_contest", "candle_contest"),
    "runtime": ("enterprise_control", "admin_control_center", "runtime_safety", "operations_governance", "operations", "ai_runtime_settings"),
    "report": (),
}


def _family(action: str) -> str:
    from modules.ai_action_firewall import action_family
    return action_family(action)


def sections_for_actions(actions: list[str]) -> tuple[str, ...]:
    result: set[str] = set()
    for action in actions:
        result.update(_FAMILY_SECTIONS.get(_family(action), ()))
    return tuple(sorted(result))


def create_undo_snapshot(actor_id: int | str, actions: list[str], *, ttl_minutes: int = 60) -> dict[str, Any]:
    sections = sections_for_actions(actions)
    token = secrets.token_urlsafe(18)
    def mutate(db: dict[str, Any]) -> dict[str, Any]:
        row = {
            "token": token,
            "actions": list(actions),
            "sections": {key: copy.deepcopy(db.get(key)) for key in sections},
            "section_keys": list(sections),
            "status": "available",
            "created_by": str(actor_id),
            "created_at": utc_iso(),
            "expires_at": utc_iso(utc_now() + timedelta(minutes=max(5, min(ttl_minutes, 1440)))),
        }
        rows = db.setdefault("ai_undo_snapshots", [])
        rows.append(row)
        # Undo snapshots are operational recovery data, not security audit.
        db["ai_undo_snapshots"] = rows[-100:]
        append_security_audit(db, action="ai_undo_snapshot_created", actor_id=actor_id, details={"token": token, "actions": actions, "sections": list(sections)}, source="ai_execution")
        return {key: value for key, value in row.items() if key != "sections"}
    return with_db(mutate)


def restore_undo_snapshot(token: str, actor_id: int | str, *, automatic: bool = False) -> dict[str, Any]:
    target = str(token or "")
    def mutate(db: dict[str, Any]) -> dict[str, Any]:
        row = next((item for item in reversed(db.setdefault("ai_undo_snapshots", [])) if isinstance(item, dict) and item.get("token") == target), None)
        if not row:
            raise ValueError("AI_UNDO_TOKEN_NOT_FOUND")
        if row.get("status") != "available":
            raise ValueError("AI_UNDO_TOKEN_ALREADY_USED")
        expiry = parse_dt(row.get("expires_at"))
        if expiry and expiry <= utc_now():
            row["status"] = "expired"
            raise ValueError("AI_UNDO_TOKEN_EXPIRED")
        snapshot = row.get("sections") if isinstance(row.get("sections"), dict) else {}
        for key in row.get("section_keys") or []:
            if key in snapshot:
                db[key] = copy.deepcopy(snapshot[key])
            else:
                db.pop(key, None)
        row["status"] = "restored"
        row["restored_by"] = str(actor_id)
        row["restored_at"] = utc_iso()
        row["automatic"] = bool(automatic)
        append_security_audit(db, action="ai_undo_snapshot_restored", actor_id=actor_id, details={"token": target, "automatic": bool(automatic)}, source="ai_execution")
        return {key: value for key, value in row.items() if key != "sections"}
    return with_db(mutate)
