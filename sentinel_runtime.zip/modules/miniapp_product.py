from __future__ import annotations

import base64
import binascii
import io
import re
import secrets
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

from PIL import Image, ImageOps, UnidentifiedImageError

from config import SETTINGS  # noqa: F401 -- compatibility hook for legacy integration tests
from core.domain import (
    activate_vip,
    add_points,
    consume_discount,
    is_vip,
    release_discount,
    reserve_discount,
    validate_discount,
)
from core.utils import parse_dt, utc_iso
from modules.discount_campaigns import calculate_discount_amount
from modules.payment_verification import normalize_txid, txid_used
from modules.payment_pricing import calculate_usdt_amount, format_usdt_amount
from modules.receipt_storage import receipt_exists, store_receipt_blob
from modules.sales_growth import active_vip_plans, get_vip_plan, register_plan_sale
from modules.user_intelligence import record_user_activity

_ALLOWED_RECEIPT_MIME = {"image/jpeg", "image/png", "image/webp"}
_ALLOWED_RECEIPT_EXTENSIONS = {".jpg", ".jpeg", ".png", ".webp"}
_MAX_RECEIPT_INPUT_BYTES = 5_000_000
_MAX_RECEIPT_OUTPUT_BYTES = 1_500_000
_MAX_IMAGE_PIXELS = 20_000_000
_QUOTE_STATES = {"active", "consumed", "expired", "cancelled"}


def user_has_vip_purchase(db: dict[str, Any], user_id: int | str) -> bool:
    uid = str(user_id)
    return any(
        isinstance(order, dict)
        and str(order.get("user_id")) == uid
        and str(order.get("status")) == "approved"
        for order in db.get("vip_orders", [])
    )


def payment_configuration(db: dict[str, Any]) -> dict[str, Any]:
    settings = db.setdefault("vip_settings", {})
    card_number = re.sub(r"\D", "", str(settings.get("card_number") or ""))
    card_ready = len(card_number) == 16 and bool(str(settings.get("owner_name") or "").strip())
    usdt_ready = (
        bool(settings.get("usdt_enabled", False))
        and bool(str(settings.get("usdt_wallet_address") or "").strip())
        and float(settings.get("usdt_rate_toman", 0) or 0) > 0
    )
    return {
        "card": {
            "enabled": card_ready,
            "card_number": card_number,
            "owner_name": str(settings.get("owner_name") or ""),
        },
        "usdt": {
            "enabled": usdt_ready,
            "network": str(settings.get("usdt_network") or "TRC20").upper(),
            "wallet": str(settings.get("usdt_wallet_address") or ""),
            "rate_toman": float(settings.get("usdt_rate_toman", 0) or 0),
            "rate_updated_at": settings.get("usdt_rate_updated_at"),
            "quote_valid_minutes": max(5, int(settings.get("usdt_quote_valid_minutes", 30) or 30)),
        },
    }


def vip_catalog(db: dict[str, Any], user_id: int | str, *, vip_active: bool) -> dict[str, Any]:
    plans = active_vip_plans(
        db,
        user_is_vip=vip_active,
        user_has_purchased=user_has_vip_purchase(db, user_id),
    )
    return {
        "plans": [
            {
                "id": int(row.get("id", 0) or 0),
                "name": str(row.get("name") or "VIP"),
                "name_en": str(row.get("name_en") or ""),
                "description": str(row.get("description") or ""),
                "description_en": str(row.get("description_en") or ""),
                "price": max(0, int(row.get("price", 0) or 0)),
                "original_price": max(0, int(row.get("original_price", 0) or 0)),
                "duration_days": max(1, int(row.get("duration_days", 30) or 30)),
                "features": [str(item) for item in row.get("features", []) if str(item).strip()][:12],
                "features_en": [str(item) for item in row.get("features_en", []) if str(item).strip()][:12],
                "highlight": bool(row.get("highlight", False)),
                "audience": str(row.get("audience") or "all"),
                "sales_limit": max(0, int(row.get("sales_limit", 0) or 0)),
                "sales_count": max(0, int(row.get("sales_count", 0) or 0)),
            }
            for row in plans
        ],
        "payment": payment_configuration(db),
    }


def _payment_method_ready(config: dict[str, Any], method: str) -> bool:
    row = config.get(method, {}) if isinstance(config, dict) else {}
    return bool(row.get("enabled", False))


def _usdt_amount(price_toman: int, rate_toman: float):
    """Compatibility wrapper around the exact shared pricing engine."""
    if int(price_toman or 0) <= 0:
        return calculate_usdt_amount(0, rate_toman)
    return calculate_usdt_amount(price_toman, rate_toman)


def _available_plan(db: dict[str, Any], user_id: int | str, plan_id: int | str) -> dict[str, Any]:
    plan = get_vip_plan(db, plan_id)
    available_ids = {
        int(row.get("id", 0) or 0)
        for row in active_vip_plans(
            db,
            user_is_vip=is_vip(db, user_id),
            user_has_purchased=user_has_vip_purchase(db, user_id),
        )
    }
    if not plan or int(plan.get("id", 0) or 0) not in available_ids:
        raise ValueError("VIP_PLAN_UNAVAILABLE")
    return plan


def create_checkout_quote(
    db: dict[str, Any], user_id: int | str, *, plan_id: int | str, payment_method: str, coupon: str = ""
) -> dict[str, Any]:
    uid = str(user_id)
    plan = _available_plan(db, uid, plan_id)
    method = str(payment_method or "").lower().strip()
    if method not in {"card", "usdt"}:
        raise ValueError("INVALID_PAYMENT_METHOD")
    payment = payment_configuration(db)
    if not _payment_method_ready(payment, method):
        raise ValueError("PAYMENT_METHOD_UNAVAILABLE")
    price = max(0, int(plan.get("price", 0) or 0))
    coupon_code = str(coupon or "").strip().upper()
    discount = None
    if coupon_code:
        valid, message, discount = validate_discount(
            db,
            coupon_code,
            int(uid),
            plan_id=plan.get("id"),
            product_type="vip",
            order_amount=price,
            payment_method=method,
        )
        if not valid or not discount:
            raise ValueError(f"COUPON_INVALID:{message}")
    pricing = calculate_discount_amount(discount, price) if discount else {
        "configured_percent": 0,
        "effective_percent": 0,
        "discount_amount": 0,
        "final_amount": price,
    }
    final_price = max(0, int(pricing.get("final_amount", price) or 0))
    valid_minutes = int(payment.get("usdt", {}).get("quote_valid_minutes", 30) or 30) if method == "usdt" else 60
    expires = datetime.now(UTC) + timedelta(minutes=max(5, min(valid_minutes, 120)))
    quote_id = f"Q-{secrets.token_hex(6).upper()}"
    quote = {
        "quote_id": quote_id,
        "user_id": uid,
        "plan_id": int(plan.get("id", 0) or 0),
        "plan_name": str(plan.get("name") or "VIP"),
        "duration_days": max(1, int(plan.get("duration_days", 30) or 30)),
        "base_price": price,
        "discount_percent": int(pricing.get("effective_percent", 0) or 0),
        "discount_configured_percent": int(pricing.get("configured_percent", 0) or 0),
        "discount_amount": int(pricing.get("discount_amount", 0) or 0),
        "payable_toman": final_price,
        "coupon": coupon_code,
        "payment_method": method,
        "payment_network": str(payment.get("usdt", {}).get("network") or "TRC20") if method == "usdt" else "",
        "payment_wallet": str(payment.get("usdt", {}).get("wallet") or "") if method == "usdt" else "",
        "payment_card_number": str(payment.get("card", {}).get("card_number") or "") if method == "card" else "",
        "payment_card_owner": str(payment.get("card", {}).get("owner_name") or "") if method == "card" else "",
        "payment_rate_toman": float(payment.get("usdt", {}).get("rate_toman", 0) or 0) if method == "usdt" else 0.0,
        "payment_amount_usdt": format_usdt_amount(final_price, payment.get("usdt", {}).get("rate_toman", 0)) if method == "usdt" and final_price > 0 else "0.000000",
        "status": "active",
        "created_at": utc_iso(),
        "expires_at": expires.isoformat(),
        "consumed_at": None,
        "order_id": "",
    }
    db.setdefault("checkout_quotes", {})[quote_id] = quote
    return dict(quote)


def get_checkout_quote(
    db: dict[str, Any], user_id: int | str, quote_id: str, *, require_active: bool = True
) -> dict[str, Any]:
    quote = db.setdefault("checkout_quotes", {}).get(str(quote_id or ""))
    if not isinstance(quote, dict) or str(quote.get("user_id")) != str(user_id):
        raise ValueError("CHECKOUT_QUOTE_NOT_FOUND")
    expires = parse_dt(str(quote.get("expires_at") or ""))
    if quote.get("status") == "active" and expires and expires <= datetime.now(UTC):
        quote["status"] = "expired"
    if require_active and quote.get("status") != "active":
        raise ValueError("CHECKOUT_QUOTE_EXPIRED")
    return quote


def _encode_receipt(image: Image.Image) -> bytes:
    image = ImageOps.exif_transpose(image)
    if image.mode not in {"RGB", "L"}:
        background = Image.new("RGB", image.size, "white")
        if image.mode == "RGBA":
            background.paste(image, mask=image.getchannel("A"))
        else:
            background.paste(image.convert("RGB"))
        image = background
    elif image.mode == "L":
        image = image.convert("RGB")
    maximum = 1600
    image.thumbnail((maximum, maximum), Image.Resampling.LANCZOS)
    for quality in (82, 74, 66, 58):
        output = io.BytesIO()
        image.save(output, format="WEBP", quality=quality, method=6)
        payload = output.getvalue()
        if len(payload) <= _MAX_RECEIPT_OUTPUT_BYTES:
            return payload
    raise ValueError("RECEIPT_TOO_LARGE_AFTER_PROCESSING")


def store_receipt_bytes(
    db: dict[str, Any], *, payload: bytes, content_type: str, user_id: int | str, original_name: str = "receipt"
) -> dict[str, Any]:
    normalized_mime = content_type.lower().split(";", 1)[0].strip()
    if normalized_mime not in _ALLOWED_RECEIPT_MIME:
        raise ValueError("UNSUPPORTED_RECEIPT_FORMAT")
    safe_original_name = Path(str(original_name or "receipt")).name[:120]
    suffix = Path(safe_original_name).suffix.lower()
    if suffix and suffix not in _ALLOWED_RECEIPT_EXTENSIONS:
        raise ValueError("UNSUPPORTED_RECEIPT_EXTENSION")
    if suffix in {".jpg", ".jpeg"} and normalized_mime != "image/jpeg":
        raise ValueError("RECEIPT_EXTENSION_MISMATCH")
    if suffix in {".png", ".webp"} and normalized_mime != f"image/{suffix[1:]}":
        raise ValueError("RECEIPT_EXTENSION_MISMATCH")
    if not payload or len(payload) > _MAX_RECEIPT_INPUT_BYTES:
        raise ValueError("RECEIPT_SIZE_INVALID")
    try:
        with Image.open(io.BytesIO(payload)) as probe:
            if probe.width * probe.height > _MAX_IMAGE_PIXELS or probe.width < 64 or probe.height < 64:
                raise ValueError("RECEIPT_DIMENSIONS_INVALID")
            probe.verify()
        with Image.open(io.BytesIO(payload)) as source:
            normalized = _encode_receipt(source.copy())
    except (UnidentifiedImageError, OSError, Image.DecompressionBombError) as exc:
        raise ValueError("RECEIPT_IMAGE_INVALID") from exc
    receipt_id = f"R-{secrets.token_hex(8).upper()}"
    storage = store_receipt_blob(normalized, user_id=user_id, mime_type="image/webp")
    record = {
        "receipt_id": receipt_id,
        "user_id": str(user_id),
        **storage,
        "original_name": safe_original_name,
        "created_at": utc_iso(),
        "status": "available",
        "order_id": "",
    }
    db.setdefault("receipt_uploads", {})[receipt_id] = record
    return dict(record)


def store_receipt_data_url(data_url: str, user_id: int | str, db: dict[str, Any] | None = None) -> str:
    """Compatibility path for old clients; new clients should use multipart upload."""
    raw = str(data_url or "").strip()
    if not raw:
        return ""
    match = re.fullmatch(r"data:(image/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=\r\n]+)", raw)
    if not match:
        raise ValueError("UNSUPPORTED_RECEIPT_FORMAT")
    try:
        payload = base64.b64decode(match.group(2), validate=True)
    except (ValueError, binascii.Error) as exc:
        raise ValueError("RECEIPT_IMAGE_INVALID") from exc
    working = db if isinstance(db, dict) else {"receipt_uploads": {}}
    record = store_receipt_bytes(
        working,
        payload=payload,
        content_type=match.group(1),
        user_id=user_id,
        original_name="legacy-receipt",
    )
    return str(record.get("path") or record.get("object_key") or "")


def _receipt_for_order(db: dict[str, Any], user_id: int | str, receipt_id: str) -> dict[str, Any]:
    row = db.setdefault("receipt_uploads", {}).get(str(receipt_id or ""))
    if not isinstance(row, dict) or str(row.get("user_id")) != str(user_id):
        raise ValueError("RECEIPT_NOT_FOUND")
    if row.get("status") != "available":
        raise ValueError("RECEIPT_ALREADY_USED")
    if not receipt_exists(row):
        raise ValueError("RECEIPT_FILE_MISSING")
    return row


def _find_order(db: dict[str, Any], user_id: int | str, order_id: str) -> dict[str, Any]:
    order = next(
        (
            row for row in db.setdefault("vip_orders", [])
            if isinstance(row, dict) and str(row.get("user_id")) == str(user_id) and str(row.get("order_id")) == str(order_id)
        ),
        None,
    )
    if not order:
        raise ValueError("VIP_ORDER_NOT_FOUND")
    return order


def create_vip_order_from_miniapp(
    db: dict[str, Any], *, user_id: int, username: str, first_name: str, payload: dict[str, Any]
) -> dict[str, Any]:
    uid = str(user_id)
    existing = next(
        (
            row for row in db.setdefault("vip_orders", [])
            if isinstance(row, dict)
            and str(row.get("user_id")) == uid
            and str(row.get("status")) in {"pending", "approving"}
        ),
        None,
    )
    if existing:
        raise ValueError("VIP_ORDER_PENDING_EXISTS")
    quote = get_checkout_quote(db, uid, str(payload.get("quote_id") or ""))
    receipt: dict[str, Any] | None = None
    if int(quote.get("payable_toman", 0) or 0) > 0:
        receipt = _receipt_for_order(db, uid, str(payload.get("receipt_id") or ""))
    transaction_hash = ""
    if quote.get("payment_method") == "usdt" and int(quote.get("payable_toman", 0) or 0) > 0:
        raw_txid = str(payload.get("transaction_hash") or "").strip()
        transaction_hash = normalize_txid(raw_txid) if raw_txid else ""
        if transaction_hash and txid_used(db, transaction_hash):
            raise ValueError("TXID_ALREADY_USED")
    order_id = secrets.token_hex(5).upper()
    order = {
        "order_id": order_id,
        "user_id": user_id,
        "username": username,
        "first_name": first_name,
        "quote_id": quote["quote_id"],
        "quote_expires_at": quote.get("expires_at"),
        "plan_id": int(quote.get("plan_id", 0) or 0),
        "plan_name": str(quote.get("plan_name") or "VIP"),
        "duration_days": int(quote.get("duration_days", 30) or 30),
        "base_price": int(quote.get("base_price", 0) or 0),
        "discount_percent": int(quote.get("discount_percent", 0) or 0),
        "discount_configured_percent": int(quote.get("discount_configured_percent", 0) or 0),
        "discount_amount": int(quote.get("discount_amount", 0) or 0),
        "price": int(quote.get("payable_toman", 0) or 0),
        "coupon": str(quote.get("coupon") or ""),
        "receipt_file_id": "",
        "receipt_id": receipt.get("receipt_id") if receipt else "",
        "receipt_path": receipt.get("path") if receipt else "",
        "receipt_object_key": receipt.get("object_key") if receipt else "",
        "receipt_storage_backend": receipt.get("storage_backend") if receipt else "",
        "receipt_bucket": receipt.get("bucket") if receipt else "",
        "receipt_checksum": receipt.get("checksum") if receipt else "",
        "receipt_source": "miniapp_multipart" if receipt else "none",
        "payment_method": quote.get("payment_method"),
        "payment_amount_usdt": quote.get("payment_amount_usdt"),
        "payment_network": quote.get("payment_network"),
        "payment_wallet": quote.get("payment_wallet"),
        "payment_rate_toman": quote.get("payment_rate_toman"),
        "payment_card_number": quote.get("payment_card_number"),
        "payment_card_owner": quote.get("payment_card_owner"),
        "transaction_hash": transaction_hash,
        "verification_status": "pending" if transaction_hash else "manual_review",
        "verification_verified": False,
        "status": "pending",
        "rejection_reason": "",
        "cancellation_reason": "",
        "created_at": utc_iso(),
        "updated_at": utc_iso(),
        "admin_notified_at": None,
        "admin_notification_attempts": 0,
        "user_notified_at": None,
        "user_notification_attempts": 0,
    }
    discount = None
    if quote.get("coupon"):
        valid, _message, discount = validate_discount(
            db,
            str(quote.get("coupon")),
            user_id,
            plan_id=quote.get("plan_id"),
            product_type="vip",
            order_amount=int(quote.get("base_price", 0) or 0),
            payment_method=str(quote.get("payment_method") or ""),
        )
        if not valid:
            raise ValueError("COUPON_NO_LONGER_VALID")
    if discount:
        reserve_discount(discount, order_id, user_id, db=db)
    db["vip_orders"].append(order)
    quote["status"] = "consumed"
    quote["consumed_at"] = utc_iso()
    quote["order_id"] = order_id
    if receipt:
        receipt["status"] = "used"
        receipt["order_id"] = order_id
    record_user_activity(
        db,
        user_id,
        "vip_order_created",
        source="miniapp",
        detail=order_id,
        metadata={"plan_id": order["plan_id"], "price": order["price"], "payment_method": order["payment_method"]},
    )
    # Zero-value/coupon orders also remain pending. Entitlement activation and
    # Telegram invite creation always require the same explicit admin workflow.
    return order_summary(order)


def order_summary(order: dict[str, Any]) -> dict[str, Any]:
    return {
        "order_id": str(order.get("order_id") or ""),
        "quote_id": str(order.get("quote_id") or ""),
        "plan_id": int(order.get("plan_id", 0) or 0),
        "plan_name": str(order.get("plan_name") or "VIP"),
        "price": int(order.get("price", 0) or 0),
        "payment_method": str(order.get("payment_method") or ""),
        "payment_amount_usdt": str(order.get("payment_amount_usdt") or ""),
        "payment_network": str(order.get("payment_network") or ""),
        "status": str(order.get("status") or ""),
        "rejection_reason": str(order.get("rejection_reason") or ""),
        "cancellation_reason": str(order.get("cancellation_reason") or ""),
        "created_at": order.get("created_at"),
        "updated_at": order.get("updated_at"),
    }


def orders_for_user(db: dict[str, Any], user_id: int | str) -> list[dict[str, Any]]:
    rows = [
        order_summary(row)
        for row in db.setdefault("vip_orders", [])
        if isinstance(row, dict) and str(row.get("user_id")) == str(user_id)
    ]
    rows.sort(key=lambda row: str(row.get("created_at") or ""), reverse=True)
    return rows


def order_detail(db: dict[str, Any], user_id: int | str, order_id: str) -> dict[str, Any]:
    """Return a user-safe order DTO without storage or admin-only fields."""
    order = _find_order(db, user_id, order_id)
    data = order_summary(order)
    data.update({
        "duration_days": int(order.get("duration_days", 30) or 30),
        "base_price": int(order.get("base_price", order.get("price", 0)) or 0),
        "discount_percent": int(order.get("discount_percent", 0) or 0),
        "discount_amount": int(order.get("discount_amount", 0) or 0),
        "coupon": str(order.get("coupon") or ""),
        "quote_expires_at": order.get("quote_expires_at"),
        "transaction_hash": str(order.get("transaction_hash") or ""),
        "verification_status": str(order.get("verification_status") or ""),
        "verification_verified": bool(order.get("verification_verified", False)),
        "received_amount_usdt": order.get("received_amount_usdt"),
        "confirmation_count": int(order.get("confirmation_count", 0) or 0),
        "expires_at": order.get("expires_at"),
        "can_cancel": str(order.get("status")) in {"pending", "approving"},
        "can_resubmit": str(order.get("status")) in {"rejected", "cancelled", "expired"},
        "receipt_attached": bool(order.get("receipt_id") or order.get("receipt_file_id")),
    })
    return data


def cancel_vip_order(db: dict[str, Any], user_id: int | str, order_id: str, reason: str = "") -> dict[str, Any]:
    order = _find_order(db, user_id, order_id)
    if str(order.get("status")) != "pending":
        raise ValueError("VIP_ORDER_NOT_CANCELLABLE")
    order["status"] = "cancelled"
    order["cancellation_reason"] = str(reason or "user_cancelled")[:300]
    order["updated_at"] = utc_iso()
    release_discount(db, order)
    return order_summary(order)


def resubmit_vip_order(
    db: dict[str, Any],
    user_id: int | str,
    order_id: str,
    *,
    receipt_id: str,
    quote_id: str,
    transaction_hash: str = "",
) -> dict[str, Any]:
    """Resubmit a rejected/cancelled order against a fresh binding quote.

    Payment rates, discounts and wallet/card instructions may change after an
    order is rejected. Requiring a new active quote prevents stale USDT rates
    or expired coupons from being reused silently.
    """
    order = _find_order(db, user_id, order_id)
    if str(order.get("status")) not in {"rejected", "cancelled", "expired"}:
        raise ValueError("VIP_ORDER_NOT_RESUBMITTABLE")
    quote = get_checkout_quote(db, user_id, quote_id)
    if int(quote.get("plan_id", 0) or 0) != int(order.get("plan_id", 0) or 0):
        raise ValueError("RESUBMIT_QUOTE_PLAN_MISMATCH")
    receipt: dict[str, Any] | None = None
    if int(quote.get("payable_toman", 0) or 0) > 0:
        receipt = _receipt_for_order(db, user_id, receipt_id)
    txid = ""
    if quote.get("payment_method") == "usdt" and int(quote.get("payable_toman", 0) or 0) > 0:
        raw_txid = str(transaction_hash or "").strip()
        txid = normalize_txid(raw_txid) if raw_txid else ""
        if txid and txid_used(db, txid, exclude_order_id=str(order.get("order_id") or "")):
            raise ValueError("TXID_ALREADY_USED")

    # Preserve an audit snapshot of the previous payment attempt before
    # replacing mutable payment instructions with the fresh quote.
    order.setdefault("resubmission_history", []).append({
        "quote_id": order.get("quote_id"),
        "price": order.get("price"),
        "payment_method": order.get("payment_method"),
        "transaction_hash": order.get("transaction_hash"),
        "receipt_id": order.get("receipt_id"),
        "status": order.get("status"),
        "rejection_reason": order.get("rejection_reason"),
        "created_at": utc_iso(),
    })
    for source, target in (
        ("quote_id", "quote_id"), ("expires_at", "quote_expires_at"), ("base_price", "base_price"),
        ("discount_percent", "discount_percent"), ("discount_configured_percent", "discount_configured_percent"),
        ("discount_amount", "discount_amount"), ("payable_toman", "price"), ("coupon", "coupon"),
        ("payment_method", "payment_method"), ("payment_amount_usdt", "payment_amount_usdt"),
        ("payment_network", "payment_network"), ("payment_wallet", "payment_wallet"),
        ("payment_rate_toman", "payment_rate_toman"), ("payment_card_number", "payment_card_number"),
        ("payment_card_owner", "payment_card_owner"),
    ):
        order[target] = quote.get(source)
    order["transaction_hash"] = txid
    order["receipt_id"] = receipt["receipt_id"] if receipt else ""
    order["receipt_path"] = receipt.get("path", "") if receipt else ""
    order["receipt_object_key"] = receipt.get("object_key", "") if receipt else ""
    order["receipt_storage_backend"] = receipt.get("storage_backend", "") if receipt else ""
    order["receipt_bucket"] = receipt.get("bucket", "") if receipt else ""
    order["receipt_checksum"] = receipt.get("checksum", "") if receipt else ""
    order["receipt_source"] = "miniapp_multipart" if receipt else "none"
    if receipt:
        receipt["status"] = "used"
        receipt["order_id"] = str(order.get("order_id") or "")
    quote["status"] = "consumed"
    quote["consumed_at"] = utc_iso()
    quote["order_id"] = str(order.get("order_id") or "")
    order["status"] = "pending"
    order["verification_status"] = "pending" if txid else "manual_review"
    order["verification_verified"] = False
    order["rejection_reason"] = ""
    order["cancellation_reason"] = ""
    order["updated_at"] = utc_iso()
    return order_summary(order)
