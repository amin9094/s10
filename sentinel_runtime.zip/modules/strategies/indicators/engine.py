"""Four separately classified models with all directional indicators aligned."""

from __future__ import annotations

from decimal import Decimal as D

from modules.entry_selection import inside_tick
from modules.strategies.common import _candidate, confirmed_swings
from modules.indicator_suite import indicators, agreement, DEFAULT_SELECTION, LEGACY_SELECTION, SUITE_VERSION


def directional_agreement(stats, direction, selected=None):
    if selected is None and 'suite' not in stats:selected=LEGACY_SELECTION
    return agreement(stats,direction,selected)


def protective_stop(context, stats, swings, direction, entry, zone, model):
    """Protect the prospective trade's structure, with a volatility/spread floor.

    ATR is a distance constraint, never a directional vote. A new stop never
    moves a target to manufacture an attractive reward/risk ratio.
    """
    sign = D(1) if direction == 'BUY' else D(-1)
    kind = 'low' if direction == 'BUY' else 'high'
    choices = [s for s in swings if s.kind == kind and sign * (entry - s.value) > 0]
    if not choices:
        return None
    pivot = choices[-1]
    buffer = max(stats['atr'] * context.parameters.stop_buffer_atr,
                 context.spread * 2, context.tick_size * 2)
    minimum = max(stats['atr'], context.spread * 3, context.tick_size * 4)
    boundary = zone[0] if sign == 1 else zone[1]
    candidates = [pivot.value - sign * buffer, boundary - sign * buffer,
                  entry - sign * minimum]
    supertrend=stats.get('suite',{}).get('supertrend',{})
    selection=getattr(context,'indicator_selection',None)
    if ((selection is None or 'supertrend' in selection)
            and supertrend.get('direction')==direction and supertrend.get('line') is not None):
        candidates.append(supertrend['line']-sign*buffer)
    stop = min(candidates) if sign == 1 else max(candidates)
    if stop <= 0:
        return None
    return stop, {'method': 'CONFIRMED_STRUCTURE_ATR_SPREAD_FLOOR',
                  'protective_swing': str(pivot.value), 'swing_available_ms': pivot.available_ms,
                  'buffer': str(buffer), 'minimum_risk_distance': str(minimum),
                  'spread_at_proposal': str(context.spread),
                  'model': model, 'target_levels_moved': False}


class IndicatorsOnly:
    name = "indicators"

    def evaluate(self, context):
        bars, p = context.closed, context.parameters
        stats, swings = indicators(bars), confirmed_swings(bars, p)
        atr, last = stats["atr"], bars[-1]
        if len(swings) < 4 or atr <= 0:
            return []
        output = []
        for direction, sign, kind in [("BUY", D(1), "low"), ("SELL", D(-1), "high")]:
            selected=getattr(context,'indicator_selection',None)
            agreed, votes = directional_agreement(stats, direction, selected)
            if not agreed:
                continue
            protected = [s for s in swings if s.kind == kind]
            opposites = [s for s in swings if s.kind != kind]
            if len(protected) < 2 or not opposites:
                continue
            a, b = protected[-2:]
            buffer = max(context.spread * 2, atr * p.stop_buffer_atr)
            stop = b.value - sign * buffer
            common = {"directional_agreement": votes, "adx": str(stats["adx"]), "atr": str(atr),
                      "ema_periods": [20, 50, 100], "ema_type": "EMA", "atr_is_directional_vote": False,
                      "ma_macd_independent_vote_count_claimed": False}
            common.update(indicator_suite_version=SUITE_VERSION,selected_indicators=list(votes),
                          custom_selection=selected is not None)
            ma = stats["ma"]
            trend = sign * (ma[20][-1] - ma[50][-1]) > 0 and sign * (ma[50][-1] - ma[100][-1]) > 0
            models = []
            if trend and stats["adx"] >= p.adx_trend:
                models.append(("trend_continuation", ma[20][-1], stop, last.end_ms, ["trend", bars[b.index].source_id, bars[opposites[-1].index].source_id]))
            rsi = stats["rsi"]
            divergence = rsi[a.index] is not None and rsi[b.index] is not None and sign * (b.value - a.value) < 0 and sign * (rsi[b.index] - rsi[a.index]) > 0
            if divergence and sign * (stats["macd_hist"][-1] - stats["macd_hist"][-3]) > 0:
                models.append(("early_reversal", b.value, stop, bars[b.index + p.swing_right].end_ms, ["reversal", bars[a.index].source_id, bars[b.index].source_id]))
            if stats["adx"] <= p.adx_range:
                lows = [s for s in swings if s.kind == "low"][-2:]
                highs = [s for s in swings if s.kind == "high"][-2:]
                if len(lows) == len(highs) == 2:
                    low, high = max(s.value for s in lows), min(s.value for s in highs)
                    if low < high:
                        edge = low if direction == "BUY" else high
                        models.append(("range_reversal", edge, edge - sign * buffer, last.end_ms, ["range_reversal", bars[lows[-1].index].source_id, bars[highs[-1].index].source_id]))
                        breakout_edge = high if direction == "BUY" else low
                        models.append(("range_breakout", breakout_edge + sign * context.tick_size, breakout_edge - sign * buffer,
                                       last.end_ms, ["range_breakout", bars[lows[-1].index].source_id, bars[highs[-1].index].source_id]))
            for name, desired, sl, after, thesis in models:
                halfwidth = context.tick_size if name == "range_breakout" else max(context.tick_size, atr * D(".05"))
                zone = desired - halfwidth, desired + halfwidth
                if zone[0] <= 0:
                    continue
                entry = inside_tick(desired, *zone, context.tick_size, direction)
                protection = protective_stop(context, stats, swings, direction, entry, zone, name)
                if protection is None:
                    continue
                sl, stop_detail = protection
                thesis = [SUITE_VERSION, ':'.join(votes), 'indicator-structure-atr-stop-v2', *thesis]
                detail = {**common, "entry_selector": "PROSPECTIVE_BOUNDARY_STOP" if name == "range_breakout" else "PRELOCKED_LEVEL_PULLBACK",
                          "planned_level": str(desired), "forecast_arrival_time_claimed": False,
                          "stop_protection": stop_detail}
                output.append(_candidate(context, self.name, name, direction, zone, entry, sl, swings, thesis,
                                         [("all_directional_indicators", last.available_ms, detail)], fresh_after=after))
        return output
