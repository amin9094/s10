"""One opposing candle, locked causal-wave POC, and explicit review cases."""

from __future__ import annotations

from decimal import Decimal as D

from modules.entry_selection import inside_tick
from modules.fibonacci_geometry import wave_level
from modules.strategies.common import _candidate, confirmed_swings, freshness, indicators
from modules.strategies.fibonacci.engine import causal_wave
from modules.volume_profile import anchored_profile


class OrderBlockVolume:
    name = "order_block"

    def evaluate(self, context):
        bars = context.closed
        p = context.parameters
        swings = confirmed_swings(bars, p)
        atr = indicators(bars)["atr"]
        output = []
        for i in range(20, len(bars) - 2):
            ob, departure = bars[i:i + 2]
            if ob.end_ms!=departure.start_ms or bars[i-1].end_ms!=ob.start_ms:
                continue
            direction = "BUY" if departure.close > departure.open else "SELL"
            sign = D(1) if direction == "BUY" else D(-1)
            if sign * (ob.close - ob.open) > 0 or sign * (bars[i - 1].close - bars[i - 1].open) < 0:
                continue
            if sign * (departure.close - departure.open) < atr * p.displacement_atr:
                continue
            if sign * (departure.close - (ob.high if direction == "BUY" else ob.low)) <= 0:
                continue
            remaining = freshness(context, ob.low, ob.high, after_ms=departure.end_ms)
            if not remaining.get("untouched"):
                continue
            if any(proof.get("ob_source_id") == ob.source_id and proof.get("complete_coverage") and proof.get("no_reentry") is False
                   and proof.get("available_ms", context.cutoff_ms + 1) <= context.cutoff_ms
                   for proof in context.ob_departure_proofs):
                continue
            review = {
                "engine": self.name, "submodel": "causal_wave_poc", "state": "NEEDS_REVIEW",
                "symbol": ob.symbol, "timeframe": ob.timeframe, "provider": ob.provider,
                "venue": ob.venue, "product": ob.product, "direction": direction,
                "original_zone": [str(ob.low), str(ob.high)], "ob_source_id": ob.source_id,
                "available_ms": context.cutoff_ms, "requires_admin_decision": True,
                "profile_id": p.profile_id,
            }
            wave = causal_wave(bars, swings, direction, i, confirmation_right=p.swing_right)
            if not wave:
                output.append({**review, "reason": "CAUSAL_WAVE_NOT_YET_CONFIRMED", "title_fa": "نیازمند بررسی: موج سازندهٔ اردربلاک هنوز تأیید نشده"})
                continue
            start, end = wave
            start_ms, end_ms = bars[start.index].start_ms, bars[end.index].end_ms
            wave_fact = {"start_index": start.index, "end_index": end.index, "start_price": str(start.value),
                         "end_price": str(end.value), "start_ms": start_ms, "end_ms": end_ms,
                         "orientation": "ZERO_AT_START_ONE_AT_END"}
            try:
                value = anchored_profile(context.profile_candles, start_ms=start_ms, end_ms=end_ms,
                                         cutoff_ms=context.cutoff_ms, tick_size=context.tick_size,
                                         parent_bars=tuple(bars[start.index:end.index + 1]),
                                         review_only=getattr(context,'review_only',False))
            except ValueError as exc:
                output.append({**review, "reason": str(exc), "causal_wave":wave_fact,
                               "title_fa": "نیازمند بررسی: دادهٔ پروفایل حجم موج کامل نیست"})
                continue
            if (value["symbol"], value["provider"], value["venue"], value["product"]) != (ob.symbol, ob.provider, ob.venue, ob.product):
                output.append({**review, "reason": "POC_MARKET_MISMATCH", "title_fa": "نیازمند بررسی: منبع POC با اردربلاک یکسان نیست"})
                continue
            fib = wave_level(start.value, end.value, D(".61"))
            poc = D(value["price"])
            wave_fact = {"start_index": start.index, "end_index": end.index, "start_price": str(start.value),
                         "end_price": str(end.value), "start_ms": start_ms, "end_ms": end_ms,
                         "orientation": "ZERO_AT_START_ONE_AT_END"}
            if not ob.low <= poc <= ob.high:
                output.append({**review, "reason": "POC_OUTSIDE_ORIGINAL_OB",
                               "title_fa": "نیازمند بررسی: POC خارج از اوردر بلاک",
                               "poc": value, "fib_061": str(fib), "fib_061_inside": ob.low <= fib <= ob.high,
                               "causal_wave": wave_fact,
                               "explanation_fa": "POC موج سازنده بیرون محدودهٔ اصلی است؛ محل POC، فیبوناچی و بلاک برای تصمیم ادمین ارائه می‌شود."})
                continue
            # Traded volume or approved native tick volume, never quote polling counts.
            kind = ob.volume_kind
            comparison = [b.volume for b in bars[i - 20:i] if b.volume is not None and b.volume_kind == kind]
            allowed_kinds={'reported_tick_proxy'} if getattr(context,'review_only',False) else {'traded','tick_proxy'}
            if kind not in allowed_kinds or departure.volume_kind != kind or departure.volume is None or len(comparison) != 20 or sum(comparison) <= 0:
                output.append({**review, "reason": "NATIVE_VOLUME_QUALITY_UNAVAILABLE", "title_fa": "نیازمند بررسی: کیفیت حجم اردربلاک نامشخص است"})
                continue
            if departure.volume < sum(comparison) / 20 * p.volume_ratio:
                continue
            proof = next((proof for proof in context.ob_departure_proofs
                          if proof.get("ob_source_id") == ob.source_id and proof.get("fully_exited_ms")
                          and proof.get("departure_source_id") == departure.source_id
                          and proof.get("no_reentry") and proof.get("complete_coverage")
                          and proof.get("available_ms", context.cutoff_ms + 1) <= context.cutoff_ms
                          and proof.get("observed_through_ms", 0) >= departure.end_ms
                          and remaining.get("complete_coverage")), None)
            if not proof and not getattr(context,'review_only',False):
                output.append({**review, "reason": "OB_FIRST_DEPARTURE_ORDER_UNPROVEN", "poc": value,
                               "title_fa": "نیازمند بررسی: ترتیب خروج و بازگشت به اردربلاک تأیید نشده"})
                continue
            if proof is None:
                proof={'available_ms':context.cutoff_ms,'native_departure_order_verified':False,
                       'scope':'ADMIN_REVIEW_ONLY_CANDLE_DEPARTURE_NOT_NATIVE_TICK_PROOF'}
            entry = inside_tick(poc, ob.low, ob.high, context.tick_size, direction)
            protected = [s.value for s in swings if s.kind == ("low" if direction == "BUY" else "high") and s.index + p.swing_right <= i + 1]
            invalidation = min([ob.low, *protected[-1:]]) if direction == "BUY" else max([ob.high, *protected[-1:]])
            stop = invalidation - sign * max(context.spread * 2, atr * p.stop_buffer_atr)
            selection = {"selector": "CAUSAL_WAVE_POC", "entry": str(entry), "poc": value,
                         "fib_061": str(fib), "fib_061_is_confirmation": ob.low <= fib <= ob.high}
            output.append(_candidate(context, self.name, "causal_wave_poc", direction, (ob.low, ob.high),
                                     entry, stop, swings, ["ob_impulse", ob.source_id, departure.source_id],
                                     [("ob_full_candle", ob.available_ms, {"index": i}),
                                      ("causal_wave", end.available_ms, wave_fact),
                                      ("entry_selection", context.cutoff_ms, selection),
                                      ("ordered_trade_departure_proof", proof["available_ms"], proof)],
                                     fresh_after=departure.end_ms))
        return output
