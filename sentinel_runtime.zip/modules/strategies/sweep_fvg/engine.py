"""Independent M5/H1 sweep, closed reclaim and CHoCH, untouched FVG."""

from __future__ import annotations

from decimal import Decimal as D

from modules.entry_selection import fvg_entry
from modules.strategies.common import _candidate, confirmed_swings, indicators, Swing
from modules.strategies.liquidity import reversals


class SweepCHoCHFVG:
    name = "sweep_fvg"

    def evaluate(self, context):
        bars, p = context.closed, context.parameters
        swings = confirmed_swings(bars, p)
        atr = indicators(bars)["atr"]
        if atr <= 0:
            return []
        output = []
        for event in reversals(bars, swings, p, atr, context.spread):
            direction, sign = event['direction'], event['sign']
            sweep_index, reclaim, choch = (event[k] for k in ('sweep_index', 'reclaim_index', 'choch_index'))
            pool, structure = event['pool'], event['protected']
            impulse_end = event['impulse_end']
            rejected_gaps = []
            for third in range(event['origin_index'] + 2, impulse_end + 1):
                one, middle, three = bars[third - 2:third + 1]
                if one.end_ms!=middle.start_ms or middle.end_ms!=three.start_ms:
                    continue
                zone = (one.high, three.low) if direction == "BUY" else (three.high, one.low)
                if zone[1] <= zone[0]:
                    continue
                if sign * (middle.close - middle.open) < atr * p.displacement_atr:
                    rejected_gaps.append({'third_index':third,'reason':'RELATED_DIRECTIONAL_DISPLACEMENT_INSUFFICIENT'})
                    continue
                if zone[1] - zone[0] < max(atr * p.min_fvg_atr, context.spread * p.spread_gap_multiple):
                    rejected_gaps.append({'third_index':third,'reason':'FVG_WIDTH_BELOW_ATR_OR_SPREAD_THRESHOLD'})
                    continue
                try:
                    entry, selection = fvg_entry(*zone, direction=direction, tick_size=context.tick_size, pip_size=context.pip_size)
                except ValueError as exc:
                    rejected_gaps.append({'third_index':third,'reason':str(exc)})
                    continue
                extremes = [getattr(b, "low" if direction == "BUY" else "high") for b in bars[sweep_index:max(choch, third) + 1]]
                invalidation = min(extremes + [pool.value]) if direction == "BUY" else max(extremes + [pool.value])
                stop = invalidation - sign * max(context.spread * 2, atr * p.stop_buffer_atr)
                facts = [("sweep_reclaim", bars[reclaim].available_ms, {"pool_index": pool.index, "pool_price":str(pool.value), "sweep_index": sweep_index, "reclaim_index": reclaim,
                                                                     "sweep_extreme":str(min(extremes) if direction == 'BUY' else max(extremes))}),
                         ("closed_choch", bars[choch].available_ms, {"index": choch, "protected_index": structure.index, "protected_price":str(structure.value),
                                                                    "prior_structure":event['prior_structure'],"break_kind":"CHoCH"}),
                         ("fvg_third_close", three.available_ms, {"index": third,
                             "zone_low":str(zone[0]),"zone_high":str(zone[1]),
                             "midpoint":str((zone[0]+zone[1])/2),
                             "formed_ms":three.end_ms,"direction":direction,
                             "candles":[{"start_ms":b.start_ms,"end_ms":b.end_ms,
                                 "open":str(b.open),"high":str(b.high),"low":str(b.low),"close":str(b.close)}
                                 for b in (one,middle,three)]}),
                         ("entry_selection", context.cutoff_ms, selection)]
                ends = [s for s in swings if s.kind == ('high' if direction == 'BUY' else 'low')
                        and s.index >= max(choch, third - 1)]
                if ends:
                    origin = event['origin_index']
                    start = Swing(origin, 'low' if direction == 'BUY' else 'high',
                                  event['sweep_extreme'], bars[choch].available_ms)
                    end = ends[0]
                    if sign * (end.value - start.value) > 0:
                        facts.append(("causal_wave", max(start.available_ms, end.available_ms),
                            {"start_index": start.index, "end_index": end.index,
                             "start_price": str(start.value), "end_price": str(end.value),
                             "anchor_basis": "ACTUAL_SWEEP_EXTREME_TO_CONFIRMED_IMPULSE_END",
                             "orientation": "ZERO_AT_START_ONE_AT_END"}))
                row = _candidate(context, self.name, "liquidity_reversal", direction, zone, entry, stop,
                                 swings, ["sweep-sequence-v3",direction,bars[pool.index].source_id,bars[structure.index].source_id,
                                          bars[choch].source_id], facts, fresh_after=three.end_ms)
                if row.get("plan") or row.get('draft_plan'):
                    row['selection_basis'] = 'FIRST_CHRONOLOGICAL_VALID_FRESH_FVG'
                    row['earlier_disqualified_fvg'] = rejected_gaps
                    output.append(row)
                    break
                rejected_gaps.append({'third_index':third,'reason':row.get('reason')})
        return output
