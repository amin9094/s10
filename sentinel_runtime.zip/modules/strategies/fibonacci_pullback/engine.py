"""Fifth, experimental engine: trend-aligned closed break and first 0.61 return."""

from __future__ import annotations

from decimal import Decimal as D

from modules.entry_selection import inside_tick
from modules.fibonacci_geometry import wave_level, golden_extension_band
from modules.strategies.common import _candidate, confirmed_swings, indicators


class FibonacciPullback:
    name = "fibonacci_pullback"

    def evaluate(self, context):
        bars, p = context.closed, context.parameters
        swings, stats = confirmed_swings(bars, p), indicators(bars)
        atr, ma = stats["atr"], stats["ma"]
        if atr <= 0:
            return []
        output = []
        for direction, sign, first_kind in [("BUY", D(1), "low"), ("SELL", D(-1), "high")]:
            trend = sign * (ma[20][-1] - ma[50][-1]) > 0 and sign * (ma[50][-1] - ma[100][-1]) > 0
            trend = trend and sign * (ma[20][-1] - ma[20][-4]) > 0 and stats["adx"] >= p.adx_trend
            trend = trend and sign * (stats["plus_di"] - stats["minus_di"]) > 0
            if not trend:
                continue
            pairs = [(a, b) for a, b in zip(swings, swings[1:]) if a.index < b.index and a.kind == first_kind and b.kind != first_kind and sign * (b.value - a.value) > atr]
            if not pairs:
                continue
            start, end = pairs[-1]
            if any(a.end_ms!=b.start_ms for a,b in zip(bars[start.index:end.index+1],bars[start.index+1:end.index+1])):
                continue
            level = wave_level(start.value, end.value, D(".61"))
            broken = next((i for i in range(start.index + 1, len(bars))
                           if sign * (bars[i - 1].close - level) <= 0 and sign * (bars[i].close - level) > 0), None)
            if broken is None:
                continue
            zone = (level - context.tick_size / 2, level + context.tick_size / 2)
            entry = inside_tick(level, *zone, context.tick_size, direction)
            sl = wave_level(start.value, end.value, D(".50")) - sign * max(context.spread * 2, atr * p.stop_buffer_atr)
            tp1, tp2 = end.value, wave_level(start.value, end.value, D("1.61"))
            golden_low,golden_high=golden_extension_band(start.value,end.value,convention='two_anchor')
            try:
                tp2=inside_tick(tp2,golden_low,golden_high,context.tick_size,direction)
            except ValueError:
                continue
            if sl <= 0 or sign * (entry - sl) <= 0 or abs(tp1 - entry) / abs(entry - sl) < 2:
                continue
            facts = [("causal_wave", end.available_ms, {"start_index": start.index, "end_index": end.index,
                      "start_price": str(start.value), "end_price": str(end.value), "orientation": "ZERO_AT_START_ONE_AT_END"}),
                     ("closed_061_break", bars[broken].available_ms, {"index": broken, "level": str(level)}),
                     ("experimental_pullback_levels", context.cutoff_ms, {"sl_basis": ".50", "tp1_basis": "1.00", "tp2_basis": "1.61", "first_return_only": True})]
            row = _candidate(context, self.name, "trend_061_first_pullback", direction, zone, entry, sl,
                             swings, ["fib_pullback", bars[start.index].source_id,bars[end.index].source_id,
                                      bars[broken].source_id], facts,
                             fresh_after=bars[broken].end_ms, targets=(tp1, tp2, None))
            row["experimental"] = True
            output.append(row)
        return output
