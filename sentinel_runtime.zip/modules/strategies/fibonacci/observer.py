"""Source-bound shared confirmations of observations, never their entry price."""
from decimal import Decimal as D
from modules.fibonacci_geometry import wave_level,golden_extension_band
from modules.strategies.observations import contiguous,safe_swings


def confirm(context,row):
    bars,p = context.closed,context.parameters
    swings = safe_swings(bars,p)
    subject = row['observation']
    wave = subject.get('causal_wave')
    anchor = None
    if wave:
        pair = [next((s for s in swings if s.index==wave[key]),None) for key in ('start_index','end_index')]
        if all(pair):
            anchor = tuple(pair)
    if anchor is None and row['engine']=='indicators':
        expected = 'low' if row['direction']=='BUY' else 'high'
        anchor = next(((a,b) for a,b in reversed(list(zip(swings,swings[1:])))
                       if a.index<b.index and a.kind==expected and b.kind!=expected and contiguous(bars,a.index,b.index+1)),None)
    levels,factors = {},[]
    low,high = map(D,row['original_zone'])
    if anchor:
        start,end = anchor
        if contiguous(bars,start.index,end.index+1):
            levels = {'0':str(start.value),'1':str(end.value)}
            for ratio in [D('.61')]+([D('.71')] if row['engine']=='sweep_fvg' else []):
                level = wave_level(start.value,end.value,ratio)
                levels[str(ratio)] = str(level)
                if low<=level<=high:
                    factors.append({'kind':'MAIN_WAVE_LEVEL_IN_ZONE','ratio':str(ratio),'price':str(level)})
            for a,b in zip(swings,swings[1:]):
                if a.index>=b.index or a.kind==b.kind or a.value==b.value or (a.index,b.index)==(start.index,end.index) or abs(b.value-a.value)>=abs(end.value-start.value) or not contiguous(bars,a.index,b.index+1):
                    continue
                gl,gh = golden_extension_band(a.value,b.value,convention='two_anchor')
                if gl<=high and gh>=low:
                    factors.append({'kind':'OTHER_MINOR_WAVE_GOLDEN_OVERLAP','anchors':[a.index,b.index],
                                    'anchor_source_ids':[bars[a.index].source_id,bars[b.index].source_id],
                                    'golden_low':str(gl),'golden_high':str(gh)})
    return {'engine':'fibonacci','state':'CONFIRMATION_ONLY','observation_id':subject['observation_id'],
            'main_levels':levels,'confirmations':factors,'confirmed':bool(factors),
            'required_for_entry':False,'is_win_probability':False,'execution_eligible':False,'entry_changed':False}
