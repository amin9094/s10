"""Fourth engine: optional confluence from preconfirmed, separate waves."""

from __future__ import annotations

from decimal import Decimal as D

from modules.fibonacci_geometry import golden_extension_band, wave_level
from modules.strategies.common import confirmed_swings


def causal_wave(bars, swings, direction, origin_index, *, confirmation_right=2):
    kind = "low" if direction == "BUY" else "high"
    starts = [s for s in swings if s.kind == kind and s.index + confirmation_right <= origin_index]
    if not starts:
        return None
    start = starts[-1]
    # First available opposite swing locks the initial wave; later extrema are
    # distinct prospective scenarios and cannot rewrite the original anchors.
    ends = [s for s in swings if s.kind != kind and s.index > origin_index]
    if not ends:
        return None
    end = ends[0]
    sign = D(1) if direction == "BUY" else D(-1)
    if sign * (end.value - start.value) <= 0:
        return None
    return start, end


class Fibonacci:
    name = "fibonacci"

    def evaluate(self, context, candidates=()):
        bars = context.closed
        swings = confirmed_swings(bars, context.parameters)
        result = []
        for row in candidates:
            plan = row.get("plan") or row.get('draft_plan')
            if not plan:
                continue
            details = [fact["detail"] for fact in plan["evidence"] if fact["kind"] == "causal_wave"]
            wave = details[0] if details else None
            anchor = None
            if wave:
                pair = [next((s for s in swings if s.index == wave[key]), None) for key in ("start_index", "end_index")]
                if wave.get('anchor_basis') == 'ACTUAL_SWEEP_EXTREME_TO_CONFIRMED_IMPULSE_END':
                    from modules.strategies.common import Swing
                    pair[0] = Swing(wave['start_index'], 'low' if plan['direction'] == 'BUY' else 'high',
                                    D(wave['start_price']), context.cutoff_ms)
                if all(pair):
                    anchor = tuple(pair)
            if anchor is None and plan['engine'] != 'sweep_fvg':
                origins = [s for s in swings if s.available_ms <= context.cutoff_ms]
                pairs = [(a, b) for a, b in zip(origins, origins[1:]) if a.kind != b.kind]
                expected = "low" if plan["direction"] == "BUY" else "high"
                anchor = next((pair for pair in reversed(pairs) if pair[0].kind == expected), None)
            low, high = D(plan["zone_low"]), D(plan["zone_high"])
            confirmations = []
            main_levels = {}
            if anchor:
                start, end = anchor
                main_levels["0"] = str(start.value)
                main_levels["1"] = str(end.value)
                for ratio in (D(".61"), D(".71")):
                    if ratio == D(".71") and plan["engine"] != "sweep_fvg":
                        continue
                    level = wave_level(start.value, end.value, ratio)
                    main_levels[str(ratio)] = str(level)
                    if low <= level <= high:
                        confirmations.append({"kind": "MAIN_WAVE_LEVEL_IN_ZONE", "ratio": str(ratio), "price": str(level)})
                magnitude = abs(end.value - start.value)
                for a, b in zip(swings, swings[1:]):
                    if a.kind == b.kind or a.index >= b.index or (a.index, b.index) == (start.index, end.index):
                        continue
                    if max(a.available_ms, b.available_ms) > context.cutoff_ms or abs(b.value - a.value) >= magnitude:
                        continue
                    if any(x.end_ms != y.start_ms for x, y in zip(bars[a.index:b.index], bars[a.index + 1:b.index + 1])):
                        continue
                    try:
                        golden_low, golden_high = golden_extension_band(a.value, b.value, convention="two_anchor")
                    except ValueError:
                        continue
                    if golden_low <= high and golden_high >= low:
                        confirmations.append({
                            "kind": "OTHER_MINOR_WAVE_GOLDEN_OVERLAP", "anchors": [a.index, b.index],
                            "anchor_source_ids": [bars[a.index].source_id, bars[b.index].source_id],
                            "golden_low": str(golden_low), "golden_high": str(golden_high),
                            "available_ms": max(a.available_ms, b.available_ms), "convention": "two_anchor",
                        })
            result.append({
                "engine": self.name, "submodel": "shared_confirmation", "state": "CONFIRMATION_ONLY",
                "setup_id": plan["setup_id"], "main_levels": main_levels, "confirmations": confirmations,
                "confirmed": bool(confirmations), "required_for_entry": False,
                "is_win_probability": False, "entry_changed": False,
            })
        return result
