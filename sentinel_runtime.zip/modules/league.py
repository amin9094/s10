from __future__ import annotations

from typing import Any


def _thresholds(db: dict[str, Any] | None = None) -> list[tuple[int, str]]:
    settings = (db or {}).get("league_settings", {}) if isinstance(db, dict) else {}
    return sorted(
        [
            (int(settings.get("bronze_min", 0) or 0), "🥉 برنز"),
            (int(settings.get("silver_min", 100) or 100), "🥈 نقره"),
            (int(settings.get("gold_min", 200) or 200), "🥇 طلا"),
            (int(settings.get("diamond_min", 500) or 500), "💎 الماس"),
        ],
        key=lambda item: item[0],
    )


def get_league(points: int, db: dict[str, Any] | None = None, *, language: str = 'fa') -> str:
    value = int(points)
    current = "🥉 برنز"
    for minimum, label in _thresholds(db):
        if value >= minimum:
            current = label
    return _language_label(current,language)


def league_progress(points: int, db: dict[str, Any] | None = None) -> dict[str, Any]:
    value = int(points)
    thresholds = _thresholds(db)
    current_index = 0
    for index, (minimum, _) in enumerate(thresholds):
        if value >= minimum:
            current_index = index
    current_min, current_label = thresholds[current_index]
    if current_index >= len(thresholds) - 1:
        return {
            "league": current_label,
            "current_min": current_min,
            "next_league": None,
            "next_min": None,
            "remaining": 0,
            "percent": 100,
        }
    next_min, next_label = thresholds[current_index + 1]
    span = max(1, next_min - current_min)
    percent = max(0, min(100, round((value - current_min) * 100 / span)))
    return {
        "league": current_label,
        "current_min": current_min,
        "next_league": next_label,
        "next_min": next_min,
        "remaining": max(0, next_min - value),
        "percent": percent,
    }


def get_level(points: int, db: dict, *, language: str = 'fa') -> str:
    levels = sorted(db.get("settings", {}).get("levels", []), key=lambda item: int(item.get("minPoints", 0)))
    current = "🥉 برنزی"
    for level in levels:
        if int(points) >= int(level.get("minPoints", 0)):
            current = str(level.get("name", current))
    return _language_label(current,language)


def _language_label(value: str,language: str) -> str:
    if language!='en':return value
    return {'🥉 برنز':'🥉 Bronze','🥉 برنزی':'🥉 Bronze','🥈 نقره':'🥈 Silver','🥈 نقره‌ای':'🥈 Silver',
            '🥇 طلا':'🥇 Gold','🥇 طلایی':'🥇 Gold','💎 الماس':'💎 Diamond','💎 الماسی':'💎 Diamond'}.get(value,value)
