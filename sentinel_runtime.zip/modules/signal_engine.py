from __future__ import annotations

from decimal import Decimal, InvalidOperation
import math
import re
from typing import Any

from core.utils import utc_iso
from modules.market_scope import classify_market_symbol, normalize_market_category


def normalize_entries(value: str | list[str]) -> list[str]:
    raw = value if isinstance(value, list) else [part.strip() for part in str(value or "").replace("؛", ",").split(",")]
    entries: list[str] = []
    for item in raw:
        if not str(item).strip():
            continue
        try:
            number = Decimal(str(item).replace(",", "").strip())
        except InvalidOperation as exc:
            raise ValueError("قیمت ورود نامعتبر است") from exc
        if not number.is_finite() or number <= 0:
            raise ValueError("قیمت ورود باید بیشتر از صفر باشد")
        clean = format(number.normalize(), "f")
        if clean not in entries:
            entries.append(clean)
    if not 1 <= len(entries) <= 5:
        raise ValueError("بین ۱ تا ۵ نقطه ورود وارد کنید")
    return entries


def average_entry(entries: list[str]) -> str:
    if not entries:
        raise ValueError("حداقل یک نقطه ورود لازم است")
    numbers = [Decimal(item) for item in entries]
    return format((sum(numbers) / Decimal(len(numbers))).normalize(), "f")


def _partial_close_plan(target_count: int) -> list[float]:
    count = max(0, min(int(target_count), 10))
    if count == 0:
        return []
    base = Decimal(100) / Decimal(count)
    plan = [base.quantize(Decimal("0.01")) for _ in range(count)]
    difference = Decimal(100) - sum(plan)
    plan[-1] += difference
    return [float(value) for value in plan]


def _rr_targets(entry: Decimal, stop: Decimal, targets: list[Any]) -> list[float]:
    risk = abs(entry - stop)
    if risk <= 0:
        return []
    output: list[float] = []
    for target in targets:
        try:
            reward = abs(Decimal(str(target)) - entry)
        except InvalidOperation:
            continue
        output.append(round(float(reward / risk), 4))
    return output


def _positive_signal_level(value: Any) -> Decimal | None:
    if isinstance(value, dict):
        value = next((value[key] for key in ("price", "value", "target") if value.get(key) not in (None, "")), None)
    try:
        text = str(value).strip()
        # Commas denote either valid thousands grouping or a list of entries.
        # Never silently turn an ambiguous list such as "100, 110" into 100110.
        if "," in text:
            if not re.fullmatch(r"[0-9]{1,3}(?:,[0-9]{3})+(?:\.[0-9]+)?", text):
                return None
            text = text.replace(",", "")
        number = Decimal(text)
        return number if number.is_finite() and number > 0 and math.isfinite(float(number)) and float(number) > 0 else None
    except (InvalidOperation, ValueError, TypeError):
        return None


def signal_rr_snapshot(row: dict[str, Any]) -> dict[str, Any]:
    """Use published Entry/SL/TP levels, independent of the market quote.

    An entry zone is not an executed price. Prefer the published entry. Legacy
    ladders without that field use the same arithmetic mean as the publisher.
    Missing/ambiguous levels yield None, never a stored or client-provided RR.
    """
    entry = _positive_signal_level(row.get("entry"))
    if entry is None:
        entry = _positive_signal_level(row.get("entry_price"))
    basis = "published_entry" if entry is not None else "unavailable"
    if entry is None:
        raw_entries = row.get("entries")
        if isinstance(raw_entries, (list, tuple)) and raw_entries:
            parsed_values = [_positive_signal_level(value) for value in raw_entries]
            values = [value for value in parsed_values if value is not None]
            if len(values) == len(parsed_values):
                entry = sum(values, Decimal("0")) / Decimal(len(values))
                basis = "average_entries"
    stop_raw = row.get("stop")
    stop = _positive_signal_level(stop_raw if stop_raw not in (None, "") else row.get("stop_loss"))
    side = str(row.get("side") or "").strip().lower()
    side = {"long": "buy", "short": "sell"}.get(side, side)
    risk = None
    if entry is not None and stop is not None:
        if side == "buy":
            risk = entry - stop
        elif side == "sell":
            risk = stop - entry
    valid_risk = risk is not None and risk > 0
    raw_targets = row.get("targets") or row.get("take_profits") or []
    if isinstance(raw_targets, str):
        raw_targets = [raw_targets] if _positive_signal_level(raw_targets) is not None else re.split(r"[\s,;/|]+", raw_targets.strip())
    elif not isinstance(raw_targets, (list, tuple)):
        raw_targets = [raw_targets]
    targets = []
    for index, raw in enumerate(raw_targets, start=1):
        target = _positive_signal_level(raw)
        valid_reward = bool(target is not None and entry is not None and (
            (side == "buy" and target > entry) or (side == "sell" and target < entry)
        ))
        rr = (
            _rr_targets(entry, stop, [target])[0]
            if valid_risk and valid_reward and entry is not None and stop is not None and target is not None
            else None
        )
        if rr is not None and not math.isfinite(rr):
            rr = None
        targets.append({"label": f"TP{index}", "price": float(target) if target is not None else None, "r": rr})
    return {
        "rr_entry": float(entry) if entry is not None else None,
        "rr_basis": basis,
        "risk_unit": float(risk) if risk is not None and risk > 0 else 0.0,
        "target_rr": targets,
        "risk_reward": targets[0]["r"] if targets else None,
    }


def enrich_signal_payload(payload: dict[str, Any]) -> dict[str, Any]:
    row = dict(payload)
    if row.get("symbol"):
        row["market_category"] = normalize_market_category(
            row.get("market_category"), default=classify_market_symbol(row.get("symbol"))
        )
        from modules.prices import normalize_tracking_symbol

        row.setdefault("display_symbol", str(row.get("symbol") or "").strip())
        try:
            row["market_symbol"] = normalize_tracking_symbol(str(row.get("market_symbol") or row["display_symbol"]))
        except ValueError:
            # Keep manual-only signals usable.  The tracker explicitly marks
            # these records unsupported instead of breaking the entire cycle.
            row["market_symbol"] = ""
            row["tracking_supported"] = False
        else:
            row["tracking_supported"] = True
    source = row.get("entries") or row.get("entry")
    if source:
        entries = normalize_entries(source)
        row["entries"] = entries
        row["entry"] = average_entry(entries)
        row.setdefault("entry_mode", "single" if len(entries) == 1 else "ladder")
    else:
        entries = []
        row.setdefault("entries", [])
        row.setdefault("entry_mode", "single")

    targets = list(row.get("targets", []))
    if "partial_close_plan" not in row or len(list(row.get("partial_close_plan") or [])) != len(targets):
        row["partial_close_plan"] = _partial_close_plan(len(targets))

    if entries and row.get("stop") is not None:
        try:
            row["rr_targets"] = _rr_targets(Decimal(str(row["entry"])), Decimal(str(row["stop"])), targets)
            if row["rr_targets"]:
                row.setdefault("rr", row["rr_targets"][-1])
        except InvalidOperation:
            row.setdefault("rr_targets", [])
    else:
        row.setdefault("rr_targets", [])

    trailing = dict(row.get("trailing_stop") or {})
    trailing.setdefault("enabled", False)
    trailing.setdefault("activate_after_tp", 1)
    trailing.setdefault("distance_percent", 0.0)
    trailing.setdefault("last_price", None)
    row["trailing_stop"] = trailing
    row.setdefault("breakeven_after_tp", 1)
    row.setdefault("max_risk_percent", float(row.get("risk", 0) or 0))

    execution = dict(row.get("execution") or {})
    execution.setdefault("filled_percent", 0.0)
    execution.setdefault("filled_entries", [])
    execution.setdefault("average_fill_price", None)
    execution.setdefault("slippage_percent", 0.0)
    execution.setdefault("closed_percent", 0.0)
    row["execution"] = execution
    row.setdefault("signal_version", 2)
    row.setdefault("updated_at", utc_iso())
    return row


def update_execution(
    row: dict[str, Any],
    *,
    filled_percent: float | None = None,
    filled_entries: list[str] | None = None,
    average_fill_price: float | None = None,
    closed_percent: float | None = None,
    slippage_percent: float | None = None,
    trailing_enabled: bool | None = None,
    trailing_distance_percent: float | None = None,
    last_price: float | None = None,
) -> dict[str, Any]:
    execution = row.setdefault("execution", {})
    if filled_percent is not None:
        execution["filled_percent"] = max(0.0, min(float(filled_percent), 100.0))
    if filled_entries is not None:
        execution["filled_entries"] = list(dict.fromkeys(str(item) for item in filled_entries))
    if average_fill_price is not None:
        execution["average_fill_price"] = float(average_fill_price)
    if closed_percent is not None:
        execution["closed_percent"] = max(0.0, min(float(closed_percent), 100.0))
    if slippage_percent is not None:
        execution["slippage_percent"] = max(-100.0, min(float(slippage_percent), 100.0))
    trailing = row.setdefault("trailing_stop", {})
    if trailing_enabled is not None:
        trailing["enabled"] = bool(trailing_enabled)
    if trailing_distance_percent is not None:
        trailing["distance_percent"] = max(0.0, min(float(trailing_distance_percent), 100.0))
    if last_price is not None:
        trailing["last_price"] = float(last_price)
    row["updated_at"] = utc_iso()
    return row
