"""Persistent work assignments projected from canonical records, never duplicate tasks."""
from __future__ import annotations
from typing import Any
from core.db import next_id
from core.domain import audit
from core.utils import utc_iso, utc_now
from modules.admin_access import has_permission
from modules.operations_handoff import create_shift_handoff

# Entity types and permissions are a fixed whitelist, never executable input.
SOURCES = {
 'payment': ('vip_orders', 'order_id', 'payment_receipts_view'),
 'ticket': ('tickets', 'id', 'tickets'),
 'reward': ('reward_requests', 'id', 'reward_requests'),
 'gift': ('vip_gifts', 'gift_id', 'payment_receipts_view'),
 'campaign': ('marketing_campaigns', 'id', 'campaigns'),
 'signal': ('scheduled_signals', 'id', 'signals'),
 'published_signal': ('signals', 'id', 'signals'),
 'automation': ('automation_v2_dead_letter', 'id', 'automations'),
 'incident': ('incidents', 'id', 'incidents'),
 'approval': ('pending_admin_actions', 'id', 'two_step_approvals'),
 'user': ('users', 'id', 'users'),
 'vip': ('vip_users', 'user_id', 'users'),
 'referral': ('user_referrals', 'user_id', 'users'),
 'coupon': ('discount_codes', 'code', 'discounts'),
 'course': ('lessons', 'id', 'education'),
 'job': ('automation_v2_jobs', 'id', 'automations'),
}
QUEUE_TYPES = {'payment', 'ticket', 'reward', 'gift', 'campaign', 'signal', 'automation', 'incident', 'approval'}
OPEN_STATES = {
 'payment': {'pending', 'approving'}, 'ticket': {'open', 'pending', 'answered'},
 'reward': {'pending', 'requested'}, 'gift': {'pending_payment'},
 'campaign': {'pending', 'pending_approval', 'draft'}, 'signal': {'pending', 'draft', 'scheduled'},
 'automation': {'failed', 'dead', 'pending'}, 'incident': {'open', 'acknowledged'},
 'approval': {'pending'},
}


def records(db: dict, kind: str):
    section, id_field, _ = SOURCES[kind]; raw = db.get(section, {})
    if isinstance(raw, dict):
        return [(str(row.get(id_field) or key), row) for key, row in raw.items() if isinstance(row, dict)]
    return [(str(row.get(id_field) or row.get('order_id') or ''), row) for row in raw if isinstance(row, dict)]


def can_access(db, actor, kind):
    return kind in SOURCES and has_permission(db, actor, SOURCES[kind][2])


def read_entity(db, actor, kind, reference):
    if not can_access(db, actor, kind): raise PermissionError('مجوز مشاهده این بخش را ندارید.')
    return next((dict(row) for rid, row in records(db, kind) if rid == str(reference)), None)


def reconcile_work_queue(db: dict, *, external_payments=None, external_tickets=None) -> dict:
    queue = db.setdefault('admin_work_queue', {}); seen = set(); now = utc_iso()
    for kind in QUEUE_TYPES:
        sources = records(db, kind)
        if kind == 'payment' and external_payments is not None:
            sources += [(str(o['order_id']),o) for o in external_payments]
        if kind == 'ticket' and external_tickets is not None:
            sources += [(str(o['id']),o) for o in external_tickets]
        for reference, entity in sources:
            if not reference: continue
            key = f'{kind}:{reference}'; seen.add(key)
            state = str(entity.get('status') or ('failed' if kind == 'automation' else 'pending'))
            actionable = state in OPEN_STATES[kind]
            if kind == 'ticket' and entity.get('waiting_for') == 'user': actionable = True
            if kind == 'gift' and not entity.get('order_id'): actionable = False
            existing = queue.get(key)
            if not actionable and not existing: continue
            if existing is None:
                existing = {'id': next_id(db, 'work_item'), 'type': kind, 'reference_id': reference,
                            'priority': entity.get('priority') or ('high' if kind in {'payment', 'incident'} else 'normal'),
                            'status': 'open', 'assigned_admin_id': str(entity.get('assigned_admin') or ''),
                            'created_at': entity.get('created_at') or now, 'due_at': entity.get('sla_due_at') or entity.get('due_at'),
                            'metadata': {'normalized': bool(entity.get('normalized_order') or entity.get('normalized_ticket'))}}
                queue[key] = existing
            previous = existing['status']
            if not actionable: existing['status'] = 'completed' if state not in {'cancelled', 'rejected'} else 'cancelled'
            elif kind == 'ticket' and entity.get('waiting_for') == 'user': existing['status'] = 'waiting_user'
            elif previous in {'completed', 'cancelled', 'waiting_user'}: existing['status'] = 'in_progress' if existing.get('assigned_admin_id') else 'open'
            if kind == 'ticket' and not entity.get('normalized_ticket'): existing['assigned_admin_id'] = str(entity.get('assigned_admin') or '')
            existing['last_activity_at'] = entity.get('updated_at') or entity.get('created_at') or existing.get('last_activity_at') or now
            if previous != existing['status']: existing['last_activity_at'] = now
    for key, row in queue.items():
        if row.get('metadata', {}).get('normalized') and ((row['type']=='payment' and external_payments is None) or (row['type']=='ticket' and external_tickets is None)): continue
        if key not in seen and row['status'] not in {'completed', 'cancelled'}:
            row['status'] = 'cancelled'; row['last_activity_at'] = now
    for handoff in db.get('shift_handoffs', []):
        if not handoff.get('entity_type'): continue
        item = queue.get(f"{handoff['entity_type']}:{handoff['entity_id']}")
        if item and item['status'] in {'completed', 'cancelled'} and handoff.get('status') in {'pending', 'accepted'}:
            handoff['status'] = item['status']; handoff['completed_at'] = now
            handoff.setdefault('history', []).append({'status':item['status'], 'at':now, 'note':'source entity completed'})
    return queue


def work_items(db, actor, filter_name='all'):
    queue = reconcile_work_queue(db)
    rows = [dict(r) for r in queue.values() if can_access(db, actor, r['type']) and
            ((r['status'] in {'completed', 'cancelled'}) if filter_name == 'completed' else (r['status'] not in {'completed', 'cancelled'}))]
    if filter_name == 'errors': rows = [r for r in rows if r['type'] in {'automation', 'incident'}]
    if filter_name == 'mine': rows = [r for r in rows if r.get('assigned_admin_id') == str(actor)]
    elif filter_name == 'unassigned': rows = [r for r in rows if not r.get('assigned_admin_id')]
    elif filter_name == 'urgent': rows = [r for r in rows if r['priority'] == 'urgent']
    elif filter_name == 'today': rows = [r for r in rows if str(r.get('due_at') or r['created_at'])[:10] == utc_now().date().isoformat()]
    elif filter_name in QUEUE_TYPES: rows = [r for r in rows if r['type'] == filter_name]
    return sorted(rows, key=lambda r: ({'urgent':0,'high':1,'normal':2,'low':3}.get(r['priority'],2), r.get('due_at') or '9999', r['created_at']))


def work_item(db, actor, item_id):
    row = next((r for r in reconcile_work_queue(db).values() if str(r['id']) == str(item_id)), None)
    if not row: raise ValueError('کار پیدا نشد.')
    if not can_access(db, actor, row['type']): raise PermissionError('مجوز این کار را ندارید.')
    return row


def assign_work(db, actor, item_id):
    row = work_item(db, actor, item_id)
    if row['status'] in {'completed','cancelled'}: raise ValueError('این کار بسته شده است.')
    if row.get('assigned_admin_id') not in {'', str(actor)}: raise ValueError('این کار مسئول دارد؛ از واگذاری استفاده کنید.')
    row.update(assigned_admin_id=str(actor), status='in_progress', last_activity_at=utc_iso())
    if row['type'] == 'ticket' and not row.get('metadata', {}).get('normalized'):
        from modules.support import assign_ticket
        assign_ticket(db, row['reference_id'], actor)
    audit(db, actor, 'work_assigned', str(item_id))
    return dict(row)


def handoff_work(db, actor, item_id, target, note, request_key):
    row = work_item(db, actor, item_id)
    if not can_access(db, target, row['type']): raise PermissionError('مدیر مقصد مجوز لازم را ندارد.')
    previous = next((h for h in db.get('shift_handoffs', []) if h.get('request_key') == request_key and h.get('from_admin_id') == str(actor)), None)
    if previous: return dict(previous)
    if row.get('assigned_admin_id') not in {'', str(actor)}: raise PermissionError('فقط مسئول فعلی می‌تواند واگذار کند.')
    if str(actor) == str(target): raise ValueError('مدیر دیگری را انتخاب کنید.')
    if row['status'] in {'completed','cancelled'}: raise ValueError('کار بسته شده است.')
    handoff = create_shift_handoff(db, from_admin_id=actor, to_admin_id=target, summary=note)
    stored = next(h for h in db['shift_handoffs'] if h['id'] == handoff['id'])
    stored.update(entity_type=row['type'], entity_id=row['reference_id'], work_item_id=row['id'],
                  note=note[:2000], request_key=request_key, status='pending', accepted_at=None, notification_sent_at=None)
    row.update(assigned_admin_id=str(target), status='in_progress', last_activity_at=utc_iso())
    if row['type'] == 'ticket' and not row.get('metadata', {}).get('normalized'):
        from modules.support import assign_ticket
        assign_ticket(db, row['reference_id'], target)
    audit(db, actor, 'work_handoff', f"item={item_id};to={target};handoff={stored['id']}")
    return dict(stored)


def accept_handoff(db, actor, handoff_id):
    row = next((h for h in db.get('shift_handoffs', []) if str(h['id']) == str(handoff_id) and h.get('entity_type')), None)
    if not row or row['to_admin_id'] != str(actor) or not can_access(db, actor, row['entity_type']): raise PermissionError('واگذاری در دسترس نیست.')
    if row['status'] == 'accepted': return dict(row)
    if row['status'] != 'pending': raise ValueError('واگذاری قابل پذیرش نیست.')
    row.update(status='accepted', accepted_at=utc_iso())
    row.setdefault('history', []).append({'status':'accepted', 'admin_id':str(actor), 'at':utc_iso()})
    audit(db, actor, 'handoff_accepted', str(handoff_id))
    return dict(row)


def palette_search(db, actor, query, limit=20):
    query = str(query).strip()[:100]; kind_hint, _, term = query.partition(' ')
    types = [kind_hint] if kind_hint in SOURCES else list(SOURCES)
    if kind_hint == 'signal': types = ['signal', 'published_signal']
    needle = (term if kind_hint in SOURCES else query).lstrip('@').casefold(); found = []
    for kind in types:
        if not can_access(db, actor, kind): continue
        for reference, row in records(db, kind):
            # Never search or return secrets, receipts, or unrestricted metadata.
            label = str(row.get('title') or row.get('name') or row.get('symbol') or row.get('subject') or row.get('first_name') or reference)[:100]
            searchable = f"{reference} {label}"
            if kind == 'user':searchable += f" {row.get('username','')} {row.get('last_name','')} {row.get('telegram_id','')}"
            if kind in {'coupon', 'referral'}:searchable += ' ' + str(row.get('code') or '')
            if needle in searchable.casefold(): found.append({'type':kind, 'reference_id':reference, 'label':label})
            if len(found) >= limit: return found
    return found
