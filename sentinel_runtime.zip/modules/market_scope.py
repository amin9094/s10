from __future__ import annotations

import re
from typing import Any

from modules.market_catalog import ASSET_BY_SYMBOL, normalize_asset_symbol

MARKET_FOREX = "forex"
MARKET_CRYPTO = "crypto"
MARKET_CATEGORIES = (MARKET_FOREX, MARKET_CRYPTO)
MARKET_LABELS = {
    MARKET_FOREX: "فارکس",
    MARKET_CRYPTO: "کریپتو",
}

# The list is intentionally broad enough for manual broker/exchange symbols while
# still treating metals, indices, energy and classic currency pairs as the
# Forex/CFD side of the product, exactly as the UI exposes them.
_CRYPTO_BASES = {
    "BTC", "ETH", "BNB", "SOL", "XRP", "ADA", "DOGE", "TRX", "TON", "DOT",
    "AVAX", "LINK", "LTC", "BCH", "ETC", "XLM", "ATOM", "NEAR", "APT", "ARB",
    "OP", "SUI", "SEI", "INJ", "FIL", "ICP", "UNI", "AAVE", "MKR", "SHIB",
    "PEPE", "WIF", "BONK", "FLOKI", "RUNE", "TIA", "ALGO", "VET", "HBAR",
    "MATIC", "POL", "FTM", "EGLD", "THETA", "SAND", "MANA", "GALA", "KAS",
}
_CRYPTO_QUOTES = ("USDT", "USDC", "FDUSD", "TUSD", "BUSD", "USD", "BTC", "ETH", "EUR")


def normalize_market_category(value: Any, *, default: str = MARKET_FOREX) -> str:
    clean = str(value or "").strip().lower()
    aliases = {
        "fx": MARKET_FOREX,
        "forex": MARKET_FOREX,
        "cfd": MARKET_FOREX,
        "crypto": MARKET_CRYPTO,
        "cryptocurrency": MARKET_CRYPTO,
        "digital": MARKET_CRYPTO,
    }
    return aliases.get(clean, default if default in MARKET_CATEGORIES else MARKET_FOREX)


def classify_market_symbol(symbol: Any) -> str:
    raw = str(symbol or "").strip()
    if not raw:
        return MARKET_FOREX
    try:
        normalized = normalize_asset_symbol(raw)
    except ValueError:
        normalized = re.sub(r"[^A-Z0-9]", "", raw.upper())
    catalog = ASSET_BY_SYMBOL.get(normalized)
    if catalog and catalog.category == MARKET_CRYPTO:
        return MARKET_CRYPTO

    compact = re.sub(r"[^A-Z0-9]", "", raw.upper().split(".", 1)[0])
    for quote in _CRYPTO_QUOTES:
        if compact.endswith(quote) and len(compact) > len(quote):
            base = compact[: -len(quote)]
            if base in _CRYPTO_BASES:
                return MARKET_CRYPTO
    if compact in _CRYPTO_BASES:
        return MARKET_CRYPTO
    return MARKET_FOREX


def market_label(value: Any) -> str:
    return MARKET_LABELS[normalize_market_category(value)]


def signal_market_category(row: dict[str, Any] | None) -> str:
    if not isinstance(row, dict):
        return MARKET_FOREX
    stored = str(row.get("market_category") or "").strip().lower()
    if stored in MARKET_CATEGORIES:
        return stored
    return classify_market_symbol(row.get("symbol"))
