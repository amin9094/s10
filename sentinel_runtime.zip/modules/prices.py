from __future__ import annotations

import asyncio
import logging
import math
import os
import re
import statistics
import time
from dataclasses import dataclass, field, replace
from datetime import UTC, datetime
from typing import Any
from urllib.parse import quote

from core.async_primitives import LoopLocalSemaphore
from core.async_runtime import run_blocking
from core.db import load_db, with_db
from core.http_client import get_json
from core.shared_cache import cache_get, cache_set, reset_shared_cache_for_tests
from modules.market_catalog import asset_title, normalize_asset_symbol
from modules.admin_control_center import is_module_enabled, module_state
from modules.provider_health import record_provider_result, select_healthy_provider

logger = logging.getLogger(__name__)
_CACHE_SECONDS = 20
_CACHE: dict[str, tuple[float, MarketQuote]] = {}
_INFLIGHT: dict[tuple[asyncio.AbstractEventLoop, str], asyncio.Task[MarketQuote]] = {}
_FETCH_LIMITER = LoopLocalSemaphore(12)

_FIAT = {
    "USD",
    "EUR",
    "GBP",
    "JPY",
    "CHF",
    "CAD",
    "AUD",
    "NZD",
    "CNY",
    "HKD",
    "SGD",
    "SEK",
    "NOK",
    "DKK",
    "PLN",
    "CZK",
    "HUF",
    "TRY",
    "AED",
    "SAR",
    "ZAR",
    "MXN",
    "BRL",
    "INR",
    "KRW",
    "IDR",
    "THB",
    "MYR",
    "PHP",
    "ILS",
    "RON",
    "BGN",
    "ISK",
}
_YAHOO = {
    "US100": "^NDX",
    "US500": "^GSPC",
    "US30": "^DJI",
    "GER40": "^GDAXI",
    "UK100": "^FTSE",
    "JP225": "^N225",
    "HK50": "^HSI",
    "VIX": "^VIX",
    "DXY": "DX-Y.NYB",
    "WTI": "CL=F",
    "BRENT": "BZ=F",
    "NATGAS": "NG=F",
    "COPPER": "HG=F",
    "PLATINUM": "PL=F",
    "PALLADIUM": "PA=F",
    "WHEAT": "ZW=F",
    "CORN": "ZC=F",
    "COFFEE": "KC=F",
    "SUGAR": "SB=F",
    "COTTON": "CT=F",
}
_SYMBOL_ALIASES = {
    "GOLD": "XAUUSD",
    "XAU": "XAUUSD",
    "SILVER": "XAGUSD",
    "XAG": "XAGUSD",
    "NASDAQ": "US100",
    "NAS100": "US100",
    "NDX": "US100",
    "SP500": "US500",
    "SPX500": "US500",
    "DOW": "US30",
    "DJI": "US30",
    "DAX": "GER40",
    "DE40": "GER40",
    "FTSE": "UK100",
    "NIKKEI": "JP225",
    "DX": "DXY",
    "CL": "WTI",
    "CRUDE": "WTI",
    "BZ": "BRENT",
    "NG": "NATGAS",
    "BTC": "BTCUSD",
    "BTCUSDT": "BTCUSD",
    "ETH": "ETHUSD",
    "ETHUSDT": "ETHUSD",
    "BNB": "BNBUSD",
    "SOL": "SOLUSD",
}
_SAFE_TICKER = re.compile(r"^[A-Z0-9.^=_-]{1,24}$")
_BROKER_SUFFIXES = (".PRO", ".RAW", ".ECN", ".STD", ".M", "_PRO", "_RAW", "_ECN", "_STD")


@dataclass(frozen=True, slots=True)
class MarketQuote:
    symbol: str
    title: str
    price: float
    source: str
    updated_at: datetime
    change_percent: float | None = None
    high: float | None = None
    low: float | None = None
    open_price: float | None = None
    previous_close: float | None = None
    bid: float | None = None
    ask: float | None = None
    stale: bool = False
    delayed: bool = False
    market_open: bool | None = None
    confidence: float = 1.0
    provider_count: int = 1
    dispersion_bps: float = 0.0
    consensus: bool = False
    fetched_at: datetime = field(default_factory=lambda: datetime.now(UTC))

    @property
    def age_seconds(self) -> float:
        updated = self.updated_at
        if updated.tzinfo is None:
            updated = updated.replace(tzinfo=UTC)
        return max(0.0, (datetime.now(UTC) - updated.astimezone(UTC)).total_seconds())

    def as_dict(self) -> dict[str, Any]:
        return {
            "symbol": self.symbol,
            "title": self.title,
            "price": self.price,
            "source": self.source,
            "updated_at": self.updated_at.isoformat(),
            "fetched_at": self.fetched_at.isoformat(),
            "age_seconds": round(self.age_seconds, 3),
            "change_percent": self.change_percent,
            "high": self.high,
            "low": self.low,
            "open_price": self.open_price,
            "previous_close": self.previous_close,
            "bid": self.bid,
            "ask": self.ask,
            "stale": self.stale,
            "delayed": self.delayed,
            "market_open": self.market_open,
            "confidence": max(0.0, min(1.0, float(self.confidence))),
            "provider_count": max(1, int(self.provider_count)),
            "dispersion_bps": max(0.0, float(self.dispersion_bps)),
            "consensus": bool(self.consensus),
        }


def _quote_from_dict(payload: dict[str, Any]) -> MarketQuote | None:
    try:
        updated = datetime.fromisoformat(str(payload["updated_at"]).replace("Z", "+00:00"))
        fetched = datetime.fromisoformat(str(payload.get("fetched_at") or payload["updated_at"]).replace("Z", "+00:00"))
        return MarketQuote(
            symbol=str(payload["symbol"]),
            title=str(payload.get("title") or payload["symbol"]),
            price=_valid_price(payload["price"]),
            source=str(payload.get("source") or "shared-cache"),
            updated_at=updated,
            change_percent=_optional_float(payload.get("change_percent")),
            high=_optional_float(payload.get("high")),
            low=_optional_float(payload.get("low")),
            open_price=_optional_float(payload.get("open_price")),
            previous_close=_optional_float(payload.get("previous_close")),
            bid=_optional_float(payload.get("bid")),
            ask=_optional_float(payload.get("ask")),
            stale=bool(payload.get("stale", False)),
            delayed=bool(payload.get("delayed", False)),
            market_open=payload.get("market_open") if isinstance(payload.get("market_open"), bool) else None,
            confidence=float(payload.get("confidence", 1.0) or 0.0),
            provider_count=max(1, int(payload.get("provider_count", 1) or 1)),
            dispersion_bps=max(0.0, float(payload.get("dispersion_bps", 0) or 0)),
            consensus=bool(payload.get("consensus", False)),
            fetched_at=fetched,
        )
    except (KeyError, TypeError, ValueError, RuntimeError):
        return None


def normalize_market_symbol(symbol: str) -> str:
    clean = str(symbol or "").upper().replace("/", "").replace(" ", "").strip()
    clean = _SYMBOL_ALIASES.get(clean, clean)
    return normalize_asset_symbol(clean)


def normalize_tracking_symbol(symbol: str) -> str:
    """Normalize broker/exchange aliases to the canonical market symbol.

    Signal authors often paste values such as ``BTC/USDT``, ``BINANCE:BTCUSDT``,
    ``XAUUSD.pro`` or ``EURUSDm``.  Public quote lookup and candle tracking must
    use one stable key or a perfectly valid signal can remain untracked forever.
    The display symbol is intentionally preserved elsewhere.
    """
    clean = str(symbol or "").strip().upper()
    if ":" in clean:
        clean = clean.rsplit(":", 1)[-1]
    clean = clean.replace("/", "").replace(" ", "")
    if clean.endswith("-USDT"):
        clean = clean[:-5] + "USDT"
    elif clean.endswith("-USD"):
        clean = clean[:-4] + "USD"
    for suffix in _BROKER_SUFFIXES:
        if clean.endswith(suffix):
            clean = clean[: -len(suffix)]
            break
    # A very common MetaTrader convention is a single trailing ``m`` suffix.
    # Only strip it when the remaining symbol is a known six-character FX/metal
    # pair, avoiding accidental changes to ordinary stock tickers.
    if len(clean) == 7 and clean.endswith("M") and re.fullmatch(r"[A-Z]{6}M", clean):
        candidate = clean[:-1]
        if candidate[:3] in _FIAT | {"XAU", "XAG"} and candidate[3:] in _FIAT | {"USD"}:
            clean = candidate
    return normalize_market_symbol(clean)


async def _get_json(
    url: str,
    *,
    params: dict[str, Any] | None = None,
    headers: dict[str, str] | None = None,
) -> Any:
    try:
        request_headers = {"User-Agent": "SENTINELBot/6.12"}
        request_headers.update(headers or {})
        async with _FETCH_LIMITER():
            return await get_json(
                url,
                params=params,
                headers=request_headers,
                retries=2,
            )
    except Exception as exc:
        raise RuntimeError("سرویس قیمت در دسترس نیست") from exc


def _valid_price(value: Any) -> float:
    try:
        price = float(value)
    except (TypeError, ValueError) as exc:
        raise RuntimeError("پاسخ سرویس قیمت نامعتبر بود") from exc
    if not math.isfinite(price) or price <= 0:
        raise RuntimeError("قیمت دریافت‌شده نامعتبر بود")
    return price


def _optional_float(value: Any) -> float | None:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if math.isfinite(number) else None


def _change_percent(price: float, previous: float | None) -> float | None:
    if previous is None or previous <= 0:
        return None
    return (price - previous) / previous * 100


async def _yahoo_quote(ticker: str, symbol: str) -> MarketQuote:
    payload = await _get_json(
        f"https://query1.finance.yahoo.com/v8/finance/chart/{quote(ticker, safe='')}",
        params={"interval": "1m", "range": "1d", "includePrePost": "true"},
    )
    result = (((payload or {}).get("chart") or {}).get("result") or [None])[0]
    if not isinstance(result, dict):
        raise RuntimeError("پاسخ سرویس بازار نامعتبر بود")
    meta = result.get("meta") or {}
    quote_rows = ((result.get("indicators") or {}).get("quote") or [{}])[0] or {}
    value = meta.get("regularMarketPrice")
    closes = quote_rows.get("close", []) if isinstance(quote_rows, dict) else []
    if value is None:
        value = next((item for item in reversed(closes) if item is not None), None)
    price = _valid_price(value)
    previous = _optional_float(meta.get("chartPreviousClose") or meta.get("previousClose"))
    highs = [float(item) for item in quote_rows.get("high", []) if item is not None]
    lows = [float(item) for item in quote_rows.get("low", []) if item is not None]
    opens = [float(item) for item in quote_rows.get("open", []) if item is not None]
    market_time = meta.get("regularMarketTime")
    updated = datetime.fromtimestamp(int(market_time), tz=UTC) if market_time else datetime.now(UTC)
    return MarketQuote(
        symbol=symbol,
        title=asset_title(symbol),
        price=price,
        source="Yahoo Finance",
        updated_at=updated,
        change_percent=_change_percent(price, previous),
        high=max(highs) if highs else _optional_float(meta.get("regularMarketDayHigh")),
        low=min(lows) if lows else _optional_float(meta.get("regularMarketDayLow")),
        open_price=opens[0] if opens else _optional_float(meta.get("regularMarketOpen")),
        previous_close=previous,
        bid=_optional_float(meta.get("bid")),
        ask=_optional_float(meta.get("ask")),
        delayed=bool(int(meta.get("exchangeDataDelayedBy", 0) or 0) > 0),
        market_open=str(meta.get("marketState") or "").upper() in {"REGULAR", "PRE", "POST"},
        confidence=0.9,
    )


async def _metal_quote(symbol: str) -> MarketQuote:
    from services.market_reference_service import gold_reference
    reference = await gold_reference(symbol)
    return MarketQuote(
        symbol,
        asset_title(symbol),
        _valid_price(reference['price']),
        "Gold-API" if reference['provider']=='gold_api' else "GoldPriceToday.ir (snapshot time; asset time unverified)",
        datetime.fromisoformat(reference['updated_at']),
        market_open=reference['state']=='CURRENT_REFERENCE' if reference['provider']=='gold_api' else None,
        delayed=reference['provider']!='gold_api',
        stale=reference['state']=='STALE_OR_SESSION_CLOSED',
        confidence=0.8 if reference['provider']=='gold_api' else 0.5,
    )


async def _forex_quote(symbol: str) -> MarketQuote:
    base, counter = symbol[:3], symbol[3:]
    payload = await _get_json(f"https://api.frankfurter.dev/v1/latest?base={base}&symbols={counter}")
    value = payload.get("rates", {}).get(counter) if isinstance(payload, dict) else None
    price = _valid_price(value)
    market_date = str(payload.get("date") or "") if isinstance(payload, dict) else ""
    try:
        updated = datetime.fromisoformat(market_date).replace(tzinfo=UTC)
    except ValueError:
        updated = datetime.now(UTC)
    return MarketQuote(
        symbol,
        asset_title(symbol),
        price,
        "Frankfurter/ECB",
        updated,
        delayed=True,
        market_open=False,
        confidence=0.65,
    )


async def _binance_quote(symbol: str) -> MarketQuote:
    base = symbol
    if base.endswith("USDT"):
        pair = base
        shown = f"{base[:-4]}USD"
    elif base.endswith("USD"):
        pair = f"{base[:-3]}USDT"
        shown = base
    else:
        pair = f"{base}USDT"
        shown = f"{base}USD"
    payload = await _get_json("https://api.binance.com/api/v3/ticker/24hr", params={"symbol": pair})
    if not isinstance(payload, dict):
        raise RuntimeError("پاسخ بایننس نامعتبر بود")
    price = _valid_price(payload.get("lastPrice"))
    close_ms = payload.get("closeTime")
    updated = datetime.fromtimestamp(int(close_ms) / 1000, tz=UTC) if close_ms else datetime.now(UTC)
    return MarketQuote(
        shown,
        asset_title(shown),
        price,
        "Binance",
        updated,
        change_percent=_optional_float(payload.get("priceChangePercent")),
        high=_optional_float(payload.get("highPrice")),
        low=_optional_float(payload.get("lowPrice")),
        open_price=_optional_float(payload.get("openPrice")),
        bid=_optional_float(payload.get("bidPrice")),
        ask=_optional_float(payload.get("askPrice")),
        market_open=True,
        confidence=0.98,
    )


async def _coinbase_quote(symbol: str) -> MarketQuote:
    base = symbol[:-4] if symbol.endswith("USDT") else symbol[:-3] if symbol.endswith("USD") else symbol
    product = f"{base}-USD"
    payload = await _get_json(f"https://api.exchange.coinbase.com/products/{quote(product, safe='-')}/ticker")
    if not isinstance(payload, dict):
        raise RuntimeError("پاسخ Coinbase نامعتبر بود")
    updated_raw = str(payload.get("time") or "")
    try:
        updated = datetime.fromisoformat(updated_raw.replace("Z", "+00:00")).astimezone(UTC)
    except ValueError:
        updated = datetime.now(UTC)
    shown = f"{base}USD"
    return MarketQuote(
        shown,
        asset_title(shown),
        _valid_price(payload.get("price")),
        "Coinbase Exchange",
        updated,
        bid=_optional_float(payload.get("bid")),
        ask=_optional_float(payload.get("ask")),
        market_open=True,
        confidence=0.98,
    )


_COINGECKO_IDS = {
    "BTC": "bitcoin",
    "ETH": "ethereum",
    "BNB": "binancecoin",
    "SOL": "solana",
    "XRP": "ripple",
    "ADA": "cardano",
    "DOGE": "dogecoin",
    "TRX": "tron",
    "AVAX": "avalanche-2",
    "DOT": "polkadot",
    "LINK": "chainlink",
    "LTC": "litecoin",
    "BCH": "bitcoin-cash",
    "TON": "the-open-network",
    "SHIB": "shiba-inu",
}


async def _coingecko_quote(symbol: str) -> MarketQuote:
    base = symbol[:-4] if symbol.endswith("USDT") else symbol[:-3] if symbol.endswith("USD") else symbol
    coin_id = _COINGECKO_IDS.get(base)
    if not coin_id:
        raise RuntimeError("نماد در فهرست تأییدشده CoinGecko نیست")
    headers: dict[str, str] = {}
    demo_key = os.getenv("COINGECKO_DEMO_API_KEY", "").strip()
    if demo_key:
        headers["x-cg-demo-api-key"] = demo_key
    payload = await _get_json(
        "https://api.coingecko.com/api/v3/simple/price",
        params={"ids": coin_id, "vs_currencies": "usd", "include_last_updated_at": "true"},
        headers=headers,
    )
    row = payload.get(coin_id, {}) if isinstance(payload, dict) else {}
    updated = (
        datetime.fromtimestamp(int(row.get("last_updated_at")), tz=UTC)
        if row.get("last_updated_at")
        else datetime.now(UTC)
    )
    shown = f"{base}USD"
    return MarketQuote(
        shown,
        asset_title(shown),
        _valid_price(row.get("usd")),
        "CoinGecko",
        updated,
        market_open=True,
        confidence=0.9,
    )


async def _twelve_data_quote(symbol: str) -> MarketQuote:
    api_key = os.getenv("TWELVE_DATA_API_KEY", "").strip()
    if not api_key:
        raise RuntimeError("TWELVE_DATA_API_KEY تنظیم نشده است")
    if len(symbol) == 6 and symbol[:3] in _FIAT | {"XAU", "XAG"}:
        provider_symbol = f"{symbol[:3]}/{symbol[3:]}"
    elif symbol.endswith("USDT"):
        provider_symbol = f"{symbol[:-4]}/USD"
    elif symbol.endswith("USD"):
        provider_symbol = f"{symbol[:-3]}/USD"
    else:
        provider_symbol = symbol
    payload = await _get_json(
        "https://api.twelvedata.com/price",
        params={"symbol": provider_symbol, "apikey": api_key},
    )
    if not isinstance(payload, dict) or payload.get("status") == "error":
        raise RuntimeError("پاسخ Twelve Data نامعتبر بود")
    return MarketQuote(
        symbol,
        asset_title(symbol),
        _valid_price(payload.get("price")),
        "Twelve Data",
        datetime.now(UTC),
        confidence=0.96,
    )


def _provider_attempts(clean: str) -> list[tuple[str, Any]]:
    if clean in {"XAUUSD", "XAGUSD"}:
        attempts = [
            ("Gold-API", lambda: _metal_quote(clean)),
        ]
        if os.getenv("TWELVE_DATA_API_KEY", "").strip():
            attempts.append(("Twelve Data", lambda: _twelve_data_quote(clean)))
        return attempts
    if len(clean) == 6 and clean[:3] in _FIAT and clean[3:] in _FIAT:
        attempts = [
            ("Yahoo Finance", lambda: _yahoo_quote({'USDJPY':'JPY=X','USDCHF':'CHF=X','USDCAD':'CAD=X'}.get(clean,f"{clean}=X"), clean)),
            ("Frankfurter/ECB", lambda: _forex_quote(clean)),
        ]
        if os.getenv("TWELVE_DATA_API_KEY", "").strip():
            attempts.append(("Twelve Data", lambda: _twelve_data_quote(clean)))
        return attempts
    if clean in _YAHOO:
        return [("Yahoo Finance", lambda: _yahoo_quote(_YAHOO[clean], clean))]
    if clean.endswith("USD") or clean.endswith("USDT"):
        if not _SAFE_TICKER.fullmatch(clean):
            raise ValueError("این نماد پشتیبانی نمی‌شود")
        base = clean[:-4] if clean.endswith("USDT") else clean[:-3]
        yahoo_ticker = f"{base}-USD"
        attempts = [
            ("Binance", lambda: _binance_quote(clean)),
            ("Coinbase Exchange", lambda: _coinbase_quote(clean)),
            ("Yahoo Finance", lambda: _yahoo_quote(yahoo_ticker, f"{base}USD")),
        ]
        if base in _COINGECKO_IDS:
            attempts.append(("CoinGecko", lambda: _coingecko_quote(clean)))
        if os.getenv("TWELVE_DATA_API_KEY", "").strip():
            attempts.append(("Twelve Data", lambda: _twelve_data_quote(clean)))
        return attempts
    if _SAFE_TICKER.fullmatch(clean):
        return [("Yahoo Finance", lambda: _yahoo_quote(clean, clean))]
    raise ValueError("این نماد در بخش قیمت بازار پشتیبانی نمی‌شود")


def provider_names_for_symbols(symbols: list[str] | tuple[str, ...] | set[str]) -> set[str]:
    """Return the concrete provider registry used for representative symbols."""
    names: set[str] = set()
    for raw in symbols:
        try:
            clean = normalize_market_symbol(str(raw or ""))
            if not clean:
                continue
            names.update(name for name, _ in _provider_attempts(clean))
            if clean in {'XAUUSD','XAGUSD'}:
                names.add('GoldPriceToday.ir')
        except (ValueError, RuntimeError):
            continue
    return names


def _consensus_quote(clean: str, quotes: list[MarketQuote]) -> MarketQuote:
    if not quotes:
        raise RuntimeError("هیچ قیمت معتبری دریافت نشد")
    if len(quotes) == 1:
        return replace(
            quotes[0],
            confidence=min(float(quotes[0].confidence), 0.82),
            provider_count=1,
            consensus=False,
        )
    prices = [row.price for row in quotes]
    median_price = float(statistics.median(prices))
    threshold_bps = (
        40.0
        if len(clean) == 6 and clean[:3] in _FIAT and clean[3:] in _FIAT
        else 100.0
        if clean in {"XAUUSD", "XAGUSD"}
        else 180.0
        if clean.endswith(("USD", "USDT"))
        else 120.0
    )
    accepted = [
        row
        for row in quotes
        if abs(row.price - median_price) / median_price * 10_000 <= threshold_bps
    ]
    if not accepted:
        accepted = [min(quotes, key=lambda row: abs(row.price - median_price))]
    final_price = float(statistics.median(row.price for row in accepted))
    dispersion = (
        (max(row.price for row in accepted) - min(row.price for row in accepted))
        / final_price
        * 10_000
        if len(accepted) > 1
        else 0.0
    )
    primary = max(
        accepted,
        key=lambda row: (
            float(row.confidence),
            -abs(row.price - final_price),
            row.updated_at.timestamp(),
        ),
    )
    bids = [row.bid for row in accepted if row.bid is not None]
    asks = [row.ask for row in accepted if row.ask is not None]
    confidence = min(
        0.99,
        0.74 + min(0.18, 0.06 * len(accepted)) + max(0.0, 0.07 * (1 - dispersion / max(1.0, threshold_bps))),
    )
    return replace(
        primary,
        symbol=clean[:-4] + "USD" if clean.endswith("USDT") else clean,
        price=final_price,
        source="Consensus: " + " + ".join(row.source for row in accepted),
        updated_at=max(row.updated_at for row in accepted),
        bid=float(statistics.median(bids)) if bids else None,
        ask=float(statistics.median(asks)) if asks else None,
        stale=all(row.stale for row in accepted),
        delayed=all(row.delayed for row in accepted),
        confidence=confidence,
        provider_count=len(accepted),
        dispersion_bps=round(dispersion, 3),
        consensus=len(accepted) >= 2,
    )


async def _fetch_market_quote_uncached(clean: str) -> MarketQuote:
    attempts = _provider_attempts(clean)
    db = await run_blocking(load_db, timeout=10)
    tracker = module_state(db, "tracker")
    failover = bool(
        is_module_enabled(db, "tracker")
        and tracker.get("multi_provider", True)
        and tracker.get("auto_failover", True)
    )
    names = [name for name, _ in attempts]
    # Keep finite Twelve credits for candle history when public reference feeds
    # are working. A consensus display must not poll every paid fallback.
    preferred_names = [name for name in names if name!='Twelve Data'] or names
    preferred = select_healthy_provider(db, preferred_names) if failover else preferred_names[0]
    if preferred:
        attempts.sort(key=lambda item: item[0] != preferred)
    if not failover:
        attempts = attempts[:1]
    async def run_provider(provider: str, fetcher: Any) -> MarketQuote | Exception:
        started = time.monotonic()
        try:
            quote_row = await fetcher()
            actual_provider='GoldPriceToday.ir' if provider=='Gold-API' and quote_row.source.startswith('GoldPriceToday.ir') else provider
            await run_blocking(
                with_db, lambda current, row=quote_row, elapsed=(time.monotonic() - started) * 1000: record_provider_result(
                    current,
                    actual_provider,
                    success=True,
                    latency_ms=elapsed,
                    price=row.price,
                    symbol=clean,
                ), timeout=10
            )
            return quote_row
        except Exception as exc:
            await run_blocking(
                with_db, lambda current, error=exc, elapsed=(time.monotonic() - started) * 1000: record_provider_result(
                    current,
                    provider,
                    success=False,
                    latency_ms=elapsed,
                    symbol=clean,
                    error=error.__class__.__name__,
                ), timeout=10
            )
            return exc

    if not failover:
        attempts = attempts[:1]
    ordinary = [(name,fetcher) for name,fetcher in attempts if name!='Twelve Data']
    deferred = [(name,fetcher) for name,fetcher in attempts if name=='Twelve Data']
    results = list(await asyncio.gather(*(run_provider(name,fetcher) for name,fetcher in ordinary)))
    if not any(isinstance(row,MarketQuote) for row in results):
        results.extend(await asyncio.gather(*(run_provider(name,fetcher) for name,fetcher in deferred)))
    quotes = [row for row in results if isinstance(row, MarketQuote)]
    errors = [row for row in results if isinstance(row, Exception)]
    if quotes:
        return _consensus_quote(clean, quotes)
    cached = _CACHE.get(clean)
    if cached:
        return replace(
            cached[1],
            stale=True,
            delayed=True,
            confidence=min(0.35, float(cached[1].confidence)),
            source=f"{cached[1].source} (last-known-good)",
        )
    raise RuntimeError("همه منابع قیمت موقتاً در دسترس نیستند") from (
        errors[-1] if errors else None
    )


async def fetch_market_quote(symbol: str, *, force: bool = False) -> MarketQuote:
    clean = normalize_market_symbol(symbol)
    cached = _CACHE.get(clean)
    if not force and cached and time.monotonic() - cached[0] < _CACHE_SECONDS:
        return cached[1]
    if not force:
        shared = await cache_get("market-quote", clean)
        if isinstance(shared, dict):
            shared_quote = _quote_from_dict(shared)
            if shared_quote is not None and not shared_quote.stale:
                _CACHE[clean] = (time.monotonic(), shared_quote)
                return shared_quote

    key = (asyncio.get_running_loop(), clean)
    existing = _INFLIGHT.get(key)
    if existing is not None and not existing.done():
        return await asyncio.shield(existing)

    async def finalized_quote() -> MarketQuote:
        quote_row = await _fetch_market_quote_uncached(clean)
        age = quote_row.age_seconds
        if "Frankfurter/ECB" in quote_row.source and quote_row.provider_count == 1:
            stale_after = 72 * 3600
        elif "Yahoo Finance" in quote_row.source and quote_row.provider_count == 1:
            stale_after = 30 * 60
        else:
            stale_after = 10 * 60
        quote_row = replace(
            quote_row,
            stale=bool(quote_row.stale or age > stale_after),
            confidence=max(0.0, min(1.0, float(quote_row.confidence))),
        )
        _CACHE[clean] = (time.monotonic(), quote_row)
        await cache_set("market-quote", clean, quote_row.as_dict(), ttl_seconds=_CACHE_SECONDS)
        return quote_row

    task = asyncio.create_task(finalized_quote(), name=f"market-quote:{clean}")
    _INFLIGHT[key] = task

    def completed(done: asyncio.Task[MarketQuote]) -> None:
        if _INFLIGHT.get(key) is done:
            _INFLIGHT.pop(key, None)
        # A timed-out reader may leave the shared provider task running. Consume
        # its exception and retain the task until completion for other readers.
        if not done.cancelled():
            done.exception()

    task.add_done_callback(completed)
    return await asyncio.shield(task)


async def fetch_price(symbol: str) -> float:
    return (await fetch_market_quote(symbol)).price


async def fetch_prices(symbols: list[str] | set[str], *, force: bool = False) -> dict[str, MarketQuote | Exception]:
    unique = list(dict.fromkeys(normalize_market_symbol(item) for item in symbols))
    results = await asyncio.gather(*(fetch_market_quote(item, force=force) for item in unique), return_exceptions=True)
    return dict(zip(unique, results, strict=True))


def clear_price_cache_for_tests() -> None:
    _CACHE.clear()
    for task in list(_INFLIGHT.values()):
        if not task.done():
            loop = task.get_loop()
            if not loop.is_closed():
                loop.call_soon_threadsafe(task.cancel)
    _INFLIGHT.clear()
    reset_shared_cache_for_tests()
