from __future__ import annotations

import math

from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from typing import Any
from zoneinfo import ZoneInfo

from core.metrics_v2 import action_result
from core.storage.engine import DatabaseEngine, normalized_engine
from repositories.v2.accounts import AccountRepository
from repositories.v2.common import json_dump, json_load, new_id, utc_iso
from repositories.v2.positions import PositionRepository

DEFAULT_RULES: dict[str, Any] = {
    "daily_loss_percent": 5.0,
    "total_loss_percent": 10.0,
    "profit_target_percent": 8.0,
    "daily_loss_basis": "equity",  # balance | equity
    "total_drawdown_mode": "static",  # static | trailing
    "include_floating_in_daily_loss": True,
    "include_commission_swap_fees": True,
    "daily_reset_timezone": "UTC",
    "daily_reset_hour": 0,
    "max_open_risk_percent": 5.0,
    "max_open_trades": 5,
    "min_trading_days": 5,
    "news_restriction_minutes_before": 0,
    "news_restriction_minutes_after": 0,
    "weekend_holding_allowed": True,
    "overnight_holding_allowed": True,
    "consistency_rule_percent": 0.0,
    "data_max_age_seconds": 900,
    "minimum_data_confidence": 0.6,
}


@dataclass(frozen=True)
class RuleDecision:
    decision: str
    hard_blocks: tuple[dict[str, Any], ...]
    warnings: tuple[dict[str, Any], ...]
    metrics: dict[str, Any]
    template_id: str
    rules_version: int

    @property
    def allowed(self) -> bool:
        return not self.hard_blocks


class PropRuleEngine:
    """Versioned, auditable prop/personal risk rule evaluator.

    Every decision is based on normalized account, PnL-event and equity-event
    rows. Hard blocks cannot be overridden by the Mini App. Warnings may be
    acknowledged by the user but are retained in the evaluation audit trail.
    """

    def __init__(self, engine: DatabaseEngine | None = None):
        self.engine = engine or normalized_engine()
        self.accounts = AccountRepository(self.engine)
        self.positions = PositionRepository(self.engine)
        self.seed_defaults()

    def seed_defaults(self) -> None:
        templates = (
            (
                "personal-standard", "SENTINEL", "Personal Standard", 1,
                {**DEFAULT_RULES, "daily_loss_percent": 100.0, "total_loss_percent": 100.0, "min_trading_days": 0},
            ),
            ("prop-static-5-10", "Generic", "Static 5/10", 1, DEFAULT_RULES),
            (
                "prop-trailing-4", "Generic", "Trailing 4%", 1,
                {**DEFAULT_RULES, "daily_loss_percent": 4.0, "total_loss_percent": 4.0, "total_drawdown_mode": "trailing"},
            ),
        )
        now = utc_iso()
        with self.engine.transaction() as cursor:
            for template_id, provider, name, version, rules in templates:
                cursor.execute(
                    """INSERT INTO v8_prop_rule_templates(id,provider,name,version,active,rules,created_at,updated_at)
                       VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(id) DO NOTHING""",
                    (template_id, provider, name, version, 1, json_dump(rules), now, now),
                )

    def create_template(
        self,
        *,
        provider: str,
        name: str,
        rules: dict[str, Any],
        version: int = 1,
        template_id: str | None = None,
    ) -> dict[str, Any]:
        merged = self._validate_rules({**DEFAULT_RULES, **rules})
        now = utc_iso()
        row = {
            "id": template_id or new_id("rule"),
            "provider": str(provider)[:80],
            "name": str(name)[:120],
            "version": max(1, int(version)),
            "active": True,
            "rules": merged,
            "created_at": now,
            "updated_at": now,
        }
        with self.engine.transaction() as cursor:
            cursor.execute(
                """INSERT INTO v8_prop_rule_templates(id,provider,name,version,active,rules,created_at,updated_at)
                   VALUES(?,?,?,?,?,?,?,?)""",
                (row["id"], row["provider"], row["name"], row["version"], 1, json_dump(merged), now, now),
            )
        return row

    def list_templates(self, *, provider: str = "", active_only: bool = True) -> list[dict[str, Any]]:
        clauses: list[str] = []
        params: list[Any] = []
        if provider:
            clauses.append("provider=?")
            params.append(str(provider))
        if active_only:
            clauses.append("active=1")
        where = f" WHERE {' AND '.join(clauses)}" if clauses else ""
        with self.engine.transaction(read_only=True) as cursor:
            rows = cursor.execute(
                f"SELECT * FROM v8_prop_rule_templates{where} ORDER BY provider,name,version DESC",  # nosec B608
                params,
            ).fetchall()
        return [
            {
                "id": row["id"], "provider": row["provider"], "name": row["name"],
                "version": int(row["version"]), "active": bool(row["active"]),
                "rules": json_load(row["rules"], {}) or {}, "updated_at": str(row["updated_at"]),
            }
            for row in rows
        ]

    def get_template(self, template_id: str | None) -> dict[str, Any]:
        target = template_id or "personal-standard"
        with self.engine.transaction(read_only=True) as cursor:
            row = cursor.execute(
                "SELECT * FROM v8_prop_rule_templates WHERE id=? AND active=1",
                (target,),
            ).fetchone()
        if not row:
            raise ValueError("PROP_RULE_TEMPLATE_NOT_FOUND")
        return {
            "id": row["id"], "provider": row["provider"], "name": row["name"],
            "version": int(row["version"]), "rules": json_load(row["rules"], {}) or {},
        }

    def evaluate(
        self,
        *,
        user_id: int | str,
        account_id: str | int,
        candidate: dict[str, Any] | None = None,
        news_events: list[dict[str, Any]] | None = None,
        evaluated_at: str | None = None,
        record: bool = True,
    ) -> RuleDecision:
        started = datetime.now(UTC)
        ok = False
        try:
            result = self._evaluate(
                user_id=user_id,
                account_id=account_id,
                candidate=candidate,
                news_events=news_events,
                evaluated_at=evaluated_at,
            )
            if record:
                self._record(user_id, account_id, candidate, result)
            ok = True
            return result
        finally:
            action_result("prop_rule_evaluation", ok=ok, duration=(datetime.now(UTC) - started).total_seconds())

    def _evaluate(
        self,
        *,
        user_id: int | str,
        account_id: str | int,
        candidate: dict[str, Any] | None,
        news_events: list[dict[str, Any]] | None,
        evaluated_at: str | None,
    ) -> RuleDecision:
        account = self.accounts.get(user_id, account_id)
        if not account:
            raise ValueError("TRADING_ACCOUNT_NOT_FOUND")
        template = self.get_template(str(account.get("rule_template_id") or "personal-standard"))
        rules = self._validate_rules({**DEFAULT_RULES, **template["rules"]})
        for field, personal in (("max_open_risk_percent", "max_open_risk_percent"),
                               ("max_open_trades", "max_open_trades"),
                               ("daily_loss_percent", "max_daily_loss_percent"),
                               ("total_loss_percent", "max_total_loss_percent")):
            if account.get(personal) is not None:
                value = float(account[personal])
                if not math.isfinite(value) or value <= 0:
                    raise ValueError("INVALID_ACCOUNT_RISK_LIMIT")
                rules[field] = min(float(rules[field]), value)

        now = self._parse(evaluated_at or utc_iso())
        local_date = self._trading_day(now, rules["daily_reset_timezone"], int(rules["daily_reset_hour"]))
        period_start, period_end = self._period_bounds(now, rules["daily_reset_timezone"], int(rules["daily_reset_hour"]))
        daily_state = self._daily_state(account_id, period_start, period_end, account)
        pnl = self.positions.pnl_for_date(account_id, local_date)
        exposure = self.positions.active_exposure(user_id, account_id)

        starting = max(float(account.get("starting_balance") or account.get("balance") or 0), 1e-9)
        balance = float(account.get("balance") or 0)
        equity = float(account.get("equity") if account.get("equity") is not None else balance)
        high_water = max(float(account.get("high_water_mark") or equity), equity)
        floating = float(account.get("floating_pnl") or equity - balance)
        daily_realized = float(pnl["net_pnl"])
        basis = str(rules["daily_loss_basis"])
        opening_reference = float(daily_state["opening_equity"] if basis == "equity" else daily_state["opening_balance"])
        opening_reference = max(opening_reference, 1e-9)
        daily_change = daily_realized
        if bool(rules["include_floating_in_daily_loss"]):
            daily_change += floating
        daily_loss_pct = max(0.0, -daily_change / opening_reference * 100)

        total_reference = max(starting, high_water) if rules["total_drawdown_mode"] == "trailing" else starting
        total_drawdown_pct = max(0.0, (total_reference - equity) / max(total_reference, 1e-9) * 100)
        profit_pct = (equity - starting) / starting * 100
        candidate_payload = candidate or {}
        candidate_risk = max(0.0, float(candidate_payload.get("risk_percent") or 0))
        candidate_count = 1 if candidate else 0
        projected_open_risk = float(exposure["risk_percent"]) + candidate_risk
        projected_open_trades = int(exposure["open_count"]) + candidate_count
        with self.engine.transaction(read_only=True) as cursor:
            used = cursor.execute("""SELECT COALESCE(SUM(risk_percent),0) AS risk FROM v8_positions
                WHERE user_id=? AND account_id=? AND opened_at>=? AND opened_at<?
                AND status IN ('planned','open','partial','closed')""",
                (str(user_id), str(account_id), period_start.isoformat(), period_end.isoformat())).fetchone() or {}
        daily_risk = float(used.get("risk") or 0)

        trading_days, consistency = self._trading_day_metrics(account_id)

        hard: list[dict[str, Any]] = []
        warnings: list[dict[str, Any]] = []

        def block(code: str, message: str, actual: float | int | None = None, limit: float | int | None = None) -> None:
            hard.append({"code": code, "message": message, "actual": actual, "limit": limit, "severity": "hard"})

        def warn(code: str, message: str, actual: float | int | None = None, limit: float | int | None = None) -> None:
            warnings.append({"code": code, "message": message, "actual": actual, "limit": limit, "severity": "soft"})

        if equity <= 0:
            block("ACCOUNT_EQUITY_INVALID", "Account equity must be positive", equity, 0)
        if daily_loss_pct >= float(rules["daily_loss_percent"]):
            block("DAILY_LOSS_LIMIT_BREACHED", "Daily loss limit is already breached", daily_loss_pct, rules["daily_loss_percent"])
        if total_drawdown_pct >= float(rules["total_loss_percent"]):
            block("TOTAL_DRAWDOWN_LIMIT_BREACHED", "Maximum loss limit is already breached", total_drawdown_pct, rules["total_loss_percent"])
        if projected_open_risk > float(rules["max_open_risk_percent"]) + 1e-9:
            block("MAX_OPEN_RISK_EXCEEDED", "Projected open risk exceeds the rule", projected_open_risk, rules["max_open_risk_percent"])
        if account.get("max_daily_risk_percent") is not None:
            limit = float(account["max_daily_risk_percent"])
            if not math.isfinite(limit) or limit <= 0:
                raise ValueError("INVALID_ACCOUNT_RISK_LIMIT")
            if daily_risk + candidate_risk > limit + 1e-9:
                block("MAX_DAILY_RISK_EXCEEDED", "Daily risk budget exceeded", daily_risk + candidate_risk, limit)
        if projected_open_trades > int(rules["max_open_trades"]):
            block("MAX_OPEN_TRADES_EXCEEDED", "Projected open trade count exceeds the rule", projected_open_trades, rules["max_open_trades"])

        if candidate:
            status = str(candidate_payload.get("signal_status") or "open").lower()
            if status in {"closed", "cancelled", "expired", "stopped", "tp", "win", "loss"}:
                block("SIGNAL_NOT_TRADABLE", "Signal is closed, cancelled or expired")
            entry = float(candidate_payload.get("actual_entry") or 0)
            stop = float(candidate_payload.get("actual_stop") or 0)
            side = str(candidate_payload.get("side") or "").upper()
            if entry <= 0 or stop <= 0:
                block("INVALID_EXECUTION_LEVELS", "Entry and stop must be positive")
            elif entry == stop:
                block("INVALID_STOP_DISTANCE", "Entry and stop cannot be equal")
            elif side == "BUY" and stop >= entry:
                block("INVALID_BUY_STOP", "Buy stop must be below entry")
            elif side == "SELL" and stop <= entry:
                block("INVALID_SELL_STOP", "Sell stop must be above entry")
            if candidate_risk <= 0:
                block("INVALID_RISK_PERCENT", "Risk percent must be positive", candidate_risk, 0)
            if not rules["weekend_holding_allowed"] and (
                now.astimezone(ZoneInfo(rules["daily_reset_timezone"])).weekday() >= 5
                or bool(candidate_payload.get("hold_weekend"))
            ):
                block("WEEKEND_TRADING_BLOCKED", "This template does not allow weekend holding")
            if not rules["overnight_holding_allowed"] and bool(candidate_payload.get("hold_overnight")):
                block("OVERNIGHT_HOLDING_BLOCKED", "This template does not allow overnight holding")
            if self._news_block(now, news_events or [], rules, candidate_payload.get("symbol")):
                block("NEWS_RESTRICTION", "A restricted high-impact event is inside the configured window")

        confidence = float(account.get("data_confidence") or 0.5)
        if confidence < float(rules["minimum_data_confidence"]):
            warn("LOW_DATA_CONFIDENCE", "Account values are manual or low confidence", confidence, rules["minimum_data_confidence"])
        age_seconds: int | None = None
        if account.get("data_observed_at"):
            age_seconds = max(0, int((now - self._parse(str(account["data_observed_at"]))).total_seconds()))
            if age_seconds > int(rules["data_max_age_seconds"]):
                warn("STALE_ACCOUNT_DATA", "Account equity data is stale", age_seconds, rules["data_max_age_seconds"])
        if profit_pct >= float(rules["profit_target_percent"]) > 0:
            warn("PROFIT_TARGET_REACHED", "Profit target has been reached", profit_pct, rules["profit_target_percent"])
        if trading_days < int(rules["min_trading_days"]):
            warn("MIN_TRADING_DAYS_PENDING", "Minimum trading days are not complete", trading_days, rules["min_trading_days"])
        consistency_limit = float(rules["consistency_rule_percent"])
        if consistency_limit > 0 and consistency > consistency_limit:
            warn("CONSISTENCY_RULE_EXCEEDED", "Best profitable day exceeds the consistency rule", consistency, consistency_limit)

        metrics = {
            "local_date": local_date,
            "period_start": period_start.isoformat(),
            "period_end": period_end.isoformat(),
            "daily_loss_basis": basis,
            "opening_balance": daily_state["opening_balance"],
            "opening_equity": daily_state["opening_equity"],
            "lowest_equity": daily_state["lowest_equity"],
            "highest_equity": daily_state["highest_equity"],
            "daily_realized_pnl": daily_realized,
            "daily_loss_percent": daily_loss_pct,
            "daily_loss_limit_percent": float(rules["daily_loss_percent"]),
            "total_drawdown_percent": total_drawdown_pct,
            "total_loss_limit_percent": float(rules["total_loss_percent"]),
            "profit_percent": profit_pct,
            "profit_progress_percent": max(0.0, min(100.0, profit_pct / max(float(rules["profit_target_percent"]), 1e-9) * 100)),
            "profit_target_percent": float(rules["profit_target_percent"]),
            "open_risk_percent": exposure["risk_percent"],
            "daily_risk_percent": daily_risk,
            "projected_open_risk_percent": projected_open_risk,
            "open_trades": exposure["open_count"],
            "projected_open_trades": projected_open_trades,
            "trading_days": trading_days,
            "min_trading_days": int(rules["min_trading_days"]),
            "consistency_percent": consistency,
            "equity": equity,
            "total_drawdown_reference": total_reference,
            "effective_max_open_risk_percent": float(rules["max_open_risk_percent"]),
            "balance": balance,
            "floating_pnl": floating,
            "high_water_mark": high_water,
            "data_source": str(account.get("data_source") or "manual"),
            "data_confidence": confidence,
            "data_age_seconds": age_seconds,
        }
        decision = "blocked" if hard else "warning" if warnings else "allowed"
        return RuleDecision(decision, tuple(hard), tuple(warnings), metrics, str(template["id"]), int(template["version"]))

    def _daily_state(
        self,
        account_id: str | int,
        period_start: datetime,
        period_end: datetime,
        account: dict[str, Any],
    ) -> dict[str, float]:
        with self.engine.transaction(read_only=True) as cursor:
            first = cursor.execute(
                """SELECT balance,equity FROM v8_equity_events
                   WHERE account_id=? AND observed_at>=? AND observed_at<? ORDER BY observed_at,id LIMIT 1""",
                (str(account_id), period_start.isoformat(), period_end.isoformat()),
            ).fetchone()
            aggregate = cursor.execute(
                """SELECT MIN(equity) AS lowest_equity,MAX(equity) AS highest_equity,COUNT(*) AS event_count
                   FROM v8_equity_events WHERE account_id=? AND observed_at>=? AND observed_at<?""",
                (str(account_id), period_start.isoformat(), period_end.isoformat()),
            ).fetchone() or {}
        opening_balance = float(first["balance"] if first and first.get("balance") is not None else account.get("balance") or 0)
        opening_equity = float(first["equity"] if first and first.get("equity") is not None else account.get("equity") if account.get("equity") is not None else opening_balance)
        return {
            "opening_balance": opening_balance,
            "opening_equity": opening_equity,
            "lowest_equity": float(aggregate["lowest_equity"] if aggregate.get("lowest_equity") is not None else account.get("equity") if account.get("equity") is not None else opening_equity),
            "highest_equity": float(aggregate["highest_equity"] if aggregate.get("highest_equity") is not None else account.get("equity") if account.get("equity") is not None else opening_equity),
            "event_count": float(aggregate.get("event_count") or 0),
        }

    def _trading_day_metrics(self, account_id: str | int) -> tuple[int, float]:
        with self.engine.transaction(read_only=True) as cursor:
            rows = cursor.execute(
                """SELECT account_local_date,SUM(realized_pnl-commission-swap-fees) AS pnl
                   FROM v8_position_pnl_events WHERE account_id=?
                   GROUP BY account_local_date ORDER BY account_local_date""",
                (str(account_id),),
            ).fetchall()
        profits = [max(0.0, float(row.get("pnl") or 0)) for row in rows]
        total_profit = sum(profits)
        consistency = max(profits, default=0.0) / total_profit * 100 if total_profit > 0 else 0.0
        return len(rows), consistency

    def _record(
        self,
        user_id: int | str,
        account_id: str | int,
        candidate: dict[str, Any] | None,
        result: RuleDecision,
    ) -> None:
        with self.engine.transaction() as cursor:
            cursor.execute(
                """INSERT INTO v8_prop_rule_evaluations(id,user_id,account_id,position_id,template_id,decision,
                   hard_blocks,warnings,metrics,evaluated_at,rules_version) VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    new_id("eval"), str(user_id), str(account_id),
                    str((candidate or {}).get("position_id") or "") or None,
                    result.template_id, result.decision, json_dump(result.hard_blocks),
                    json_dump(result.warnings), json_dump(result.metrics), utc_iso(), result.rules_version,
                ),
            )

    @staticmethod
    def _validate_rules(rules: dict[str, Any]) -> dict[str, Any]:
        out = dict(rules)
        for key in (
            "daily_loss_percent", "total_loss_percent", "profit_target_percent",
            "max_open_risk_percent", "consistency_rule_percent", "minimum_data_confidence",
        ):
            out[key] = max(0.0, float(out.get(key) or 0))
        out["minimum_data_confidence"] = min(1.0, out["minimum_data_confidence"])
        out["max_open_trades"] = max(1, int(out.get("max_open_trades") or 1))
        out["min_trading_days"] = max(0, int(out.get("min_trading_days") or 0))
        out["daily_reset_hour"] = min(23, max(0, int(out.get("daily_reset_hour") or 0)))
        out["data_max_age_seconds"] = max(30, int(out.get("data_max_age_seconds") or 900))
        out["news_restriction_minutes_before"] = max(0, int(out.get("news_restriction_minutes_before") or 0))
        out["news_restriction_minutes_after"] = max(0, int(out.get("news_restriction_minutes_after") or 0))
        for key in (
            "include_floating_in_daily_loss", "include_commission_swap_fees",
            "weekend_holding_allowed", "overnight_holding_allowed",
        ):
            out[key] = bool(out.get(key))
        if out.get("daily_loss_basis") not in {"balance", "equity"}:
            raise ValueError("INVALID_DAILY_LOSS_BASIS")
        if out.get("total_drawdown_mode") not in {"static", "trailing"}:
            raise ValueError("INVALID_DRAWDOWN_MODE")
        ZoneInfo(str(out.get("daily_reset_timezone") or "UTC"))
        return out

    @staticmethod
    def _parse(value: str) -> datetime:
        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        return parsed if parsed.tzinfo else parsed.replace(tzinfo=UTC)

    @staticmethod
    def _trading_day(now: datetime, timezone: str, reset_hour: int) -> str:
        local = now.astimezone(ZoneInfo(timezone)) - timedelta(hours=reset_hour)
        return local.date().isoformat()

    @staticmethod
    def _period_bounds(now: datetime, timezone: str, reset_hour: int) -> tuple[datetime, datetime]:
        zone = ZoneInfo(timezone)
        local = now.astimezone(zone)
        shifted = local - timedelta(hours=reset_hour)
        start_shifted = shifted.replace(hour=0, minute=0, second=0, microsecond=0)
        local_start = start_shifted + timedelta(hours=reset_hour)
        return local_start.astimezone(UTC), (local_start + timedelta(days=1)).astimezone(UTC)

    @staticmethod
    def _news_block(
        now: datetime,
        events: list[dict[str, Any]],
        rules: dict[str, Any],
        symbol: Any,
    ) -> bool:
        before = int(rules.get("news_restriction_minutes_before") or 0)
        after = int(rules.get("news_restriction_minutes_after") or 0)
        if not before and not after:
            return False
        text = str(symbol or "").upper()
        currencies = {code for code in ("USD", "EUR", "GBP", "JPY", "AUD", "CAD", "CHF", "NZD") if code in text}
        for event in events:
            if str(event.get("impact") or "").lower() not in {"high", "very_high", "3", "red"}:
                continue
            if currencies and str(event.get("currency") or "").upper() not in currencies:
                continue
            try:
                event_at = PropRuleEngine._parse(str(event.get("datetime") or event.get("time") or ""))
            except (TypeError, ValueError):
                continue
            if event_at - timedelta(minutes=before) <= now <= event_at + timedelta(minutes=after):
                return True
        return False
