from __future__ import annotations

import hashlib
import math
import os
import tempfile
import textwrap
from collections.abc import Iterable
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter, ImageFont

from modules.signal_template_editor import OUTPUT_TEMPLATE_HEIGHT, sanitize_signal_template_settings

WIDTH = 1145
REFERENCE_HEIGHT = 1374
WHITE = (246, 248, 255)
MUTED = (169, 179, 205)
CYAN = (34, 198, 255)
BLUE = (64, 108, 255)
PURPLE = (166, 74, 255)
GREEN = (50, 238, 131)
RED = (255, 62, 90)
GOLD = (255, 186, 55)
DARK = (3, 8, 23)
CARD = (5, 12, 29, 239)
CARD_SOFT = (8, 16, 36, 230)


# Every static string rendered on the signal poster is exposed through the
# enterprise admin control center. Dynamic values (symbol, prices, risk,
# signal direction and metadata) are already entered by the admin when a
# signal is created.
DEFAULT_SIGNAL_IMAGE_TEXTS: dict[str, str] = {
    "brand_name": "SENTINEL",
    "brand_handle": "@SENTINEL",
    "tagline": "TRADE THE STORM. PROFIT THE MOMENT.",
    "signal_type_label": "SIGNAL TYPE",
    "signal_number_prefix": "SIGNAL #",
    "symbol_label": "SYMBOL",
    "entry_label": "ENTRY",
    "entry_icon": "EN",
    "stop_loss_label": "STOP LOSS",
    "stop_loss_icon": "SL",
    "take_profit_label": "TAKE PROFIT",
    "target_singular_label": "TARGET",
    "target_plural_label": "TARGETS",
    "risk_label": "RISK",
    "risk_icon": "RK",
    "market_momentum_label": "MARKET MOMENTUM",
    "bullish_label": "BULLISH",
    "bearish_label": "BEARISH",
    "date_label": "DATE",
    "time_label": "TIME (UTC)",
    "timeframe_label": "TIMEFRAME",
    "trend_label": "TREND",
    "analysis_label": "ANALYSIS",
    "volatility_label": "VOLATILITY",
    "strategy_label": "STRATEGY",
    "confidence_label": "CONFIDENCE",
    "notes_label": "NOTES",
    "principle_1_title": "DISCIPLINE",
    "principle_1_subtitle": "OVER EMOTION",
    "principle_2_title": "STRATEGY",
    "principle_2_subtitle": "OVER NOISE",
    "principle_3_title": "FOCUS",
    "principle_3_subtitle": "OVER DISTRACTION",
    "footer_slogan": "PROTECT. ANALYZE. EXECUTE.",
    "default_note_1": "Price structure supports the selected market direction.",
    "default_note_2": "Wait for confirmation and respect the stop-loss level.",
    "default_note_3": "Keep position size within the selected risk.",
}


@dataclass(frozen=True, slots=True)
class InstrumentVisual:
    display: str
    primary: str
    secondary: str | None
    category: str


@dataclass(frozen=True, slots=True)
class SignalMeta:
    timeframe: str
    analysis: str
    volatility: str
    strategy: str
    confidence: str
    trend: str
    notes: tuple[str, ...]
    created_at: datetime


@dataclass(frozen=True, slots=True)
class SignalLayout:
    height: int
    signal_box: tuple[int, int, int, int]
    symbol_box: tuple[int, int, int, int]
    entry_box: tuple[int, int, int, int]
    stop_box: tuple[int, int, int, int]
    target_strip_box: tuple[int, int, int, int]
    target_start_y: int
    risk_box: tuple[int, int, int, int]
    details_box: tuple[int, int, int, int]
    notes_box: tuple[int, int, int, int]
    footer_box: tuple[int, int, int, int]


def _load_font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    candidates: list[str] = []
    if os.name == "nt":
        win = os.environ.get("WINDIR", "C:/Windows")
        candidates.extend(
            [
                os.path.join(win, "Fonts", "segoeuib.ttf" if bold else "segoeui.ttf"),
                os.path.join(win, "Fonts", "arialbd.ttf" if bold else "arial.ttf"),
            ]
        )
    else:
        candidates.extend(
            [
                "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
                if bold
                else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
                "/usr/share/fonts/truetype/liberation2/LiberationSans-Bold.ttf"
                if bold
                else "/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf",
            ]
        )
    for path in candidates:
        if not os.path.exists(path):
            continue
        try:
            return ImageFont.truetype(path, size=size)
        except OSError:
            continue
    return ImageFont.load_default()


def _fit_font(
    draw: ImageDraw.ImageDraw,
    text: str,
    max_width: int,
    start_size: int,
    min_size: int = 14,
    *,
    bold: bool = True,
) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    for size in range(start_size, min_size - 1, -2):
        font = _load_font(size, bold=bold)
        bounds = draw.textbbox((0, 0), text, font=font)
        if bounds[2] - bounds[0] <= max_width:
            return font
    return _load_font(min_size, bold=bold)


def _fit_text(
    draw: ImageDraw.ImageDraw,
    text: str,
    max_width: int,
    start_size: int,
    min_size: int = 12,
    *,
    bold: bool = True,
) -> tuple[str, ImageFont.FreeTypeFont | ImageFont.ImageFont]:
    clean = str(text)
    font = _fit_font(draw, clean, max_width, start_size, min_size, bold=bold)
    if draw.textbbox((0, 0), clean, font=font)[2] <= max_width:
        return clean, font
    while clean:
        candidate = clean[:-1] + "…"
        if draw.textbbox((0, 0), candidate, font=font)[2] <= max_width:
            return candidate, font
        clean = clean[:-1]
    return "…", font


def _center_text(
    draw: ImageDraw.ImageDraw,
    box: tuple[int, int, int, int],
    text: str,
    font: ImageFont.FreeTypeFont | ImageFont.ImageFont,
    fill: tuple[int, int, int],
    *,
    y_offset: int = 0,
) -> None:
    bounds = draw.textbbox((0, 0), text, font=font)
    width = bounds[2] - bounds[0]
    height = bounds[3] - bounds[1]
    x = box[0] + (box[2] - box[0] - width) / 2
    y = box[1] + (box[3] - box[1] - height) / 2 - bounds[1] + y_offset
    draw.text((x, y), text, font=font, fill=fill)




def _exact_symbol_layout(
    draw: ImageDraw.ImageDraw,
    text: str,
    max_width: int,
) -> tuple[list[str], ImageFont.FreeTypeFont | ImageFont.ImageFont]:
    clean = str(text)
    for size in range(64, 17, -2):
        font = _load_font(size, bold=True)
        bounds = draw.textbbox((0, 0), clean, font=font)
        if bounds[2] - bounds[0] <= max_width:
            return [clean], font

    midpoint = len(clean) // 2
    candidates = [index + 1 for index, char in enumerate(clean) if char in "/-_:."]
    candidates.extend(range(1, len(clean)))
    for split_at in sorted(set(candidates), key=lambda idx: abs(idx - midpoint)):
        lines = [clean[:split_at], clean[split_at:]]
        if not all(lines):
            continue
        for size in range(40, 11, -2):
            font = _load_font(size, bold=True)
            widths = [draw.textbbox((0, 0), line, font=font)[2] for line in lines]
            if max(widths) <= max_width:
                return lines, font
    raise ValueError("symbol is too wide to render safely")

def _clean_symbol(symbol: str) -> str:
    value = (symbol or "").strip()
    if not value:
        raise ValueError("symbol is required")
    return value


def _compact_symbol(symbol: str) -> str:
    return "".join(ch for ch in symbol.upper() if ch.isalnum())


def _instrument_visual(symbol: str) -> InstrumentVisual:
    display = _clean_symbol(symbol)
    analysis_symbol = display.split(".", 1)[0]
    compact = _compact_symbol(analysis_symbol)
    known_pairs = (
        "USDT",
        "USDC",
        "USD",
        "EUR",
        "GBP",
        "JPY",
        "AUD",
        "CAD",
        "CHF",
        "NZD",
        "BTC",
        "ETH",
        "XAU",
        "XAG",
    )
    secondary: str | None = None
    primary = compact[:6] or display[:6]

    for separator in ("/", "-", ":", "_"):
        if separator in display:
            parts = [part.strip().upper() for part in display.split(separator) if part.strip()]
            if len(parts) >= 2:
                primary, secondary = parts[0][:6], parts[1][:6]
                break

    if secondary is None:
        for quote in known_pairs:
            quote_at = compact.rfind(quote)
            suffix_length = len(compact) - (quote_at + len(quote)) if quote_at >= 0 else 999
            if quote_at > 0 and suffix_length <= 4:
                primary = compact[:quote_at][:6]
                secondary = quote
                break

    if compact.startswith(("XAU", "XAG")):
        category = "METAL"
    elif compact.startswith(("BTC", "ETH", "SOL", "XRP", "DOGE", "ADA")):
        category = "CRYPTO"
    elif any(key in compact for key in ("US100", "NAS100", "USTEC", "US30", "SPX", "GER40", "DAX", "UK100")):
        category = "INDEX"
    elif any(key in compact for key in ("OIL", "WTI", "BRENT", "BRN", "NGAS")):
        category = "ENERGY"
    elif secondary and primary in known_pairs and secondary in known_pairs:
        category = "FOREX"
    else:
        category = "MARKET"

    return InstrumentVisual(display=display, primary=primary or "MARKET", secondary=secondary, category=category)


def _instrument_description(instrument: InstrumentVisual) -> str:
    descriptions = {
        "XAU": "GOLD",
        "XAG": "SILVER",
        "BTC": "BITCOIN",
        "ETH": "ETHEREUM",
        "US100": "NASDAQ 100",
        "NAS100": "NASDAQ 100",
        "US30": "DOW JONES",
    }
    base = descriptions.get(instrument.primary, instrument.primary)
    if instrument.secondary:
        return f"{base} / {instrument.secondary}"
    return f"{base} • {instrument.category}"


def _hex_seed(*values: str) -> int:
    digest = hashlib.sha256("|".join(values).encode("utf-8")).digest()
    return int.from_bytes(digest[:8], "big")


def _theme_asset_path() -> str:
    return os.path.join(os.path.dirname(os.path.dirname(__file__)), "assets", "signal_theme_reference.png")


def _scale_box(box: tuple[int, int, int, int]) -> tuple[int, int, int, int]:
    sx = WIDTH / 1080
    sy = REFERENCE_HEIGHT / 1350
    return tuple(int(round(value * (sx if index % 2 == 0 else sy))) for index, value in enumerate(box))  # type: ignore[return-value]


def _layout(target_count: int) -> SignalLayout:
    # Base coordinates were tuned for the exact user-approved storm template.
    signal_box = _scale_box((408, 360, 1052, 500))
    symbol_box = _scale_box((408, 514, 1052, 650))
    entry_box = _scale_box((408, 664, 1052, 728))
    stop_box = _scale_box((408, 740, 1052, 804))
    targets_top = _scale_box((0, 816, 0, 0))[1]
    row_step = max(60, int(round(66 * (REFERENCE_HEIGHT / 1350))))
    strip_bottom = targets_top + target_count * row_step - 8
    target_strip_box = (_scale_box((408, 0, 478, 0))[0], targets_top, _scale_box((0, 0, 478, 0))[2], strip_bottom)
    risk_top = strip_bottom + 14
    risk_box = (_scale_box((490, 0, 1052, 0))[0], risk_top, _scale_box((0, 0, 1052, 0))[2], risk_top + max(68, int(round(68 * (REFERENCE_HEIGHT / 1350)))))
    footer_top = max(int(round(1188 * (REFERENCE_HEIGHT / 1350))), risk_box[3] + 26)
    footer_box = _scale_box((28, 1190, 1052, 1342))
    footer_box = (footer_box[0], footer_top, footer_box[2], footer_top + (footer_box[3] - footer_box[1]))
    height = max(REFERENCE_HEIGHT, footer_box[3] + 24)
    dummy = (0, 0, 0, 0)
    return SignalLayout(
        height=height,
        signal_box=signal_box,
        symbol_box=symbol_box,
        entry_box=entry_box,
        stop_box=stop_box,
        target_strip_box=target_strip_box,
        target_start_y=targets_top,
        risk_box=risk_box,
        details_box=dummy,
        notes_box=dummy,
        footer_box=footer_box,
    )


def _load_theme_canvas(height: int) -> Image.Image:
    with Image.open(_theme_asset_path()) as source_file:
        source_image = source_file.convert("RGBA")
        base = source_image.resize((WIDTH, REFERENCE_HEIGHT), Image.Resampling.LANCZOS)
        source_image.close()

    if height <= REFERENCE_HEIGHT:
        return base.copy()

    canvas = Image.new("RGBA", (WIDTH, height), DARK + (255,))
    canvas.paste(base, (0, 0))

    extension = Image.new("RGBA", (WIDTH, height - REFERENCE_HEIGHT), DARK + (255,))
    ed = ImageDraw.Draw(extension, "RGBA")
    for y in range(extension.height):
        t = y / max(1, extension.height - 1)
        color = (4 + int(4 * t), 8 + int(8 * t), 22 + int(15 * t), 255)
        ed.line((0, y, WIDTH, y), fill=color)
    for x in range(0, WIDTH, 64):
        ed.line((x, 0, x, extension.height), fill=(31, 48, 89, 46), width=1)
    for y in range(0, extension.height, 64):
        ed.line((0, y, WIDTH, y), fill=(31, 48, 89, 40), width=1)
    glow = Image.new("RGBA", extension.size, (0, 0, 0, 0))
    gd = ImageDraw.Draw(glow, "RGBA")
    gd.ellipse((-180, -180, 420, 360), fill=PURPLE + (46,))
    gd.ellipse((620, -140, 1180, 380), fill=BLUE + (36,))
    extension.alpha_composite(glow.filter(ImageFilter.GaussianBlur(80)))
    canvas.paste(extension, (0, REFERENCE_HEIGHT))
    return canvas


def _resolve_image_texts(
    overrides: dict[str, str] | None,
    *,
    brand_name: str,
    brand_handle: str,
) -> dict[str, str]:
    texts = dict(DEFAULT_SIGNAL_IMAGE_TEXTS)
    texts["brand_name"] = (brand_name or texts["brand_name"]).strip()
    texts["brand_handle"] = (brand_handle or texts["brand_handle"]).strip()
    for key, value in (overrides or {}).items():
        if key not in texts:
            continue
        clean = str(value or "").strip()
        if clean:
            texts[key] = clean[:500]
    return texts


def _draw_brand_header(draw: ImageDraw.ImageDraw, texts: dict[str, str]) -> None:
    brand_box = (400, 214, 1050, 296)
    tagline_box = (418, 296, 1044, 340)
    draw.rounded_rectangle(brand_box, radius=22, fill=(2, 7, 22, 224), outline=PURPLE + (180,), width=2)
    brand = texts["brand_name"]
    _center_text(
        draw,
        brand_box,
        brand,
        _fit_font(draw, brand, brand_box[2] - brand_box[0] - 42, 56, 18),
        WHITE,
        y_offset=-1,
    )
    tagline = texts["tagline"]
    _center_text(
        draw,
        tagline_box,
        tagline,
        _fit_font(draw, tagline, tagline_box[2] - tagline_box[0] - 20, 20, 10),
        MUTED,
    )


def _glow_card(
    draw: ImageDraw.ImageDraw,
    box: tuple[int, int, int, int],
    outline: tuple[int, int, int],
    *,
    fill: tuple[int, int, int, int] = CARD,
    radius: int = 22,
    width: int = 2,
) -> None:
    x1, y1, x2, y2 = box
    for step, alpha in ((9, 16), (5, 30), (2, 46)):
        draw.rounded_rectangle((x1 - step, y1 - step, x2 + step, y2 + step), radius=radius + step, outline=outline + (alpha,), width=2)
    draw.rounded_rectangle(box, radius=radius, fill=fill, outline=outline + (238,), width=width)


def _draw_signal_type(
    draw: ImageDraw.ImageDraw,
    box: tuple[int, int, int, int],
    side: str,
    texts: dict[str, str],
    signal_id: int | None = None,
) -> None:
    color = GREEN if side == "BUY" else RED
    _glow_card(draw, box, PURPLE, fill=(4, 12, 26, 242), radius=24)
    title = (
        f"{texts['signal_number_prefix']}{int(signal_id)}"
        if signal_id is not None
        else texts["signal_type_label"]
    )
    _center_text(draw, (box[0], box[1] + 8, box[2], box[1] + 40), title, _load_font(17, bold=True), WHITE)
    inner = (box[0] + 18, box[1] + 42, box[2] - 18, box[3] - 14)
    draw.rounded_rectangle(inner, radius=18, fill=(4, 17, 24, 238), outline=color + (220,), width=2)
    font = _fit_font(draw, side, inner[2] - inner[0] - 160, 76, 30)
    _center_text(draw, inner, side, font, color, y_offset=-2)
    for edge in (inner[0] + 28, inner[2] - 76):
        for idx in range(3):
            y = inner[1] + 14 + idx * 23
            if side == "BUY":
                points = [(edge, y + 15), (edge + 18, y), (edge + 36, y + 15)]
            else:
                points = [(edge, y), (edge + 18, y + 15), (edge + 36, y)]
            draw.line(points, fill=color + (255,), width=5, joint="curve")


def _draw_symbol(
    draw: ImageDraw.ImageDraw,
    box: tuple[int, int, int, int],
    instrument: InstrumentVisual,
    label: str,
) -> None:
    _glow_card(draw, box, PURPLE, fill=(13, 9, 29, 242), radius=24)
    _center_text(draw, (box[0], box[1] + 8, box[2], box[1] + 38), label, _fit_font(draw, label, box[2] - box[0] - 80, 17, 10), WHITE)
    symbol_font = _fit_font(draw, instrument.display, box[2] - box[0] - 54, 65, 22)
    _center_text(draw, (box[0] + 20, box[1] + 36, box[2] - 20, box[3] - 14), instrument.display, symbol_font, GOLD, y_offset=-3)


def _draw_icon_badge(draw: ImageDraw.ImageDraw, box: tuple[int, int, int, int], label: str, color: tuple[int, int, int]) -> None:
    draw.ellipse(box, fill=(4, 13, 31, 245), outline=color + (245,), width=2)
    _center_text(draw, box, label, _load_font(15, bold=True), WHITE)


def _draw_value_row(
    draw: ImageDraw.ImageDraw,
    box: tuple[int, int, int, int],
    label: str,
    value: str,
    color: tuple[int, int, int],
    icon: str,
    *,
    fill: tuple[int, int, int, int] = CARD,
) -> None:
    _glow_card(draw, box, color, fill=fill, radius=18)
    icon_box = (box[0] + 14, box[1] + 9, box[0] + 66, box[3] - 9)
    _draw_icon_badge(draw, icon_box, icon, color)
    label_font = _fit_font(draw, label, max(80, box[2] - box[0] - 330), 19, 9)
    draw.text((box[0] + 84, box[1] + 19), label, font=label_font, fill=color if color == RED else WHITE)
    value_font = _fit_font(draw, value, box[2] - box[0] - 245, 42, 14)
    bounds = draw.textbbox((0, 0), value, font=value_font)
    draw.text((box[2] - 22 - (bounds[2] - bounds[0]), box[1] + (box[3] - box[1] - (bounds[3] - bounds[1])) / 2 - bounds[1]), value, font=value_font, fill=WHITE)


def _draw_targets(
    draw: ImageDraw.ImageDraw,
    img: Image.Image,
    strip_box: tuple[int, int, int, int],
    start_y: int,
    targets: list[str],
    side: str,
    texts: dict[str, str],
) -> None:
    accent = GREEN if side == "BUY" else RED
    _glow_card(draw, strip_box, PURPLE, fill=(21, 12, 47, 240), radius=18)
    count_label = texts["target_singular_label"] if len(targets) == 1 else texts["target_plural_label"]
    label = f"{len(targets)} {count_label}"
    temp = Image.new("RGBA", (strip_box[3] - strip_box[1], strip_box[2] - strip_box[0]), (0, 0, 0, 0))
    td = ImageDraw.Draw(temp)
    _center_text(td, (0, 0, temp.width, temp.height), label, _fit_font(td, label, temp.width - 18, 25, 10), WHITE)
    rotated = temp.rotate(90, expand=True)
    img.alpha_composite(rotated, (strip_box[0] + (strip_box[2] - strip_box[0] - rotated.width) // 2, strip_box[1] + (strip_box[3] - strip_box[1] - rotated.height) // 2))

    for idx, value in enumerate(targets, start=1):
        y = start_y + (idx - 1) * 66
        row = (490, y, 1052, y + 58)
        _glow_card(draw, row, accent, fill=(3, 23, 25, 239) if side == "BUY" else (29, 7, 17, 239), radius=16)
        bubble = (row[0] + 12, row[1] + 8, row[0] + 54, row[1] + 50)
        _draw_icon_badge(draw, bubble, str(idx), accent)
        target_label = f"{texts['take_profit_label']} {idx}"
        target_font = _fit_font(draw, target_label, 260, 16, 9)
        draw.text((row[0] + 66, row[1] + 16), target_label, font=target_font, fill=accent)
        value_font = _fit_font(draw, value, 190, 33, 13)
        bounds = draw.textbbox((0, 0), value, font=value_font)
        draw.text((row[2] - 20 - (bounds[2] - bounds[0]), row[1] + (row[3] - row[1] - (bounds[3] - bounds[1])) / 2 - bounds[1]), value, font=value_font, fill=WHITE)


def _draw_market_chart(
    draw: ImageDraw.ImageDraw,
    box: tuple[int, int, int, int],
    side: str,
    seed: int,
    texts: dict[str, str],
) -> None:
    color = CYAN if side == "BUY" else RED
    _glow_card(draw, box, PURPLE, fill=(3, 10, 27, 242), radius=30)
    x1, y1, x2, y2 = box
    chart = (x1 + 20, y1 + 18, x2 - 20, y2 - 92)
    cx = (chart[0] + chart[2]) // 2
    cy = (chart[1] + chart[3]) // 2
    radius = min(chart[2] - chart[0], chart[3] - chart[1]) // 2 - 8
    draw.ellipse((cx - radius, cy - radius, cx + radius, cy + radius), fill=(1, 10, 28, 232), outline=PURPLE + (220,), width=4)
    for frac in (0.25, 0.5, 0.75):
        y = cy - radius + int(2 * radius * frac)
        draw.line((cx - radius + 14, y, cx + radius - 14, y), fill=(85, 118, 184, 62), width=1)
        x = cx - radius + int(2 * radius * frac)
        draw.line((x, cy - radius + 14, x, cy + radius - 14), fill=(85, 118, 184, 54), width=1)

    points: list[tuple[int, int]] = []
    for idx in range(9):
        t = idx / 8
        base = chart[3] - 48 - int(t * (chart[3] - chart[1] - 105)) if side == "BUY" else chart[1] + 48 + int(t * (chart[3] - chart[1] - 105))
        jitter = (((seed >> (idx * 3)) & 7) - 3) * 8 + int(math.sin(t * math.pi * 3) * 15)
        points.append((chart[0] + 28 + int(t * (chart[2] - chart[0] - 56)), base + jitter))
    draw.line([(x, y + 8) for x, y in points], fill=color + (55,), width=15)
    draw.line(points, fill=color + (245,), width=5)

    candle_count = 12
    for idx in range(candle_count):
        x = chart[0] + 34 + int(idx * (chart[2] - chart[0] - 68) / max(1, candle_count - 1))
        t = idx / max(1, candle_count - 1)
        center = chart[3] - 42 - int(t * 125) if side == "BUY" else chart[1] + 42 + int(t * 125)
        swing = ((seed >> (idx * 2)) & 7) - 3
        top = center - 14 - abs(swing) * 2
        bottom = center + 14 + abs(swing) * 2
        body_top = center - 8
        body_bottom = center + 8
        draw.line((x, top, x, bottom), fill=WHITE + (150,), width=2)
        draw.rectangle((x - 4, body_top, x + 4, body_bottom), fill=color + (210,))

    sentiment = texts["bullish_label"] if side == "BUY" else texts["bearish_label"]
    footer = (x1 + 18, y2 - 78, x2 - 18, y2 - 18)
    draw.rounded_rectangle(footer, radius=16, fill=(3, 12, 29, 244), outline=color + (235,), width=2)
    momentum = texts["market_momentum_label"]
    _center_text(
        draw,
        (footer[0], footer[1] + 2, footer[2], footer[1] + 28),
        momentum,
        _fit_font(draw, momentum, footer[2] - footer[0] - 24, 14, 8),
        WHITE,
    )
    _center_text(
        draw,
        (footer[0], footer[1] + 26, footer[2], footer[3]),
        sentiment,
        _fit_font(draw, sentiment, footer[2] - footer[0] - 24, 24, 10),
        color,
    )


def _default_meta(
    side: str,
    risk: str,
    created_at: datetime | None,
    texts: dict[str, str],
) -> SignalMeta:
    timestamp = created_at or datetime(2026, 1, 1, 12, 0, tzinfo=UTC)
    risk_value = float(str(risk).strip().rstrip("%") or "1")
    if risk_value <= 0.75:
        volatility = "LOW"
    elif risk_value <= 2:
        volatility = "MEDIUM"
    else:
        volatility = "HIGH"
    trend = texts["bullish_label"] if side == "BUY" else texts["bearish_label"]
    notes = (
        texts["default_note_1"],
        texts["default_note_2"],
        texts["default_note_3"],
    )
    return SignalMeta(
        timeframe="1H",
        analysis="TECHNICAL",
        volatility=volatility,
        strategy="TREND FOLLOWING",
        confidence="HIGH",
        trend=trend,
        notes=notes,
        created_at=timestamp,
    )


def _draw_details(
    draw: ImageDraw.ImageDraw,
    box: tuple[int, int, int, int],
    meta: SignalMeta,
    texts: dict[str, str],
    side: str,
) -> None:
    _glow_card(draw, box, PURPLE, fill=(5, 10, 27, 244), radius=22)
    date_text = meta.created_at.astimezone(UTC).strftime("%d/%m/%Y")
    time_text = meta.created_at.astimezone(UTC).strftime("%H:%M")
    items = (
        (texts["date_label"], date_text, CYAN),
        (texts["time_label"], time_text, PURPLE),
        (texts["timeframe_label"], meta.timeframe, CYAN),
        (texts["trend_label"], meta.trend, GREEN if side == "BUY" else RED),
        (texts["analysis_label"], meta.analysis, CYAN),
        (texts["volatility_label"], meta.volatility, PURPLE),
        (texts["strategy_label"], meta.strategy, CYAN),
        (texts["confidence_label"], meta.confidence, GREEN),
    )
    col_w = (box[2] - box[0]) // 4
    row_h = (box[3] - box[1]) // 2
    for index, (label, value, color) in enumerate(items):
        row = index // 4
        col = index % 4
        x1 = box[0] + col * col_w
        y1 = box[1] + row * row_h
        y2 = y1 + row_h
        if col:
            draw.line((x1, y1 + 12, x1, y2 - 12), fill=(255, 255, 255, 48), width=1)
        draw.text((x1 + 18, y1 + 13), label, font=_load_font(13, bold=True), fill=color)
        value_text, value_font = _fit_text(draw, value, col_w - 36, 18, 10)
        draw.text((x1 + 18, y1 + 38), value_text, font=value_font, fill=WHITE)


def _draw_notes(
    draw: ImageDraw.ImageDraw,
    box: tuple[int, int, int, int],
    notes: tuple[str, ...],
    label: str,
) -> None:
    _glow_card(draw, box, PURPLE, fill=(5, 10, 27, 244), radius=22)
    draw.text((box[0] + 20, box[1] + 14), label, font=_fit_font(draw, label, box[2] - box[0] - 40, 15, 9), fill=PURPLE)
    y = box[1] + 42
    for note in notes[:3]:
        wrapped = textwrap.wrap(note, width=88) or [note]
        for line_index, line in enumerate(wrapped[:2]):
            prefix = "• " if line_index == 0 else "  "
            draw.text((box[0] + 24, y), prefix + line, font=_load_font(13, bold=False), fill=WHITE)
            y += 20
        y += 2


def _draw_footer(
    draw: ImageDraw.ImageDraw,
    box: tuple[int, int, int, int],
    handle: str,
    texts: dict[str, str],
) -> None:
    _glow_card(draw, box, PURPLE, fill=(5, 10, 27, 246), radius=22)
    principles = (
        (texts["principle_1_title"], texts["principle_1_subtitle"]),
        (texts["principle_2_title"], texts["principle_2_subtitle"]),
        (texts["principle_3_title"], texts["principle_3_subtitle"]),
    )
    x = box[0] + 22
    for idx, (title, subtitle) in enumerate(principles):
        draw.text((x, box[1] + 20), title, font=_fit_font(draw, title, 122, 13, 7), fill=WHITE)
        draw.text((x, box[1] + 44), subtitle, font=_fit_font(draw, subtitle, 122, 10, 6), fill=MUTED)
        if idx < 2:
            draw.line((x + 125, box[1] + 16, x + 125, box[3] - 16), fill=(255, 255, 255, 55), width=1)
        x += 145
    slogan = texts["footer_slogan"]
    draw.text((box[0] + 454, box[1] + 27), slogan, font=_fit_font(draw, slogan, 330, 22, 12), fill=WHITE)
    handle_box = (box[2] - 190, box[1] + 18, box[2] - 18, box[3] - 18)
    draw.rounded_rectangle(handle_box, radius=18, fill=(18, 11, 48, 244), outline=PURPLE + (238,), width=2)
    handle_text, handle_font = _fit_text(draw, handle, handle_box[2] - handle_box[0] - 20, 20, 10)
    _center_text(draw, handle_box, handle_text, handle_font, WHITE)


def _exact_fill(draw: ImageDraw.ImageDraw, box: tuple[int, int, int, int], fill: tuple[int, int, int, int], *, inset: int = 10, radius: int = 16, outline: tuple[int, int, int] | None = None, outline_alpha: int = 220) -> tuple[int, int, int, int]:
    inner = (box[0] + inset, box[1] + inset, box[2] - inset, box[3] - inset)
    draw.rounded_rectangle(inner, radius=radius, fill=fill, outline=(outline + (outline_alpha,)) if outline else None, width=2 if outline else 1)
    return inner


def _clear_text_zone(draw: ImageDraw.ImageDraw, box: tuple[int, int, int, int], fill: tuple[int, int, int, int], *, radius: int = 10) -> None:
    draw.rounded_rectangle(box, radius=radius, fill=fill)


def _draw_exact_signal_type(draw: ImageDraw.ImageDraw, side: str, texts: dict[str, str]) -> None:
    color = GREEN if side == "BUY" else RED
    panel = (432, 362, 1058, 528)
    draw.rounded_rectangle(panel, radius=22, fill=(3, 10, 26, 250), outline=PURPLE + (210,), width=2)
    title_box = (590, 365, 900, 402)
    draw.rounded_rectangle(title_box, radius=7, fill=(8, 12, 31, 248))
    _center_text(draw, title_box, texts["signal_type_label"], _fit_font(draw, texts["signal_type_label"], 290, 18, 10), WHITE)
    inner = (444, 400, 1046, 521)
    draw.rounded_rectangle(inner, radius=18, fill=(1, 18, 24, 250), outline=color + (245,), width=2)
    side_box = (530, 402, 960, 519)
    _center_text(draw, side_box, side, _fit_font(draw, side, 400, 82, 34), color, y_offset=-2)
    for edge in (470, 995):
        for idx in range(3):
            y = 414 + idx * 25
            points = [(edge, y + 16), (edge + 18, y), (edge + 36, y + 16)] if side == "BUY" else [(edge, y), (edge + 18, y + 16), (edge + 36, y)]
            draw.line(points, fill=color + (255,), width=5, joint="curve")


def _draw_exact_symbol(draw: ImageDraw.ImageDraw, instrument: InstrumentVisual, label: str) -> None:
    panel = (420, 550, 1075, 718)
    draw.rounded_rectangle(panel, radius=22, fill=(12, 8, 29, 250), outline=PURPLE + (210,), width=2)
    label_box = (655, 552, 850, 590)
    draw.rounded_rectangle(label_box, radius=7, fill=(12, 8, 29, 250))
    _center_text(draw, label_box, label, _fit_font(draw, label, 180, 18, 10), WHITE)
    value_box = (445, 585, 1050, 707)
    lines, font = _exact_symbol_layout(draw, instrument.display, value_box[2] - value_box[0] - 20)
    if len(lines) == 1:
        _center_text(draw, value_box, lines[0], font, GOLD, y_offset=-3)
    else:
        line_h = max(draw.textbbox((0, 0), line, font=font)[3] for line in lines)
        total_h = line_h * len(lines) + 6 * (len(lines) - 1)
        y = value_box[1] + (value_box[3] - value_box[1] - total_h) / 2
        for line in lines:
            b = draw.textbbox((0, 0), line, font=font)
            x = value_box[0] + (value_box[2] - value_box[0] - (b[2] - b[0])) / 2
            draw.text((x, y - b[1]), line, font=font, fill=GOLD)
            y += line_h + 6


def _draw_exact_value_row(
    draw: ImageDraw.ImageDraw,
    box: tuple[int, int, int, int],
    label: str,
    value: str,
    color: tuple[int, int, int],
    icon: str,
    *,
    fill: tuple[int, int, int, int],
    value_color: tuple[int,int,int] | None = None,
    value_font_size: int = 43,
) -> None:
    draw.rounded_rectangle(box, radius=17, fill=fill, outline=color + (240,), width=2)
    icon_box = (box[0] + 14, box[1] + 10, box[0] + 61, box[3] - 10)
    _draw_icon_badge(draw, icon_box, icon, color)
    label_box = (box[0] + 78, box[1] + 8, box[0] + 300, box[3] - 8)
    _center_text(draw, label_box, label, _fit_font(draw, label, 210, 20, 9), color if color == RED else WHITE)
    value_box = (box[2] - 265, box[1] + 7, box[2] - 18, box[3] - 7)
    value_font = _fit_font(draw, value, value_box[2] - value_box[0], value_font_size, 18)
    b = draw.textbbox((0, 0), value, font=value_font)
    if b[2]-b[0]>value_box[2]-value_box[0]:raise ValueError('SIGNAL_TEMPLATE_VALUE_DOES_NOT_FIT')
    draw.text((value_box[2] - (b[2] - b[0]), value_box[1] + (value_box[3] - value_box[1] - (b[3] - b[1])) / 2 - b[1]), value, font=value_font, fill=value_color or WHITE)


def _draw_exact_targets(draw: ImageDraw.ImageDraw, img: Image.Image, targets: list[str], side: str, texts: dict[str, str]) -> None:
    accent = GREEN if side == "BUY" else RED
    # Remove all baked target values first, then recreate the same three-row structure.
    target_area = (452, 912, 1078, 1123)
    draw.rounded_rectangle(target_area, radius=20, fill=(3, 10, 25, 250), outline=PURPLE + (205,), width=2)
    strip = (458, 918, 523, 1117)
    draw.rounded_rectangle(strip, radius=16, fill=(21, 12, 47, 248), outline=PURPLE + (235,), width=2)
    count_label = texts["target_singular_label"] if len(targets) == 1 else texts["target_plural_label"]
    vertical = f"{len(targets)} {count_label}"
    temp = Image.new("RGBA", (strip[3] - strip[1], strip[2] - strip[0]), (0, 0, 0, 0))
    td = ImageDraw.Draw(temp)
    _center_text(td, (0, 0, temp.width, temp.height), vertical, _fit_font(td, vertical, temp.width - 18, 24, 10), WHITE)
    rotated = temp.rotate(90, expand=True)
    img.alpha_composite(rotated, (strip[0] + (strip[2] - strip[0] - rotated.width) // 2, strip[1] + (strip[3] - strip[1] - rotated.height) // 2))
    row_ys = [(918, 977), (985, 1044), (1052, 1111)]
    for index, (y1, y2) in enumerate(row_ys, start=1):
        row = (528, y1, 1071, y2)
        if index <= len(targets):
            fill = (3, 25, 25, 248) if side == "BUY" else (31, 7, 18, 248)
            draw.rounded_rectangle(row, radius=15, fill=fill, outline=accent + (240,), width=2)
            bubble = (row[0] + 12, row[1] + 8, row[0] + 53, row[3] - 8)
            _draw_icon_badge(draw, bubble, str(index), accent)
            target_label = f"{texts['take_profit_label']} {index}"
            _center_text(draw, (row[0] + 64, row[1] + 5, row[0] + 290, row[3] - 5), target_label, _fit_font(draw, target_label, 215, 16, 9), accent)
            value = targets[index - 1]
            value_font = _fit_font(draw, value, 210, 34, 13)
            b = draw.textbbox((0, 0), value, font=value_font)
            draw.text((row[2] - 18 - (b[2] - b[0]), row[1] + (row[3] - row[1] - (b[3] - b[1])) / 2 - b[1]), value, font=value_font, fill=WHITE)
        else:
            draw.rounded_rectangle(row, radius=15, fill=(4, 12, 27, 245), outline=(80, 61, 122, 135), width=1)


def _draw_exact_brand_header(draw: ImageDraw.ImageDraw, texts: dict[str, str]) -> None:
    brand_box = (460, 235, 1005, 305)
    tagline_box = (480, 305, 1000, 342)
    draw.rounded_rectangle(brand_box, radius=12, fill=(8, 10, 26, 232))
    _center_text(draw, brand_box, texts["brand_name"], _fit_font(draw, texts["brand_name"], 520, 67, 24), WHITE)
    draw.rounded_rectangle(tagline_box, radius=7, fill=(8, 10, 26, 232))
    _center_text(draw, tagline_box, texts["tagline"], _fit_font(draw, texts["tagline"], 500, 19, 10), WHITE)


def _draw_exact_footer_overrides(draw: ImageDraw.ImageDraw, texts: dict[str, str], handle: str) -> None:
    principle_boxes = [(34, 1245, 173, 1340), (178, 1245, 326, 1340), (330, 1245, 480, 1340)]
    principle_pairs = [
        (texts["principle_1_title"], texts["principle_1_subtitle"]),
        (texts["principle_2_title"], texts["principle_2_subtitle"]),
        (texts["principle_3_title"], texts["principle_3_subtitle"]),
    ]
    for box, (title, subtitle) in zip(principle_boxes, principle_pairs, strict=True):
        draw.rounded_rectangle(box, radius=9, fill=(5, 10, 27, 238))
        _center_text(draw, (box[0], box[1] + 5, box[2], box[1] + 42), title, _fit_font(draw, title, box[2] - box[0] - 10, 13, 7), WHITE)
        _center_text(draw, (box[0], box[1] + 35, box[2], box[3] - 5), subtitle, _fit_font(draw, subtitle, box[2] - box[0] - 10, 10, 6), MUTED)
    slogan_box = (492, 1240, 820, 1340)
    draw.rounded_rectangle(slogan_box, radius=10, fill=(5, 10, 27, 238))
    _center_text(draw, slogan_box, texts["footer_slogan"], _fit_font(draw, texts["footer_slogan"], 310, 21, 11), WHITE)
    handle_box = (875, 1240, 1060, 1340)
    draw.rounded_rectangle(handle_box, radius=17, fill=(18, 11, 48, 240), outline=PURPLE + (225,), width=2)
    _center_text(draw, handle_box, handle, _fit_font(draw, handle, 165, 20, 10), WHITE)


def _render_exact_template_signal_image(
    instrument: InstrumentVisual,
    side: str,
    entry_text: str,
    stop_text: str,
    targets: list[str],
    risk_text: str,
    texts: dict[str, str],
    handle: str,
) -> Image.Image:
    img = _load_theme_canvas(REFERENCE_HEIGHT)
    draw = ImageDraw.Draw(img, "RGBA")
    _draw_exact_signal_type(draw, side, texts)
    _draw_exact_symbol(draw, instrument, texts["symbol_label"])
    _draw_exact_value_row(draw, (432, 735, 1075, 816), texts["entry_label"], entry_text, CYAN, texts["entry_icon"], fill=(3, 12, 29, 250))
    _draw_exact_value_row(draw, (432, 825, 1075, 908), texts["stop_loss_label"], stop_text, RED, texts["stop_loss_icon"], fill=(31, 5, 16, 248))
    _draw_exact_targets(draw, img, targets, side, texts)
    _draw_exact_value_row(draw, (458, 1128, 1075, 1210), texts["risk_label"], risk_text, PURPLE, texts["risk_icon"], fill=(23, 10, 43, 248))
    if side == "SELL" or texts["market_momentum_label"] != DEFAULT_SIGNAL_IMAGE_TEXTS["market_momentum_label"] or texts["bullish_label"] != DEFAULT_SIGNAL_IMAGE_TEXTS["bullish_label"] or texts["bearish_label"] != DEFAULT_SIGNAL_IMAGE_TEXTS["bearish_label"]:
        chart_box = (22, 835, 420, 1200)
        draw.rounded_rectangle(chart_box, radius=30, fill=(2, 8, 24, 252))
        _draw_market_chart(draw, chart_box, side, _hex_seed(instrument.display, side, entry_text, stop_text, *targets), texts)
    if any(texts[key] != DEFAULT_SIGNAL_IMAGE_TEXTS[key] for key in ("brand_name", "tagline")):
        _draw_exact_brand_header(draw, texts)
    if any(texts[key] != DEFAULT_SIGNAL_IMAGE_TEXTS[key] for key in ("principle_1_title", "principle_1_subtitle", "principle_2_title", "principle_2_subtitle", "principle_3_title", "principle_3_subtitle", "footer_slogan")) or handle != DEFAULT_SIGNAL_IMAGE_TEXTS["brand_handle"]:
        _draw_exact_footer_overrides(draw, texts, handle)
    return img


def _sentinel_template_path(side: str) -> Path:
    root = Path(__file__).resolve().parents[1]
    name = "sentinel_buy.png" if side == "BUY" else "sentinel_sell.png"
    path = root / "assets" / "signal_templates" / name
    if not path.is_file():
        raise FileNotFoundError(f"signal template is missing: {path}")
    return path


def _draw_template_value(
    draw: ImageDraw.ImageDraw,
    box: tuple[int, int, int, int],
    value: str,
    *,
    accent: tuple[int, int, int],
    font_size: int = 46,
) -> None:
    clean = str(value or "—").strip() or "—"
    font = _fit_font(draw, clean, box[2] - box[0] - 26, max(18, min(72, int(font_size))), 18, bold=True)
    bounds = draw.textbbox((0, 0), clean, font=font)
    size=max(18,min(72,int(font_size)))
    while bounds[3]-bounds[1]>box[3]-box[1]-8 and size>18:
        size-=1;font=_fit_font(draw,clean,box[2]-box[0]-26,size,18,bold=True)
        bounds=draw.textbbox((0,0),clean,font=font)
    if bounds[2]-bounds[0]>box[2]-box[0]-26 or bounds[3]-bounds[1]>box[3]-box[1]-8:
        raise ValueError('SIGNAL_TEMPLATE_VALUE_DOES_NOT_FIT')
    width = bounds[2] - bounds[0]
    height = bounds[3] - bounds[1]
    x = box[0] + (box[2] - box[0] - width) / 2
    y = box[1] + (box[3] - box[1] - height) / 2 - bounds[1]
    # The supplied panels are already dark and high-contrast. A single solid
    # antialiased draw avoids glow, halos and compression noise.
    draw.text((x, y), clean, font=font, fill=accent + (255,))



def _extend_owner_template(img: Image.Image, side: str) -> Image.Image:
    """Return the approved artwork at native size without geometric changes."""
    source = img.convert("RGBA")
    if source.size != (1229, OUTPUT_TEMPLATE_HEIGHT):
        source.close()
        img.close()
        raise ValueError(
            f"approved {side} template must be 1229x{OUTPUT_TEMPLATE_HEIGHT}, got {img.size}"
        )
    output = source.copy()
    source.close()
    img.close()
    return output


def _draw_template_risk_badge(
    draw: ImageDraw.ImageDraw,
    box: tuple[int, int, int, int],
    risk: str,
    *,
    accent: tuple[int, int, int],
    font_size: int = 38,
) -> None:
    """Draw a compact RISK badge inside the approved footer safe area."""
    x1, y1, x2, y2 = (int(item) for item in box)
    if x2 <= x1 or y2 <= y1:
        raise ValueError("risk template box is invalid")
    clean = str(risk or "").strip().replace("%", "") or "—"
    value = f"{clean}%" if clean != "—" else clean

    # Opaque enough to replace only the footer copy beneath the badge while
    # preserving the surrounding shield/lock/radar artwork.
    shadow = (x1 + 3, y1 + 5, x2 + 3, y2 + 5)
    draw.rounded_rectangle(shadow, radius=16, fill=(0, 0, 0, 170))
    draw.rounded_rectangle(
        (x1, y1, x2, y2),
        radius=16,
        fill=(3, 9, 19, 247),
        outline=(176, 184, 197, 235),
        width=2,
    )
    draw.line((x1 + 18, y1 + 3, x2 - 18, y1 + 3), fill=accent + (220,), width=2)
    draw.line((x1 + 18, y2 - 3, x2 - 18, y2 - 3), fill=accent + (110,), width=1)

    divider_x = x1 + int((x2 - x1) * 0.43)
    draw.line((divider_x, y1 + 13, divider_x, y2 - 13), fill=(151, 160, 177, 150), width=1)
    label_box = (x1 + 14, y1 + 5, divider_x - 10, y2 - 5)
    value_box = (divider_x + 10, y1 + 5, x2 - 14, y2 - 5)
    label_font = _fit_font(draw, "RISK", label_box[2] - label_box[0], min(28, int(font_size)), 16, bold=True)
    value_font = _fit_font(draw, value, value_box[2] - value_box[0], max(20, min(72, int(font_size))), 18, bold=True)
    _center_text(draw, label_box, "RISK", label_font, (232, 236, 244))
    _center_text(draw, value_box, value, value_font, accent)


def create_signal_image(
    symbol: str,
    entry: str,
    tp_values: Iterable[str],
    sl: str,
    signal_type: str = "BUY",
    risk: str = "1",
    channel_id: str = "@Sentinel",
    brand_name: str = "SENTINEL",
    *,
    timeframe: str = "1H",
    analysis: str = "TECHNICAL",
    volatility: str = "MEDIUM",
    strategy: str = "TREND FOLLOWING",
    confidence: str = "HIGH",
    notes: Iterable[str] | None = None,
    created_at: datetime | None = None,
    signal_id: int | None = None,
    text_overrides: dict[str, str] | None = None,
    layout_overrides: dict[str, object] | None = None,
    template_path: str | None = None,
) -> str:
    """Render values on the exact BUY/SELL templates supplied by the owner.

    No generated redesign is used. The two source template files are opened as
    immutable bases and only the blank value fields are populated.
    """
    side = (signal_type or "").strip().upper()
    if side not in {"BUY", "SELL"}:
        raise ValueError("signal_type must be BUY or SELL")
    clean_symbol = _clean_symbol(symbol)
    entry_text = str(entry or "").strip()
    stop_text = str(sl or "").strip()
    if not entry_text or not stop_text:
        raise ValueError("entry and stop-loss are required")
    targets = [str(value).strip() for value in (tp_values or []) if str(value).strip()]
    if not targets:
        raise ValueError("at least one take-profit value is required")
    if len(targets) > 10:
        raise ValueError("at most ten take-profit values are supported")

    selected_template = (
        Path(str(template_path)).expanduser().resolve()
        if template_path is not None and str(template_path).strip()
        else _sentinel_template_path(side)
    )
    if not selected_template.is_file():
        selected_template = _sentinel_template_path(side)
    try:
        with Image.open(selected_template) as base:
            img = base.convert("RGBA").copy()
    except (OSError, ValueError):
        # A damaged or concurrently replaced custom template must never block
        # signal publication; fall back to the bundled owner-approved artwork.
        with Image.open(_sentinel_template_path(side)) as base:
            img = base.convert("RGBA").copy()
    img = _extend_owner_template(img, side)
    draw = ImageDraw.Draw(img, "RGBA")
    accent = (105, 255, 196) if side == "BUY" else (255, 105, 105)
    white = (239, 244, 250)

    # Coordinates correspond to the native owner-approved 1229x1536 canvases.
    # The source files remain immutable and are copied in memory for each render.
    layout_source = {side.lower(): layout_overrides or {}}
    layout = sanitize_signal_template_settings(layout_source)[side.lower()]
    field_settings = layout["fields"]

    def draw_field(key: str, value: str, color: tuple[int, int, int]) -> None:
        row = field_settings[key]
        configured_color = str(row["color"])
        color = (
            int(configured_color[1:3], 16),
            int(configured_color[3:5], 16),
            int(configured_color[5:7], 16),
        )
        box_values = [int(item) for item in row["box"]]
        box = (box_values[0], box_values[1], box_values[2], box_values[3])
        _draw_template_value(
            draw,
            box,
            value,
            accent=color,
            font_size=int(row.get("font_size", layout.get("font_size", 46))),
        )

    draw_field("symbol", clean_symbol, white)
    draw_field("entry", entry_text, accent)
    draw_field("stop", stop_text, (255, 126, 126))
    display_targets = targets[:3]

    for index, key in enumerate(("tp1", "tp2", "tp3")):
        value = display_targets[index] if index < len(display_targets) else "—"
        draw_field(key, value, accent)

    clean_risk = str(risk or "").strip().replace("%", "") or "—"
    draw_field("risk", f"{clean_risk}%" if clean_risk != "—" else clean_risk, accent)

    if len(targets)>3:
        original=img;original_height=original.height
        height=max(original.height+(len(targets)-3)*78+24,max(field_settings[f'tp{i}']['box'][3]+20 for i in range(4,len(targets)+1)))
        img=Image.new('RGBA',(original.width,height),(8,15,29,255))
        img.alpha_composite(original,(0,0));original.close();draw=ImageDraw.Draw(img)
        for index,value in enumerate(targets[3:],4):
            y=original_height+12+(index-4)*78
            style=field_settings[f'tp{index}'];color=tuple(int(style['color'][i:i+2],16) for i in (1,3,5))
            _draw_exact_value_row(draw,(24,y,img.width-24,y+66),f'TP{index}','',color,str(index),
                                  fill=(3,25,25,248),value_color=color,value_font_size=style['font_size'])
            draw_field(f'tp{index}',value,color)

    fd, path = tempfile.mkstemp(prefix="sentinel_signal_", suffix=".png")
    os.close(fd)
    rgb = img.convert("RGB")
    try:
        # Lossless compression preserves every owner-approved template pixel
        # outside the editable value boxes while still trimming the output.
        rgb.save(path, format="PNG", compress_level=8)
    finally:
        rgb.close()
        img.close()
    return path
