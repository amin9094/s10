"""Human-readable rules and side-effect-free impact previews for admins."""
from copy import deepcopy
from collections import Counter
from core.utils import utc_iso

CONDITIONS={
    'vip':('کاربر VIP فعال باشد',{'field':'profile.vip_active','operator':'eq','value':True}),
    'nonvip':('کاربر VIP فعال نباشد',{'field':'profile.vip_active','operator':'eq','value':False}),
    'no_ticket':('تیکت باز نداشته باشد',{'field':'profile.open_ticket_count','operator':'eq','value':0}),
    'buyer':('حداقل یک خرید تأییدشده داشته باشد',{'field':'profile.total_purchase_count','operator':'gte','value':1}),
    'active_week':('در هفت روز گذشته فعال بوده باشد',{'field':'profile.recency_days','operator':'lte','value':7}),
}


def enriched_event(db,event):
    result=deepcopy(event)
    uid=str(event.get('user_id') or '')
    if uid:
        from modules.user_intelligence import build_user_profile
        result['profile']=build_user_profile(db,uid)
    return result


def condition_labels(conditions):
    if not conditions:return ['بدون شرط اضافی']
    if isinstance(conditions,list):return [label for item in conditions for label in condition_labels(item)]
    if 'all' in conditions:return ['همهٔ این شرط‌ها: '+ ' و '.join(condition_labels(conditions['all']))]
    if 'any' in conditions:return ['یکی از این شرط‌ها: '+ ' یا '.join(condition_labels(conditions['any']))]
    for label,value in CONDITIONS.values():
        if value==conditions:return [label]
    if conditions=={'field':'user_id','operator':'exists'}:return ['کاربر مشخص باشد']
    return ['شرط پیشرفتهٔ ثبت‌شده (بدون تغییر)']


def toggle_condition(db,actor,rule_id,key):
    from modules.admin_access import has_permission,PERMISSION_AUTOMATIONS
    from modules.automation_v2 import update_automation_rule
    if not has_permission(db,actor,PERMISSION_AUTOMATIONS):raise PermissionError('FORBIDDEN')
    if key not in CONDITIONS:raise ValueError('شرط نامعتبر است')
    row=db.get('automation_rules_v2',{}).get(rule_id)
    if not row or row.get('deleted_at'):raise ValueError('قانون پیدا نشد')
    old=deepcopy(row.get('conditions') or [])
    if isinstance(old,dict):old=[old]
    value=CONDITIONS[key][1]
    new=[c for c in old if c!=value] if value in old else [*old,deepcopy(value)]
    return update_automation_rule(db,rule_id,{'conditions':new},actor_id=actor)


def preview_impact(db,actor,rule_id,*,limit=100,after=''):
    from modules.admin_access import has_permission,PERMISSION_AUTOMATIONS
    from modules.automation_v2 import _matches,_execute_action
    from modules.contact_budget import quiet,usage
    from modules.management_suite import automation_settings
    if not has_permission(db,actor,PERMISSION_AUTOMATIONS):raise PermissionError('FORBIDDEN')
    rule=db.get('automation_rules_v2',{}).get(rule_id)
    if not rule or rule.get('deleted_at'):raise ValueError('قانون پیدا نشد')
    # Read helpers may initialize legacy defaults; keep preview isolated.
    working=deepcopy(db)
    ids=sorted(str(uid) for uid in db.get('users',{}) if str(uid)>str(after))[:max(1,min(1000,int(limit)))+1]
    has_more=len(ids)>limit;ids=ids[:limit]
    reasons=Counter();examples=[];matched=0
    for uid in ids:
        event=enriched_event(working,{'user_id':uid,'entity_id':uid,'event_id':'preview:'+uid,'dry_run':True})
        if not _matches(rule.get('conditions'),event):reasons['conditions']+=1;continue
        matched+=1
        if quiet(working,uid):reasons['quiet_hours']+=1
        if usage(working,uid)>=int(automation_settings(working)['crm_daily_contact_cap']):reasons['daily_cap']+=1
        if len(examples)<3:
            try:
                effects=[_execute_action(working,rule,a,event,dry_run=True,run_id='preview',action_index=i) for i,a in enumerate(rule['actions'])]
            except ValueError:
                effects=[{'validation_error':'برای پیش‌نمایش این اقدام، اطلاعات رویداد واقعی لازم است.'}]
            examples.append({'user_id':uid,'effects':effects})
    return {'rule_id':rule_id,'checked':len(ids),'matched_conditions':matched,'exclusions':dict(reasons),
            'examples':examples,'next_after':ids[-1] if has_more else None,'actual_deliveries':0,
            'event_specific_conditions_may_require_real_event':True,'generated_at':utc_iso()}


def delivery_summary(db,rule_id=None):
    rows=[r for r in db.get('automation_outbox',{}).values() if not rule_id or str(r.get('dedupe_key','')).startswith('av2:'+rule_id+':')]
    counts=Counter(r.get('status','unknown') for r in rows)
    return {'queued':counts['pending']+counts['retry'],'processing':counts['processing'],'delivered':counts['sent'],
            'uncertain':counts['uncertain'],'failed':counts['dead_letter'],'cancelled':counts['cancelled']}


def pause(db,actor,mode):
    from modules.admin_access import has_permission,PERMISSION_AUTOMATIONS
    from modules.management_suite import automation_settings
    from core.domain import audit
    if not has_permission(db,actor,PERMISSION_AUTOMATIONS):raise PermissionError('FORBIDDEN')
    if mode not in {'immediate','drain','resume'}:raise ValueError('شیوهٔ توقف نامعتبر است')
    cfg=automation_settings(db);cfg['enabled']=mode=='resume';cfg['pause_mode']='drain' if mode=='drain' else 'immediate'
    audit(db,actor,'automation_pause',mode)
    return cfg
