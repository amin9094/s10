from __future__ import annotations

from collections import Counter
from datetime import datetime, timedelta
from typing import Any

from core.utils import parse_dt, utc_iso, utc_now
from modules.admin_control_center import notification_preferences
from modules.business_dashboard import commercial_dashboard
from modules.kpi_trader import kpi_trader_dashboard, task_is_overdue
from modules.user_intelligence import build_user_profile


def _rows(value: Any) -> list[dict[str, Any]]:
    return [row for row in value if isinstance(row, dict)] if isinstance(value, list) else []


def _stamp(value: Any) -> datetime | None:
    return parse_dt(value)


def _within(value: Any, start: datetime, end: datetime) -> datetime | None:
    stamp = _stamp(value)
    return stamp if stamp and start <= stamp <= end else None


def team_operations_calendar(
    db: dict[str, Any],
    *,
    admin_ids: list[int | str] | tuple[int | str, ...] = (),
    days: int = 14,
    now: datetime | None = None,
) -> dict[str, Any]:
    """Unify operational deadlines in one conflict-aware team calendar."""
    current = now or utc_now()
    end = current + timedelta(days=max(1, min(int(days), 90)))
    events: list[dict[str, Any]] = []

    for task in _rows(db.get("kpi_trader_tasks")):
        if task.get("status") != "active":
            continue
        due = _within(task.get("due_at"), current - timedelta(days=30), end)
        if not due:
            continue
        assignees = [str(value) for value in task.get("assignee_ids", [])]
        events.append(
            {
                "id": str(task.get("id") or ""),
                "kind": "kpi_task",
                "title": str(task.get("title_fa") or task.get("title_en") or task.get("id")),
                "at": utc_iso(due),
                "owners": assignees,
                "priority": str(task.get("priority") or "normal"),
                "overdue": due < current,
                "callback": f"kpi_admin_task:{task.get('id')}",
            }
        )

    for row in _rows(db.get("scheduled_signals")):
        if row.get("status") not in {"pending", "processing", "failed"}:
            continue
        run_at = _within(row.get("run_at"), current - timedelta(days=1), end)
        if run_at:
            payload = row.get("payload") if isinstance(row.get("payload"), dict) else {}
            events.append(
                {
                    "id": f"SIG-{row.get('id')}",
                    "kind": "scheduled_signal",
                    "title": f"سیگنال {payload.get('symbol') or row.get('id')}",
                    "at": utc_iso(run_at),
                    "owners": [str(row.get("admin_id") or "")],
                    "priority": "high",
                    "overdue": run_at < current,
                    "callback": "a_channel_center",
                }
            )

    campaigns = db.get("marketing_campaigns", {})
    if isinstance(campaigns, dict):
        for row in campaigns.values():
            if not isinstance(row, dict) or row.get("status") in {"completed", "cancelled", "archived"}:
                continue
            scheduled = _within(row.get("scheduled_for"), current - timedelta(days=1), end)
            if scheduled:
                events.append(
                    {
                        "id": str(row.get("id") or ""),
                        "kind": "campaign",
                        "title": str(row.get("name") or row.get("id")),
                        "at": utc_iso(scheduled),
                        "owners": [str(row.get("created_by") or "")],
                        "priority": "normal",
                        "overdue": scheduled < current,
                        "callback": "a_campaigns",
                    }
                )

    events.sort(key=lambda row: str(row.get("at") or ""))
    workload: dict[str, int] = Counter()
    for event in events:
        for owner in event["owners"]:
            if owner:
                workload[owner] += 1

    conflicts: list[dict[str, Any]] = []
    for owner in {str(value) for value in admin_ids if str(value)} | set(workload):
        owned = [row for row in events if owner in row["owners"]]
        for first, second in zip(owned, owned[1:]):
            first_at, second_at = _stamp(first["at"]), _stamp(second["at"])
            if first_at and second_at and second_at - first_at <= timedelta(minutes=30):
                conflicts.append(
                    {
                        "owner_id": owner,
                        "first_id": first["id"],
                        "second_id": second["id"],
                        "at": second["at"],
                    }
                )

    shifts = db.get("admin_shifts", {})
    shift_coverage = {
        str(uid): bool(isinstance(row, dict) and row.get("enabled", True))
        for uid, row in shifts.items()
    } if isinstance(shifts, dict) else {}
    return {
        "generated_at": utc_iso(current),
        "days": days,
        "events": events,
        "event_count": len(events),
        "overdue_count": sum(1 for row in events if row.get("overdue")),
        "conflicts": conflicts,
        "workload": dict(sorted(workload.items(), key=lambda item: item[1], reverse=True)),
        "shift_coverage": shift_coverage,
    }


def team_performance_dashboard(
    db: dict[str, Any], admin_ids: list[int | str] | tuple[int | str, ...]
) -> dict[str, Any]:
    """Quality, speed and commercial impact for every managed administrator."""
    submissions = _rows(db.get("kpi_trader_submissions"))
    outcomes = _rows(db.get("kpi_business_outcomes"))
    rows: list[dict[str, Any]] = []
    for value in admin_ids:
        uid = str(value)
        dashboard = kpi_trader_dashboard(db, uid)
        owned = [row for row in submissions if str(row.get("trader_id") or "") == uid]
        task_ids = {str(row.get("task_id") or "") for row in owned}
        business = [row for row in outcomes if str(row.get("task_id") or "") in task_ids]
        turnaround: list[float] = []
        first_pass = 0
        for submission in owned:
            submitted = _stamp(submission.get("submitted_at"))
            reviewed = _stamp(submission.get("reviewed_at"))
            if submitted and reviewed:
                turnaround.append(max(0.0, (reviewed - submitted).total_seconds() / 3600))
            if submission.get("status") == "approved" and not submission.get("resubmission_of"):
                first_pass += 1
        reviewed_count = sum(1 for row in owned if row.get("status") in {"approved", "rejected"})
        assigned = [
            row
            for row in _rows(db.get("kpi_trader_tasks"))
            if uid in [str(item) for item in row.get("assignee_ids", [])]
        ]
        rows.append(
            {
                **dashboard,
                "assigned_tasks": len(assigned),
                "active_tasks": sum(1 for row in assigned if row.get("status") == "active"),
                "overdue_assigned": sum(1 for row in assigned if task_is_overdue(row)),
                "first_pass_rate": round(first_pass / max(1, reviewed_count) * 100, 2),
                "average_review_hours": round(sum(turnaround) / max(1, len(turnaround)), 2),
                "commercial": {
                    key: sum(int(row.get(key, 0) or 0) for row in business)
                    for key in ("revenue", "sales", "renewals", "leads")
                },
            }
        )
    rows.sort(
        key=lambda row: (
            int(row["commercial"]["revenue"]),
            float(row["quality_score"]),
            int(row["points_total"]),
        ),
        reverse=True,
    )
    return {
        "generated_at": utc_iso(),
        "admins": rows,
        "team": {
            "points": sum(int(row["points_total"]) for row in rows),
            "revenue": sum(int(row["commercial"]["revenue"]) for row in rows),
            "sales": sum(int(row["commercial"]["sales"]) for row in rows),
            "renewals": sum(int(row["commercial"]["renewals"]) for row in rows),
            "leads": sum(int(row["commercial"]["leads"]) for row in rows),
            "quality_score": round(
                sum(float(row["quality_score"]) for row in rows) / max(1, len(rows)), 2
            ),
        },
    }


def subscription_growth_center(db: dict[str, Any]) -> dict[str, Any]:
    """Actionable subscription funnel built from verified orders and CRM behavior."""
    commercial = commercial_dashboard(db)
    users = db.get("users", {}) if isinstance(db.get("users"), dict) else {}
    profiles = [build_user_profile(db, uid) for uid in users]
    segments: Counter[str] = Counter()
    for profile in profiles:
        segments.update(str(item) for item in profile.get("segments", []))
    revenue = commercial["revenue"]
    vip = commercial["vip"]
    opportunities = {
        "renewal_due": int(segments.get("renewal_due", 0)),
        "abandoned_checkout": int(segments.get("abandoned_checkout", 0)),
        "high_intent": int(commercial["crm"].get("high_intent", 0)),
        "at_risk": int(commercial["crm"].get("at_risk", 0)),
        "never_vip": int(segments.get("never_vip", 0)),
    }
    actions: list[dict[str, Any]] = []
    action_specs = (
        ("renewal_due", "کمپین تمدید ۷ روزه", "renewal_due"),
        ("abandoned_checkout", "بازیابی خرید نیمه‌تمام", "abandoned_checkout"),
        ("high_intent", "پیشنهاد VIP به کاربران مستعد", "plan_interested"),
        ("at_risk", "کمپین جلوگیری از ریزش", "behavior_at_risk"),
    )
    for key, title, audience in action_specs:
        if opportunities[key]:
            actions.append(
                {
                    "key": key,
                    "title": title,
                    "audience": audience,
                    "users": opportunities[key],
                    "estimated_value": opportunities[key] * int(revenue.get("average_order_value", 0) or 0),
                }
            )
    return {
        "generated_at": utc_iso(),
        "revenue": revenue,
        "vip": vip,
        "growth": commercial["growth"],
        "campaigns": commercial["campaigns"],
        "opportunities": opportunities,
        "actions": actions,
        "funnel": {
            "users": len(users),
            "high_intent": opportunities["high_intent"],
            "buyers_30d": int(vip.get("buyers_30d", 0) or 0),
            "active_vip": int(vip.get("active", 0) or 0),
            "conversion_percent": float(vip.get("conversion_30d", 0) or 0),
        },
    }


def notification_intelligence(db: dict[str, Any]) -> dict[str, Any]:
    """Explain reach, preferences and recommended audiences before a broadcast."""
    users = db.get("users", {}) if isinstance(db.get("users"), dict) else {}
    language_counts: Counter[str] = Counter()
    market_counts: Counter[str] = Counter()
    quiet = paused = 0
    segment_counts: Counter[str] = Counter()
    for uid, user in users.items():
        user = user if isinstance(user, dict) else {}
        language_counts[str(user.get("language") or "fa")] += 1
        pref = notification_preferences(db, uid)
        market_counts.update(str(item) for item in pref.get("markets", []))
        quiet += int(bool(pref.get("quiet_enabled")))
        paused += int(bool(_stamp(pref.get("paused_until")) and _stamp(pref.get("paused_until")) > utc_now()))
        segment_counts.update(str(item) for item in build_user_profile(db, uid).get("segments", []))

    log = _rows(db.get("notification_routing_log"))
    allowed = sum(1 for row in log if row.get("allowed"))
    blocked = len(log) - allowed
    reasons = Counter(str(row.get("reason") or "unknown") for row in log if not row.get("allowed"))
    recommendations = [
        {
            "segment": segment,
            "title": title,
            "users": int(segment_counts.get(segment, 0)),
            "best_channel": "personal" if segment != "all" else "broadcast",
        }
        for segment, title in (
            ("renewal_due", "یادآوری تمدید VIP"),
            ("abandoned_checkout", "تکمیل خرید نیمه‌تمام"),
            ("behavior_at_risk", "بازگشت کاربر در معرض ریزش"),
            ("active_user", "اعلان فوری فرصت بازار"),
        )
        if segment_counts.get(segment, 0)
    ]
    return {
        "generated_at": utc_iso(),
        "users": len(users),
        "languages": dict(language_counts),
        "markets": dict(market_counts),
        "quiet_hours_users": quiet,
        "paused_users": paused,
        "routing": {
            "total": len(log),
            "allowed": allowed,
            "blocked": blocked,
            "delivery_rate": round(allowed / max(1, len(log)) * 100, 2),
            "blocked_reasons": dict(reasons),
        },
        "segments": dict(segment_counts),
        "recommendations": recommendations,
    }
