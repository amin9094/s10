"""Frozen-input experiments. These results never mutate live settings or ledgers."""
from dataclasses import replace
from decimal import Decimal as D
from copy import deepcopy
import time
from modules.research_context import decode,implementation_hash
from modules.strategy_experiments import research_profiles
from repositories.v2.common import content_hash


def evaluate(context):
    if getattr(context,'review_only',False):
        from modules.admin_review_proposals import evaluate_review_proposals
        return evaluate_review_proposals(context)
    from modules.strategy_engines import evaluate_all
    return evaluate_all(context)


def simulate(plan,ticks,*,slippage_ticks=0,spread_ticks=0,cost_model=None,deadline=None):
    if not ticks:return {'state':'TAPE_UNAVAILABLE','result_is_observed_trade':False}
    # Quote perturbation is a declared scenario, never written into the archive.
    tape=deepcopy(ticks);quantum=D(plan.get('tick_size',plan.get('calculation_quantum','0')))
    for t in tape:
        t['bid']=str(D(t['bid'])-quantum*D(spread_ticks)/2)
        t['ask']=str(D(t['ask'])+quantum*D(spread_ticks)/2)
    first=tape[0];sign=D(1) if plan['direction']=='BUY' else D(-1)
    above=(plan['direction']=='BUY')!=(plan['submodel']=='range_breakout')
    if not (D(first['bid'])>D(plan['zone_high']) if above else D(first['ask'])<D(plan['zone_low'])):
        return {'state':'ORIGINAL_ZONE_NOT_AHEAD','result_is_observed_trade':False}
    p={'plan':deepcopy(plan),'state':'WAITING','epoch':first['epoch'],'last_tick_id':first['id'],
       'last_received_ms':first['received_ms'],'last_event_ms':first['event_ms'],'armed_ms':first['received_ms'],
       'entry_balance_usd':'5000','realized_usd':'0','unrealized_usd':'0','risk_usd':'0','risk_percent':'1',
       'remaining':'1','targets_hit':[],'events':[],'cost_model':cost_model,'fees_included':False}
    from modules.strategy_paper import advance
    for index,t in enumerate(tape[1:]):
        if index%32==0 and deadline is not None and time.monotonic()>=deadline:
            return {'state':'RESEARCH_TIME_LIMIT','result_is_observed_trade':False,'outcome_unknown':True}
        before=p['state'];p,_=advance(p,t)
        if before=='WAITING' and p['state']=='OPEN' and slippage_ticks:
            # The locked stop/targets remain unchanged. This is adverse entry
            # slippage, with a fresh 1% sizing against the adverse fill.
            fill=D(p['fill_price'])+sign*quantum*slippage_ticks;distance=sign*(fill-D(plan['stop']))
            if distance<=0:return {'state':'SCENARIO_RISK_INVALID','result_is_observed_trade':False}
            p.update(fill_price=str(fill),risk_distance=str(distance),quantity=str(D(50)/distance))
        if p['state'] not in {'WAITING','OPEN'}:break
    return {'state':p['state'],'reason':p.get('reason'),'realized_usd':p['realized_usd'],
            'unrealized_usd':p['unrealized_usd'],'events':p['events'],'excursions':p.get('excursions'),
            'fees_included':p.get('fees_included',False),'risk_percent':1,'initial_balance_usd':'5000',
            'result_is_observed_trade':False,'model':'HISTORICAL_QUOTE_SCENARIO_NOT_ACTUAL_FORWARD_LEDGER'}


def experiment(bundle,mode='replay',ticks=()):
    deadline=time.monotonic()+70
    context=decode(bundle);variants=[('baseline',context)]
    if mode=='variants':
        variants=[]
        for p in research_profiles(context.parameters):
            variants.append((p.profile_id,replace(context,parameters=p,engine_parameters=tuple((k,replace(p,profile_id=p.profile_id)) for k,_ in context.engine_parameters))))
    elif mode=='ablation':
        from modules.indicator_suite import CATALOG
        chosen=context.indicator_selection or tuple(CATALOG)
        variants += [('without:'+key,replace(context,indicator_selection=tuple(k for k in chosen if k!=key))) for key in chosen if len(chosen)>1]
        custom=context.custom_settings
        if custom and custom.enabled:
            from modules.custom_strategy import FILTERS
            variants += [('custom_without:'+key,replace(context,custom_settings=replace(custom,**{key:False}))) for key in FILTERS if getattr(custom,key)]
    elif mode not in {'replay','sensitivity'}:raise ValueError('RESEARCH_MODE_INVALID')
    rows=[]
    for label,selected in variants:
        if time.monotonic()>=deadline:break
        result=evaluate(selected);plans=[r.get('plan') or r.get('draft_plan') for r in result['results'] if r.get('plan') or r.get('draft_plan')]
        outcomes=[{'setup_id':p['setup_id'],'engine':p['engine'],'plan_hash':content_hash(p),'plan':p,'outcome':simulate(p,ticks,deadline=deadline)} for p in plans]
        if mode=='sensitivity':
            for row in outcomes:
                row['scenarios']=[{'spread_ticks':s,'adverse_slippage_ticks':l,'outcome':simulate(row['plan'],ticks,spread_ticks=s,slippage_ticks=l,deadline=deadline)} for s,l in ((0,0),(1,1),(2,2),(4,4))]
        rows.append({'variant':label,'results':result['results'],'outcomes':outcomes,'sample_count':len(plans)})
    return {'version':1,'input_hash':content_hash(bundle),'implementation_hash':implementation_hash(),
            'same_implementation':bundle['implementation_hash']==implementation_hash(),'mode':mode,'variants':rows,
            'automatic_activation':False,'win_rate':None,'evaluation_kind':'FROZEN_INPUT_RESEARCH',
            'tape_samples':len(ticks),'tape_through_ms':ticks[-1]['received_ms'] if ticks else None,
            'variant_count_requested':len(variants),'variant_count_completed':len(rows),
            'time_limit_reached':time.monotonic()>=deadline,'sample_disclosure':'ONE_CASE_IS_NOT_OUT_OF_SAMPLE_VALIDATION'}
