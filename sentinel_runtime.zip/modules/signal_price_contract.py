"""One exact display contract for plan, caption and poster render inputs."""
from decimal import Decimal as D
from modules.signal_targets import TARGET_KEYS
from modules.strategy_signal_format import exact_price
from repositories.v2.common import content_hash


def manifest(entry,stop,targets):
    levels={'entry':exact_price(entry),'stop':exact_price(stop),**{f'tp{i}':exact_price(p) for i,p in enumerate(targets,1)}}
    return {'levels':levels,'sha256':content_hash(levels),'model':'EXACT_DECIMAL_RENDER_INPUTS_NOT_OCR'}


def assert_identity(plan,rendered,*,signal_number=None):
    aliases={'1H':'1h','H1':'1h','M5':'5m','5M':'5m','H4':'4h','4H':'4h'}
    expected=str(plan['timeframe']);actual=str(rendered.get('meta',{}).get('timeframe',''))
    if (rendered.get('symbol')!=plan['symbol'] or str(rendered.get('side','')).upper()!=plan['direction']
        or aliases.get(actual,actual)!=aliases.get(expected,expected)):
        raise ValueError('SIGNAL_RENDER_IDENTITY_MISMATCH')
    if signal_number is not None and str(rendered.get('signal_id'))!=str(signal_number):
        raise ValueError('SIGNAL_RENDER_NUMBER_MISMATCH')
    return True


def assert_parity(plan,rendered):
    expected=manifest(plan['entry'],plan['stop'],[plan[k] for k in TARGET_KEYS if plan.get(k) is not None])
    actual=rendered.get('meta',{}).get('price_manifest')
    if actual!=expected:raise ValueError('SIGNAL_RENDER_PRICE_MISMATCH')
    text=rendered.get('text','')
    import re
    labels={'entry':'نقطه ورود','stop':'حد ضرر',**{k:k.upper() for k in expected['levels'] if k.startswith('tp')}}
    for key,label in labels.items():
        matches=re.findall(re.escape(label)+r': <code>([0-9]+(?:\.[0-9]+)?)</code>',text)
        if len(matches)!=1 or D(matches[0])!=D(expected['levels'][key]):raise ValueError('SIGNAL_CAPTION_PRICE_MISMATCH')
    quantum=D(plan.get('tick_size',plan.get('calculation_quantum','0')))
    if quantum<=0:raise ValueError('SIGNAL_PRICE_QUANTUM_UNAVAILABLE')
    # The native plan is already quantized. Reject off-grid publication; never
    # alter its prices to make presentation pass. Indicative precision is not
    # falsely called a broker tick size.
    if any(D(value)%quantum for value in expected['levels'].values()):raise ValueError('SIGNAL_RENDER_OFF_GRID')
    return expected
