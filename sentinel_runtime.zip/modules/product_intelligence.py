from __future__ import annotations

import hashlib
import html
from collections import defaultdict
from typing import Any

from core.utils import utc_iso
from modules.market_scope import signal_market_category
from modules.outcome_engine import FINAL_SIGNAL_STATUSES, calculate_signal_outcome
from modules.signal_versioning import signal_version_history
from modules.trading_os import trust_passport

ONBOARDING_EXPERIENCE = {"beginner", "intermediate", "advanced", "professional"}
ONBOARDING_MARKETS = {"forex", "crypto", "both"}
ONBOARDING_RISK = {"conservative", "balanced", "aggressive"}
ONBOARDING_GOALS = {"education", "signals", "prop", "journal"}
REGIMES = {"trend", "range", "high_volatility", "news_driven", "low_liquidity", "balanced"}


def ensure_product_intelligence(db: dict[str, Any]) -> None:
    db.setdefault("miniapp_onboarding", {})
    db.setdefault("signal_replays", {})
    db.setdefault("signal_share_cards", {})
    db.setdefault("market_regime_history", [])


def onboarding_profile(db: dict[str, Any], user_id: int | str) -> dict[str, Any]:
    ensure_product_intelligence(db)
    uid = str(user_id)
    row = db["miniapp_onboarding"].setdefault(
        uid,
        {
            "experience": "",
            "market": "both",
            "account_size": 0.0,
            "risk_tolerance": "balanced",
            "goal": "",
            "completed": False,
            "completed_at": None,
            "updated_at": utc_iso(),
        },
    )
    row.setdefault("experience", "")
    row.setdefault("market", "both")
    row.setdefault("account_size", 0.0)
    row.setdefault("risk_tolerance", "balanced")
    row.setdefault("goal", "")
    row.setdefault("completed", False)
    row.setdefault("completed_at", None)
    return dict(row)


def _recommendation(row: dict[str, Any]) -> dict[str, Any]:
    experience = str(row.get("experience") or "")
    goal = str(row.get("goal") or "")
    market = str(row.get("market") or "both")
    risk = str(row.get("risk_tolerance") or "balanced")
    home_mode = "guided" if experience in {"", "beginner"} else "professional"
    primary_page = "risk" if goal == "prop" else "signals" if goal == "signals" else "journal" if goal == "journal" else "home"
    education_prompts = experience in {"", "beginner", "intermediate"} or goal == "education"
    return {
        "home_mode": home_mode,
        "primary_page": primary_page,
        "market_filter": market,
        "risk_tone": risk,
        "education_prompts": education_prompts,
        "show_advanced_metrics": experience in {"advanced", "professional"},
    }


def update_onboarding(db: dict[str, Any], user_id: int | str, values: dict[str, Any]) -> dict[str, Any]:
    ensure_product_intelligence(db)
    row = onboarding_profile(db, user_id)
    experience = str(values.get("experience") or row.get("experience") or "").lower()
    market = str(values.get("market") or row.get("market") or "both").lower()
    risk = str(values.get("risk_tolerance") or row.get("risk_tolerance") or "balanced").lower()
    goal = str(values.get("goal") or row.get("goal") or "").lower()
    if experience not in ONBOARDING_EXPERIENCE:
        raise ValueError("ONBOARDING_EXPERIENCE_INVALID")
    if market not in ONBOARDING_MARKETS:
        raise ValueError("ONBOARDING_MARKET_INVALID")
    if risk not in ONBOARDING_RISK:
        raise ValueError("ONBOARDING_RISK_INVALID")
    if goal not in ONBOARDING_GOALS:
        raise ValueError("ONBOARDING_GOAL_INVALID")
    try:
        account_size = max(0.0, min(float(values.get("account_size", row.get("account_size", 0)) or 0), 1_000_000_000.0))
    except (TypeError, ValueError) as exc:
        raise ValueError("ONBOARDING_ACCOUNT_SIZE_INVALID") from exc
    now = utc_iso()
    stored = {
        "experience": experience,
        "market": market,
        "account_size": round(account_size, 2),
        "risk_tolerance": risk,
        "goal": goal,
        "completed": True,
        "completed_at": row.get("completed_at") or now,
        "updated_at": now,
    }
    db["miniapp_onboarding"][str(user_id)] = stored
    return {**stored, "recommendation": _recommendation(stored)}


def onboarding_snapshot(db: dict[str, Any], user_id: int | str) -> dict[str, Any]:
    row = onboarding_profile(db, user_id)
    return {**row, "recommendation": _recommendation(row)}


def _signal(db: dict[str, Any], signal_id: int | str) -> dict[str, Any]:
    target = int(signal_id)
    row = next(
        (
            item
            for item in db.get("signals", [])
            if isinstance(item, dict) and int(item.get("id", 0) or 0) == target
        ),
        None,
    )
    if not row:
        raise ValueError("SIGNAL_NOT_FOUND")
    return row


def infer_signal_regime(signal: dict[str, Any]) -> dict[str, Any]:
    text = " ".join(
        str(signal.get(key) or "")
        for key in ("strategy", "analysis", "note", "market_session_label", "market_session")
    ).lower()
    volatility = str(signal.get("volatility") or signal.get("market_volatility") or "").lower()
    reasons: list[str] = []
    regime = "balanced"
    confidence = 0.45
    if any(token in text for token in ("nfp", "cpi", "fomc", "news", "خبر", "economic")):
        regime, confidence = "news_driven", 0.82
        reasons.append("economic-event context")
    elif volatility in {"high", "very_high", "extreme"} or any(token in text for token in ("high volatility", "نوسان بالا")):
        regime, confidence = "high_volatility", 0.78
        reasons.append("high volatility metadata")
    elif any(token in text for token in ("trend", "breakout", "momentum", "روند", "شکست")):
        regime, confidence = "trend", 0.72
        reasons.append("trend or breakout setup")
    elif any(token in text for token in ("range", "sideway", "support resistance", "رنج", "حمایت", "مقاومت")):
        regime, confidence = "range", 0.68
        reasons.append("range or mean-reversion setup")
    elif any(token in text for token in ("asian close", "rollover", "low liquidity", "نقدشوندگی پایین")):
        regime, confidence = "low_liquidity", 0.66
        reasons.append("low-liquidity session")
    session = str(signal.get("market_session_label") or signal.get("market_session") or "")
    return {
        "regime": regime,
        "confidence": round(confidence, 3),
        "reasons": reasons or ["insufficient history; neutral classification"],
        "volatility": volatility or "unknown",
        "session": session,
        "basis": "transparent metadata heuristic",
    }


def market_regime_dashboard(db: dict[str, Any], *, market: str = "", symbol: str = "") -> dict[str, Any]:
    ensure_product_intelligence(db)
    groups: dict[str, list[float]] = defaultdict(list)
    rows = [item for item in db.get("signals", []) if isinstance(item, dict)]
    if market:
        rows = [item for item in rows if signal_market_category(item) == str(market)]
    if symbol:
        rows = [item for item in rows if str(item.get("symbol") or "").upper() == str(symbol).upper()]
    for item in rows:
        outcome = calculate_signal_outcome(item)
        if not outcome.final:
            continue
        regime = infer_signal_regime(item)["regime"]
        groups[regime].append(float(outcome.net_r or 0))
    performance = []
    for regime in sorted(REGIMES):
        values = groups.get(regime, [])
        wins = sum(1 for value in values if value > 0)
        performance.append(
            {
                "regime": regime,
                "sample_size": len(values),
                "win_rate": round(wins / max(1, len(values)) * 100, 3),
                "average_r": round(sum(values) / max(1, len(values)), 4),
                "net_r": round(sum(values), 4),
            }
        )
    recent = rows[0] if rows else {}
    current = infer_signal_regime(recent) if recent else {
        "regime": "balanced",
        "confidence": 0.0,
        "reasons": ["no signal history"],
        "volatility": "unknown",
        "session": "",
        "basis": "no data",
    }
    return {
        "current": current,
        "performance": performance,
        "sample_size": sum(len(values) for values in groups.values()),
        "generated_at": utc_iso(),
    }


def _event_time(row: dict[str, Any]) -> str:
    return str(row.get("created_at") or row.get("updated_at") or row.get("at") or "")


def signal_replay(db: dict[str, Any], signal_id: int | str) -> dict[str, Any]:
    ensure_product_intelligence(db)
    signal = _signal(db, signal_id)
    sid = int(signal.get("id", 0) or 0)
    revisions = signal_version_history(signal, db.get("signal_revisions"))
    outcome_events = [
        dict(row)
        for row in db.get("signal_outcome_events", [])
        if isinstance(row, dict) and int(row.get("signal_id", 0) or 0) == sid
    ]
    timeline: list[dict[str, Any]] = [
        {
            "type": "published",
            "at": signal.get("created_at"),
            "title": "Signal published",
            "fields": {
                "entry": signal.get("entry") or signal.get("entries"),
                "stop": signal.get("stop"),
                "targets": signal.get("targets"),
                "risk": signal.get("risk"),
            },
        }
    ]
    for row in revisions:
        if int(row.get("revision", row.get("version", 1)) or 1) <= 1:
            continue
        timeline.append(
            {
                "type": "revision",
                "at": _event_time(row),
                "title": f"Revision {int(row.get('revision', row.get('version', 1)) or 1)}",
                "changed_fields": [str(value) for value in row.get("changed_fields", [])],
                "reason": str(row.get("reason") or ""),
                "hash": str(row.get("hash") or ""),
            }
        )
    for row in outcome_events:
        timeline.append(
            {
                "type": str(row.get("event") or row.get("kind") or row.get("status") or "outcome"),
                "at": _event_time(row),
                "title": str(row.get("title") or row.get("event") or row.get("status") or "Outcome update"),
                "details": {key: value for key, value in row.items() if key not in {"signal_id", "created_at", "updated_at"}},
            }
        )
    timeline.sort(key=lambda row: str(row.get("at") or ""))
    passport = trust_passport(db, signal)
    result = {
        "signal_id": sid,
        "display_number": int(signal.get("display_number", sid) or sid),
        "symbol": str(signal.get("symbol") or ""),
        "side": str(signal.get("side") or "").upper(),
        "market_category": signal_market_category(signal),
        "status": str(signal.get("status") or "open"),
        "final": str(signal.get("status") or "open") in FINAL_SIGNAL_STATUSES,
        "timeline": timeline,
        "regime": infer_signal_regime(signal),
        "outcome": passport["outcome"],
        "evidence_hash": passport["evidence_hash"],
        "revision_chain_valid": passport["revision_chain_valid"],
        "analyst_lesson": str(signal.get("post_mortem") or signal.get("lesson") or signal.get("education_note") or ""),
        "generated_at": utc_iso(),
    }
    db["signal_replays"][str(sid)] = result
    return result


def _safe_svg_text(value: Any, limit: int = 120) -> str:
    return html.escape(str(value or "")[:limit], quote=True)


def signal_share_card(db: dict[str, Any], signal_id: int | str) -> dict[str, Any]:
    ensure_product_intelligence(db)
    replay = signal_replay(db, signal_id)
    record = trust_passport(db, _signal(db, signal_id))
    summary = {
        "symbol": replay["symbol"],
        "side": replay["side"],
        "status": replay["status"],
        "net_r": float(replay["outcome"].get("net_r") or 0),
        "sample_size": 1,
        "evidence_hash": replay["evidence_hash"],
        "generated_at": replay["generated_at"],
    }
    tone = "#2dd4bf" if summary["net_r"] > 0 else "#fb7185" if summary["net_r"] < 0 else "#fbbf24"
    svg = f'''<svg xmlns="http://www.w3.org/2000/svg" width="1080" height="1350" viewBox="0 0 1080 1350">
<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#02070c"/><stop offset="1" stop-color="#0b1720"/></linearGradient></defs>
<rect width="1080" height="1350" rx="64" fill="url(#g)"/><rect x="64" y="64" width="952" height="1222" rx="44" fill="none" stroke="#243746" stroke-width="3"/>
<text x="110" y="160" fill="#d9e7ef" font-family="Arial,sans-serif" font-size="42" letter-spacing="8">SENTINEL</text>
<text x="110" y="260" fill="#ffffff" font-family="Arial,sans-serif" font-size="86" font-weight="700">{_safe_svg_text(summary['symbol'])}</text>
<text x="110" y="330" fill="{tone}" font-family="Arial,sans-serif" font-size="42">{_safe_svg_text(summary['side'])} · {_safe_svg_text(summary['status']).upper()}</text>
<text x="110" y="570" fill="#8aa2b2" font-family="Arial,sans-serif" font-size="34">VERIFIED RESULT</text>
<text x="110" y="720" fill="{tone}" font-family="Arial,sans-serif" font-size="150" font-weight="700">{summary['net_r']:+.2f}R</text>
<text x="110" y="830" fill="#a9becb" font-family="Arial,sans-serif" font-size="32">Losses are never hidden · Sample size: 1</text>
<text x="110" y="1010" fill="#8aa2b2" font-family="Arial,sans-serif" font-size="28">EVIDENCE HASH</text>
<text x="110" y="1060" fill="#d9e7ef" font-family="monospace" font-size="22">{_safe_svg_text(summary['evidence_hash'], 64)}</text>
<text x="110" y="1200" fill="#607887" font-family="Arial,sans-serif" font-size="25">Not financial advice · Transparent outcome ledger</text>
</svg>'''
    digest = hashlib.sha256(svg.encode()).hexdigest()
    output = {
        **summary,
        "svg": svg,
        "mime_type": "image/svg+xml",
        "filename": f"sentinel-signal-{replay['display_number']}.svg",
        "card_hash": digest,
        "revision_chain_valid": record["revision_chain_valid"],
    }
    db["signal_share_cards"][str(signal_id)] = {key: value for key, value in output.items() if key != "svg"}
    return output
