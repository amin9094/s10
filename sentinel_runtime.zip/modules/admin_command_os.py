from __future__ import annotations

import copy
import hashlib
import heapq
import json
import re
import threading
import time
from collections import OrderedDict, defaultdict
from difflib import SequenceMatcher
from typing import Any, Callable, Iterable
from zoneinfo import ZoneInfo

from config import SETTINGS, is_primary_admin
from core.utils import parse_dt, utc_iso, utc_now
from modules.admin_access import has_permission

_FA_DIGITS = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")
_SEARCH_CACHE_LOCK = threading.RLock()
_SEARCH_INDEX_CACHE: OrderedDict[str, dict[str, Any]] = OrderedDict()
_SEARCH_CACHE_LIMIT = 4
_SEARCH_CACHE_TTL_SECONDS = 3.0
_SEARCH_CACHE_EPOCH = 0

ADMIN_PANEL_TAXONOMY: dict[str, dict[str, Any]] = {
    "command": {"title": "🛰 فرماندهی و هوش مصنوعی", "description": "مرکز فرماندهی، Gemini، جست‌وجو، تأییدها، Undo و حالت اضطراری"},
    "trading": {"title": "📡 سیگنال و عملیات معاملاتی", "description": "ساخت، بررسی، انتشار، نتایج، قالب‌ها و عملکرد تریدر"},
    "market": {"title": "📈 بازار، ریسک و حساب‌ها", "description": "بازار، اخبار، ژورنال، MT5، Risk OS و نگهبان پراپ"},
    "users": {"title": "👥 کاربران، CRM و پشتیبانی", "description": "پروفایل ۳۶۰، تیکت، رفتار، نگهداشت و دسترسی کاربران"},
    "sales": {"title": "💳 VIP، فروش و پرداخت", "description": "پلن، پرداخت، تخفیف، تمدید، فاکتور و گزارش مالی"},
    "content": {"title": "📣 کانال، محتوا و تبلیغات", "description": "انتشار، Broadcast، تبلیغات Gemini، رسانه و زمان‌بندی"},
    "education": {"title": "🎓 آموزش و محتوای کاربر", "description": "دوره، درس، فایل، آزمون، محتوای رایگان و پولی"},
    "engagement": {"title": "🏆 مسابقه، مأموریت و وفاداری", "description": "مسابقه، مأموریت، امتیاز، جایزه، رفرال و لیدربورد"},
    "automation": {"title": "🤖 اتوماسیون و زمان‌بندی", "description": "Rule Builder، Job، Reminder، Webhook، Retry و تقویم"},
    "analytics": {"title": "📊 گزارش، تحلیل و داده", "description": "داشبوردها، KPI، خروجی، Audit و تحلیل عملکرد"},
    "system": {"title": "⚙️ ادمین، امنیت و سیستم", "description": "ادمین‌ها، مجوزها، API، سلامت، بکاپ، لاگ و Railway"},
}


def _norm(value: Any) -> str:
    text = str(value or "").translate(_FA_DIGITS).casefold().replace("ي", "ی").replace("ك", "ک")
    return " ".join(re.findall(r"[\w\-@.#]+", text, flags=re.UNICODE))


def _rows(value: Any) -> list[dict[str, Any]]:
    if isinstance(value, list):
        return [row for row in value if isinstance(row, dict)]
    if isinstance(value, dict):
        return [row for row in value.values() if isinstance(row, dict)]
    return []


def _allowed(db: dict[str, Any], actor_id: int | str, permissions: tuple[str, ...]) -> bool:
    return bool(is_primary_admin(actor_id) or any(has_permission(db, actor_id, item) for item in permissions))


def _search_specs() -> list[dict[str, Any]]:
    return [
        {"key": "users", "sections": ("users",), "label": "کاربران", "category": "users", "permissions": ("users_view", "users"), "title": ("username", "first_name", "last_name", "name"), "fields": ("id", "user_id", "telegram_id", "username", "first_name", "last_name", "phone", "language", "status", "source")},
        {"key": "payments", "sections": ("vip_orders", "checkout_quotes", "payment_reconciliations", "receipt_uploads"), "label": "پرداخت‌ها", "category": "sales", "permissions": ("payment_dashboard_view", "payment_transactions_view", "payments"), "title": ("transaction_hash", "txid", "id", "order_id"), "fields": ("id", "order_id", "user_id", "transaction_hash", "txid", "amount", "status", "method", "reference")},
        {"key": "signals", "sections": ("signals", "signal_archive", "scheduled_signals"), "label": "سیگنال‌ها", "category": "trading", "permissions": ("signals_view", "signals"), "title": ("symbol", "display_number", "id"), "fields": ("id", "display_number", "symbol", "side", "status", "entry", "stop_loss", "result", "note")},
        {"key": "tickets", "sections": ("tickets", "support_tickets"), "label": "تیکت‌ها", "category": "users", "permissions": ("tickets_view", "tickets"), "title": ("subject", "title", "id"), "fields": ("id", "user_id", "subject", "title", "message", "status", "priority", "waiting_for")},
        {"key": "crm", "sections": ("crm_profiles", "crm_activities", "behavioral_insights"), "label": "CRM", "category": "users", "permissions": ("crm_view", "crm"), "title": ("title", "type", "user_id", "id"), "fields": ("id", "user_id", "title", "type", "note", "detail", "stage", "tags", "status")},
        {"key": "campaigns", "sections": ("marketing_campaigns", "announcements", "channel_management", "channel_insights"), "label": "محتوا و تبلیغات", "category": "content", "permissions": ("campaigns", "announcements", "channel_posts_publish"), "title": ("name", "title", "id"), "fields": ("id", "name", "title", "message", "text", "status", "delivery", "objective", "tracking")},
        {"key": "education", "sections": ("lessons", "education_lessons", "education_categories", "education_orders", "faq"), "label": "آموزش", "category": "education", "permissions": ("education_view", "education"), "title": ("title", "name", "id"), "fields": ("id", "title", "name", "description", "content", "status", "price", "category")},
        {"key": "contests", "sections": ("contests", "missions", "reward_requests", "referrals"), "label": "مسابقه و وفاداری", "category": "engagement", "permissions": ("contest_view", "mission_view", "contests", "missions"), "title": ("title", "name", "id"), "fields": ("id", "title", "name", "description", "status", "reward", "user_id")},
        {"key": "automation", "sections": ("automation_rules_v2", "automation_schedules", "automation_outbox", "automation_v2_runs", "automation_v2_jobs", "automation_v2_dead_letter", "crm_automation_log"), "label": "اتوماسیون", "category": "automation", "permissions": ("automations",), "title": ("name", "trigger", "id"), "fields": ("id", "name", "trigger", "status", "enabled", "last_error", "actions", "conditions")},
        {"key": "portfolio", "sections": ("trade_journal", "accounts", "mt5_connectors", "positions"), "label": "ژورنال و حساب‌ها", "category": "market", "permissions": ("portfolio", "risk_boards"), "title": ("symbol", "name", "id"), "fields": ("id", "user_id", "symbol", "side", "status", "name", "account_number", "broker", "note")},
        {"key": "admins", "sections": ("delegated_admins", "admin_shifts"), "label": "ادمین‌ها", "category": "system", "permissions": ("admin_management", "admin_shifts"), "title": ("username", "name", "user_id", "id"), "fields": ("id", "user_id", "username", "name", "role", "permissions", "active", "status")},
        {"key": "audit", "sections": ("admin_logs", "ai_audit_log", "security_audit_log", "incidents", "operations"), "label": "لاگ و رخداد", "category": "analytics", "permissions": ("audit_logs", "incidents", "runtime_logs_view"), "title": ("action", "title", "type", "id"), "fields": ("id", "action", "title", "type", "actor_id", "detail", "details", "status", "error", "created_at")},
        {"key": "system", "sections": ("feature_flags", "admin_control_center", "provider_health", "ai_health", "runtime_safety", "platform_registry"), "label": "سیستم", "category": "system", "permissions": ("system_control", "provider_health", "runtime_safety"), "title": ("name", "provider", "module", "id"), "fields": ("id", "name", "provider", "module", "status", "enabled", "error", "updated_at")},
    ]



def _open_callback_for(spec_key: str, section: str, row_id: str, row: dict[str, Any]) -> str:
    """Return a registered Telegram callback for directly opening a search hit.

    Only callbacks with stable, permission-checked handlers are emitted. Unknown
    or malformed identifiers deliberately return an empty value rather than
    creating a dead navigation target.
    """
    value = str(row_id or "").strip()
    numeric = value.isdigit() and int(value) > 0
    if spec_key in {"users", "crm"}:
        candidate = str(row.get("user_id") or row.get("telegram_id") or value).strip()
        return f"crm_open:{candidate}" if candidate.isdigit() and int(candidate) > 0 else ""
    if spec_key == "tickets" and numeric:
        return f"ticket_a:{value}"
    if spec_key == "signals" and numeric:
        return f"sig_result_view:{value}"
    if spec_key == "campaigns" and re.fullmatch(r"CMP-\d+", value):
        return f"campaign_view:{value}"
    if spec_key == "education":
        if section in {"lessons", "education_lessons"} and numeric:
            return f"lesson_manage:{value}"
        order_id = str(row.get("order_id") or value).strip()
        if re.fullmatch(r"EDU-\d+", order_id):
            return f"edu_order_view:{order_id}"
    if spec_key == "contests" and section == "missions" and numeric:
        return f"mission_manage:{value}"
    if spec_key == "admins":
        candidate = str(row.get("user_id") or value).strip()
        return f"admin_manage:{candidate}" if candidate.isdigit() and int(candidate) > 0 else ""
    if spec_key == "automation":
        return "a_automations"
    if spec_key == "payments":
        order_id = str(row.get("order_id") or value).strip().upper()
        return f"pending_detail:{order_id}:0" if re.fullmatch(r"[A-Z0-9]+", order_id) else ""
    return ""

def _trigrams(value: str) -> set[str]:
    compact = f"  {value}  "
    return {compact[index:index + 3] for index in range(max(0, len(compact) - 2))}


def invalidate_search_index() -> None:
    """Invalidate process-local indexes after a committed database mutation.

    The short TTL below also limits staleness when another Railway worker writes
    to PostgreSQL, while local writes invalidate immediately.
    """
    global _SEARCH_CACHE_EPOCH
    with _SEARCH_CACHE_LOCK:
        _SEARCH_CACHE_EPOCH += 1
        _SEARCH_INDEX_CACHE.clear()


def _edge_rows(value: Any) -> tuple[dict[str, Any], dict[str, Any]]:
    """Return first/last mapping without allocating a full section copy."""
    if isinstance(value, dict):
        first: dict[str, Any] = {}
        last: dict[str, Any] = {}
        for row in value.values():
            if not isinstance(row, dict):
                continue
            if not first:
                first = row
            last = row
        return first, last
    if isinstance(value, list):
        first = next((row for row in value if isinstance(row, dict)), {})
        last = next((row for row in reversed(value) if isinstance(row, dict)), {})
        return first, last
    return {}, {}


def _index_signature(db: dict[str, Any]) -> str:
    parts: list[Any] = [("epoch", _SEARCH_CACHE_EPOCH)]
    for spec in _search_specs():
        for section in spec["sections"]:
            value = db.get(section)
            length = len(value) if isinstance(value, (dict, list)) else 0
            first, last = _edge_rows(value)
            parts.append((
                section, length,
                first.get("updated_at") or first.get("created_at") or first.get("id"),
                last.get("updated_at") or last.get("created_at") or last.get("id"),
            ))
    parts.append(("next_ids", db.get("next_ids") or {}))
    raw = json.dumps(parts, ensure_ascii=False, sort_keys=True, default=str, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _build_search_index(db: dict[str, Any]) -> dict[str, Any]:
    documents: list[dict[str, Any]] = []
    token_index: dict[str, set[int]] = defaultdict(set)
    gram_index: dict[str, set[int]] = defaultdict(set)
    exact_index: dict[str, set[int]] = defaultdict(set)
    global_seen: set[tuple[str, str]] = set()
    for spec in _search_specs():
        for section in spec["sections"]:
            for index, row in enumerate(_rows(db.get(section))):
                row_id = str(row.get("id") or row.get("user_id") or row.get("order_id") or index)
                # Deduplicate mirrored stores in the same domain while retaining the first authoritative section.
                dedupe = (str(spec["key"]), row_id)
                if dedupe in global_seen:
                    continue
                global_seen.add(dedupe)
                values: list[str] = []
                for field in spec["fields"]:
                    value = row.get(field)
                    if isinstance(value, (dict, list)):
                        value = json.dumps(value, ensure_ascii=False, sort_keys=True, default=str)
                    if value not in (None, ""):
                        values.append(str(value))
                haystack = _norm(" ".join(values))
                if not haystack:
                    continue
                title = next((str(row.get(field) or "").strip() for field in spec["title"] if str(row.get(field) or "").strip()), row_id)
                subtitle_parts = [str(row.get(key) or "").strip() for key in ("status", "user_id", "symbol", "created_at") if str(row.get(key) or "").strip()]
                doc_id = len(documents)
                document = {
                    "type": spec["key"], "category": spec["category"], "permissions": tuple(spec["permissions"]),
                    "domain_label": spec["label"], "section": section, "id": row_id,
                    "title": title[:160], "subtitle": " • ".join(subtitle_parts)[:220], "haystack": haystack,
                    "target": {"section": section, "id": row_id},
                    "deep_link": f"sentinel://admin/{spec['key']}/{row_id}",
                    "open_callback": _open_callback_for(str(spec["key"]), section, row_id, row),
                }
                documents.append(document)
                exact_index[_norm(row_id)].add(doc_id)
                for token in set(haystack.split()):
                    if len(token) >= 2:
                        token_index[token].add(doc_id)
                for gram in _trigrams(haystack):
                    gram_index[gram].add(doc_id)
    return {"documents": documents, "tokens": token_index, "grams": gram_index, "exact": exact_index}


def _get_search_index(db: dict[str, Any]) -> dict[str, Any]:
    signature = _index_signature(db)
    now = time.monotonic()
    with _SEARCH_CACHE_LOCK:
        cached = _SEARCH_INDEX_CACHE.get(signature)
        if cached is not None and now - float(cached.get("_built_at", 0.0) or 0.0) <= _SEARCH_CACHE_TTL_SECONDS:
            _SEARCH_INDEX_CACHE.move_to_end(signature)
            return cached
        if cached is not None:
            _SEARCH_INDEX_CACHE.pop(signature, None)
    built = _build_search_index(db)
    built["_built_at"] = now
    with _SEARCH_CACHE_LOCK:
        _SEARCH_INDEX_CACHE[signature] = built
        _SEARCH_INDEX_CACHE.move_to_end(signature)
        while len(_SEARCH_INDEX_CACHE) > _SEARCH_CACHE_LIMIT:
            _SEARCH_INDEX_CACHE.popitem(last=False)
    return built


def _score(query: str, query_tokens: set[str], query_grams: set[str], haystack: str) -> float:
    if not query or not haystack:
        return 0.0
    if query == haystack:
        return 100.0
    if query in haystack:
        return 82.0 + min(10.0, len(query) / max(1, len(haystack)) * 10)
    hay_tokens = set(haystack.split())
    token_score = 55.0 * (len(query_tokens & hay_tokens) / max(1, len(query_tokens)))
    hay_grams = _trigrams(haystack[:2000])
    gram_score = 25.0 * (len(query_grams & hay_grams) / max(1, len(query_grams)))
    fuzzy = 20.0 * SequenceMatcher(None, query, haystack[: max(len(query) * 5, 100)]).ratio()
    return token_score + gram_score + fuzzy


def admin_global_search(
    db: dict[str, Any], actor_id: int | str, query: str, *, domain: str = "", limit: int = 30, offset: int = 0,
) -> dict[str, Any]:
    clean_query = _norm(query)
    if len(clean_query) < 2:
        raise ValueError("SEARCH_QUERY_TOO_SHORT")
    domain = str(domain or "").strip().lower()
    bounded = max(1, min(int(limit or 30), 100))
    offset = max(0, min(int(offset or 0), 10_000))
    index = _get_search_index(db)
    documents: list[dict[str, Any]] = index["documents"]
    query_tokens = {token for token in clean_query.split() if len(token) >= 2}
    query_grams = _trigrams(clean_query)
    candidates: set[int] = set(index["exact"].get(clean_query, set()))
    for token in query_tokens:
        candidates.update(index["tokens"].get(token, set()))
    if not candidates:
        # Rare trigrams produce a compact typo-tolerant candidate set instead of an O(N) full scan.
        postings = sorted((index["grams"].get(gram, set()) for gram in query_grams if index["grams"].get(gram)), key=len)
        for posting in postings[:12]:
            candidates.update(posting)
            if len(candidates) >= 5000:
                break
    if not candidates and len(documents) <= 2000:
        candidates = set(range(len(documents)))
    scored: list[tuple[float, int]] = []
    for doc_id in candidates:
        doc = documents[doc_id]
        if domain and domain not in {doc["type"], doc["category"]}:
            continue
        if not _allowed(db, actor_id, tuple(doc["permissions"])):
            continue
        score = _score(clean_query, query_tokens, query_grams, str(doc["haystack"]))
        if score >= 25:
            scored.append((score, doc_id))
    page_size = bounded + offset
    top = heapq.nlargest(page_size, scored, key=lambda item: (item[0], -item[1]))
    items: list[dict[str, Any]] = []
    for score, doc_id in top[offset:offset + bounded]:
        doc = documents[doc_id]
        items.append({
            "type": doc["type"], "domain_label": doc["domain_label"], "section": doc["section"],
            "id": doc["id"], "title": doc["title"], "subtitle": doc["subtitle"],
            "score": round(score, 3), "target": copy.deepcopy(doc["target"]), "deep_link": doc["deep_link"],
            "open_callback": str(doc.get("open_callback") or ""),
        })
    return {
        "query": str(query), "domain": domain, "total": len(scored), "items": items,
        "offset": offset, "limit": bounded, "has_more": len(scored) > offset + bounded,
        "candidate_count": len(candidates), "indexed_documents": len(documents), "generated_at": utc_iso(),
    }


def _count(rows: Any, predicate: Callable[[dict[str, Any]], bool] | None = None) -> int:
    values = _rows(rows)
    return sum(1 for row in values if predicate(row)) if predicate else len(values)


def _unique_rows(values: Iterable[Any], keys: tuple[str, ...]) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    seen: set[str] = set()
    for value in values:
        for index, row in enumerate(_rows(value)):
            identity = next((str(row.get(key)) for key in keys if row.get(key) not in (None, "")), "")
            if not identity:
                identity = hashlib.sha256(json.dumps(row, ensure_ascii=False, sort_keys=True, default=str).encode("utf-8")).hexdigest()
            if identity in seen:
                continue
            seen.add(identity)
            result.append(row)
    return result


def _is_active_vip(row: dict[str, Any], now: Any) -> bool:
    if str(row.get("status") or "active").lower() in {"expired", "cancelled", "canceled", "revoked", "inactive", "disabled"}:
        return False
    expiry = parse_dt(row.get("expires_at") or row.get("expire_at") or row.get("end_at") or row.get("valid_until"))
    return expiry is None or expiry > now


def _is_recent_user(row: dict[str, Any], now: Any) -> bool:
    stamp = parse_dt(row.get("last_seen_at") or row.get("last_activity_at") or row.get("updated_at") or row.get("created_at"))
    return bool(stamp and (now - stamp).days <= 30)


def admin_command_center_snapshot(db: dict[str, Any], actor_id: int | str) -> dict[str, Any]:
    if not _allowed(db, actor_id, ("mission_control", "dashboard", "ai_command_center")):
        raise PermissionError("ADMIN_PERMISSION_REQUIRED")
    now = utc_now()
    users_rows = _unique_rows((db.get("users"),), ("id", "user_id", "telegram_id"))
    vip_rows = _unique_rows((db.get("vip_users"),), ("user_id", "id"))
    payment_rows = _unique_rows((db.get("vip_orders"), db.get("payment_reconciliations")), ("id", "order_id", "transaction_hash", "txid"))
    ticket_rows = _unique_rows((db.get("tickets"), db.get("support_tickets")), ("id", "ticket_id"))
    signal_rows = _unique_rows((db.get("signals"), db.get("scheduled_signals")), ("id", "signal_id", "display_number"))
    campaign_rows = _unique_rows((db.get("marketing_campaigns"),), ("id", "campaign_id"))
    automation_rows = _unique_rows((db.get("automation_outbox"), db.get("automation_v2_runs"), db.get("automation_v2_jobs"), db.get("automation_v2_dead_letter")), ("id", "run_id", "job_id"))

    pending_payments = sum(1 for row in payment_rows if str(row.get("status") or "").lower() in {"pending", "submitted", "manual_review", "under_review"})
    waiting_tickets = sum(1 for row in ticket_rows if str(row.get("status") or "open").lower() not in {"closed", "resolved"} and str(row.get("waiting_for") or "admin").lower() in {"admin", "support", ""})
    pending_ai = _count(db.get("ai_admin_command_queue"), lambda row: str(row.get("status") or "").lower().startswith("pending"))
    incidents = _count(db.get("incidents"), lambda row: str(row.get("status") or "open").lower() not in {"closed", "resolved"})
    automation_failures = sum(1 for row in automation_rows if str(row.get("status") or "").lower() in {"failed", "dead", "dead_letter", "retry"})
    active_signals = sum(1 for row in signal_rows if str(row.get("status") or "").lower() in {"open", "active", "published", "scheduled"})
    ready_campaigns = sum(1 for row in campaign_rows if str(row.get("status") or "").lower() in {"approved", "ready_for_review", "scheduled"} or str(row.get("ai_ad_status") or "").lower() in {"ready_for_review", "approved", "scheduled"})
    total_users = len(users_rows)
    active_users = sum(1 for row in users_rows if _is_recent_user(row, now))
    active_vip = sum(1 for row in vip_rows if _is_active_vip(row, now))
    try:
        local_zone = ZoneInfo(str(SETTINGS.timezone or "UTC"))
    except Exception:
        local_zone = ZoneInfo("UTC")
    local_today = now.astimezone(local_zone).date()
    new_users_today = sum(
        1 for row in users_rows
        if (stamp := parse_dt(row.get("created_at"))) is not None and stamp.astimezone(local_zone).date() == local_today
    )
    metrics = {
        "users": active_users,
        "active_users_30d": active_users,
        "total_users": total_users,
        "new_users_today": new_users_today,
        "active_vip": active_vip,
        "pending_payments": pending_payments,
        "waiting_tickets": waiting_tickets,
        "pending_ai_approvals": pending_ai,
        "open_incidents": incidents,
        "automation_failures": automation_failures,
        "active_signals": active_signals,
        "ready_campaigns": ready_campaigns,
    }
    definitions = [
        (100, "پرداخت‌های معلق", pending_payments, "a_pending", "پرداخت‌هایی که نیازمند بررسی هستند"),
        (95, "تأییدهای Gemini", pending_ai, "a_ai_command_center", "فرمان‌های حساس در انتظار تأیید انسانی"),
        (90, "تیکت‌های منتظر", waiting_tickets, "a_tickets", "درخواست‌های بدون پاسخ ادمین"),
        (85, "رخدادهای باز", incidents, "a_incidents", "خطاها و رخدادهای عملیاتی"),
        (80, "خطاهای اتوماسیون", automation_failures, "a_automations", "اجراهای ناموفق یا Retry"),
        (65, "تبلیغات آماده", ready_campaigns, "a_campaigns", "تبلیغات آماده بررسی یا انتشار"),
        (55, "سیگنال‌های فعال", active_signals, "a_signal_results", "سیگنال‌های فعال یا زمان‌بندی‌شده"),
    ]
    action_items = [
        {"priority": priority, "title": title, "count": count, "callback": callback, "description": description}
        for priority, title, count, callback, description in definitions if count
    ]
    action_items.sort(key=lambda row: int(str(row["priority"])), reverse=True)
    suggestions: list[dict[str, Any]] = []
    if waiting_tickets >= 5:
        suggestions.append({"type": "support_load", "title": "صف تیکت‌ها نیازمند رسیدگی است", "action": "a_tickets", "count": waiting_tickets})
    if pending_payments:
        suggestions.append({"type": "payment_review", "title": "رسیدهای معلق را بررسی کنید", "action": "a_pending", "count": pending_payments})
    if automation_failures:
        suggestions.append({"type": "automation_health", "title": "اتوماسیون‌های خطادار را بازبینی کنید", "action": "a_automations", "count": automation_failures})
    return {
        "metrics": metrics,
        "action_items": action_items,
        "suggestions": suggestions,
        "taxonomy": copy.deepcopy(ADMIN_PANEL_TAXONOMY),
        "generated_at": utc_iso(now),
    }
