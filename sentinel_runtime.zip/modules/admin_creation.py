"""Persistent, permission-checked creation drafts over existing domain services."""
from __future__ import annotations

import copy
import re
import secrets
from datetime import timedelta
from zoneinfo import ZoneInfo
from core.utils import utc_iso, utc_now, parse_dt
from core.domain import add_points, activate_vip, generate_code, audit, is_vip
from core.economy_integrity import economic_event
from modules.admin_access import has_permission

KINDS = {'discount':'🎟 کد تخفیف', 'reward':'🎁 جایزه', 'points':'⭐ مدیریت امتیاز',
         'mission':'🎯 مأموریت', 'contest':'🏆 مسابقه', 'milestone':'👥 مرحله معرفی', 'education':'🎓 آموزش'}
PERMISSIONS = {'discount':'discounts','reward':'user_rewards','points':'reward_points',
               'mission':'mission_create','contest':'contest_create','milestone':'reward_points','education':'education_create'}
PUBLISH_PERMISSIONS = {'mission':'mission_publish','contest':'contest_publish','education':'education_publish'}
# field: human question, allowed choices (label, server value). Empty choices accept text.
FIELDS = {
 'title':('چه نامی داشته باشد؟',()),
 'code':('کد را خودم بسازم یا شما وارد می‌کنید؟',(('ساخت خودکار','AUTO'),)),
 'discount_type':('چه نوع تخفیفی؟',(('درصدی','percentage'),('مبلغ ثابت (تومان)','fixed'))),
 'value':('مقدار را وارد کنید.',()),
 'plans':('برای کدام پلن‌ها؟ نام یا شناسه پلن را هم می‌توانید بفرستید.',(('همه پلن‌ها','all'),)),
 'eligible':('چه کسانی مجازند؟',(('همه','everyone'),('VIP','vip'),('غیر VIP','nonvip'),('دعوت‌شده‌ها','referral'),('افراد انتخابی','selected'))),
 'users':('نام، نام کاربری یا شناسه کاربر را بفرستید؛ برای چند نفر با ویرگول جدا کنید.',(('کاربران اخیر','recent'),('کاربران VIP','vip'),('همه کاربران','everyone'))),
 'per_user':('هر نفر چند بار می‌تواند استفاده کند؟',(('یک بار','1'),('نامحدود','0'))),
 'total':('سقف کل استفاده چند بار باشد؟',(('۱۰۰ بار','100'),('۵۰۰ بار','500'))),
 'start':('چه زمانی شروع شود؟ تاریخ دلخواه را با ساعت تهران بنویسید.',(('اکنون','now'),)),
 'expiry':('تا چه زمانی معتبر باشد؟',(('۷ روز','7'),('۳۰ روز','30'),('بدون انقضا','none'))),
 'stackable':('امکان ترکیب با تخفیف دیگر؟',(('خیر','no'),('بله','yes'))),
 'reward_type':('چه جایزه‌ای؟',(('امتیاز','points'),('روز VIP','vip_days'),('کد تخفیف','discount_coupon'),('جایزه سفارشی','custom'),('امتیاز + VIP + تخفیف','combined'))),
 'cost':('هزینه دریافت چند امتیاز باشد؟',(('رایگان','0'),)),
 'claim':('چگونه دریافت شود؟',(('کاربر درخواست کند','claim'),('به افراد انتخابی بده','assign'))),
 'operation':('چه کاری انجام دهیم؟',(('افزودن امتیاز','add'),('کسر امتیاز','remove'))),
 'reason':('دلیل این تغییر چیست؟',(('پاداش دستی','پاداش دستی'),('جبران مشکل','جبران مشکل'),('مسابقه','مسابقه'),('مأموریت','مأموریت'))),
 'period':('مأموریت چه دوره‌ای دارد؟',(('یک‌بار','one_time'),('روزانه','daily'),('هفتگی','weekly'))),
 'description':('توضیح کوتاهی بنویسید.',(('بدون توضیح','-'),)),
 'event':('موفقیت چگونه بررسی شود؟',(('مطالعه درس‌های متفاوت','complete_lesson'),('برنده مسابقه','win_contest'),('دعوت معتبر','referral_join'),('مدرک و بررسی ادمین','manual'))),
 'target':('چند مورد لازم است؟',(('۱ مورد','1'),('۳ مورد','3'))),
 'trigger_type':('این مرحله با چه چیزی باز شود؟',(('تعداد دعوت معتبر','referrals_joined'),('تعداد خریدار','referrals_purchased'),('مبلغ خرید تأییدشده','referral_revenue'))),
 'repeatable':('قابل تکرار باشد؟',(('خیر','no'),('بله','yes'))),
 'symbol':('نماد مسابقه چیست؟',(('طلا','XAUUSD'),('بیت‌کوین','BTCUSDT'),('یورو/دلار','EURUSD'))),
 'duration':('مسابقه چند دقیقه باز باشد؟',(('۶۰ دقیقه','60'),('یک روز','1440'))),
 'limit':('حداکثر شرکت‌کننده؟',(('۱۰۰ نفر','100'),('۵۰۰ نفر','500'))),
 'winner_count':('چند رتبه جایزه بگیرند؟',(('اول','1'),('سه رتبه','3'))),
 'second':('پاداش رتبه دوم چند امتیاز است؟',()),
 'third':('پاداش رتبه سوم چند امتیاز است؟',()),
 'ties':('در صورت تساوی چه کنیم؟',(('همه هم‌رتبه‌ها جایزه بگیرند','shared'),('پاسخ زودتر برنده شود','earliest'))),
 'content':('متن، لینک، عکس، آلبوم، ویدئو، صدا یا فایل را بفرستید. سپس «ادامه» را بزنید.',()),
 'category':('دسته آموزش چیست؟',(('عمومی','عمومی'),('تحلیل تکنیکال','تحلیل تکنیکال'),('مدیریت ریسک','مدیریت ریسک'))),
 'publish_mode':('چگونه منتشر شود؟',(('انتشار پس از تأیید','now'),('زمان‌بندی','schedule'))),
}
# Combined prizes ask only about explicitly selected components.
FIELDS.update({
 'prize_points': ('چند امتیاز؟ صفر یعنی بدون امتیاز.', (('بدون امتیاز','0'),)),
 'prize_vip': ('چند روز VIP؟ صفر یعنی بدون VIP.', (('بدون VIP','0'),)),
 'prize_coupon': ('چند درصد تخفیف؟', (('بدون تخفیف','0'),('۱۰ درصد','10'),('۲۰ درصد','20'),('۳۰ درصد','30'),('۴۰ درصد','40'),('۵۰ درصد','50'))),
})
for rank, name in [('second','دوم'),('third','سوم')]:
    for component, label in [('points','امتیاز'),('vip','روز VIP'),('coupon','درصد تخفیف')]:
        FIELDS[f'{rank}_{component}']=(f'جایزه رتبه {name}: چند {label}؟ صفر یعنی ندارد.', FIELDS['prize_coupon'][1] if component=='coupon' else (('ندارد','0'),))


def prize_fields(values, rank=''):
    if values.get('reward_type') == 'combined':
        return [f'{rank}_{component}' if rank else f'prize_{component}' for component in ('points','vip','coupon')]
    return [rank or 'value']


def configured_prize(values, rank=''):
    from modules.prize_delivery import validate_prize
    kind=values.get('reward_type','points')
    if kind=='custom':
        raise ValueError('برای مأموریت و مسابقه امتیاز، VIP، تخفیف یا ترکیب انتخاب کنید.')
    if kind=='combined':
        result={key:int(values.get(f'{rank}_{field}' if rank else f'prize_{field}',0) or 0) for key,field in [('points','points'),('vip_days','vip'),('coupon_percent','coupon')]}
    else:
        result={ {'points':'points','vip_days':'vip_days','discount_coupon':'coupon_percent'}[kind]:int(values.get(rank or 'value',0)) }
    return validate_prize(result)

TEMPLATES = {
 'welcome':('🎁 خوش‌آمدگویی','reward',{'title':'پاداش خوش‌آمدگویی','reward_type':'points','value':10,'cost':0,'claim':'assign'}),
 'renewal':('💎 تخفیف تمدید','discount',{'title':'تمدید VIP','discount_type':'percentage','value':15,'expiry':'7','renewal_only':True}),
 'referral':('👥 پاداش معرفی','milestone',{'title':'معرفی پنج دوست','trigger_type':'referrals_joined','target':5,'reward_type':'points','value':50}),
 'contest':('🏆 جایزه مسابقه','contest',{'title':'پیش‌بینی قیمت','symbol':'XAUUSD','value':25}),
 'daily':('🎯 مأموریت روزانه','mission',{'title':'مطالعه یک درس','period':'daily','event':'complete_lesson','target':1,'value':5}),
 'weekly':('🎯 مأموریت هفتگی','mission',{'title':'مطالعه سه درس','period':'weekly','event':'complete_lesson','target':3,'value':15}),
 'promotion':('🔥 تخفیف تبلیغاتی','discount',{'title':'تخفیف ویژه','discount_type':'percentage','value':10}),
 'points':('💰 پاداش امتیازی','points',{'title':'پاداش','operation':'add','value':10}),
}
DEFAULTS = {'code':'AUTO','discount_type':'percentage','value':10,'plans':'all','eligible':'everyone',
 'per_user':1,'total':100,'start':'now','expiry':'30','stackable':'no','reward_type':'points','cost':0,'claim':'claim',
 'operation':'add','reason':'پاداش دستی','period':'one_time','description':'','event':'manual','target':1,
 'trigger_type':'referrals_joined','repeatable':'no','symbol':'XAUUSD','duration':60,'limit':100,'winner_count':1,
 'prize_points':10,'prize_vip':0,'prize_coupon':0,'second_points':5,'second_vip':0,'second_coupon':0,'third_points':3,'third_vip':0,'third_coupon':0,'second':10,'third':5,'ties':'earliest','category':'عمومی','publish_mode':'now'}


def require(db, actor, kind, *, publish=False):
    permitted = kind in KINDS and has_permission(db, actor, PERMISSIONS[kind])
    if kind == 'education':
        permitted = permitted or has_permission(db, actor, 'education.create') or any(
            has_permission(db, actor, 'education.create_' + media)
            for media in ('text', 'link', 'image', 'video', 'voice', 'audio', 'document', 'file', 'animation', 'media_group'))
    if not permitted:
        raise PermissionError('مجوز لازم برای این عملیات را ندارید.')
    if publish and kind in PUBLISH_PERMISSIONS and not has_permission(db,actor,PUBLISH_PERMISSIONS[kind]):
        raise PermissionError('مجوز انتشار لازم است.')


def fields(draft):
    v=draft['values']; kind=draft['kind']
    if kind=='discount':
        return ['title','code','discount_type','value','plans','eligible']+(['users'] if v.get('eligible')=='selected' else [])+['per_user','total','start','expiry']
    if kind=='reward':return ['title','reward_type']+(['description'] if v.get('reward_type')=='custom' else prize_fields(v))+['claim']+([] if draft.get('selected_user') else ['users'] if v.get('claim')=='assign' else ['cost'])+['expiry']
    if kind=='points':return ['operation']+([] if draft.get('selected_user') else ['users'])+['value','reason']
    if kind=='mission':return ['period','title','description','event','target','reward_type']+prize_fields(v)+['limit','start','expiry']
    if kind=='milestone':return ['title','trigger_type','target','reward_type']+(['description'] if v.get('reward_type')=='custom' else ['value'])+['repeatable','start','expiry']
    if kind=='contest':return ['title','description','symbol','duration','eligible']+(['users'] if v.get('eligible')=='selected' else [])+['limit','winner_count','reward_type']+prize_fields(v)+(prize_fields(v,'second')+prize_fields(v,'third') if int(v.get('winner_count',1))==3 else [])+['ties']
    return ['content','title','category','description','publish_mode']+(['start'] if v.get('publish_mode')=='schedule' else [])


def create_draft(db, actor, kind, *, mode='guided', template='', selected_user=None):
    require(db,actor,kind)
    if mode not in {'guided','quick','template'}:raise ValueError('روش ساخت نامعتبر است.')
    values=copy.deepcopy(DEFAULTS)
    values['title']=KINDS[kind].split(' ',1)[1]
    if template:
        if template not in TEMPLATES or TEMPLATES[template][1]!=kind:raise ValueError('الگو نامعتبر است.')
        values.update(copy.deepcopy(TEMPLATES[template][2]))
    if selected_user is not None:
        if kind not in {'reward','points','discount'}:raise ValueError('این عملیات برای یک گیرنده پشتیبانی نمی‌شود.')
        if str(selected_user) not in db.get('users',{}):raise ValueError('کاربر پیدا نشد.')
        values['users']=[str(selected_user)]; values['claim']='assign'
        if kind=='discount':values['eligible']='selected'
    key=secrets.token_hex(6)
    row={'id':key,'kind':kind,'actor':str(actor),'values':values,'step':0,'status':'draft','revision':1,
         'created_at':utc_iso(),'updated_at':utc_iso(),'mode':mode,'answered':[],'editing':None,'attachments':[],
         'selected_user':str(selected_user) if selected_user is not None else None}
    if mode!='guided':row['step']='review'
    db.setdefault('admin_creation_drafts',{})[key]=row
    return copy.deepcopy(row)


def get_draft(db,actor,key):
    row=db.get('admin_creation_drafts',{}).get(str(key))
    if not row or row['actor']!=str(actor):raise PermissionError('پیش‌نویس در دسترس نیست.')
    require(db,actor,row['kind'])
    return row


def select_users(db,query):
    users=db.get('users',{})
    q=str(query).strip()
    if q=='everyone':return sorted(users)
    if q=='vip':return [u for u in users if is_vip(db,u)]
    if q=='recent':return sorted(users,key=lambda u:str(users[u].get('last_seen_at') or ''),reverse=True)[:10]
    found=[]
    for term in re.split('[,،\n]',q):
        term=term.strip().lstrip('@').casefold()
        if not term:continue
        exact=[uid for uid,r in users.items() if term in {str(uid),str(r.get('username') or '').casefold(),str(r.get('internal_id') or '')}]
        candidates=exact or [uid for uid,r in users.items() if term in f"{r.get('first_name','')} {r.get('last_name','')}".casefold()]
        if len(candidates)!=1:raise ValueError('کاربر پیدا نشد یا نام تکراری است؛ نام کاربری یا شناسه دقیق را بفرستید.')
        found.append(candidates[0])
    if not found:raise ValueError('حداقل یک کاربر انتخاب کنید.')
    return sorted(set(found))


def date_value(value, *, start=None):
    if str(value)=='none':return None
    if str(value)=='now':return utc_iso()
    if str(value).isdigit() and len(str(value))<=4:return utc_iso((parse_dt(start) if start else utc_now())+timedelta(days=int(value)))
    from datetime import datetime
    try:
        dt=datetime.fromisoformat(str(value).strip())
        if dt.tzinfo is None:dt=dt.replace(tzinfo=ZoneInfo('Asia/Tehran'))
        return utc_iso(dt)
    except (ValueError,TypeError):raise ValueError('تاریخ را مانند 2026-10-10 18:30 به وقت تهران وارد کنید.') from None


def answer(db,actor,key,field,value):
    row=get_draft(db,actor,key)
    if row['status']!='draft':raise ValueError('این پیش‌نویس دیگر قابل تغییر نیست.')
    if field not in fields(row)+['stackable']:raise ValueError('فیلد نامعتبر است.')
    choices=dict((str(v),label) for label,v in FIELDS[field][1])
    if field in {'discount_type','eligible','reward_type','claim','operation','period','event','trigger_type','repeatable','ties','publish_mode','stackable'} and str(value) not in choices:raise ValueError('یکی از گزینه‌های نمایش‌داده‌شده را انتخاب کنید.')
    if row.get('selected_user') and (field=='users' or field=='claim' and str(value)!='assign' or field=='eligible' and str(value)!='selected'):
        raise ValueError('گیرنده این فرم همان کاربر انتخاب‌شده است؛ برای عملیات گروهی از مرکز ساخت استفاده کنید.')
    if field=='users':value=select_users(db,value)
    elif field in {'value','cost','target','total','per_user','duration','limit','winner_count','second','third','prize_points','prize_vip','prize_coupon','second_points','second_vip','second_coupon','third_points','third_vip','third_coupon'}:
        try:value=int(str(value).translate(str.maketrans('۰۱۲۳۴۵۶۷۸۹','0123456789')))
        except ValueError:raise ValueError('یک عدد صحیح وارد کنید.') from None
        minimum=0 if field in {'cost','per_user','second','third'} or field.startswith(('prize_','second_','third_')) else 1
        if not minimum<=value<=1_000_000:raise ValueError('مقدار خارج از محدوده مجاز است.')
        if field=='winner_count' and value not in {1,3}:raise ValueError('یک یا سه رتبه انتخاب کنید.')
        if field.endswith(('vip','coupon')):
            if field.endswith('vip') and value>3650:raise ValueError('حداکثر ۳۶۵۰ روز VIP مجاز است.')
            if field.endswith('coupon') and value not in {0,10,20,30,40,50}:raise ValueError('درصد کوپن نامعتبر است.')
        if field in {'value','second','third'}:
            kind=row['kind'];values=row['values']
            if kind=='discount' and values.get('discount_type')=='percentage' and value>100:raise ValueError('درصد باید بین ۱ و ۱۰۰ باشد.')
            if kind in {'reward','milestone','mission','contest'} and values.get('reward_type')=='vip_days' and value>3650:raise ValueError('حداکثر ۳۶۵۰ روز مجاز است.')
            if kind in {'reward','milestone','mission','contest'} and values.get('reward_type')=='discount_coupon' and value not in {10,20,30,40,50}:raise ValueError('درصد کوپن: ۱۰، ۲۰، ۳۰، ۴۰ یا ۵۰.')
    elif field=='code':
        value=str(value).strip().upper()
        if value!='AUTO' and not re.fullmatch('[A-Z0-9_-]{4,24}',value):raise ValueError('کد باید ۴ تا ۲۴ حرف انگلیسی، عدد، خط تیره یا زیرخط باشد.')
    elif field=='plans' and value!='all':
        terms=re.split('[,،]',str(value)); ids=[]
        for term in terms:
            matches=[p for p in db.get('vip_plans',[]) if term.strip().casefold() in {str(p['id']),str(p.get('name','')).casefold()} and p.get('active',True)]
            if len(matches)!=1:raise ValueError('پلن پیدا نشد؛ نام یا شناسه دقیق را بفرستید.')
            ids.append(int(matches[0]['id']))
        value=ids
    elif field in {'start','expiry'}:
        date_value(value)
    else:
        value=str(value).strip()[:1000]
        if not value:raise ValueError('پاسخ خالی است.')
    if field=='reward_type' and row['kind'] in {'mission','contest','milestone'} and value in {'custom','combined'} and (row['kind']=='milestone' or value=='custom'):raise ValueError('این نوع جایزه در این فرم قابل استفاده نیست.')
    if field=='reward_type' and value=='discount_coupon':
        row['values']['second']=10;row['values']['third']=10
    row['values'][field]=value
    if field not in row['answered']:row['answered'].append(field)
    row['updated_at']=utc_iso();row['revision']+=1
    if row.get('editing'):row['step']='review';row['editing']=None
    else:
        order=fields(row);index=order.index(field)+1
        row['step']='review' if index>=len(order) else index
    return row


def review(db,actor,key):
    row=get_draft(db,actor,key);v=row['values'];rows=[]
    for field in fields(row):
        if field=='content':value=f"{len(row.get('attachments',[]))} فایل؛ {len(v.get('content',''))} حرف متن"
        else:
            value=v.get(field,'—')
            labels={str(val):label for label,val in FIELDS[field][1]}
            value=labels.get(str(value),value)
        rows.append((FIELDS[field][0].split('؟')[0],str(value)))
    if row.get('selected_user'):
        uid=row['selected_user'];user=db.get('users',{}).get(uid)
        if user is None:raise ValueError('کاربر انتخاب‌شده دیگر موجود نیست.')
        name=' '.join(str(user.get(k) or '') for k in ('first_name','last_name')).strip()
        rows.insert(0,('گیرنده انتخاب‌شده',f"{name or user.get('username') or 'کاربر'} | {uid}"))
        rows.insert(1,('روش دریافت','اعطای مستقیم به همین کاربر پس از تأیید شما'))
    recipients=v.get('users',[]) if isinstance(v.get('users'),list) else []
    if recipients:
        amount=int(v.get('value',0));rows.append(('تعداد افراد',str(len(recipients))))
        if row['kind']=='points' or v.get('reward_type') in {'points','vip_days'}:
            rows.append(('مجموع روز VIP' if v.get('reward_type')=='vip_days' and row['kind']!='points' else 'مجموع امتیاز',str(len(recipients)*amount)))
    if row['kind'] in {'mission','contest'} or v.get('reward_type')=='combined':
        from modules.prize_delivery import prize_label
        prize=configured_prize(v)
        rows.append(('بسته جایزه',prize_label(prize)))
        if row['kind']=='contest':
            prizes=[prize]+([configured_prize(v,'second'),configured_prize(v,'third')] if int(v.get('winner_count',1))==3 else [])
            multiplier=int(v['limit']) if v['ties']=='shared' else 1
            rows.append(('سقف تعهد مسابقه',prize_label({key:sum(p.get(key,0) for p in prizes)*multiplier for key in ('points','vip_days','coupon_percent') if key!='coupon_percent'})+'؛ تعداد کد: '+str(sum(bool(p.get('coupon_percent')) for p in prizes)*multiplier)))
        elif recipients:
            rows.append(('مجموع تعهد',prize_label({key:prize[key]*len(recipients) for key in ('points','vip_days')})+'؛ تعداد کد: '+str(len(recipients) if prize['coupon_percent'] else 0)))
        else:
            rows.append(('پرداخت جایزه','فقط پس از بررسی شرایط در سرور'))
            if row['kind']=='mission':rows.append(('سقف تعهد',prize_label({key:prize[key]*int(v['limit']) for key in ('points','vip_days')})+'؛ تعداد کد: '+str(int(v['limit']) if prize['coupon_percent'] else 0)))
    row['step']='review';row['reviewed_revision']=row['revision']
    return rows


def publish(db,actor,key,revision):
    row=get_draft(db,actor,key);require(db,actor,row['kind'],publish=True)
    if row['status']=='published':return copy.deepcopy(row['result'])
    if row['status']!='draft' or row.get('step')!='review' or row.get('reviewed_revision')!=int(revision) or row['revision']!=int(revision):raise ValueError('پیش‌نمایش را دوباره بررسی کنید.')
    v=copy.deepcopy(row['values']);kind=row['kind'];users=v.get('users') or []
    if row.get('selected_user'):
        uid=str(row['selected_user'])
        if users!=[uid] or uid not in db.get('users',{}) or kind=='reward' and v.get('claim')!='assign' or kind=='discount' and v.get('eligible')!='selected':
            raise ValueError('گیرنده یا روش دریافت با کاربر انتخاب‌شده مطابقت ندارد.')
    if kind in {'reward','milestone'} and v['reward_type']=='custom':v['value']=1
    if not isinstance(users,list):raise ValueError('گیرنده‌ها را دوباره انتخاب کنید.')
    if kind=='points' or (kind=='reward' and v['claim']=='assign') or (kind=='discount' and v['eligible']=='selected'):
        if not users or any(str(u) not in db.get('users',{}) for u in users):raise ValueError('گیرنده معتبر انتخاب کنید.')
        exposure=configured_prize(v) if kind=='reward' and v['reward_type']=='combined' else {}
        if (len(users)>100 or len(users)*int(exposure.get('points',v['value']))>100000 or len(users)*exposure.get('vip_days',0)>365 or (exposure.get('coupon_percent',0) and len(users)>100)) and not has_permission(db,actor,'economy.bulk_high_value'):raise PermissionError('این عملیات بزرگ به مجوز ویژه نیاز دارد.')
    start=date_value(v['start']);expiry=date_value(v['expiry'],start=start)
    if expiry and parse_dt(expiry)<=parse_dt(start):raise ValueError('پایان باید بعد از شروع باشد.')
    if kind=='discount' and v['discount_type']=='percentage' and not 1<=int(v['value'])<=100:raise ValueError('درصد نامعتبر است.')
    if kind in {'reward','milestone','mission','contest'} and v['reward_type']=='vip_days' and not 1<=int(v['value'])<=3650:raise ValueError('مدت VIP نامعتبر است.')
    if kind in {'reward','milestone','mission','contest'} and v['reward_type']=='discount_coupon' and int(v['value']) not in {10,20,30,40,50}:raise ValueError('درصد کوپن نامعتبر است.')
    source=f'admin_draft:{key}'
    if kind=='discount':
        from core.domain import create_discount
        from modules.discount_campaigns import normalize_campaign_fields
        code=generate_code(16) if v['code']=='AUTO' else v['code']
        if code in db.get('discount_codes',{}):raise ValueError('این کد قبلاً وجود دارد.')
        result=create_discount(db, int(v['value']) if v['discount_type']=='percentage' else 1, code=code, source='admin_wizard')
        result.update(name=v['title'],scope='public',discount_type=v['discount_type'],fixed_amount=int(v['value']) if v['discount_type']=='fixed' else 0,
            starts_at=start,expires_at=expiry,max_uses=int(v['total']),max_uses_per_user=int(v['per_user']),one_per_user=int(v['per_user'])==1,
            stackable=v['stackable']=='yes',eligible_group=v['eligible'],allowed_user_ids=users if v['eligible']=='selected' else [],
            applicable_plan_ids=[] if v['plans']=='all' else v['plans'],created_by=str(actor),renewal_only=bool(v.get('renewal_only')),enabled=True)
        normalize_campaign_fields(result)
    elif kind=='points':
        amount=int(v['value'])*(1 if v['operation']=='add' else -1)
        if amount<0 and any(int(db.get('user_points',{}).get(uid,0)) < -amount for uid in users):raise ValueError('موجودی یکی از کاربران کافی نیست؛ هیچ تغییری اعمال نشد.')
        for uid in users:
            add_points(db,uid,amount,v['reason'],source_event=f'{source}:{uid}',actor=actor)
            if row.get('selected_user') and amount>0:
                from modules.advanced_features import record_user_reward
                record_user_reward(db,uid,v['reason'],reward_type='points',detail=str(amount),source='admin_wizard',reference_id=f'{source}:{uid}',status='delivered')
        result={'recipients':len(users),'total_points':amount*len(users)}
    elif kind=='mission':
        from modules.missions import create_mission
        prize=configured_prize(v)
        result=create_mission(db,title=v['title'],reward=prize['points'],event=v['event'],target=int(v['target']),period=v['period'],description=v['description'],starts_at=start,ends_at=expiry,actor_id=actor)
        result['prize']=prize
        result['max_completions']=int(v['limit']);result['completions_count']=0
    elif kind=='milestone':
        from modules.referral_milestones import save_milestone
        if v['reward_type']=='custom':
            items=db.setdefault('settings',{}).setdefault('rewardItems',[])
            item_id=max([int(r.get('id',0)) for r in items]+[0])+1
            items.append({'id':item_id,'name':v['title'],'description':v['description'],'points':0,'type':'custom','active':False,'enabled':False})
            v['reward_type']='reward_item';v['value']=item_id
        result=save_milestone(db,actor,{'title':v['title'],'trigger_type':v['trigger_type'],'required_count':int(v['target']),
              'reward_type':v['reward_type'],'reward_value':int(v['value']),'repeatable':v['repeatable']=='yes','max_claims':10 if v['repeatable']=='yes' else 1,
              'start_at':start,'expire_at':expiry,'retroactive':False})
    elif kind=='reward':
        if v['claim']=='assign':
            from modules.advanced_features import record_user_reward
            from core.domain import assign_discount_from_pool
            for uid in users:
                if v['reward_type']=='combined':
                    from modules.prize_delivery import deliver_prize
                    deliver_prize(db,uid,configured_prize(v),source_event=f'{source}:{uid}',title=v['title'],actor=actor,source='admin_wizard',coupon_expires_at=expiry,apply_expiry_policy=True)
                    continue
                event=f'{source}:{uid}'
                if not economic_event(db,event,uid,kind=v['reward_type'],value=int(v['value']),actor=actor,reason=v['title']):continue
                reference=event; detail=v['description'] if v['reward_type']=='custom' else str(v['value'])
                if v['reward_type']=='points':add_points(db,uid,int(v['value']),v['title'],source_event=f'points:{event}',actor=actor)
                elif v['reward_type']=='vip_days':activate_vip(db,uid,int(v['value']),source_order_id=event)
                elif v['reward_type']=='discount_coupon':
                    coupon,_=assign_discount_from_pool(db,int(v['value']),uid,issued_via='admin_wizard',coupon_expires_at=expiry,apply_expiry_policy=True);reference=coupon['code'];detail=reference
                record_user_reward(db,uid,v['title'],reward_type=v['reward_type'],detail=detail,source='admin_wizard',reference_id=reference,status='pending' if v['reward_type']=='custom' else 'delivered')
            result={'recipients':len(users)}
        else:
            from core.db import next_id
            result={'id':max([int(r.get('id',0)) for r in db.get('settings',{}).get('rewardItems',[])]+[0])+1,'name':v['title'],'points':int(v['cost']),'type':v['reward_type'],'value':int(v['value']),'active':True,'enabled':True,'expires_at':expiry,'coupon_expires_at':expiry,'per_user_limit':1,'stock':100,'discountPct':int(v['value']) if v['reward_type']=='discount_coupon' else 0,'created_by':str(actor)}
            if v['reward_type']=='combined':result['prize']=configured_prize(v)
            db.setdefault('settings',{}).setdefault('rewardItems',[]).append(result)
    elif kind=='contest':
        from modules.contest import start_price_contest
        if v['eligible']=='selected' and not users:raise ValueError('گیرنده‌های مسابقه را انتخاب کنید.')
        first=configured_prize(v)
        prizes={'1':first}
        if int(v['winner_count'])==3:prizes.update({'2':configured_prize(v,'second'),'3':configured_prize(v,'third')})
        if any(p['points']>100000 for p in prizes.values()):raise ValueError('حداکثر امتیاز هر رتبه ۱۰۰٬۰۰۰ است.')
        result=start_price_contest(db,v['symbol'],int(v['duration']),question=v['description'],reward_points=first['points'])
        result.update(title=v['title'],eligible_group=v['eligible'],max_participants=int(v['limit']),tie_handling=v['ties'],
                      allowed_user_ids=users if v['eligible']=='selected' else [],prize_by_rank=prizes,reward_by_rank={rank:p['points'] for rank,p in prizes.items()},created_by=str(actor))
    else:
        from modules.education import create_lesson,add_lesson_attachment,set_lesson_status
        content=str(v.get('content',''))
        if not content and not row.get('attachments'):raise ValueError('محتوای آموزشی ارسال کنید.')
        required_media = {'text'} if content and content != '-' else set()
        for attachment in row.get('attachments', []):
            media = attachment['type']
            required_media.add('image' if media == 'photo' else 'document' if media == 'pdf' else media)
            if attachment.get('media_group_id'):required_media.add('media_group')
        if any(not has_permission(db, actor, 'education.create_' + media) for media in required_media):
            raise PermissionError('مجوز یکی از انواع محتوای این پیش‌نویس لغو شده است.')
        result=create_lesson(db,category=v['category'],title=v['title'],access_type='free',price=0,text=content,status='draft',actor_id=actor)
        for attachment in row.get('attachments',[]):add_lesson_attachment(db,result['id'],attachment)
        if v['publish_mode']=='schedule':
            if not has_permission(db,actor,'education.schedule'):raise PermissionError('مجوز زمان‌بندی لازم است.')
            if parse_dt(start)<=utc_now():raise ValueError('زمان انتشار باید در آینده باشد.')
            result['scheduled_at']=start
        else:set_lesson_status(db,result['id'],'published')
    row.update(status='published',published_at=utc_iso(),result=copy.deepcopy(result))
    audit(db,actor,'creation_published',f'{kind}:{key}')
    return copy.deepcopy(result)
