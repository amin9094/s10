from __future__ import annotations

import math
from statistics import fmean
from typing import Any

from core.storage.engine import DatabaseEngine, normalized_engine
from repositories.v2.common import utc_iso


class CorrelationService:
    def __init__(self, engine: DatabaseEngine | None = None):
        self.engine = engine or normalized_engine()

    def record_return(self, *, symbol: str, timeframe: str, observed_at: str, return_value: float,
                      source: str, confidence: float) -> None:
        with self.engine.transaction() as cursor:
            cursor.execute(
                """INSERT INTO v8_market_returns(symbol,timeframe,observed_at,return_value,source,confidence)
                   VALUES(?,?,?,?,?,?) ON CONFLICT(symbol,timeframe,observed_at) DO UPDATE SET
                   return_value=excluded.return_value,source=excluded.source,confidence=excluded.confidence""",
                (self._symbol(symbol), str(timeframe), str(observed_at), float(return_value), str(source),
                 min(1.0, max(0.0, float(confidence)))),
            )

    def rolling(self, symbols: list[str], *, timeframe: str = "1h", windows: tuple[int, ...] = (20, 60, 120)) -> dict[str, Any]:
        clean = sorted({self._symbol(symbol) for symbol in symbols if str(symbol).strip()})
        if len(clean) < 2:
            return {"symbols": clean, "timeframe": timeframe, "windows": {}, "generated_at": utc_iso(), "confidence": 0.0}
        placeholders = ",".join("?" for _ in clean)
        with self.engine.transaction(read_only=True) as cursor:
            rows = cursor.execute(
                f"SELECT symbol,observed_at,return_value,source,confidence FROM v8_market_returns "
                f"WHERE timeframe=? AND symbol IN ({placeholders}) ORDER BY observed_at DESC",  # nosec B608
                [str(timeframe), *clean],
            ).fetchall()
        series: dict[str, dict[str, tuple[float, float]]] = {symbol: {} for symbol in clean}
        for row in rows:
            series[str(row["symbol"])][str(row["observed_at"])] = (float(row["return_value"]), float(row["confidence"]))
        output: dict[str, Any] = {}
        confidences: list[float] = []
        for window in windows:
            matrix: dict[str, dict[str, float | None]] = {symbol: {} for symbol in clean}
            samples: dict[str, int] = {}
            for index, left in enumerate(clean):
                matrix[left][left] = 1.0
                for right in clean[index + 1:]:
                    common = sorted(set(series[left]) & set(series[right]), reverse=True)[: int(window)]
                    pairs = [(series[left][stamp][0], series[right][stamp][0]) for stamp in common]
                    correlation = self._pearson(pairs)
                    matrix[left][right] = correlation
                    matrix[right][left] = correlation
                    samples[f"{left}:{right}"] = len(pairs)
                    confidences.extend((series[left][stamp][1] + series[right][stamp][1]) / 2 for stamp in common)
            output[str(window)] = {"matrix": matrix, "samples": samples}
        return {
            "symbols": clean,
            "timeframe": timeframe,
            "windows": output,
            "generated_at": utc_iso(),
            "confidence": round(fmean(confidences), 4) if confidences else 0.0,
            "method": "Pearson correlation of aligned periodic returns",
        }

    @staticmethod
    def _pearson(pairs: list[tuple[float, float]]) -> float | None:
        if len(pairs) < 5:
            return None
        xs = [item[0] for item in pairs]
        ys = [item[1] for item in pairs]
        x_mean = fmean(xs)
        y_mean = fmean(ys)
        numerator = sum((x - x_mean) * (y - y_mean) for x, y in pairs)
        x_var = sum((x - x_mean) ** 2 for x in xs)
        y_var = sum((y - y_mean) ** 2 for y in ys)
        denominator = math.sqrt(x_var * y_var)
        if denominator <= 1e-18:
            return None
        return round(max(-1.0, min(1.0, numerator / denominator)), 6)

    @staticmethod
    def _symbol(value: str) -> str:
        return str(value).upper().replace("/", "").replace("-", "")[:30]
