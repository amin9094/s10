"""A coherent private CRM case and exact follow-up lists behind counters."""
from core.utils import parse_dt,utc_iso,utc_now


def followups(db,mode='open',*,after='',limit=40):
    if mode not in {'open','overdue','unnotified'}:raise ValueError('پیگیری نامعتبر است')
    rows=[];now=utc_now()
    for uid,row in db.get('crm_profiles',{}).items():
        if uid not in db.get('users',{}) or row.get('follow_up_status','scheduled') not in {'scheduled','notified'}:continue
        stamp=parse_dt(row.get('follow_up_at'))
        if not stamp:continue
        if mode=='overdue' and stamp>now:continue
        if mode=='unnotified' and row.get('follow_up_notified_at'):continue
        rows.append({'user_id':uid,'at':stamp.isoformat(),'note':row.get('follow_up_note',''),
                     'assigned_admin':row.get('assigned_admin'),'status':row.get('follow_up_status','scheduled')})
    rows.sort(key=lambda r:(r['at'],r['user_id']))
    selected=[r for r in rows if not after or r['at']+'|'+r['user_id']>after][:max(1,min(int(limit),100))]
    return {'total':len(rows),'items':selected,'next_after':selected[-1]['at']+'|'+selected[-1]['user_id'] if len(selected)==limit else None}


def claim_case(db,actor,uid,revision):
    from modules.admin_access import has_permission,PERMISSION_CRM_VIEW
    from modules.crm_automation import record_crm_activity
    if not has_permission(db,actor,PERMISSION_CRM_VIEW):raise PermissionError('FORBIDDEN')
    uid=str(uid)
    if uid not in db.get('users',{}):raise ValueError('کاربر پیدا نشد')
    row=db.setdefault('crm_profiles',{}).setdefault(uid,{})
    if int(row.get('owner_revision',1))!=int(revision):raise ValueError('مسئول پرونده تغییر کرده؛ دوباره بررسی کنید')
    if row.get('assigned_admin') and str(row['assigned_admin'])!=str(actor):raise ValueError('این پرونده مسئول دیگری دارد؛ از تحویل پرونده استفاده کنید')
    row.update(assigned_admin=str(actor),owner_revision=int(revision)+1,updated_at=utc_iso())
    record_crm_activity(db,uid,'assigned',actor_id=actor,detail='پذیرش مسئولیت پرونده')
    return row


def case_summary(db,uid):
    from modules.crm_engine import refresh_crm_profile
    from modules.learning_path import lesson_for_user
    from modules.crm_automation import crm_activity_timeline
    uid=str(uid)
    if uid not in db.get('users',{}):raise ValueError('کاربر پیدا نشد')
    profile=refresh_crm_profile(db,uid)
    sections={}
    for key,label,callback in [('vip_orders','خرید اشتراک','crm_orders:'+uid),('education_orders','خرید آموزش','crm_edu:'+uid),('tickets','پشتیبانی',None)]:
        records=[r for r in db.get(key,[]) if str(r.get('user_id'))==uid]
        sections[key]={'label':label,'total':len(records),'callback':callback,
                       'items':[{'id':str(r.get('order_id') or r.get('id')),'status':r.get('status'),
                                 'callback':'ticket_a:'+str(r['id']) if key=='tickets' else 'edu_order_view:'+str(r['order_id']) if key=='education_orders' else callback} for r in records[-5:]]}
    education=[]
    for identifier,progress in db.get('education_progress',{}).get(uid,{}).items():
        lesson=lesson_for_user(db,uid,identifier)
        education.append({'lesson_id':identifier,'title':(lesson or {}).get('title','درس حذف‌شده'),
                          'studied':bool(progress.get('completed')),'passed':bool(progress.get('passed')),
                          'revision':progress.get('lesson_revision')})
    contests=[]
    sources=[*db.get('contests',[]),*db.get('contest_history',[]),*(db.get(k,{}) for k in ('chart_contest','candle_contest','news_direction_contest'))]
    seen=set()
    for row in sources:
        if not row.get('id') or row['id'] in seen:continue
        seen.add(row['id'])
        if uid in row.get('participants',row.get('answers',{})):
            contests.append({'id':row['id'],'status':row.get('status'),'title':row.get('question') or row.get('symbol') or row.get('news_name')})
    contacts=[r for r in db.get('automation_outbox',{}).values() if str(r.get('recipient_id'))==uid]
    return {'user_id':uid,'profile':profile,'sections':sections,'education':education[-10:],
            'contests':contests[-10:],'contacts':[{'id':r['id'],'status':r['status'],'kind':r.get('kind')} for r in contacts[-10:]],
            'timeline':crm_activity_timeline(db,uid,limit=10)}
