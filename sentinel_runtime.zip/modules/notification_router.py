from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

from core.utils import utc_iso
from modules.admin_control_center import notification_allowed, notification_preferences


@dataclass(frozen=True, slots=True)
class NotificationDecision:
    allowed: bool
    reason: str
    key: str
    user_id: str


def notification_decision(
    db: dict[str, Any],
    user_id: int | str,
    key: str,
    *,
    market: str = "",
    symbol: str = "",
    now: datetime | None = None,
) -> NotificationDecision:
    """Single routing decision for every personal notification path."""
    key = {"new_signal":"signals", "signal_result":"results", "ticket":"support", "price_alert":"alerts", "renewal":"retention", "competition":"contests", "mission":"missions"}.get(key,key)
    uid = str(int(user_id))
    pref = notification_preferences(db, uid)
    if not notification_allowed(db, uid, key, now=now):
        return NotificationDecision(False, "preference_or_quiet_hours", key, uid)
    parent = {"tp":"results", "sl":"results", "risk_free":"results", "high_impact":"news"}.get(key)
    if parent and not notification_allowed(db,uid,parent,now=now):
        return NotificationDecision(False,"parent_preference",key,uid)
    markets = {
        str(value).strip().lower()
        for value in pref.get("markets", [])
        if str(value).strip()
    }
    clean_market = str(market or "").strip().lower()
    if markets and clean_market and clean_market not in markets:
        return NotificationDecision(False, "market_filter", key, uid)
    symbols = {
        str(value).strip().upper()
        for value in pref.get("symbols", [])
        if str(value).strip()
    }
    clean_symbol = str(symbol or "").strip().upper()
    if symbols and clean_symbol and clean_symbol not in symbols:
        return NotificationDecision(False, "symbol_filter", key, uid)
    return NotificationDecision(True, "allowed", key, uid)


def route_notification(
    db: dict[str, Any],
    user_id: int | str,
    key: str,
    *,
    market: str = "",
    symbol: str = "",
    now: datetime | None = None,
) -> bool:
    decision = notification_decision(
        db,
        user_id,
        key,
        market=market,
        symbol=symbol,
        now=now,
    )
    rows = db.setdefault("notification_routing_log", [])
    rows.append(
        {
            "user_id": decision.user_id,
            "key": decision.key,
            "allowed": decision.allowed,
            "reason": decision.reason,
            "market": str(market or "")[:32],
            "symbol": str(symbol or "")[:32],
            "created_at": utc_iso(now or datetime.now(UTC)),
        }
    )
    db["notification_routing_log"] = rows[-10_000:]
    return decision.allowed


def set_notification_filters(
    db: dict[str, Any],
    user_id: int | str,
    *,
    markets: list[str] | tuple[str, ...] | None = None,
    symbols: list[str] | tuple[str, ...] | None = None,
) -> dict[str, Any]:
    pref = notification_preferences(db, user_id)
    if markets is not None:
        pref["markets"] = list(
            dict.fromkeys(
                value
                for value in (str(item).strip().lower() for item in markets)
                if value in {"forex", "crypto", "gold", "stocks", "energy"}
            )
        )
    if symbols is not None:
        pref["symbols"] = list(
            dict.fromkeys(
                value[:24]
                for value in (str(item).strip().upper() for item in symbols)
                if value
            )
        )[:100]
    pref["updated_at"] = utc_iso()
    return pref


def should_notify(db, user_id, event_type, market=None, symbol=None):
    return notification_decision(db,user_id,event_type,market=market or '',symbol=symbol or '').allowed
