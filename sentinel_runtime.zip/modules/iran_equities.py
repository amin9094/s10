"""Daily IRR equity observations; independent of FX/crypto execution engines."""

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import datetime, timedelta
from decimal import Decimal, InvalidOperation
from zoneinfo import ZoneInfo

TEHRAN = ZoneInfo("Asia/Tehran")
EQUITY_TYPES = frozenset({"300", "303", "309"})


def instrument_code(value):
    # JSON numbers must never pass through a JS Number: InsCode exceeds 2**53.
    if isinstance(value, bool) or not isinstance(value, str | int) or not re.fullmatch(r"[1-9][0-9]{0,19}", str(value)):
        raise ValueError("IR_EQUITY_CODE_INVALID")
    return str(value)


def search_query(value):
    if not isinstance(value, str):
        raise ValueError("IR_EQUITY_QUERY_INVALID")
    value = value.strip().replace("ي", "ی").replace("ك", "ک")
    if not 2 <= len(value) <= 40 or not all(c.isalnum() or c in " \u200c-" for c in value):
        raise ValueError("IR_EQUITY_QUERY_INVALID")
    return value


def search_hit(row):
    """Search identifies a candidate; it need not contain instrument metadata."""
    if not isinstance(row, dict):
        raise ValueError("IR_EQUITY_IDENTITY_INVALID")
    code = instrument_code(row.get("insCode"))
    name, title = row.get("lVal18AFC"), row.get("lVal30")
    if not isinstance(name, str) or not name.strip() or not isinstance(title, str) or not title.strip():
        raise ValueError("IR_EQUITY_IDENTITY_INVALID")
    return {
        "ins_code": code,
        "symbol": name.strip()[:80],
        "title": title.strip()[:200],
        "provider": "tsetmc",
        "classification_verified": False,
        "requires_instrument_info": True,
    }


def instrument(row, *, expected_code=None):
    candidate = search_hit(row)
    if expected_code is not None and candidate["ins_code"] != expected_code:
        raise ValueError("IR_EQUITY_IDENTITY_MISMATCH")
    kind, flow = str(row.get("yVal", "")).strip(), str(row.get("flow", "")).strip()
    if not kind or not flow:
        raise ValueError("IR_EQUITY_CLASSIFICATION_UNVERIFIED")
    if kind not in EQUITY_TYPES or flow not in {"1", "2"}:
        raise ValueError("IR_CASH_EQUITY_REQUIRED")
    return {
        **candidate,
        "classification_verified": True,
        "requires_instrument_info": False,
        "security_type_code": kind,
        "market_flow": flow,
        "currency": "IRR",
        "provider": "tsetmc",
        "product": "iran_cash_equity",
        "venue": "TSE" if flow == "1" else "IFB",
    }


def number(value, *, positive=False):
    if value is None or isinstance(value, bool):
        raise ValueError("IR_EQUITY_NUMBER_INVALID")
    try:
        result = Decimal(str(value))
    except (InvalidOperation, ValueError):
        raise ValueError("IR_EQUITY_NUMBER_INVALID") from None
    if not result.is_finite() or result < 0 or result > Decimal("1e22") or positive and result == 0:
        raise ValueError("IR_EQUITY_NUMBER_INVALID")
    return result


@dataclass(frozen=True)
class DailyBar:
    date: str
    start_ms: int
    end_ms: int
    open: Decimal
    high: Decimal
    low: Decimal
    close: Decimal
    volume: Decimal
    weighted_close: Decimal
    previous_weighted_close: Decimal | None
    is_closed: bool

    def chart_bar(self):
        return {
            "timestamp": self.start_ms,
            **{k: float(getattr(self, k)) for k in ("open", "high", "low", "close", "volume")},
        }


def daily_bars(payload, code, observed_ms):
    code = instrument_code(code)
    rows = payload.get("closingPriceDaily") if isinstance(payload, dict) else None
    if not isinstance(rows, list) or len(rows) > 20000:
        raise ValueError("IR_EQUITY_HISTORY_INVALID")
    observed_date = datetime.fromtimestamp(observed_ms / 1000, TEHRAN).date()
    bars, seen, skipped = [], set(), 0
    for row in rows:
        if not isinstance(row, dict):
            raise ValueError("IR_EQUITY_HISTORY_INVALID")
        if row.get("insCode") is not None and instrument_code(row["insCode"]) != code:
            raise ValueError("IR_EQUITY_IDENTITY_MISMATCH")
        day = row.get("dEven")
        if isinstance(day, bool) or not re.fullmatch(r"[0-9]{8}", str(day)):
            raise ValueError("IR_EQUITY_DATE_INVALID")
        try:
            local = datetime.strptime(str(day), "%Y%m%d").replace(tzinfo=TEHRAN)
        except ValueError:
            raise ValueError("IR_EQUITY_DATE_INVALID") from None
        if local.year < 1990 or local.date() > observed_date or str(day) in seen:
            raise ValueError("IR_EQUITY_DATE_INVALID")
        seen.add(str(day))
        volume = number(row.get("qTotTran5J"))
        if volume == 0:
            skipped += 1
            continue  # No invented OHLC for non-trading days.
        values = [
            number(row.get(k), positive=True) for k in ("priceFirst", "priceMax", "priceMin", "pDrCotVal", "pClosing")
        ]
        opening, high, low, close, weighted = values
        if not low <= min(opening, close) <= max(opening, close) <= high:
            raise ValueError("IR_EQUITY_OHLC_INVALID")
        previous = number(row["priceYesterday"], positive=True) if row.get("priceYesterday") is not None else None
        bars.append(
            DailyBar(
                local.date().isoformat(),
                int(local.timestamp() * 1000),
                int((local + timedelta(days=1)).timestamp() * 1000),
                opening,
                high,
                low,
                close,
                volume,
                weighted,
                previous,
                local.date() < observed_date,
            )
        )
    bars.sort(key=lambda b: b.start_ms)
    if not bars:
        raise ValueError("IR_EQUITY_HISTORY_EMPTY")
    return bars, skipped


def analyze_daily(bars, observed_ms):
    """Use completed days only, resetting at unadjusted price-base breaks."""
    closed = [b for b in bars if b.is_closed]
    segment = list(closed)
    breaks = []
    for i, (prior, bar) in enumerate(zip(closed, closed[1:], strict=False), 1):
        if bar.previous_weighted_close is None or bar.previous_weighted_close != prior.weighted_close:
            breaks.append({"date": bar.date, "reason": "UNADJUSTED_PRICE_BASE_CHANGED_OR_UNVERIFIED"})
            segment = closed[i:]
    latest = closed[-1] if closed else None
    stale = not latest or observed_ms - latest.end_ms > 7 * 86400000
    result = {
        "mode": "DAILY_TECHNICAL_REVIEW",
        "is_signal": False,
        "execution_eligible": False,
        "adjustment": "UNADJUSTED",
        "currency": "IRR",
        "close_basis": "LAST_TRADE",
        "closed_days": len(closed),
        "continuous_price_base_days": len(segment),
        "price_base_breaks": breaks[-20:],
        "current_day_excluded": any(not b.is_closed for b in bars),
        "latest_closed_date": latest.date if latest else None,
        "session_calendar_verified": False,
        "state": "HISTORICAL_OR_HALTED"
        if stale
        else "INDICATOR_WARMUP_INCOMPLETE"
        if len(segment) < 105
        else "DAILY_REVIEW_AVAILABLE",
    }
    if len(segment) < 105 or stale:
        return result
    result.update(_technical_values(segment))
    return result


def _technical_values(segment):
    from modules.strategies.common import indicators

    result = {}
    math = indicators(segment)
    last = segment[-1]
    e20, e50, e100 = [math["ma"][n][-1] for n in (20, 50, 100)]
    trend = "UP" if last.close > e20 > e50 > e100 else "DOWN" if last.close < e20 < e50 < e100 else "MIXED"
    momentum = (
        "UP"
        if math["rsi"][-1] > 50 and math["macd_hist"][-1] > 0
        else "DOWN"
        if math["rsi"][-1] < 50 and math["macd_hist"][-1] < 0
        else "MIXED"
    )
    direction = (
        "UP" if math["plus_di"] > math["minus_di"] else "DOWN" if math["plus_di"] < math["minus_di"] else "MIXED"
    )
    baseline = sum(b.volume for b in segment[-21:-1]) / 20
    result.update(
        {
            "trend": trend,
            "momentum": momentum,
            "all_directional_checks_agree": trend == momentum == direction and trend != "MIXED",
            "indicators": {
                "ema20": str(e20),
                "ema50": str(e50),
                "ema100": str(e100),
                "rsi14": str(math["rsi"][-1]),
                "macd_histogram": str(math["macd_hist"][-1]),
                "adx14": str(math["adx"]),
                "plus_di14": str(math["plus_di"]),
                "minus_di14": str(math["minus_di"]),
                "atr14": str(math["atr"]),
            },
            "range20": {"low": str(min(b.low for b in segment[-20:])), "high": str(max(b.high for b in segment[-20:]))},
            "volume_vs_previous20": str(last.volume / baseline) if baseline else None,
        }
    )
    return result
