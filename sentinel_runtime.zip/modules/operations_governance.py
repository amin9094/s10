from __future__ import annotations

from collections import Counter
from datetime import UTC, datetime, timedelta
from typing import Any

from core.db import next_id
from core.observability import snapshot as observability_snapshot
from core.utils import parse_dt, utc_iso
from modules.admin_control_center import (
    apply_preset as apply_control_preset,
    is_module_enabled,
    module_state as control_module_state,
    reset_module as reset_control_module,
    set_control_value,
)
from modules.incident_center import record_incident
from modules.platform_registry import set_capability_enabled
from modules.provider_health import active_provider_rows, sanitize_provider_health

OPEN_REQUEST_STATES = {"pending", "pending_second_approval", "approved", "failed"}
FINAL_REQUEST_STATES = {"applied", "rejected", "cancelled", "expired"}
RISK_LEVELS = {"low", "medium", "high", "critical"}

ACTION_PERMISSION_MAP: dict[str, str] = {
    "control_change": "system_control",
    "control_reset": "system_control",
    "control_preset": "system_control",
    "capability_toggle": "capabilities",
    "publisher_decision": "publisher",
    "content_decision": "content_factory",
    "partner_status": "partners",
    "workspace_status": "workspaces",
    "privacy_decision": "users",
    "export_decision": "export_csv",
    "ticket_escalation": "tickets",
    "provider_override": "provider_health",
    "channel_permission_review": "channel_management",
}

AUTO_CHECK_LABELS: dict[str, str] = {
    "support_sla": "کنترل SLA پشتیبانی",
    "publisher_queue": "کنترل صف انتشار",
    "content_approval": "کنترل صف محتوای در انتظار",
    "market_freshness": "کنترل تازگی داده بازار",
    "provider_health": "کنترل سلامت Providerها",
    "paper_risk": "کنترل ریسک معامله آزمایشی",
    "partner_fraud": "کنترل تقلب همکاران",
    "webhook_outbox": "کنترل صف Webhook",
    "backup_freshness": "کنترل تازگی بکاپ",
    "job_freshness": "کنترل تازگی Jobها",
    "privacy_requests": "کنترل درخواست‌های حریم خصوصی",
    "channel_permissions": "کنترل دسترسی ربات به کانال‌ها",
    "market_outliers": "کنترل اختلاف غیرعادی قیمت منابع",
    "news_quality": "کنترل کیفیت و تکرار اخبار",
    "approval_backlog": "کنترل صف‌های تأیید ادمین",
}

# Sensitive settings never bypass human governance. The policy is intentionally
# small and explicit: routine content/UI settings remain fast, while security,
# data integrity, external delivery and financial-risk controls require review.
CRITICAL_CONTROL_FIELDS: set[tuple[str, str]] = {
    ("signals", "owner_approval"),
    ("security", "enabled"),
    ("security", "log_redaction"),
    ("backup", "encrypted"),
    ("database", "migration_guard"),
    ("audit", "enabled"),
    ("privacy", "enabled"),
    ("developer_api", "hmac"),
    ("governance", "enabled"),
    ("governance", "monitoring_mode"),
    ("governance", "two_step_critical"),
    ("governance", "creator_cannot_approve_critical"),
}
HIGH_CONTROL_FIELDS: set[tuple[str, str]] = {
    ("signals", "news_guard_fail_closed"),
    ("signals", "exposure_guard"),
    ("signals", "correlation_guard"),
    ("signals", "max_risk_percent"),
    ("signals", "max_total_open_risk"),
    ("signals", "max_market_open_risk"),
    ("signals", "max_symbol_open_risk"),
    ("signals", "max_correlated_risk"),
    ("signals", "max_daily_new_risk"),
    ("risk", "max_risk_pct"),
    ("paper_trading", "max_trade_risk"),
    ("paper_trading", "max_total_risk"),
    ("prop_guardian", "hard_block"),
    ("publisher", "approval"),
    ("content_factory", "approval"),
    ("developer_api", "enabled"),
    ("developer_api", "webhooks"),
    ("developer_api", "delivery_enabled"),
    ("developer_api", "ip_allowlist"),
    ("governance", "auto_pause_on_failure"),
}
CRITICAL_RESET_MODULES = {"security", "database", "audit", "privacy", "backup", "governance"}
HIGH_RESET_MODULES = {"signals", "risk", "paper_trading", "prop_guardian", "publisher", "developer_api", "automation", "broadcast", "workspaces"}


def governance_control_risk(module_key: str, field_key: str, old: Any, new: Any) -> str | None:
    """Return the mandatory review risk for a control change, if any."""
    key = (str(module_key), str(field_key))
    if key in CRITICAL_CONTROL_FIELDS:
        return "critical"
    if key in HIGH_CONTROL_FIELDS:
        return "high"
    if field_key == "enabled":
        if module_key in CRITICAL_RESET_MODULES:
            return "critical"
        if module_key in HIGH_RESET_MODULES:
            return "high"
    return None


def governance_reset_risk(module_key: str) -> str | None:
    if module_key in CRITICAL_RESET_MODULES:
        return "critical"
    if module_key in HIGH_RESET_MODULES:
        return "high"
    return None


JOB_MAX_AGE_MINUTES: dict[str, int] = {
    "runtime_dependencies": 5, "heartbeat": 5, "vip_expiry": 120,
    "contest_deadlines": 120, "order_notifications": 120, "broadcast_queue": 10,
    "price_alerts": 10, "automation_outbox": 5, "campaign_scheduler": 10,
    "automation": 120, "economic_calendar_automation": 15, "channel_snapshots": 180,
    "privacy_cleanup": 1800, "retention_cleanup": 1800, "receipt_cleanup": 1800,
    "signal_tracking": 30, "scheduled_signals": 10, "scenario_evaluation": 360,
    "market_morning": 15, "operational_backup": 1800, "metrics_persist": 5,
    "business_intelligence": 720, "kpi_trader_reminders": 60,
    "incident_maintenance": 5, "retention_delivery": 10,
    "signal_approval_expiry": 5, "provider_health": 15,
    "payment_reconciliation": 60, "operations_governance": 10,
}


def ensure_operations_governance(db: dict[str, Any]) -> dict[str, Any]:
    root = db.setdefault("operations_governance", {})
    if not isinstance(root, dict):
        root = {}
        db["operations_governance"] = root
    root.setdefault("schema_version", 1)
    root.setdefault("requests", [])
    root.setdefault("automation_checks", {})
    root.setdefault("events", [])
    root.setdefault("overrides", [])
    root.setdefault("last_watchdog_at", None)
    root.setdefault("last_digest_at", None)
    return root


def _settings(db: dict[str, Any]) -> dict[str, Any]:
    try:
        state = control_module_state(db, "governance")
    except ValueError:
        state = {}
    return {
        "enabled": bool(state.get("enabled", True)),
        "monitoring_mode": "automatic" if state.get("monitoring_mode") == "automatic" else "manual",
        "two_step_critical": bool(state.get("two_step_critical", True)),
        "creator_cannot_approve_critical": bool(state.get("creator_cannot_approve_critical", True)),
        "auto_incident": bool(state.get("auto_incident", True)),
        "auto_retry": bool(state.get("auto_retry", False)),
        "auto_pause_on_failure": bool(state.get("auto_pause_on_failure", False)),
        "notify_admins": bool(state.get("notify_admins", False)),
        "daily_digest": bool(state.get("daily_digest", False)),
        "notify_on_change_only": bool(state.get("notify_on_change_only", True)),
        "watchdog_interval_minutes": max(
            5, int(state.get("watchdog_interval_minutes", 10) or 10)
        ),
        "notification_cooldown_minutes": max(
            30, int(state.get("notification_cooldown_minutes", 360) or 360)
        ),
        "max_attempts": max(1, int(state.get("max_attempts", 5) or 5)),
        "stale_minutes": max(5, int(state.get("stale_minutes", 30) or 30)),
        "review_sla_minutes": max(5, int(state.get("review_sla_minutes", 120) or 120)),
        "override_expiry_minutes": max(5, int(state.get("override_expiry_minutes", 60) or 60)),
    }


def _event(db: dict[str, Any], event: str, actor_id: int | str, payload: dict[str, Any]) -> None:
    root = ensure_operations_governance(db)
    rows = root.setdefault("events", [])
    rows.append({
        "id": next_id(db, "operations_governance_event"),
        "event": str(event)[:100],
        "actor_id": str(actor_id),
        "payload": dict(payload),
        "created_at": utc_iso(),
    })
    root["events"] = rows[-10000:]


def required_approvals(db: dict[str, Any], risk_level: str) -> int:
    risk = str(risk_level or "medium").lower()
    settings = _settings(db)
    if risk == "critical" and settings["two_step_critical"]:
        return 2
    return 1 if risk in {"medium", "high", "critical"} else 0


def create_governance_request(
    db: dict[str, Any],
    *,
    action: str,
    payload: dict[str, Any],
    requested_by: int | str,
    risk_level: str = "medium",
    title: str = "",
    description: str = "",
    target_type: str = "",
    target_id: int | str | None = None,
    assigned_to: int | str | None = None,
    source: str = "admin",
    dedupe_key: str = "",
) -> dict[str, Any]:
    root = ensure_operations_governance(db)
    risk = str(risk_level or "medium").lower()
    if risk not in RISK_LEVELS:
        raise ValueError("INVALID_RISK_LEVEL")
    normalized_action = str(action or "").strip()
    if normalized_action not in ACTION_PERMISSION_MAP:
        raise ValueError("UNSUPPORTED_GOVERNANCE_ACTION")
    dedupe = str(dedupe_key or "").strip()[:160]
    if dedupe:
        for row in reversed(root["requests"]):
            if isinstance(row, dict) and row.get("dedupe_key") == dedupe and row.get("status") in OPEN_REQUEST_STATES:
                row["last_seen_at"] = utc_iso()
                row["occurrences"] = int(row.get("occurrences", 1) or 1) + 1
                return dict(row)
    approvals_needed = required_approvals(db, risk)
    status = "approved" if approvals_needed == 0 else "pending"
    now = datetime.now(UTC)
    request = {
        "id": next_id(db, "operations_governance_request"),
        "action": normalized_action,
        "required_permission": ACTION_PERMISSION_MAP[normalized_action],
        "title": str(title or normalized_action)[:160],
        "description": str(description or "")[:2000],
        "payload": dict(payload or {}),
        "original_payload": dict(payload or {}),
        "target_type": str(target_type or "")[:80],
        "target_id": None if target_id is None else str(target_id),
        "risk_level": risk,
        "required_approvals": approvals_needed,
        "status": status,
        "requested_by": str(requested_by),
        "assigned_to": None if assigned_to is None else str(assigned_to),
        "source": str(source or "admin")[:80],
        "dedupe_key": dedupe,
        "occurrences": 1,
        "approvals": [],
        "edit_history": [],
        "attempts": 0,
        "last_error": "",
        "next_attempt_at": None,
        "created_at": utc_iso(now),
        "updated_at": utc_iso(now),
        "expires_at": utc_iso(now + timedelta(days=7)),
    }
    root["requests"].append(request)
    root["requests"] = root["requests"][-5000:]
    _event(db, "request_created", requested_by, {"request_id": request["id"], "action": normalized_action, "risk": risk})
    return dict(request)


def governance_request(db: dict[str, Any], request_id: int | str) -> dict[str, Any] | None:
    target = str(request_id)
    for row in ensure_operations_governance(db)["requests"]:
        if isinstance(row, dict) and str(row.get("id")) == target:
            return row
    return None


def edit_governance_request(
    db: dict[str, Any],
    request_id: int | str,
    *,
    actor_id: int | str,
    payload: dict[str, Any] | None = None,
    title: str | None = None,
    description: str | None = None,
    risk_level: str | None = None,
    assigned_to: int | str | None = None,
) -> dict[str, Any]:
    row = governance_request(db, request_id)
    if not row:
        raise ValueError("REQUEST_NOT_FOUND")
    if row.get("status") in FINAL_REQUEST_STATES:
        raise ValueError("REQUEST_FINALIZED")
    before = {"payload": dict(row.get("payload") or {}), "title": row.get("title"), "description": row.get("description"), "risk_level": row.get("risk_level"), "assigned_to": row.get("assigned_to")}
    if payload is not None:
        row["payload"] = dict(payload)
    if title is not None:
        row["title"] = str(title)[:160]
    if description is not None:
        row["description"] = str(description)[:2000]
    if risk_level is not None:
        risk = str(risk_level).lower()
        if risk not in RISK_LEVELS:
            raise ValueError("INVALID_RISK_LEVEL")
        row["risk_level"] = risk
        row["required_approvals"] = required_approvals(db, risk)
        row["approvals"] = []
        row["status"] = "approved" if row["required_approvals"] == 0 else "pending"
    if assigned_to is not None:
        row["assigned_to"] = str(assigned_to) if str(assigned_to).strip() else None
    row.setdefault("edit_history", []).append({"actor_id": str(actor_id), "before": before, "after": {"payload": dict(row.get("payload") or {}), "title": row.get("title"), "description": row.get("description"), "risk_level": row.get("risk_level"), "assigned_to": row.get("assigned_to")}, "created_at": utc_iso()})
    row["edit_history"] = row["edit_history"][-100:]
    row["updated_at"] = utc_iso()
    _event(db, "request_edited", actor_id, {"request_id": row["id"]})
    return dict(row)


def approve_governance_request(db: dict[str, Any], request_id: int | str, actor_id: int | str, *, force: bool = False) -> dict[str, Any]:
    row = governance_request(db, request_id)
    if not row:
        raise ValueError("REQUEST_NOT_FOUND")
    if row.get("status") in FINAL_REQUEST_STATES:
        raise ValueError("REQUEST_FINALIZED")
    actor = str(actor_id)
    if any(str(item.get("actor_id")) == actor for item in row.get("approvals", []) if isinstance(item, dict)):
        raise ValueError("ALREADY_APPROVED")
    settings = _settings(db)
    if row.get("risk_level") == "critical" and settings["creator_cannot_approve_critical"] and actor == str(row.get("requested_by")) and not force:
        raise ValueError("CRITICAL_REQUEST_REQUIRES_DIFFERENT_APPROVER")
    row.setdefault("approvals", []).append({"actor_id": actor, "force": bool(force), "created_at": utc_iso()})
    if force:
        row["status"] = "approved"
        row["forced_approval"] = True
        row["approval_expires_at"] = utc_iso(datetime.now(UTC) + timedelta(minutes=settings["override_expiry_minutes"]))
    elif len(row["approvals"]) >= int(row.get("required_approvals", 1) or 1):
        row["status"] = "approved"
    else:
        row["status"] = "pending_second_approval"
    row["updated_at"] = utc_iso()
    _event(db, "request_approved", actor_id, {"request_id": row["id"], "status": row["status"], "force": bool(force)})
    return dict(row)


def reject_governance_request(db: dict[str, Any], request_id: int | str, actor_id: int | str, reason: str = "") -> dict[str, Any]:
    row = governance_request(db, request_id)
    if not row:
        raise ValueError("REQUEST_NOT_FOUND")
    if row.get("status") in FINAL_REQUEST_STATES:
        raise ValueError("REQUEST_FINALIZED")
    row.update({"status": "rejected", "rejected_by": str(actor_id), "rejection_reason": str(reason or "")[:1000], "updated_at": utc_iso()})
    _event(db, "request_rejected", actor_id, {"request_id": row["id"], "reason": str(reason or "")[:300]})
    return dict(row)


def _find_row(rows: Any, target_id: str) -> dict[str, Any] | None:
    if not isinstance(rows, list):
        return None
    return next((row for row in rows if isinstance(row, dict) and str(row.get("id")) == target_id), None)


def _apply_action(db: dict[str, Any], row: dict[str, Any], actor_id: int | str) -> dict[str, Any]:
    action = str(row.get("action"))
    payload = dict(row.get("payload") or {})
    if action == "control_change":
        old, new = set_control_value(db, str(payload["module"]), str(payload["field"]), payload.get("value"), actor_id)
        return {"old": old, "new": new}
    if action == "control_reset":
        module_key = str(payload.get("module") or row.get("target_id") or "")
        return reset_control_module(db, module_key, actor_id)
    if action == "control_preset":
        preset = str(payload.get("preset") or "")
        apply_control_preset(db, preset, actor_id)
        return {"preset": preset, "applied": True}
    if action == "capability_toggle":
        return set_capability_enabled(db, str(payload["capability"]), bool(payload.get("enabled")), actor_id)
    if action == "channel_permission_review":
        chat_id = str(payload.get("chat_id") or row.get("target_id") or "")
        health = db.setdefault("channel_permission_health", {})
        target = health.setdefault(chat_id, {"chat_id": chat_id})
        target["review_status"] = str(payload.get("status") or "acknowledged")
        target["review_note"] = str(payload.get("note") or "")[:1000]
        target["reviewed_by"] = str(actor_id)
        target["reviewed_at"] = utc_iso()
        return dict(target)

    mapping = {
        "publisher_decision": ("publisher_queue", {"approved": "approved", "rejected": "rejected"}),
        "content_decision": ("content_outputs", {"approved": "approved", "rejected": "rejected"}),
        "partner_status": ("partners", {}),
        "workspace_status": ("workspaces", {}),
        "privacy_decision": ("privacy_requests", {"approved": "approved", "rejected": "rejected"}),
        "export_decision": ("export_requests", {"approved": "approved", "rejected": "rejected"}),
        "ticket_escalation": ("tickets", {}),
        "provider_override": ("provider_health_overrides", {}),
    }
    if action in mapping:
        collection, allowed = mapping[action]
        target_id = str(payload.get("target_id") or row.get("target_id") or "")
        if action == "provider_override":
            rows = db.setdefault(collection, [])
            result = {"id": next_id(db, collection), "provider": str(payload.get("provider") or target_id), "status": str(payload.get("status") or "degraded"), "reason": str(payload.get("reason") or "")[:500], "expires_at": payload.get("expires_at"), "created_at": utc_iso()}
            rows.append(result)
            return result
        target = _find_row(db.setdefault(collection, []), target_id)
        if not target:
            raise ValueError("TARGET_NOT_FOUND")
        new_status = str(payload.get("status") or "approved")
        if allowed and new_status not in allowed:
            raise ValueError("INVALID_TARGET_STATUS")
        target["status"] = allowed.get(new_status, new_status)
        target["updated_at"] = utc_iso()
        target["updated_by"] = str(actor_id)
        if payload.get("note"):
            target["governance_note"] = str(payload.get("note"))[:1000]
        return dict(target)
    raise ValueError("UNSUPPORTED_GOVERNANCE_ACTION")


def apply_governance_request(db: dict[str, Any], request_id: int | str, actor_id: int | str) -> dict[str, Any]:
    row = governance_request(db, request_id)
    if not row:
        raise ValueError("REQUEST_NOT_FOUND")
    if row.get("status") != "approved":
        raise ValueError("REQUEST_NOT_APPROVED")
    approval_expires = parse_dt(row.get("approval_expires_at"))
    if approval_expires and approval_expires < datetime.now(UTC):
        row["status"] = "pending"
        row["approvals"] = []
        row["approval_expires_at"] = None
        raise ValueError("APPROVAL_EXPIRED")
    settings = _settings(db)
    row["attempts"] = int(row.get("attempts", 0) or 0) + 1
    try:
        result = _apply_action(db, row, actor_id)
    except Exception as exc:
        row["last_error"] = str(exc)[:500]
        row["updated_at"] = utc_iso()
        if settings["auto_retry"] and row["attempts"] < settings["max_attempts"]:
            delay = min(3600, 30 * (2 ** max(0, row["attempts"] - 1)))
            row["status"] = "failed"
            row["next_attempt_at"] = utc_iso(datetime.now(UTC) + timedelta(seconds=delay))
        else:
            row["status"] = "failed"
            row["next_attempt_at"] = None
        if settings["auto_incident"]:
            record_incident(db, source="operations_governance", kind="request_apply_failed", detail=f"Request {row['id']} failed: {row['last_error']}", severity="critical" if row.get("risk_level") == "critical" else "warning", metadata={"request_id": row["id"], "action": row.get("action"), "attempts": row["attempts"]}, dedupe_minutes=15)
        _event(db, "request_apply_failed", actor_id, {"request_id": row["id"], "error": row["last_error"]})
        raise
    row.update({"status": "applied", "result": result, "applied_by": str(actor_id), "applied_at": utc_iso(), "updated_at": utc_iso(), "last_error": "", "next_attempt_at": None})
    _event(db, "request_applied", actor_id, {"request_id": row["id"], "action": row.get("action")})
    return dict(row)


def retry_due_requests(db: dict[str, Any], actor_id: int | str = "system") -> dict[str, int]:
    now = datetime.now(UTC)
    retried = applied = failed = 0
    for row in ensure_operations_governance(db)["requests"]:
        if not isinstance(row, dict) or row.get("status") != "failed" or not row.get("next_attempt_at"):
            continue
        due = parse_dt(row.get("next_attempt_at"))
        if due and due > now:
            continue
        row["status"] = "approved"
        retried += 1
        try:
            apply_governance_request(db, row["id"], actor_id)
            applied += 1
        except Exception:
            failed += 1
    return {"retried": retried, "applied": applied, "failed": failed}


def retry_governance_request(
    db: dict[str, Any], request_id: int | str, actor_id: int | str
) -> dict[str, Any]:
    """Queue one failed request again without asking for duplicate approvals."""
    row = governance_request(db, request_id)
    if not row:
        raise ValueError("REQUEST_NOT_FOUND")
    if row.get("status") != "failed":
        raise ValueError("REQUEST_NOT_FAILED")
    approvals = row.get("approvals") if isinstance(row.get("approvals"), list) else []
    required = int(row.get("required_approvals", 0) or 0)
    row["status"] = "approved" if len(approvals) >= required else "pending"
    row["next_attempt_at"] = None
    row["last_error"] = ""
    row["updated_at"] = utc_iso()
    _event(db, "request_retry_requested", actor_id, {"request_id": row["id"]})
    return dict(row)


def _record_check(db: dict[str, Any], key: str, status: str, details: dict[str, Any], *, failure: str = "") -> dict[str, Any]:
    root = ensure_operations_governance(db)
    checks = root.setdefault("automation_checks", {})
    row = checks.setdefault(key, {"key": key, "label": AUTO_CHECK_LABELS.get(key, key), "runs": 0, "failures": 0})
    row["runs"] = int(row.get("runs", 0) or 0) + 1
    row["status"] = status
    row["details"] = dict(details)
    row["last_run_at"] = utc_iso()
    if status == "healthy":
        row["last_success_at"] = row["last_run_at"]
        row["consecutive_failures"] = 0
        row["last_error"] = ""
    elif status in {"warning", "critical"}:
        row["failures"] = int(row.get("failures", 0) or 0) + 1
        row["consecutive_failures"] = int(row.get("consecutive_failures", 0) or 0) + 1
        row["last_error"] = str(failure or details.get("message") or "")[:500]
    return dict(row)


def _age_minutes(value: Any, now: datetime) -> float | None:
    dt = parse_dt(value)
    if not dt:
        return None
    return max(0.0, (now - dt).total_seconds() / 60)


def _auto_request(db: dict[str, Any], *, action: str, title: str, description: str, risk: str, payload: dict[str, Any], dedupe_key: str, target_type: str = "", target_id: Any = None) -> dict[str, Any]:
    return create_governance_request(db, action=action, payload=payload, requested_by="watchdog", risk_level=risk, title=title, description=description, source="watchdog", dedupe_key=dedupe_key, target_type=target_type, target_id=target_id)


def governance_monitoring_enabled(db: dict[str, Any]) -> bool:
    settings = _settings(db)
    return settings["enabled"] and settings["monitoring_mode"] == "automatic"


def governance_notifications_enabled(db: dict[str, Any]) -> bool:
    settings = _settings(db)
    return governance_monitoring_enabled(db) and settings["notify_admins"]


def run_automation_checks(db: dict[str, Any], *, now: datetime | None = None, manual: bool = False) -> dict[str, Any]:
    current = (now or datetime.now(UTC)).astimezone(UTC)
    root = ensure_operations_governance(db)
    settings = _settings(db)
    if not settings["enabled"] or not is_module_enabled(db, "governance") or (not manual and not governance_monitoring_enabled(db)):
        return {"enabled": False, "checks": [], "summary": {"healthy": 0, "warning": 0, "critical": 0, "unknown": 0}}
    results: list[dict[str, Any]] = []

    # 1) Support SLA and automatic escalation request.
    support_state = control_module_state(db, "support") if is_module_enabled(db, "support") else {}
    urgent_h = max(1, int(support_state.get("sla_urgent_h", 4) or 4))
    normal_h = max(1, int(support_state.get("sla_normal_h", 24) or 24))
    overdue_tickets: list[dict[str, Any]] = []
    for ticket in db.get("tickets", []):
        if not isinstance(ticket, dict) or str(ticket.get("status")) not in {"open", "pending", "waiting"}:
            continue
        age = _age_minutes(ticket.get("updated_at") or ticket.get("created_at"), current)
        limit = urgent_h * 60 if str(ticket.get("priority")) in {"urgent", "high"} else normal_h * 60
        if age is not None and age > limit:
            overdue_tickets.append(ticket)
            _auto_request(db, action="ticket_escalation", title="تیکت عبورکرده از SLA", description="ربات عبور تیکت از زمان پاسخ‌گویی مجاز را تشخیص داد.", risk="medium", payload={"target_id": ticket.get("id"), "status": "escalated", "note": "Auto SLA escalation"}, dedupe_key=f"ticket-sla:{ticket.get('id')}", target_type="ticket", target_id=ticket.get("id"))
    results.append(_record_check(db, "support_sla", "warning" if overdue_tickets else "healthy", {"overdue": len(overdue_tickets), "urgent_sla_h": urgent_h, "normal_sla_h": normal_h}))

    # 2) Publisher queue age/failures.
    stale_queue = []
    for item in db.get("publisher_queue", []):
        if not isinstance(item, dict) or str(item.get("status")) not in {"queued", "scheduled", "retry", "failed"}:
            continue
        age = _age_minutes(item.get("scheduled_at") or item.get("created_at"), current)
        if (age is not None and age > settings["stale_minutes"]) or int(item.get("attempts", 0) or 0) >= settings["max_attempts"]:
            stale_queue.append(item)
    results.append(_record_check(db, "publisher_queue", "critical" if any(int(row.get("attempts", 0) or 0) >= settings["max_attempts"] for row in stale_queue) else ("warning" if stale_queue else "healthy"), {"stale": len(stale_queue)}))

    # 3) Content approval SLA.
    pending_content = []
    for item in db.get("content_outputs", []):
        if not isinstance(item, dict) or str(item.get("status")) not in {"pending", "draft", "review"}:
            continue
        age = _age_minutes(item.get("updated_at") or item.get("created_at"), current)
        if age is not None and age > settings["review_sla_minutes"]:
            pending_content.append(item)
    results.append(_record_check(db, "content_approval", "warning" if pending_content else "healthy", {"overdue_reviews": len(pending_content), "sla_minutes": settings["review_sla_minutes"]}))

    # 4) Market data freshness from any cached timestamp available.
    stale_market = 0
    known_market = 0
    stale_seconds = max(30, int(control_module_state(db, "market_v2").get("stale_seconds", 300) or 300))
    for key in ("market_cache", "price_cache", "market_data_cache", "market_intelligence_cache"):
        value = db.get(key)
        rows = value.values() if isinstance(value, dict) else value if isinstance(value, list) else []
        for item in rows:
            if not isinstance(item, dict):
                continue
            known_market += 1
            age = _age_minutes(item.get("updated_at") or item.get("fetched_at") or item.get("created_at"), current)
            if age is not None and age * 60 > stale_seconds:
                stale_market += 1
    stale_ratio = (stale_market / known_market) if known_market else 0.0
    if not known_market:
        market_status = "healthy"
        market_mode = "idle"
    elif stale_market == known_market:
        market_status = "warning"
        market_mode = "all_stale"
    else:
        market_status = "healthy"
        market_mode = "live" if not stale_market else "redundant_cache"
    results.append(_record_check(db, "market_freshness", market_status, {
        "known": known_market,
        "stale": stale_market,
        "stale_seconds": stale_seconds,
        "stale_ratio": round(stale_ratio, 3),
        "mode": market_mode,
    }))

    # 5) Provider health and stale probes. Multi-provider redundancy means one
    # failed source is actionable but not critical while another source is live.
    sanitize_provider_health(db)
    provider_rows = active_provider_rows(db)
    healthy_providers = degraded_providers = offline_providers = stale_providers = 0
    for provider in provider_rows:
        status = str(provider.get("status") or "unknown")
        if status == "healthy":
            healthy_providers += 1
        elif status in {"degraded", "recovering"}:
            degraded_providers += 1
        elif status == "offline":
            offline_providers += 1
        age = _age_minutes(provider.get("last_checked_at"), current)
        if age is None or age > settings["stale_minutes"]:
            stale_providers += 1
    provider_total = len(provider_rows)
    minimum_redundancy = 2 if provider_total >= 2 else 1
    if not provider_total:
        provider_status = "healthy"
        provider_mode = "idle"
    elif healthy_providers == 0:
        provider_status = "critical"
        provider_mode = "unavailable"
    elif healthy_providers < minimum_redundancy:
        provider_status = "warning"
        provider_mode = "single_source"
    elif stale_providers >= healthy_providers and stale_providers:
        provider_status = "warning"
        provider_mode = "probe_stale"
    else:
        # Optional providers are allowed to be offline while two or more live
        # providers preserve price redundancy. This avoids false yellow health
        # states when one public API is temporarily rate limited.
        provider_status = "healthy"
        provider_mode = "redundant"
    results.append(_record_check(db, "provider_health", provider_status, {
        "total": provider_total,
        "healthy": healthy_providers,
        "degraded": degraded_providers,
        "offline": offline_providers,
        "unhealthy": degraded_providers + offline_providers,
        "stale": stale_providers,
        "redundancy_ok": healthy_providers >= minimum_redundancy,
        "mode": provider_mode,
    }))

    # 6) Paper risk and prop breaches.
    account_risk: Counter[str] = Counter()
    for trade in db.get("paper_trades", []):
        if isinstance(trade, dict) and trade.get("status") == "open":
            account_risk[str(trade.get("account_id"))] += float(trade.get("risk_percent") or 0)
    max_total = float(control_module_state(db, "paper_trading").get("max_total_risk", 10) or 10)
    risky_accounts = [account_id for account_id, risk in account_risk.items() if risk > max_total]
    breached_challenges = [row for row in db.get("prop_challenges", []) if isinstance(row, dict) and str(row.get("status")) in {"breached", "blocked", "failed"}]
    results.append(_record_check(db, "paper_risk", "critical" if breached_challenges else ("warning" if risky_accounts else "healthy"), {"risky_accounts": len(risky_accounts), "breached_challenges": len(breached_challenges), "max_total_risk": max_total}))

    # 7) Duplicate referral/partner events.
    seen: set[tuple[str, str, str]] = set()
    duplicates = 0
    for event in db.get("partner_events", []):
        if not isinstance(event, dict):
            continue
        key = (str(event.get("partner_id")), str(event.get("user_id")), str(event.get("event_type") or event.get("type")))
        if key in seen:
            duplicates += 1
        else:
            seen.add(key)
    results.append(_record_check(db, "partner_fraud", "warning" if duplicates else "healthy", {"duplicate_events": duplicates, "events": len(seen)}))

    # 8) Webhook delivery queue.
    stuck_webhooks = dead_webhooks = 0
    for event in db.get("webhook_outbox", []):
        if not isinstance(event, dict):
            continue
        status = str(event.get("status") or "")
        age = _age_minutes(event.get("updated_at") or event.get("created_at"), current)
        attempts = int(event.get("attempts", 0) or 0)
        if status in {"dead", "discarded"} or attempts >= settings["max_attempts"]:
            dead_webhooks += 1
        elif status in {"pending", "held", "retry"} and age is not None and age > settings["stale_minutes"]:
            stuck_webhooks += 1
    results.append(_record_check(db, "webhook_outbox", "critical" if dead_webhooks else ("warning" if stuck_webhooks else "healthy"), {"stuck": stuck_webhooks, "dead": dead_webhooks}))

    # 9) Backup freshness only when backup is enabled. The operational backup
    # job writes its canonical timestamp under operations; older releases only
    # inspected backup_history and therefore reported a permanent false warning.
    backup_enabled = is_module_enabled(db, "backup")
    backup_status = "healthy"
    backup_age_h = None
    backup_mode = "disabled" if not backup_enabled else "ready"
    if backup_enabled:
        operations = db.get("operations") if isinstance(db.get("operations"), dict) else {}
        candidates = [
            parse_dt(operations.get("last_operational_backup_at")),
            *(parse_dt(row.get("created_at")) for row in db.get("backup_history", []) if isinstance(row, dict) and row.get("created_at")),
        ]
        latest = max((item for item in candidates if item is not None), default=None)
        uptime_seconds = int(observability_snapshot().get("uptime_seconds", 0) or 0)
        if latest:
            backup_age_h = max(0.0, (current - latest).total_seconds() / 3600)
            if backup_age_h > 48:
                backup_status = "critical"
                backup_mode = "expired"
            elif backup_age_h > 30:
                backup_status = "warning"
                backup_mode = "due"
        elif uptime_seconds < 15 * 60:
            backup_mode = "warming_up"
        else:
            backup_status = "warning"
            backup_mode = "missing"
    results.append(_record_check(db, "backup_freshness", backup_status, {
        "latest_age_hours": None if backup_age_h is None else round(backup_age_h, 2),
        "enabled": backup_enabled,
        "mode": backup_mode,
    }))

    # 10) Observed background job failures/staleness. A single transient network
    # failure is shown as recovering; only repeated failures become critical.
    observability = observability_snapshot()
    jobs = observability.get("jobs", {})
    process_uptime_minutes = max(0.0, float(observability.get("uptime_seconds", 0) or 0) / 60)
    failed_names: list[str] = []
    recovering_names: list[str] = []
    stale_names: list[str] = []
    for job_name, state in jobs.items() if isinstance(jobs, dict) else []:
        if str(job_name) == "operations_governance" and not governance_monitoring_enabled(db):
            continue
        if not isinstance(state, dict):
            continue
        status = str(state.get("status") or "unknown")
        consecutive = int(state.get("consecutive_failures", 0) or 0)
        if status == "failed" and consecutive >= 2:
            failed_names.append(str(job_name))
        elif status in {"failed", "degraded", "retrying"} or consecutive == 1:
            recovering_names.append(str(job_name))
        age = _age_minutes(state.get("finished_at") or state.get("started_at"), current)
        expected_max_age = JOB_MAX_AGE_MINUTES.get(str(job_name), max(settings["stale_minutes"] * 3, 180))
        # A job cannot be stale before the current process has lived long enough
        # for its own maximum-age window. This prevents old deployment state or
        # a freshly scheduled daily task from creating a false warning.
        if age is not None and process_uptime_minutes > expected_max_age and age > expected_max_age:
            stale_names.append(str(job_name))
    # One transient failure is retained in details for diagnosis but does not
    # paint the whole system yellow. A repeated failure or truly stale job does.
    job_status = "critical" if failed_names else ("warning" if stale_names else "healthy")
    results.append(_record_check(db, "job_freshness", job_status, {
        "known": len(jobs) if isinstance(jobs, dict) else 0,
        "failed": len(failed_names),
        "recovering": len(recovering_names),
        "stale": len(stale_names),
        "failed_jobs": failed_names[:10],
        "recovering_jobs": recovering_names[:10],
        "stale_jobs": stale_names[:10],
        "process_uptime_minutes": round(process_uptime_minutes, 2),
    }))

    # 11) Privacy/export requests waiting too long.
    overdue_privacy = []
    for key in ("privacy_requests", "data_export_requests", "deletion_requests"):
        for request in db.get(key, []):
            if not isinstance(request, dict) or str(request.get("status")) not in {"pending", "open", "review"}:
                continue
            age = _age_minutes(request.get("updated_at") or request.get("created_at"), current)
            if age is not None and age > 24 * 60:
                overdue_privacy.append((key, request))
    results.append(_record_check(db, "privacy_requests", "warning" if overdue_privacy else "healthy", {"overdue": len(overdue_privacy)}))

    # 12) Live/cached Telegram channel permission health.
    channel_health = db.get("channel_permission_health", {})
    channel_unknown = channel_bad = 0
    for chat_id, state in channel_health.items() if isinstance(channel_health, dict) else []:
        if not isinstance(state, dict):
            continue
        status = str(state.get("status") or "unknown")
        age = _age_minutes(state.get("checked_at"), current)
        if status in {"missing", "forbidden", "not_admin", "cannot_post", "error"}:
            channel_bad += 1
            _auto_request(
                db,
                action="channel_permission_review",
                title="دسترسی ربات به کانال نیازمند اصلاح است",
                description=f"وضعیت دسترسی کانال {chat_id}: {status}",
                risk="high",
                payload={"chat_id": chat_id, "status": "acknowledged", "note": "پس از اصلاح دسترسی در تلگرام تأیید شود"},
                dedupe_key=f"channel-permission:{chat_id}:{status}",
                target_type="channel",
                target_id=chat_id,
            )
        elif status == "unknown" or age is None or age > max(settings["stale_minutes"], 15):
            channel_unknown += 1
    channel_status = "critical" if channel_bad else ("warning" if channel_unknown else "healthy")
    results.append(_record_check(db, "channel_permissions", channel_status, {
        "known": len(channel_health) if isinstance(channel_health, dict) else 0,
        "bad": channel_bad,
        "stale_or_unknown": channel_unknown,
        "mode": "configured" if channel_health else "idle",
    }))

    # 13) Cross-provider price outlier detection from the free provider cache.
    prices_by_symbol: dict[str, list[float]] = {}
    for provider in provider_rows if isinstance(provider_rows, list) else []:
        if not isinstance(provider, dict) or provider.get("last_price") in {None, ""}:
            continue
        try:
            price = float(provider.get("last_price"))
        except (TypeError, ValueError):
            continue
        if price <= 0:
            continue
        symbol = str(provider.get("last_symbol") or "UNKNOWN").upper()
        prices_by_symbol.setdefault(symbol, []).append(price)
    outlier_symbols: list[str] = []
    for symbol, prices in prices_by_symbol.items():
        if len(prices) < 2:
            continue
        ordered = sorted(prices)
        median = ordered[len(ordered) // 2]
        spread_pct = (max(ordered) - min(ordered)) / max(median, 1e-12) * 100
        threshold = 0.8 if symbol.endswith(("USD", "USDT")) else 2.0
        if spread_pct > threshold:
            outlier_symbols.append(symbol)
    results.append(_record_check(db, "market_outliers", "warning" if outlier_symbols else "healthy", {
        "symbols_checked": len(prices_by_symbol),
        "outliers": outlier_symbols[:20],
        "mode": "checked" if prices_by_symbol else "idle",
    }))

    # 14) Duplicate/stale news quality control without external NLP services.
    news_rows: list[dict[str, Any]] = []
    for key in ("news_items", "market_news", "economic_news"):
        value = db.get(key)
        if isinstance(value, list):
            news_rows.extend(row for row in value if isinstance(row, dict))
    seen_titles: set[str] = set()
    duplicate_news = stale_news = 0
    retention_days = max(1, int(control_module_state(db, "news").get("retention_days", 30) or 30))
    for item in news_rows:
        title = " ".join(str(item.get("title") or item.get("headline") or "").casefold().split())
        if title:
            if title in seen_titles:
                duplicate_news += 1
            seen_titles.add(title)
        age = _age_minutes(item.get("published_at") or item.get("created_at"), current)
        if age is not None and age > retention_days * 1440:
            stale_news += 1
    news_status = "warning" if duplicate_news or stale_news else "healthy"
    results.append(_record_check(db, "news_quality", news_status, {
        "items": len(news_rows),
        "duplicates": duplicate_news,
        "past_retention": stale_news,
        "mode": "checked" if news_rows else "idle",
    }))

    # 15) Human approval queue SLA across sensitive business operations.
    approval_overdue = {"signals": 0, "payments": 0, "privacy": 0}
    for item in db.get("signal_approvals", []):
        if isinstance(item, dict) and str(item.get("status")) == "pending":
            age = _age_minutes(item.get("updated_at") or item.get("created_at"), current)
            if age is not None and age > settings["review_sla_minutes"]:
                approval_overdue["signals"] += 1
    for item in db.get("vip_orders", []):
        if isinstance(item, dict) and str(item.get("status")) in {"pending", "approving", "review"}:
            age = _age_minutes(item.get("updated_at") or item.get("created_at"), current)
            if age is not None and age > settings["review_sla_minutes"]:
                approval_overdue["payments"] += 1
    approval_overdue["privacy"] = len(overdue_privacy)
    total_approval_overdue = sum(approval_overdue.values())
    results.append(_record_check(db, "approval_backlog", "warning" if total_approval_overdue else "healthy", {**approval_overdue, "total": total_approval_overdue, "sla_minutes": settings["review_sla_minutes"]}))

    # Expire abandoned governance requests so the admin queue cannot grow forever.
    expired_requests = 0
    for request in root.get("requests", []):
        if not isinstance(request, dict) or request.get("status") in FINAL_REQUEST_STATES:
            continue
        expires_at = parse_dt(request.get("expires_at"))
        if expires_at and expires_at < current:
            request["status"] = "expired"
            request["updated_at"] = utc_iso(current)
            expired_requests += 1

    # Incidents are generated only for repeated/critical failures to avoid noise.
    if settings["auto_incident"]:
        for result in results:
            if result.get("status") == "critical" or int(result.get("consecutive_failures", 0) or 0) >= 3:
                record_incident(db, source="operations_watchdog", kind=str(result.get("key")), detail=f"{result.get('label')}: {result.get('details')}", severity="critical" if result.get("status") == "critical" else "warning", metadata={"check": result.get("key"), "details": result.get("details")}, dedupe_minutes=30)

    auto_paused: list[str] = []
    if settings["auto_pause_on_failure"] and not manual:
        pause_map = {"publisher_queue": "publisher", "provider_health": "tracker", "webhook_outbox": "developer_api"}
        for result in results:
            module_key = pause_map.get(str(result.get("key")))
            if not module_key or result.get("status") != "critical" or int(result.get("consecutive_failures", 0) or 0) < 3:
                continue
            if is_module_enabled(db, module_key):
                set_control_value(db, module_key, "enabled", False, "watchdog")
                auto_paused.append(module_key)
                record_incident(db, source="operations_watchdog", kind="module_auto_paused", detail=f"Module {module_key} was paused after repeated critical checks.", severity="critical", metadata={"module": module_key, "check": result.get("key")}, dedupe_minutes=60)

    retry_result = retry_due_requests(db) if settings["auto_retry"] and not manual else {"retried": 0, "applied": 0, "failed": 0}
    root["last_watchdog_at"] = utc_iso(current)
    summary = Counter(str(item.get("status") or "unknown") for item in results)
    _event(db, "manual_check_completed" if manual else "watchdog_completed", "system", {"summary": dict(summary), "retry": retry_result, "expired_requests": expired_requests})
    return {"enabled": True, "checks": results, "summary": {key: int(summary.get(key, 0)) for key in ("healthy", "warning", "critical", "unknown")}, "retry": retry_result, "auto_paused": auto_paused, "expired_requests": expired_requests, "generated_at": utc_iso(current)}


def governance_dashboard(db: dict[str, Any]) -> dict[str, Any]:
    root = ensure_operations_governance(db)
    requests = [dict(row) for row in root["requests"] if isinstance(row, dict)]
    requests.sort(key=lambda row: str(row.get("updated_at") or row.get("created_at") or ""), reverse=True)
    statuses = Counter(str(row.get("status") or "unknown") for row in requests)
    checks = [dict(row) for row in root.get("automation_checks", {}).values() if isinstance(row, dict)]
    checks.sort(key=lambda row: row.get("key", ""))
    health = Counter(str(row.get("status") or "unknown") for row in checks)
    return {
        "settings": _settings(db),
        "requests": requests[:200],
        "pending": [row for row in requests if row.get("status") in {"pending", "pending_second_approval", "approved", "failed"}][:100],
        "request_status": dict(statuses),
        "checks": checks,
        "health": {key: int(health.get(key, 0)) for key in ("healthy", "warning", "critical", "unknown")},
        "last_watchdog_at": root.get("last_watchdog_at"),
        "notifications_silenced_until": root.get("notifications_silenced_until"),
        "generated_at": utc_iso(),
    }


def set_governance_notification_snooze(
    db: dict[str, Any], minutes: int, actor_id: int | str
) -> dict[str, Any]:
    """Silence push digests while watchdog checks and the dashboard keep running."""
    root = ensure_operations_governance(db)
    duration = max(0, min(int(minutes), 7 * 24 * 60))
    root["notifications_silenced_until"] = (
        None
        if duration == 0
        else utc_iso(datetime.now(UTC) + timedelta(minutes=duration))
    )
    _event(
        db,
        "notifications_snoozed" if duration else "notifications_resumed",
        actor_id,
        {"minutes": duration, "until": root["notifications_silenced_until"]},
    )
    return {
        "silenced": bool(duration),
        "minutes": duration,
        "until": root["notifications_silenced_until"],
    }


def claim_governance_digest(
    db: dict[str, Any], *, force: bool = False, now: datetime | None = None
) -> dict[str, Any] | None:
    root = ensure_operations_governance(db)
    settings = _settings(db)
    if not governance_notifications_enabled(db):
        return None
    current = (now or datetime.now(UTC)).astimezone(UTC)
    silenced_until = parse_dt(root.get("notifications_silenced_until"))
    if not force and silenced_until and silenced_until > current:
        return None
    dashboard = governance_dashboard(db)
    pending_rows = dashboard["pending"][:50]
    pending_ids = [str(row.get("id")) for row in pending_rows]
    health = dashboard["health"]
    request_state = ",".join(
        f"{row.get('id')}:{row.get('status')}:{len(row.get('approvals') or [])}/{int(row.get('required_approvals', 0) or 0)}"
        for row in pending_rows
    )
    check_state = ",".join(
        f"{row.get('key')}:{row.get('status')}"
        for row in sorted(
            dashboard.get("checks", []), key=lambda item: str(item.get("key"))
        )
        if row.get("status") in {"warning", "critical"}
    )
    fingerprint = (
        f"{request_state}|{check_state}|{health['warning']}|{health['critical']}"
    )
    last_at = parse_dt(root.get("last_digest_at"))
    last_claimed_at = parse_dt(root.get("last_digest_claimed_at"))
    if not force and last_claimed_at and current - last_claimed_at < timedelta(minutes=30):
        return None
    daily_due = bool(
        settings["daily_digest"] and (not last_at or last_at.date() != current.date())
    )
    actionable = bool(pending_ids or health["warning"] or health["critical"])
    changed = fingerprint != root.get("last_digest_sent_fingerprint")
    if not force and not actionable and not daily_due:
        return None
    if not force and settings["notify_on_change_only"] and not changed and not daily_due:
        return None
    cooldown = timedelta(minutes=settings["notification_cooldown_minutes"])
    if not force and not changed and last_at and current - last_at < cooldown and not daily_due:
        return None
    root["last_digest_claimed_at"] = utc_iso(current)
    root["last_digest_claimed_fingerprint"] = fingerprint
    root["digest_status"] = "sending"
    return {
        "pending": len(pending_ids),
        "pending_ids": pending_ids[:12],
        "health": health,
        "last_watchdog_at": dashboard.get("last_watchdog_at"),
        "fingerprint": fingerprint,
    }


def mark_governance_digest(db: dict[str, Any], *, success: bool, error: str = "") -> None:
    root = ensure_operations_governance(db)
    root["digest_status"] = "sent" if success else "retry"
    root["digest_error"] = "" if success else str(error)[:500]
    if success:
        root["last_digest_at"] = utc_iso()
        root["last_digest_sent_fingerprint"] = root.get("last_digest_claimed_fingerprint")
