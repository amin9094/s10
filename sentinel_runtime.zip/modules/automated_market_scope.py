"""One approved USD-pair universe for discovery and new signal publication."""

import re

# BIS April 2025 final detailed tables, 3.9-3.12: all OTC instruments,
# net-net average daily turnover. Stable selection, not an intraday ranking.
FOREX_USD_PAIRS = ("EURUSD", "USDJPY", "USDCNY", "GBPUSD", "USDCAD", "AUDUSD", "USDCHF", "USDHKD", "USDSGD", "USDINR")
FOREX_RANK_SOURCE = "https://www.bis.org/publications/commentary-otc-derivatives/statistics-rpfx25-fx-annex.pdf"
_FIAT = frozenset(
    "USD EUR GBP JPY CHF CAD AUD NZD CNY CNH HKD SGD INR KRW MXN NOK SEK DKK ZAR TRY PLN CZK HUF BRL RUB AED SAR THB ILS IDR MYR PHP TWD VND RON BGN ISK".split()
)
CORE_MARKET_SYMBOLS = ("XAUUSD", "US30", "US100", "NAS100", *FOREX_USD_PAIRS)


def normalize_symbol(value):
    return str(value or "").strip().upper().replace("/", "")


def is_forex_pair(value):
    s = normalize_symbol(value).rsplit(":", 1)[-1][:6]
    return len(s) == 6 and s[:3] in _FIAT and s[3:] in _FIAT


def require_forex_selection(value):
    s = normalize_symbol(value).rsplit(":", 1)[-1][:6]
    if is_forex_pair(s) and s not in FOREX_USD_PAIRS:
        raise ValueError("FOREX_USD_TOP10_REQUIRED")


def global_symbol_allowed(value):
    s = normalize_symbol(value)
    return s in CORE_MARKET_SYMBOLS or bool(re.fullmatch("[A-Z0-9]{2,24}USDT", s))


def require_global_symbol(value):
    require_forex_selection(value)
    if not global_symbol_allowed(value):
        raise ValueError("SEPARATE_MARKET_DESK_REQUIRED")


def global_symbol_sql(expression):
    """Expression is a fixed repository column, never an HTTP argument."""
    marks = ",".join("?" for _ in CORE_MARKET_SYMBOLS)
    return f"({expression} IN ({marks}) OR {expression} LIKE '%USDT')", CORE_MARKET_SYMBOLS
