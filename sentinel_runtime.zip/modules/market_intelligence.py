from __future__ import annotations

import asyncio
import html
import logging
import math
import os
import re
import time
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from typing import Any

from config import SETTINGS
from core.async_primitives import LoopLocalLock
from core.db import next_id
from core.http_client import get_json
from core.utils import parse_dt, utc_iso
from modules.api_credentials import alpha_vantage_key, eia_key, fred_key, sec_user_agent, twelve_data_key
from modules.economic_calendar import fetch_economic_calendar, filter_events, local_datetime
from modules.prices import fetch_price

logger = logging.getLogger(__name__)

_ALPHA_URL = "https://www.alphavantage.co/query"
_TWELVE_URL = "https://api.twelvedata.com/quote"
_FRED_URL = "https://api.stlouisfed.org/fred/series/observations"
_WORLD_BANK_URL = "https://api.worldbank.org/v2"
_EIA_URL = "https://api.eia.gov/v2/petroleum/pri/spt/data/"
_SEC_URL = "https://data.sec.gov/submissions"

_CACHE_SECONDS = 600
_FETCH_LOCK = LoopLocalLock()
_CACHE: tuple[float, dict[str, Any]] | None = None

FRED_SERIES: dict[str, tuple[str, str]] = {
    "DGS10": ("بازده اوراق ۱۰ساله آمریکا", "%"),
    "DFF": ("نرخ مؤثر فدرال‌فاندز", "%"),
    "T10YIE": ("تورم انتظاری ۱۰ساله", "%"),
    "DTWEXBGS": ("شاخص وزنی دلار", "index"),
    "DEXUSEU": ("دلار به ازای هر یورو", "USD/EUR"),
    "CPIAUCSL": ("شاخص قیمت مصرف‌کننده آمریکا", "index"),
}

WORLD_BANK_INDICATORS: tuple[tuple[str, str, str], ...] = (
    ("USA", "NY.GDP.MKTP.KD.ZG", "رشد GDP آمریکا"),
    ("USA", "FP.CPI.TOTL.ZG", "تورم آمریکا"),
    ("EMU", "NY.GDP.MKTP.KD.ZG", "رشد GDP منطقه یورو"),
    ("EMU", "FP.CPI.TOTL.ZG", "تورم منطقه یورو"),
)

DEFAULT_SEC_COMPANIES: tuple[tuple[str, str], ...] = (
    ("AAPL", "0000320193"),
    ("MSFT", "0000789019"),
    ("NVDA", "0001045810"),
    ("JPM", "0000019617"),
    ("XOM", "0000034088"),
)


@dataclass(frozen=True, slots=True)
class ApiState:
    name: str
    configured: bool
    detail: str


def api_states() -> list[ApiState]:
    return [
        ApiState("Alpha Vantage", bool(alpha_vantage_key()), "اخبار تحلیلی و قیمت سهام"),
        ApiState("Twelve Data", bool(twelve_data_key()), "قیمت XAU/USD و EUR/USD"),
        ApiState("FRED", bool(fred_key()), "نرخ بهره، بازده و دلار"),
        ApiState("World Bank", True, "داده بنیادی بلندمدت؛ بدون کلید"),
        ApiState("EIA", bool(eia_key()), "نفت WTI و Brent"),
        ApiState("SEC EDGAR", bool(sec_user_agent()), "گزارش‌های رسمی شرکت‌ها"),
        ApiState("Economic Calendar", True, "تقویم هفتگی خبرهای مهم؛ بدون کلید"),
    ]


async def test_api_connections() -> list[dict[str, str]]:
    """Perform real, sanitized provider checks instead of only checking env presence."""
    checks: list[tuple[str, bool, Any]] = [
        ("Economic Calendar", True, lambda: fetch_economic_calendar(force=True)),
        ("Alpha Vantage", bool(alpha_vantage_key()), fetch_alpha_news),
        ("Twelve Data", bool(twelve_data_key()), lambda: _fetch_twelve_quote("EUR/USD")),
        ("FRED", bool(fred_key()), lambda: _fetch_fred_series("DGS10")),
        ("World Bank", True, lambda: _fetch_world_bank_indicator("USA", "NY.GDP.MKTP.KD.ZG", "GDP")),
        ("EIA", bool(eia_key()), fetch_eia_energy),
        (
            "SEC EDGAR",
            bool(sec_user_agent()),
            lambda: _fetch_sec_company(
                "AAPL",
                "0000320193",
                {"User-Agent": sec_user_agent(), "Accept-Encoding": "gzip, deflate"},
            ),
        ),
    ]

    async def run_one(name: str, configured: bool, factory: Any) -> dict[str, str]:
        if not configured:
            return {"name": name, "status": "missing", "detail": "تنظیم نشده"}
        try:
            value = await asyncio.wait_for(factory(), timeout=max(8, SETTINGS.request_timeout_seconds + 3))
            ok = bool(value)
            return {
                "name": name,
                "status": "ok" if ok else "empty",
                "detail": "اتصال موفق" if ok else "اتصال برقرار شد ولی داده‌ای برنگشت",
            }
        except TimeoutError:
            return {"name": name, "status": "error", "detail": "زمان پاسخ سرویس تمام شد"}
        except Exception as exc:
            detail = _clean_text(str(exc), 180)
            detail = re.sub(r"(?i)(api[_-]?key|apikey|token)=[^&\s]+", r"\1=***", detail)
            return {"name": name, "status": "error", "detail": detail or exc.__class__.__name__}

    return list(await asyncio.gather(*(run_one(*item) for item in checks)))


def _safe_float(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if math.isfinite(result) else None


def _clean_text(value: Any, limit: int = 800) -> str:
    text = re.sub(r"\s+", " ", str(value or "")).strip()
    return text[:limit]


def _h(value: Any, limit: int = 800) -> str:
    return html.escape(_clean_text(value, limit), quote=True)


async def _get_json(
    url: str,
    *,
    params: Any = None,
    headers: dict[str, str] | None = None,
    timeout_seconds: int | None = None,
) -> Any:
    request_headers = {
        "Accept": "application/json",
        "User-Agent": "SENTINELBot/5.2",
    }
    if headers:
        request_headers.update(headers)
    return await get_json(
        url,
        params=params,
        headers=request_headers,
        timeout_seconds=timeout_seconds or SETTINGS.request_timeout_seconds,
        retries=2,
    )


async def fetch_alpha_news() -> list[dict[str, Any]]:
    key = alpha_vantage_key()
    if not key:
        return []
    payload = await _get_json(
        _ALPHA_URL,
        params={
            "function": "NEWS_SENTIMENT",
            "sort": "LATEST",
            "limit": 25,
            "apikey": key,
        },
    )
    if not isinstance(payload, dict):
        return []
    if payload.get("Information") or payload.get("Note") or payload.get("Error Message"):
        raise RuntimeError(_clean_text(payload.get("Information") or payload.get("Note") or payload.get("Error Message"), 250))
    rows: list[dict[str, Any]] = []
    for item in payload.get("feed", []):
        if not isinstance(item, dict):
            continue
        title = _clean_text(item.get("title"), 240)
        if not title:
            continue
        ticker_scores: dict[str, float] = {}
        for ticker in item.get("ticker_sentiment", []):
            if not isinstance(ticker, dict):
                continue
            symbol = _clean_text(ticker.get("ticker"), 30).upper()
            score = _safe_float(ticker.get("ticker_sentiment_score"))
            if symbol and score is not None:
                ticker_scores[symbol] = score
        rows.append(
            {
                "title": title,
                "summary": _clean_text(item.get("summary"), 650),
                "url": _clean_text(item.get("url"), 500),
                "source": _clean_text(item.get("source"), 80),
                "published_at": _clean_text(item.get("time_published"), 30),
                "sentiment": _safe_float(item.get("overall_sentiment_score")) or 0.0,
                "sentiment_label": _clean_text(item.get("overall_sentiment_label"), 60),
                "ticker_scores": ticker_scores,
            }
        )
    relevance_terms = (
        "federal reserve",
        "fed ",
        "interest rate",
        "inflation",
        "jobs",
        "payroll",
        "cpi",
        "pce",
        "ecb",
        "euro",
        "dollar",
        "treasury",
        "yield",
        "gold",
        "oil",
        "energy",
        "recession",
        "tariff",
        "geopolitical",
        "central bank",
        "monetary policy",
    )
    rows.sort(
        key=lambda row: sum(1 for term in relevance_terms if term in f"{row.get('title', '')} {row.get('summary', '')}".casefold()),
        reverse=True,
    )
    return rows[:25]


async def _fetch_twelve_quote(symbol: str) -> dict[str, Any]:
    key = twelve_data_key()
    if not key:
        return {}
    payload = await _get_json(_TWELVE_URL, params={"symbol": symbol, "apikey": key})
    if not isinstance(payload, dict):
        return {}
    if payload.get("status") == "error" or payload.get("code"):
        raise RuntimeError(_clean_text(payload.get("message") or "Twelve Data error", 250))
    return {
        "symbol": symbol,
        "name": _clean_text(payload.get("name") or symbol, 80),
        "price": _safe_float(payload.get("close") or payload.get("price")),
        "open": _safe_float(payload.get("open")),
        "high": _safe_float(payload.get("high")),
        "low": _safe_float(payload.get("low")),
        "previous_close": _safe_float(payload.get("previous_close")),
        "percent_change": _safe_float(payload.get("percent_change")),
        "datetime": _clean_text(payload.get("datetime"), 40),
        "source": "Twelve Data",
    }


async def fetch_twelve_context() -> dict[str, dict[str, Any]]:
    output: dict[str, dict[str, Any]] = {}
    if twelve_data_key():
        results = await asyncio.gather(
            _fetch_twelve_quote("XAU/USD"),
            _fetch_twelve_quote("EUR/USD"),
            return_exceptions=True,
        )
        for symbol, result in zip(("XAU/USD", "EUR/USD"), results, strict=True):
            if isinstance(result, dict) and result:
                output[symbol] = result
    # No-key fallbacks keep the user-facing market page useful when a free
    # Twelve Data key is missing, exhausted, or lacks commodity permissions.
    fallback_symbols = {"XAU/USD": "XAUUSD", "EUR/USD": "EURUSD"}
    for display_symbol, raw_symbol in fallback_symbols.items():
        if output.get(display_symbol, {}).get("price") is not None:
            continue
        try:
            price = await fetch_price(raw_symbol)
        except Exception as exc:
            logger.debug("No-key quote fallback failed for %s: %s", display_symbol, exc.__class__.__name__)
            continue
        output[display_symbol] = {
            "symbol": display_symbol,
            "name": display_symbol,
            "price": price,
            "open": None,
            "high": None,
            "low": None,
            "previous_close": None,
            "percent_change": None,
            "datetime": utc_iso(),
            "source": "Gold API / Frankfurter fallback",
        }
    return output


async def _fetch_fred_series(series_id: str) -> dict[str, Any]:
    key = fred_key()
    if not key:
        return {}
    payload = await _get_json(
        _FRED_URL,
        params={
            "series_id": series_id,
            "api_key": key,
            "file_type": "json",
            "sort_order": "desc",
            "limit": 12,
        },
    )
    if isinstance(payload, dict) and (payload.get("error_code") or payload.get("error_message")):
        raise RuntimeError(_clean_text(payload.get("error_message") or payload.get("error_code"), 220))
    observations = payload.get("observations", []) if isinstance(payload, dict) else []
    valid: list[tuple[str, float]] = []
    for item in observations:
        if not isinstance(item, dict):
            continue
        value = _safe_float(item.get("value"))
        if value is not None:
            valid.append((_clean_text(item.get("date"), 20), value))
        if len(valid) >= 2:
            break
    if not valid:
        return {}
    current_date, current = valid[0]
    previous = valid[1][1] if len(valid) > 1 else None
    label, unit = FRED_SERIES[series_id]
    return {
        "series_id": series_id,
        "label": label,
        "unit": unit,
        "date": current_date,
        "value": current,
        "previous": previous,
        "change": current - previous if previous is not None else None,
        "source": "FRED",
    }


async def fetch_fred_context() -> dict[str, dict[str, Any]]:
    if not fred_key():
        return {}
    results = await asyncio.gather(*(_fetch_fred_series(series_id) for series_id in FRED_SERIES), return_exceptions=True)
    return {series_id: result for series_id, result in zip(FRED_SERIES, results, strict=True) if isinstance(result, dict) and result}


async def _fetch_world_bank_indicator(country: str, indicator: str, label: str) -> dict[str, Any]:
    current_year = datetime.now(UTC).year
    payload = await _get_json(
        f"{_WORLD_BANK_URL}/country/{country}/indicator/{indicator}",
        params={"format": "json", "per_page": 20, "date": f"{current_year - 8}:{current_year}"},
    )
    rows = payload[1] if isinstance(payload, list) and len(payload) > 1 and isinstance(payload[1], list) else []
    for item in rows:
        if not isinstance(item, dict):
            continue
        value = _safe_float(item.get("value"))
        if value is None:
            continue
        return {
            "country": country,
            "indicator": indicator,
            "label": label,
            "year": _clean_text(item.get("date"), 10),
            "value": value,
            "source": "World Bank",
        }
    return {}


async def fetch_world_bank_context() -> list[dict[str, Any]]:
    results = await asyncio.gather(
        *(_fetch_world_bank_indicator(country, indicator, label) for country, indicator, label in WORLD_BANK_INDICATORS),
        return_exceptions=True,
    )
    return [result for result in results if isinstance(result, dict) and result]


async def fetch_eia_energy() -> list[dict[str, Any]]:
    key = eia_key()
    if not key:
        return []
    params: list[tuple[str, str]] = [
        ("api_key", key),
        ("frequency", "daily"),
        ("data[]", "value"),
        ("facets[series][]", "RWTC"),
        ("facets[series][]", "RBRTE"),
        ("sort[0][column]", "period"),
        ("sort[0][direction]", "desc"),
        ("length", "10"),
    ]
    payload = await _get_json(_EIA_URL, params=params)
    if isinstance(payload, dict) and payload.get("error"):
        raise RuntimeError(_clean_text(payload.get("error"), 220))
    rows = payload.get("response", {}).get("data", []) if isinstance(payload, dict) else []
    grouped: dict[str, list[dict[str, Any]]] = {"RWTC": [], "RBRTE": []}
    for item in rows:
        if not isinstance(item, dict):
            continue
        series = _clean_text(item.get("series"), 20)
        value = _safe_float(item.get("value"))
        if series in grouped and value is not None:
            grouped[series].append({"period": _clean_text(item.get("period"), 20), "value": value})
    labels = {"RWTC": "نفت WTI", "RBRTE": "نفت Brent"}
    output: list[dict[str, Any]] = []
    for series, values in grouped.items():
        if not values:
            continue
        current = values[0]
        previous = values[1] if len(values) > 1 else None
        change_pct = None
        if previous and previous["value"]:
            change_pct = ((current["value"] / previous["value"]) - 1) * 100
        output.append(
            {
                "series": series,
                "label": labels[series],
                "date": current["period"],
                "price": current["value"],
                "previous": previous["value"] if previous else None,
                "change_pct": change_pct,
                "unit": "USD/barrel",
                "source": "EIA",
            }
        )
    return output


def _sec_companies() -> list[tuple[str, str]]:
    raw = os.getenv("SEC_TRACKED_COMPANIES", "").strip()
    if not raw:
        return list(DEFAULT_SEC_COMPANIES)
    output: list[tuple[str, str]] = []
    for part in raw.split(","):
        if ":" not in part:
            continue
        symbol, cik = part.split(":", 1)
        symbol = re.sub(r"[^A-Za-z0-9.-]", "", symbol).upper()[:15]
        cik_digits = re.sub(r"\D", "", cik).zfill(10)
        if symbol and len(cik_digits) == 10:
            output.append((symbol, cik_digits))
    return output[:10] or list(DEFAULT_SEC_COMPANIES)


async def _fetch_sec_company(symbol: str, cik: str, headers: dict[str, str]) -> list[dict[str, Any]]:
    payload = await _get_json(f"{_SEC_URL}/CIK{cik}.json", headers=headers)
    recent = payload.get("filings", {}).get("recent", {}) if isinstance(payload, dict) else {}
    forms = recent.get("form", []) if isinstance(recent, dict) else []
    filing_dates = recent.get("filingDate", []) if isinstance(recent, dict) else []
    accessions = recent.get("accessionNumber", []) if isinstance(recent, dict) else []
    documents = recent.get("primaryDocument", []) if isinstance(recent, dict) else []
    descriptions = recent.get("primaryDocDescription", []) if isinstance(recent, dict) else []
    company_name = _clean_text(payload.get("name") if isinstance(payload, dict) else symbol, 120)
    allowed_forms = {"8-K", "10-Q", "10-K", "6-K", "20-F"}
    rows: list[dict[str, Any]] = []
    for index, form in enumerate(forms):
        if form not in allowed_forms or index >= len(filing_dates) or index >= len(accessions) or index >= len(documents):
            continue
        accession = _clean_text(accessions[index], 30)
        document = _clean_text(documents[index], 160)
        cik_plain = str(int(cik))
        url = f"https://www.sec.gov/Archives/edgar/data/{cik_plain}/{accession.replace('-', '')}/{document}"
        rows.append(
            {
                "symbol": symbol,
                "company": company_name,
                "form": form,
                "date": _clean_text(filing_dates[index], 20),
                "description": _clean_text(descriptions[index] if index < len(descriptions) else "", 180),
                "url": url,
                "source": "SEC EDGAR",
            }
        )
        if len(rows) >= 2:
            break
    return rows


async def fetch_sec_filings() -> list[dict[str, Any]]:
    user_agent = sec_user_agent()
    if not user_agent:
        return []
    headers = {"User-Agent": user_agent, "Accept-Encoding": "gzip, deflate"}
    rows: list[dict[str, Any]] = []
    for symbol, cik in _sec_companies():
        try:
            rows.extend(await _fetch_sec_company(symbol, cik, headers))
        except Exception as exc:
            logger.warning("SEC EDGAR fetch failed for %s: %s", symbol, exc.__class__.__name__)
            continue
        await asyncio.sleep(0.12)
    rows.sort(key=lambda item: str(item.get("date") or ""), reverse=True)
    return rows[:8]


_GOLD_BULLISH = (
    "rate cut",
    "dovish",
    "recession",
    "geopolitical",
    "war",
    "conflict",
    "bank crisis",
    "risk-off",
    "safe haven",
    "weak jobs",
    "tariff",
)
_GOLD_BEARISH = (
    "rate hike",
    "hawkish",
    "strong dollar",
    "yields rise",
    "strong jobs",
    "inflation cools",
    "risk-on",
    "ceasefire",
)
_EUR_BULLISH = (
    "ecb hike",
    "ecb hawkish",
    "eurozone growth",
    "euro area growth",
    "weak dollar",
    "fed cut",
    "fed dovish",
    "weak jobs",
)
_EUR_BEARISH = (
    "ecb cut",
    "ecb dovish",
    "eurozone recession",
    "euro weakness",
    "strong dollar",
    "fed hike",
    "fed hawkish",
    "strong jobs",
    "yields rise",
)


def _keyword_score(news: list[dict[str, Any]], bullish: tuple[str, ...], bearish: tuple[str, ...]) -> tuple[float, list[str]]:
    score = 0.0
    reasons: list[str] = []
    for item in news[:15]:
        text = f"{item.get('title', '')} {item.get('summary', '')}".casefold()
        bull_hits = [keyword for keyword in bullish if keyword in text]
        bear_hits = [keyword for keyword in bearish if keyword in text]
        if bull_hits:
            score += min(0.45 * len(bull_hits), 1.0)
            if len(reasons) < 2:
                reasons.append(f"خبر حمایتی: {item.get('title', '')}")
        if bear_hits:
            score -= min(0.45 * len(bear_hits), 1.0)
            if len(reasons) < 2:
                reasons.append(f"خبر فشاری: {item.get('title', '')}")
    return max(-2.0, min(2.0, score)), reasons


def _change(context: dict[str, dict[str, Any]], key: str) -> float | None:
    row = context.get(key, {})
    return _safe_float(row.get("change")) if isinstance(row, dict) else None


def _value(context: dict[str, dict[str, Any]], key: str) -> float | None:
    row = context.get(key, {})
    return _safe_float(row.get("value")) if isinstance(row, dict) else None


def _probabilities(score: float, source_count: int) -> dict[str, Any]:
    score = max(-6.0, min(6.0, score))
    neutral = max(12.0, 42.0 - abs(score) * 4.6)
    directional = 100.0 - neutral
    bullish_share = 1.0 / (1.0 + math.exp(-score / 1.35))
    bullish = directional * bullish_share
    bearish = directional - bullish
    confidence = min(78, round(28 + source_count * 6 + abs(score) * 5))
    if source_count <= 1:
        confidence = min(confidence, 38)
    direction = "صعودی" if score > 0.8 else "نزولی" if score < -0.8 else "خنثی/دوطرفه"
    return {
        "score": round(score, 2),
        "direction": direction,
        "bullish_probability": round(bullish),
        "neutral_probability": round(neutral),
        "bearish_probability": round(bearish),
        "confidence": confidence,
    }


def build_outlooks(snapshot: dict[str, Any]) -> dict[str, dict[str, Any]]:
    news = snapshot.get("news", []) if isinstance(snapshot.get("news"), list) else []
    twelve = snapshot.get("quotes", {}) if isinstance(snapshot.get("quotes"), dict) else {}
    fred = snapshot.get("fred", {}) if isinstance(snapshot.get("fred"), dict) else {}
    world = snapshot.get("world_bank", []) if isinstance(snapshot.get("world_bank"), list) else []
    energy = snapshot.get("energy", []) if isinstance(snapshot.get("energy"), list) else []

    gold_score = 0.0
    gold_reasons: list[str] = []
    gold_sources = 0
    xau_change = _safe_float(twelve.get("XAU/USD", {}).get("percent_change")) if isinstance(twelve.get("XAU/USD"), dict) else None
    if xau_change is not None:
        gold_score += max(-1.5, min(1.5, xau_change / 0.8))
        gold_reasons.append(f"مومنتوم XAU/USD: {xau_change:+.2f}٪")
        gold_sources += 1
    dgs10 = _change(fred, "DGS10")
    if dgs10 is not None:
        gold_score += -1.3 if dgs10 > 0.03 else 1.3 if dgs10 < -0.03 else 0.0
        gold_reasons.append(f"تغییر بازده ۱۰ساله آمریکا: {dgs10:+.3f}")
        gold_sources += 1
    dollar = _change(fred, "DTWEXBGS")
    if dollar is not None:
        gold_score += max(-1.3, min(1.3, -dollar / 0.25))
        gold_reasons.append(f"تغییر شاخص وزنی دلار: {dollar:+.3f}")
        gold_sources += 1
    breakeven = _change(fred, "T10YIE")
    if breakeven is not None:
        gold_score += 0.7 if breakeven > 0.02 else -0.7 if breakeven < -0.02 else 0.0
        gold_reasons.append(f"تغییر تورم انتظاری: {breakeven:+.3f}")
    news_score, news_reasons = _keyword_score(news, _GOLD_BULLISH, _GOLD_BEARISH)
    if news:
        gold_score += news_score
        gold_reasons.extend(news_reasons)
        gold_sources += 1
    wti = next((row for row in energy if row.get("series") == "RWTC"), None)
    if isinstance(wti, dict):
        oil_change = _safe_float(wti.get("change_pct"))
        if oil_change is not None:
            gold_score += 0.35 if oil_change > 1 else -0.25 if oil_change < -1 else 0.0
            gold_reasons.append(f"تغییر نفت WTI: {oil_change:+.2f}٪")
            gold_sources += 1

    eur_score = 0.0
    eur_reasons: list[str] = []
    eur_sources = 0
    eur_change = _safe_float(twelve.get("EUR/USD", {}).get("percent_change")) if isinstance(twelve.get("EUR/USD"), dict) else None
    if eur_change is not None:
        eur_score += max(-1.5, min(1.5, eur_change / 0.35))
        eur_reasons.append(f"مومنتوم EUR/USD: {eur_change:+.2f}٪")
        eur_sources += 1
    dex = _change(fred, "DEXUSEU")
    if dex is not None:
        eur_score += max(-1.2, min(1.2, dex / 0.002))
        eur_reasons.append(f"تغییر نرخ مرجع EUR/USD: {dex:+.4f}")
        eur_sources += 1
    if dollar is not None:
        eur_score += max(-1.5, min(1.5, -dollar / 0.22))
        eur_reasons.append(f"قدرت دلار: {dollar:+.3f}")
        eur_sources += 1
    if dgs10 is not None:
        eur_score += -0.9 if dgs10 > 0.03 else 0.9 if dgs10 < -0.03 else 0.0
        eur_reasons.append(f"بازده آمریکا: {dgs10:+.3f}")
    eur_news_score, eur_news_reasons = _keyword_score(news, _EUR_BULLISH, _EUR_BEARISH)
    if news:
        eur_score += eur_news_score
        eur_reasons.extend(eur_news_reasons)
        eur_sources += 1

    wb_values = {str(row.get("label")): _safe_float(row.get("value")) for row in world if isinstance(row, dict)}
    us_growth = wb_values.get("رشد GDP آمریکا")
    eu_growth = wb_values.get("رشد GDP منطقه یورو")
    if us_growth is not None and eu_growth is not None:
        differential = eu_growth - us_growth
        eur_score += max(-0.35, min(0.35, differential / 3))
        eur_reasons.append(f"اختلاف رشد سالانه یورو و آمریکا: {differential:+.2f} واحد")
        eur_sources += 1

    gold = _probabilities(gold_score, gold_sources)
    eur = _probabilities(eur_score, eur_sources)
    gold["reasons"] = gold_reasons[:6]
    eur["reasons"] = eur_reasons[:6]
    gold["asset"] = "XAU/USD"
    eur["asset"] = "EUR/USD"
    return {"gold": gold, "eurusd": eur}


async def build_market_snapshot(*, force: bool = False) -> dict[str, Any]:
    global _CACHE
    now = time.monotonic()
    if not force and _CACHE and now - _CACHE[0] < _CACHE_SECONDS:
        return dict(_CACHE[1])
    async with _FETCH_LOCK():
        now = time.monotonic()
        if not force and _CACHE and now - _CACHE[0] < _CACHE_SECONDS:
            return dict(_CACHE[1])
        tasks = {
            "calendar": fetch_economic_calendar(),
            "news": fetch_alpha_news(),
            "quotes": fetch_twelve_context(),
            "fred": fetch_fred_context(),
            "world_bank": fetch_world_bank_context(),
            "energy": fetch_eia_energy(),
            "filings": fetch_sec_filings(),
        }
        keys = list(tasks)
        results = await asyncio.gather(*tasks.values(), return_exceptions=True)
        snapshot: dict[str, Any] = {
            "generated_at": utc_iso(),
            "errors": {},
            "sources": {},
        }
        for key, result in zip(keys, results, strict=True):
            if isinstance(result, Exception):
                snapshot[key] = {} if key in {"quotes", "fred"} else []
                snapshot["errors"][key] = f"{result.__class__.__name__}: provider unavailable"
            else:
                snapshot[key] = result
                snapshot["sources"][key] = bool(result)
        snapshot["outlooks"] = build_outlooks(snapshot)
        _CACHE = (time.monotonic(), snapshot)
        return dict(snapshot)


def ensure_market_intelligence(db: dict[str, Any]) -> dict[str, Any]:
    root = db.setdefault("market_intelligence", {})
    if not isinstance(root, dict):
        root = {}
        db["market_intelligence"] = root
    settings = root.setdefault("settings", {})
    if not isinstance(settings, dict):
        settings = {}
        root["settings"] = settings
    settings.setdefault("enabled", True)
    settings.setdefault("morning_time", "07:30")
    settings.setdefault("destination", "public")
    settings.setdefault("auto_generate", True)
    settings.setdefault("notify_admins", True)
    root.setdefault("briefings", [])
    root.setdefault("latest_snapshot", {})
    root.setdefault("calendar_publications", [])
    root.setdefault("last_generated_date", None)
    root.setdefault("scenario_predictions", [])
    root.setdefault("scenario_performance", {})
    return root


def save_snapshot(db: dict[str, Any], snapshot: dict[str, Any]) -> None:
    root = ensure_market_intelligence(db)
    calibrate_snapshot(db, snapshot)
    evaluate_scenario_predictions(db, snapshot)
    record_scenario_predictions(db, snapshot)
    root["latest_snapshot"] = snapshot


def latest_snapshot(db: dict[str, Any]) -> dict[str, Any]:
    root = ensure_market_intelligence(db)
    value = root.get("latest_snapshot", {})
    return dict(value) if isinstance(value, dict) else {}


def create_briefing(db: dict[str, Any], snapshot: dict[str, Any], text: str, *, created_by: str) -> dict[str, Any]:
    root = ensure_market_intelligence(db)
    calibrate_snapshot(db, snapshot)
    evaluate_scenario_predictions(db, snapshot)
    record_scenario_predictions(db, snapshot)
    briefings = root.setdefault("briefings", [])
    if not isinstance(briefings, list):
        briefings = []
        root["briefings"] = briefings
    row = {
        "id": next_id(db, "market_briefing"),
        "status": "pending",
        "text": str(text)[:18000],
        "snapshot": snapshot,
        "created_by": str(created_by),
        "created_at": utc_iso(),
        "reviewed_by": None,
        "reviewed_at": None,
        "published_at": None,
        "channel_message_ids": [],
        "error": "",
    }
    briefings.append(row)
    root["briefings"] = briefings[-120:]
    root["latest_snapshot"] = snapshot
    root["last_generated_date"] = datetime.now(UTC).date().isoformat()
    return dict(row)


def get_briefing(db: dict[str, Any], briefing_id: int) -> dict[str, Any] | None:
    root = ensure_market_intelligence(db)
    for row in root.get("briefings", []):
        if isinstance(row, dict) and int(row.get("id", 0) or 0) == int(briefing_id):
            return row
    return None


def latest_briefing(db: dict[str, Any], *, statuses: set[str] | None = None) -> dict[str, Any] | None:
    root = ensure_market_intelligence(db)
    rows = [row for row in root.get("briefings", []) if isinstance(row, dict)]
    if statuses is not None:
        rows = [row for row in rows if str(row.get("status")) in statuses]
    return dict(rows[-1]) if rows else None


def set_briefing_status(
    db: dict[str, Any],
    briefing_id: int,
    status: str,
    *,
    reviewer: int | str,
    message_ids: list[int] | None = None,
    error: str = "",
) -> dict[str, Any]:
    row = get_briefing(db, briefing_id)
    if row is None:
        raise ValueError("گزارش موردنظر پیدا نشد")
    if status not in {"pending", "approved", "published", "rejected", "failed"}:
        raise ValueError("وضعیت گزارش معتبر نیست")
    row["status"] = status
    row["reviewed_by"] = str(reviewer)
    row["reviewed_at"] = utc_iso()
    row["error"] = str(error)[:500]
    if message_ids is not None:
        row["channel_message_ids"] = [int(value) for value in message_ids]
    if status == "published":
        row["published_at"] = utc_iso()
    return dict(row)


def update_settings(db: dict[str, Any], **changes: Any) -> dict[str, Any]:
    root = ensure_market_intelligence(db)
    settings = root["settings"]
    for key, value in changes.items():
        if key in {"enabled", "auto_generate", "notify_admins"}:
            settings[key] = bool(value)
        elif key == "destination" and value in {"public", "private", "both"}:
            settings[key] = value
        elif key == "morning_time" and re.fullmatch(r"(?:[01]\d|2[0-3]):[0-5]\d", str(value)):
            settings[key] = str(value)
    return dict(settings)


def morning_generation_due(db: dict[str, Any], local_now: datetime) -> bool:
    root = ensure_market_intelligence(db)
    settings = root["settings"]
    if not settings.get("enabled", True) or not settings.get("auto_generate", True):
        return False
    target = str(settings.get("morning_time") or "07:30")
    try:
        hour, minute = (int(part) for part in target.split(":", 1))
    except (TypeError, ValueError):
        hour, minute = 7, 30
    if (local_now.hour, local_now.minute) < (hour, minute):
        return False
    return str(root.get("last_generated_date") or "") != local_now.date().isoformat()


def snapshot_age_minutes(snapshot: dict[str, Any]) -> int | None:
    generated = parse_dt(snapshot.get("generated_at"))
    if generated is None:
        return None
    return max(0, int((datetime.now(UTC) - generated).total_seconds() // 60))


def _fmt_number(value: Any, digits: int = 2) -> str:
    number = _safe_float(value)
    if number is None:
        return "—"
    return f"{number:,.{digits}f}"


def _direction_icon(direction: str) -> str:
    return "🟢" if direction == "صعودی" else "🔴" if direction == "نزولی" else "🟡"


def render_outlook(snapshot: dict[str, Any], key: str) -> str:
    outlooks = snapshot.get("outlooks", {}) if isinstance(snapshot.get("outlooks"), dict) else {}
    row = outlooks.get(key, {}) if isinstance(outlooks.get(key), dict) else {}
    if not row:
        return "⚠️ داده کافی برای تحلیل این بازار در دسترس نیست."
    icon = _direction_icon(str(row.get("direction")))
    reasons = row.get("reasons", []) if isinstance(row.get("reasons"), list) else []
    lines = [
        f"{icon} <b>تحلیل اثر خبر بر {row.get('asset', 'بازار')}</b>",
        "",
        f"سناریوی غالب: <b>{row.get('direction', '—')}</b>",
        f"📈 احتمال صعود: <b>{int(row.get('bullish_probability', 0))}٪</b>",
        f"➖ احتمال خنثی: <b>{int(row.get('neutral_probability', 0))}٪</b>",
        f"📉 احتمال نزول: <b>{int(row.get('bearish_probability', 0))}٪</b>",
        f"🎯 درجه اطمینان داده: <b>{int(row.get('confidence', 0))}٪</b>",
    ]
    if reasons:
        lines.extend(["", "<b>مهم‌ترین عوامل:</b>"])
        lines.extend(f"• {_h(reason, 240)}" for reason in reasons[:6])
    age = snapshot_age_minutes(snapshot)
    if age is not None:
        lines.extend(["", f"🕒 سن داده: حدود {age} دقیقه"])
    lines.extend(
        [
            "",
            "⚠️ <i>این درصدها خروجی مدل سناریویی و داده‌های موجود هستند، نه تضمین سود یا توصیه خرید و فروش.</i>",
        ]
    )
    return "\n".join(lines)


def render_news(snapshot: dict[str, Any], *, limit: int = 8) -> str:
    news = snapshot.get("news", []) if isinstance(snapshot.get("news"), list) else []
    lines = ["📰 <b>اخبار مهم اقتصاد و بازارهای جهان</b>", ""]
    if not news:
        lines.append("⚠️ خبری دریافت نشد؛ کلید Alpha Vantage یا سهمیه API را بررسی کنید.")
    for index, item in enumerate(news[:limit], start=1):
        title = _clean_text(item.get("title"), 220)
        source = _clean_text(item.get("source"), 60) or "منبع خبری"
        sentiment = _safe_float(item.get("sentiment")) or 0.0
        mood = "مثبت" if sentiment > 0.15 else "منفی" if sentiment < -0.15 else "خنثی"
        url = _clean_text(item.get("url"), 500)
        title_html = _h(title, 220)
        if url.startswith(("https://", "http://")):
            title_html = f'<a href="{html.escape(url, quote=True)}">{title_html}</a>'
        lines.append(f"{index}. <b>{title_html}</b>")
        lines.append(f"   منبع: {_h(source, 60)} | احساس خبر: {mood}")
    lines.extend(["", "منبع خبر: Alpha Vantage NEWS_SENTIMENT"])
    return "\n".join(lines)


def render_news_headlines(snapshot: dict[str, Any], *, limit: int = 12) -> str:
    """Render a public-safe headline list without summaries, links or sentiment."""
    news = snapshot.get("news", []) if isinstance(snapshot.get("news"), list) else []
    lines = ["📰 <b>سرتیتر خبرهای مهم بازار</b>", ""]
    if not news:
        lines.append("⚠️ در حال حاضر سرتیتر تازه‌ای دریافت نشده است.")
    for index, item in enumerate(news[: max(1, limit)], start=1):
        lines.append(f"{index}. <b>{_h(item.get('title'), 230)}</b>")
    lines.extend(
        [
            "",
            "🔒 جزئیات خبر و سناریوهای طلا و EUR/USD ابتدا توسط ادمین بررسی می‌شوند و فقط پس از تأیید در کانال منتشر خواهند شد.",
        ]
    )
    return "\n".join(lines)


def render_selected_news(snapshot: dict[str, Any], indexes: list[int]) -> str:
    news = snapshot.get("news", []) if isinstance(snapshot.get("news"), list) else []
    selected: list[dict[str, Any]] = []
    for index in indexes:
        if 0 <= int(index) < len(news) and isinstance(news[int(index)], dict):
            selected.append(news[int(index)])
    lines = ["📰 <b>خبرهای مهم منتخب بازار</b>", ""]
    if not selected:
        lines.append("خبری انتخاب نشده است.")
        return "\n".join(lines)
    for number, item in enumerate(selected, start=1):
        title = _clean_text(item.get("title"), 230)
        summary = _clean_text(item.get("summary"), 650)
        source = _clean_text(item.get("source"), 80) or "منبع خبری"
        sentiment = _safe_float(item.get("sentiment")) or 0.0
        mood = "مثبت" if sentiment > 0.15 else "منفی" if sentiment < -0.15 else "خنثی"
        url = _clean_text(item.get("url"), 500)
        title_html = _h(title, 230)
        if url.startswith(("https://", "http://")):
            title_html = f'<a href="{html.escape(url, quote=True)}">{title_html}</a>'
        lines.append(f"{number}. <b>{title_html}</b>")
        if summary:
            lines.append(f"{_h(summary, 650)}")
        lines.append(f"منبع: {_h(source, 80)} | ارزیابی احساس خبر: <b>{mood}</b>")
        lines.append("")
    lines.extend(
        [
            "⚠️ <i>این خبرها صرفاً اطلاع‌رسانی هستند و به‌تنهایی توصیه خرید یا فروش محسوب نمی‌شوند.</i>",
            "#SENTINEL #MarketNews",
        ]
    )
    return "\n".join(lines)


def render_economy(snapshot: dict[str, Any]) -> str:
    fred = snapshot.get("fred", {}) if isinstance(snapshot.get("fred"), dict) else {}
    world = snapshot.get("world_bank", []) if isinstance(snapshot.get("world_bank"), list) else []
    lines = ["🌍 <b>اقتصاد جهان و شاخص‌های کلیدی</b>", "", "<b>داده‌های نزدیک‌تر به بازار — FRED</b>"]
    if not fred:
        lines.append("⚠️ داده FRED در دسترس نیست؛ FRED_API_KEY را بررسی کنید.")
    for key in FRED_SERIES:
        row = fred.get(key)
        if not isinstance(row, dict):
            continue
        change = _safe_float(row.get("change"))
        change_text = f" ({change:+.3f})" if change is not None else ""
        digits = 4 if key == "DEXUSEU" else 2
        lines.append(
            f"• {_h(row.get('label'), 120)}: <b>{_fmt_number(row.get('value'), digits)}</b>{change_text} — {_h(row.get('date', '—'), 30)}"
        )
    lines.extend(["", "<b>زمینه بنیادی بلندمدت — World Bank</b>"])
    if not world:
        lines.append("⚠️ داده World Bank در دسترس نیست.")
    for row in world:
        if not isinstance(row, dict):
            continue
        lines.append(f"• {_h(row.get('label'), 120)}: <b>{_fmt_number(row.get('value'))}٪</b> — {_h(row.get('year', '—'), 10)}")
    lines.extend(["", "ℹ️ داده‌های World Bank سالانه‌اند و برای جهت کوتاه‌مدت بازار وزن کمی دارند."])
    return "\n".join(lines)


def render_energy(snapshot: dict[str, Any]) -> str:
    rows = snapshot.get("energy", []) if isinstance(snapshot.get("energy"), list) else []
    lines = ["🛢 <b>قیمت نفت و انرژی</b>", ""]
    if not rows:
        lines.append("⚠️ داده EIA دریافت نشد؛ EIA_API_KEY یا زمان انتشار داده را بررسی کنید.")
    for row in rows:
        if not isinstance(row, dict):
            continue
        change = _safe_float(row.get("change_pct"))
        arrow = "🟢" if change is not None and change > 0 else "🔴" if change is not None and change < 0 else "⚪️"
        change_text = f"{change:+.2f}٪" if change is not None else "—"
        lines.extend(
            [
                f"{arrow} <b>{_h(row.get('label'), 120)}</b>",
                f"قیمت: <code>${_fmt_number(row.get('price'))}</code>",
                f"تغییر نسبت به داده قبل: <b>{change_text}</b>",
                f"تاریخ داده: {_h(row.get('date', '—'), 30)}",
                "",
            ]
        )
    lines.append("منبع: U.S. Energy Information Administration (EIA)")
    return "\n".join(lines)


def render_filings(snapshot: dict[str, Any]) -> str:
    rows = snapshot.get("filings", []) if isinstance(snapshot.get("filings"), list) else []
    lines = ["🏢 <b>گزارش‌های مهم شرکت‌ها — SEC EDGAR</b>", ""]
    if not rows:
        lines.append("⚠️ گزارشی دریافت نشد؛ SEC_USER_AGENT را با نام و ایمیل معتبر تنظیم کنید.")
    for row in rows[:8]:
        if not isinstance(row, dict):
            continue
        url = _clean_text(row.get("url"), 500)
        form_html = _h(row.get("form"), 20)
        if url.startswith(("https://", "http://")):
            form_html = f'<a href="{html.escape(url, quote=True)}">{form_html}</a>'
        lines.append(
            f"• <b>{_h(row.get('symbol'), 20)}</b> — {form_html} — {_h(row.get('date'), 20)}\n"
            f"  {_h(row.get('description') or row.get('company'), 160)}"
        )
    lines.extend(["", "ℹ️ این گزارش‌ها زمینه ریسک بازار را تکمیل می‌کنند و به‌تنهایی جهت طلا یا EUR/USD را تعیین نمی‌کنند."])
    return "\n".join(lines)


def render_snapshot_summary(snapshot: dict[str, Any]) -> str:
    gold = snapshot.get("outlooks", {}).get("gold", {}) if isinstance(snapshot.get("outlooks"), dict) else {}
    eur = snapshot.get("outlooks", {}).get("eurusd", {}) if isinstance(snapshot.get("outlooks"), dict) else {}
    quotes = snapshot.get("quotes", {}) if isinstance(snapshot.get("quotes"), dict) else {}
    xau = quotes.get("XAU/USD", {}) if isinstance(quotes.get("XAU/USD"), dict) else {}
    eur_quote = quotes.get("EUR/USD", {}) if isinstance(quotes.get("EUR/USD"), dict) else {}
    lines = [
        "🧠 <b>تحلیل پیش‌بینی خبر و اقتصاد جهان</b>",
        "",
        f"🥇 طلا: {_direction_icon(str(gold.get('direction')))} <b>{gold.get('direction', 'داده ناکافی')}</b> — صعود {gold.get('bullish_probability', 0)}٪ / نزول {gold.get('bearish_probability', 0)}٪",
        f"💶 EUR/USD: {_direction_icon(str(eur.get('direction')))} <b>{eur.get('direction', 'داده ناکافی')}</b> — صعود {eur.get('bullish_probability', 0)}٪ / نزول {eur.get('bearish_probability', 0)}٪",
    ]
    if xau.get("price") is not None:
        lines.append(f"قیمت XAU/USD: <code>{_fmt_number(xau.get('price'))}</code> ({_fmt_number(xau.get('percent_change'))}٪)")
    if eur_quote.get("price") is not None:
        lines.append(
            f"قیمت EUR/USD: <code>{_fmt_number(eur_quote.get('price'), 5)}</code> ({_fmt_number(eur_quote.get('percent_change'))}٪)"
        )
    age = snapshot_age_minutes(snapshot)
    if age is not None:
        lines.extend(["", f"🕒 آخرین جمع‌آوری داده: حدود {age} دقیقه قبل"])
    errors = snapshot.get("errors", {}) if isinstance(snapshot.get("errors"), dict) else {}
    if errors:
        lines.append(f"⚠️ {len(errors)} منبع در این نوبت پاسخ کامل نداده است.")
    lines.extend(["", "<i>برای جزئیات، یکی از بخش‌های زیر را باز کنید.</i>"])
    return "\n".join(lines)


def render_morning_brief(snapshot: dict[str, Any]) -> str:
    gold = snapshot.get("outlooks", {}).get("gold", {}) if isinstance(snapshot.get("outlooks"), dict) else {}
    eur = snapshot.get("outlooks", {}).get("eurusd", {}) if isinstance(snapshot.get("outlooks"), dict) else {}
    news = snapshot.get("news", []) if isinstance(snapshot.get("news"), list) else []
    calendar = snapshot.get("calendar", []) if isinstance(snapshot.get("calendar"), list) else []
    energy = snapshot.get("energy", []) if isinstance(snapshot.get("energy"), list) else []
    fred = snapshot.get("fred", {}) if isinstance(snapshot.get("fred"), dict) else {}
    filings = snapshot.get("filings", []) if isinstance(snapshot.get("filings"), list) else []
    lines = [
        "🌅 <b>گزارش صبحگاهی بازارهای جهانی</b>",
        "",
        f"🥇 <b>طلا XAU/USD:</b> {_direction_icon(str(gold.get('direction')))} {gold.get('direction', 'داده ناکافی')}",
        f"صعود {gold.get('bullish_probability', 0)}٪ | خنثی {gold.get('neutral_probability', 0)}٪ | نزول {gold.get('bearish_probability', 0)}٪",
        f"اطمینان داده: {gold.get('confidence', 0)}٪",
        "",
        f"💶 <b>EUR/USD:</b> {_direction_icon(str(eur.get('direction')))} {eur.get('direction', 'داده ناکافی')}",
        f"صعود {eur.get('bullish_probability', 0)}٪ | خنثی {eur.get('neutral_probability', 0)}٪ | نزول {eur.get('bearish_probability', 0)}٪",
        f"اطمینان داده: {eur.get('confidence', 0)}٪",
    ]
    important = []
    for reason in list(gold.get("reasons", []))[:2] + list(eur.get("reasons", []))[:2]:
        reason_text = _clean_text(reason, 180)
        if reason_text and reason_text not in important:
            important.append(reason_text)
    if important:
        lines.extend(["", "<b>محرک‌های مهم امروز:</b>"])
        lines.extend(f"• {_h(reason, 180)}" for reason in important[:4])
    today_events = filter_events(calendar, period="today", min_impact="high") if calendar else []
    if today_events:
        lines.extend(["", "<b>تقویم خبرهای مهم امروز:</b>"])
        for event in today_events[:6]:
            when = local_datetime(event)
            clock = when.strftime("%H:%M") if when else "—"
            lines.append(f"• {clock} | {_h(event.get('currency'), 10)} | {_h(event.get('title_fa') or event.get('title'), 170)}")
    if news:
        lines.extend(["", "<b>سرتیترهای تحلیلی تکمیلی:</b>"])
        for item in news[:4]:
            lines.append(f"• {_h(item.get('title'), 170)}")
    if fred:
        lines.extend(["", "<b>داده‌های کلیدی آمریکا:</b>"])
        for key in ("DGS10", "DFF", "DTWEXBGS", "DEXUSEU"):
            row = fred.get(key)
            if not isinstance(row, dict):
                continue
            change = _safe_float(row.get("change"))
            change_text = f" ({change:+.3f})" if change is not None else ""
            lines.append(f"• {_h(row.get('label'), 120)}: {_fmt_number(row.get('value'), 4 if key == 'DEXUSEU' else 2)}{change_text}")
    if energy:
        lines.extend(["", "<b>انرژی:</b>"])
        for row in energy[:2]:
            change = _safe_float(row.get("change_pct"))
            lines.append(
                f"• {_h(row.get('label'), 120)}: ${_fmt_number(row.get('price'))} ({change:+.2f}٪)"
                if change is not None
                else f"• {_h(row.get('label'), 120)}: ${_fmt_number(row.get('price'))}"
            )
    if filings:
        lines.extend(["", "<b>SEC EDGAR:</b>"])
        for row in filings[:2]:
            lines.append(f"• {_h(row.get('symbol'), 20)} — {_h(row.get('form'), 20)} — {row.get('date')}")
    lines.extend(
        [
            "",
            "⚠️ <i>این گزارش تحلیل سناریویی است و تضمین جهت بازار یا توصیه سرمایه‌گذاری نیست. خبرهای لحظه‌ای می‌توانند نتیجه را تغییر دهند.</i>",
            "#SENTINEL #Gold #EURUSD #MarketBrief",
        ]
    )
    return "\n".join(lines)


# ───────────────────── Scenario evaluation and calibration ───────────────────
def _snapshot_asset_price(snapshot: dict[str, Any], asset: str) -> float | None:
    quotes = snapshot.get("quotes", {}) if isinstance(snapshot.get("quotes"), dict) else {}
    row = quotes.get(asset, {}) if isinstance(quotes, dict) else {}
    return _safe_float(row.get("price")) if isinstance(row, dict) else None


def record_scenario_predictions(
    db: dict[str, Any],
    snapshot: dict[str, Any],
    *,
    horizon_hours: int = 24,
) -> list[dict[str, Any]]:
    root = ensure_market_intelligence(db)
    rows = root.setdefault("scenario_predictions", [])
    if not isinstance(rows, list):
        rows = []
        root["scenario_predictions"] = rows
    created: list[dict[str, Any]] = []
    outlooks = snapshot.get("outlooks", {}) if isinstance(snapshot.get("outlooks"), dict) else {}
    now = datetime.now(UTC)
    mapping = {"gold": "XAU/USD", "eurusd": "EUR/USD"}
    for key, asset in mapping.items():
        outlook = outlooks.get(key, {}) if isinstance(outlooks, dict) else {}
        price = _snapshot_asset_price(snapshot, asset)
        if not isinstance(outlook, dict) or price is None:
            continue
        # Avoid duplicate predictions generated from the same snapshot minute.
        generated_at = str(snapshot.get("generated_at") or utc_iso())
        duplicate = any(
            isinstance(item, dict) and item.get("asset") == asset and str(item.get("snapshot_generated_at"))[:16] == generated_at[:16]
            for item in rows[-20:]
        )
        if duplicate:
            continue
        prediction = {
            "id": next_id(db, "scenario_prediction"),
            "asset": asset,
            "start_price": price,
            "start_at": now.isoformat(),
            "evaluate_after": (now + timedelta(hours=max(1, horizon_hours))).isoformat(),
            "snapshot_generated_at": generated_at,
            "direction": outlook.get("direction"),
            "bullish_probability": int(outlook.get("bullish_probability", 0) or 0),
            "neutral_probability": int(outlook.get("neutral_probability", 0) or 0),
            "bearish_probability": int(outlook.get("bearish_probability", 0) or 0),
            "confidence": int(outlook.get("confidence", 0) or 0),
            "status": "pending",
            "end_price": None,
            "actual_direction": None,
            "return_percent": None,
            "brier_score": None,
            "evaluated_at": None,
        }
        rows.append(prediction)
        created.append(dict(prediction))
    root["scenario_predictions"] = rows[-1000:]
    return created


def _actual_direction(asset: str, return_percent: float) -> str:
    threshold = 0.10 if asset == "XAU/USD" else 0.05
    if return_percent > threshold:
        return "bullish"
    if return_percent < -threshold:
        return "bearish"
    return "neutral"


def _brier_score(prediction: dict[str, Any], actual: str) -> float:
    probabilities = {
        "bullish": float(prediction.get("bullish_probability", 0) or 0) / 100,
        "neutral": float(prediction.get("neutral_probability", 0) or 0) / 100,
        "bearish": float(prediction.get("bearish_probability", 0) or 0) / 100,
    }
    return sum((probability - (1.0 if label == actual else 0.0)) ** 2 for label, probability in probabilities.items()) / 3


def evaluate_scenario_predictions(
    db: dict[str, Any],
    snapshot: dict[str, Any],
    *,
    now: datetime | None = None,
) -> list[dict[str, Any]]:
    root = ensure_market_intelligence(db)
    rows = root.setdefault("scenario_predictions", [])
    current = now or datetime.now(UTC)
    evaluated: list[dict[str, Any]] = []
    for prediction in rows if isinstance(rows, list) else []:
        if not isinstance(prediction, dict) or prediction.get("status") != "pending":
            continue
        due = parse_dt(prediction.get("evaluate_after"))
        if not due or due > current:
            continue
        asset = str(prediction.get("asset") or "")
        end_price = _snapshot_asset_price(snapshot, asset)
        start_price = _safe_float(prediction.get("start_price"))
        if end_price is None or start_price is None or start_price <= 0:
            continue
        change = (end_price / start_price - 1) * 100
        actual = _actual_direction(asset, change)
        prediction.update(
            {
                "status": "evaluated",
                "end_price": end_price,
                "actual_direction": actual,
                "return_percent": round(change, 5),
                "brier_score": round(_brier_score(prediction, actual), 6),
                "evaluated_at": current.isoformat(),
            }
        )
        evaluated.append(dict(prediction))
    _rebuild_scenario_performance(root)
    return evaluated


def _rebuild_scenario_performance(root: dict[str, Any]) -> dict[str, Any]:
    performance: dict[str, Any] = {}
    rows = [row for row in root.get("scenario_predictions", []) if isinstance(row, dict) and row.get("status") == "evaluated"]
    for asset in ("XAU/USD", "EUR/USD"):
        asset_rows = [row for row in rows if row.get("asset") == asset]
        if not asset_rows:
            performance[asset] = {"samples": 0, "accuracy": None, "average_brier": None}
            continue
        correct = 0
        for row in asset_rows:
            predicted = str(row.get("direction") or "")
            predicted_key = "bullish" if "صعود" in predicted else "bearish" if "نزول" in predicted else "neutral"
            if predicted_key == row.get("actual_direction"):
                correct += 1
        performance[asset] = {
            "samples": len(asset_rows),
            "accuracy": round(correct / len(asset_rows) * 100, 2),
            "average_brier": round(
                sum(float(row.get("brier_score", 0) or 0) for row in asset_rows) / len(asset_rows),
                6,
            ),
            "last_evaluated_at": asset_rows[-1].get("evaluated_at"),
        }
    root["scenario_performance"] = performance
    return performance


def calibrate_snapshot(db: dict[str, Any], snapshot: dict[str, Any]) -> dict[str, Any]:
    """Shrink overconfident probabilities using accumulated out-of-sample results."""
    root = ensure_market_intelligence(db)
    performance = root.get("scenario_performance", {})
    outlooks = snapshot.get("outlooks", {}) if isinstance(snapshot.get("outlooks"), dict) else {}
    mapping = {"gold": "XAU/USD", "eurusd": "EUR/USD"}
    for key, asset in mapping.items():
        outlook = outlooks.get(key)
        stats = performance.get(asset, {}) if isinstance(performance, dict) else {}
        if not isinstance(outlook, dict) or not isinstance(stats, dict):
            continue
        samples = int(stats.get("samples", 0) or 0)
        accuracy = _safe_float(stats.get("accuracy"))
        if samples < 10 or accuracy is None:
            outlook["calibration"] = {"applied": False, "samples": samples}
            continue
        reliability = max(0.35, min(1.0, accuracy / 65.0))
        bull = float(outlook.get("bullish_probability", 0) or 0)
        bear = float(outlook.get("bearish_probability", 0) or 0)
        calibrated_bull = 33.333 + (bull - 33.333) * reliability
        calibrated_bear = 33.333 + (bear - 33.333) * reliability
        calibrated_neutral = 100 - calibrated_bull - calibrated_bear
        outlook["bullish_probability"] = round(calibrated_bull)
        outlook["bearish_probability"] = round(calibrated_bear)
        outlook["neutral_probability"] = round(calibrated_neutral)
        outlook["confidence"] = min(int(outlook.get("confidence", 0) or 0), round(accuracy))
        outlook["calibration"] = {
            "applied": True,
            "samples": samples,
            "historical_accuracy": accuracy,
            "reliability_factor": round(reliability, 3),
        }
    snapshot["outlooks"] = outlooks
    return snapshot


def scenario_performance(db: dict[str, Any]) -> dict[str, Any]:
    root = ensure_market_intelligence(db)
    return dict(root.get("scenario_performance", {}))
