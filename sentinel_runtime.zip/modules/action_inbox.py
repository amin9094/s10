from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from core.utils import parse_dt


def _age_minutes(value: Any) -> int:
    created = parse_dt(value)
    if created is None:
        return 0
    return max(0, int((datetime.now(UTC) - created).total_seconds() // 60))


def _item(
    *,
    kind: str,
    item_id: Any,
    title: str,
    detail: str,
    priority: str,
    created_at: Any,
    permission: str,
    actions: list[str],
) -> dict[str, Any]:
    return {
        "key": f"{kind}:{item_id}",
        "kind": kind,
        "id": str(item_id),
        "title": str(title)[:160],
        "detail": str(detail)[:500],
        "priority": priority,
        "created_at": created_at,
        "age_minutes": _age_minutes(created_at),
        "permission": permission,
        "actions": actions,
    }


def action_inbox_snapshot(db: dict[str, Any], *, limit: int = 80) -> dict[str, Any]:
    """Return one prioritized operational queue without changing source records."""
    from modules.admin_access import (
        PERMISSION_AUTOMATIONS,
        PERMISSION_CAMPAIGNS,
        PERMISSION_INCIDENTS,
        PERMISSION_PAYMENTS,
        PERMISSION_TICKETS,
    )

    rows: list[dict[str, Any]] = []
    for incident in db.get("incidents", []):
        if not isinstance(incident, dict) or incident.get("status") not in {
            "open",
            "acknowledged",
            "investigating",
        }:
            continue
        severity = str(incident.get("severity") or "warning")
        rows.append(
            _item(
                kind="incident",
                item_id=incident.get("id"),
                title=f"{severity.upper()} · {incident.get('kind') or 'incident'}",
                detail=str(incident.get("detail") or ""),
                priority="critical" if severity == "critical" else "high",
                created_at=incident.get("last_seen_at") or incident.get("created_at"),
                permission=PERMISSION_INCIDENTS,
                actions=["acknowledged", "investigating", "resolved"],
            )
        )
    for order in db.get("vip_orders", []):
        if not isinstance(order, dict) or order.get("status") not in {"pending", "approving", "review"}:
            continue
        rows.append(
            _item(
                kind="payment",
                item_id=order.get("order_id") or order.get("id"),
                title=f"پرداخت {order.get('plan_name') or 'VIP'}",
                detail=f"کاربر {order.get('user_id') or '—'} · مبلغ {order.get('price') or 0}",
                priority="high",
                created_at=order.get("created_at"),
                permission=PERMISSION_PAYMENTS,
                actions=["open_in_bot"],
            )
        )
    for ticket in db.get("tickets", []):
        if not isinstance(ticket, dict) or ticket.get("status") != "open":
            continue
        priority = str(ticket.get("priority") or "normal")
        rows.append(
            _item(
                kind="ticket",
                item_id=ticket.get("id"),
                title=str(ticket.get("subject") or "تیکت پشتیبانی"),
                detail=f"کاربر {ticket.get('user_id') or '—'} · منتظر {ticket.get('waiting_for') or 'admin'}",
                priority="high" if priority in {"urgent", "high"} else "normal",
                created_at=ticket.get("updated_at") or ticket.get("created_at"),
                permission=PERMISSION_TICKETS,
                actions=["reply", "close"],
            )
        )
    for campaign in db.get("marketing_campaigns", {}).values():
        if not isinstance(campaign, dict):
            continue
        status = str(campaign.get("schedule_status") or "")
        if status not in {"retry", "failed", "dead_letter"}:
            continue
        rows.append(
            _item(
                kind="campaign",
                item_id=campaign.get("id"),
                title=str(campaign.get("name") or "کمپین"),
                detail=str(campaign.get("schedule_last_error") or status),
                priority="high" if status in {"failed", "dead_letter"} else "normal",
                created_at=campaign.get("updated_at") or campaign.get("created_at"),
                permission=PERMISSION_CAMPAIGNS,
                actions=["paused", "cancelled"],
            )
        )
    for outbox in db.get("automation_outbox", {}).values():
        if not isinstance(outbox, dict) or outbox.get("status") not in {"retry", "dead_letter"}:
            continue
        rows.append(
            _item(
                kind="automation",
                item_id=outbox.get("id"),
                title=f"ارسال {outbox.get('kind') or 'automation'}",
                detail=str(outbox.get("last_error") or outbox.get("status") or ""),
                priority="high" if outbox.get("status") == "dead_letter" else "normal",
                created_at=outbox.get("updated_at") or outbox.get("created_at"),
                permission=PERMISSION_AUTOMATIONS,
                actions=["retry"],
            )
        )

    rank = {"critical": 0, "high": 1, "normal": 2, "low": 3}
    rows.sort(
        key=lambda row: (
            rank.get(str(row.get("priority") or "normal"), 2),
            -int(row.get("age_minutes", 0) or 0),
            str(row.get("key") or ""),
        )
    )
    limited = rows[: max(1, min(int(limit), 250))]
    counts: dict[str, int] = {}
    for row in rows:
        kind = str(row.get("kind") or "other")
        counts[kind] = counts.get(kind, 0) + 1
    return {
        "total": len(rows),
        "critical": sum(1 for row in rows if row.get("priority") == "critical"),
        "high": sum(1 for row in rows if row.get("priority") == "high"),
        "counts": counts,
        "items": limited,
    }
