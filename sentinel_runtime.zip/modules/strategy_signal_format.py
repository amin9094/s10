"""One exact, vertical presentation for frozen strategy entry/exit prices."""
from decimal import Decimal


def exact_price(value):
    text = format(Decimal(str(value)), 'f')
    return text.rstrip('0').rstrip('.') if '.' in text else text


def level_lines(plan):
    rows = [f"Entry: {exact_price(plan['entry'])}", f"SL: {exact_price(plan['stop'])}"]
    for n in range(1, 11):
        value = plan.get(f'tp{n}')
        if value is not None:
            rows.append(f"TP{n}: {exact_price(value)}")
    return rows


def independent_confirmation_label(value):
    return value.replace('گلدباخ','PO3 مستقل').replace('DMM','PO3 مستقل')


def priority_label(plan):
    dmm=next((f.get('detail',{}) for f in plan.get('evidence',()) if f.get('kind')=='shared_goldbach_confirmation'),{})
    outer='هم‌پوشانی سقف یا کف PO3 مستقل با محدودهٔ ورود' if dmm.get('outer_structural_confluence') else ''
    custom=next((f.get('detail',{}) for f in plan.get('evidence',()) if f.get('kind')=='custom_strategy'),None)
    if custom is not None:
        priority=custom.get('confluence_priority',{})
        return independent_confirmation_label(priority.get('label_fa','')) if priority.get('confirmed') else outer
    priority = next((f.get('detail', {}) for f in plan.get('evidence', ())
                     if f.get('kind') == 'entry_confluence_priority'), {})
    return independent_confirmation_label(priority.get('label_fa', '')) if priority.get('confirmed') else outer
