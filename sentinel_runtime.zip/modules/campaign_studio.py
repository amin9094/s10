from __future__ import annotations
from core.logging_context import operation_id

import hashlib
from uuid import uuid4
import json
from collections import Counter
from datetime import UTC, datetime, timedelta
from typing import Any

from core.db import next_id
from core.utils import parse_dt, utc_iso, utc_now
from modules.discount_campaigns import campaign_report as discount_campaign_report
from modules.growth_link_lab import growth_link_lab
from modules.sales_growth import crm_segment_snapshot

CAMPAIGN_CATEGORIES: dict[str, tuple[str, str]] = {
    "acquisition": ("جذب کاربر", "افزایش اعضا و ورودی‌های جدید"),
    "activation": ("فعال‌سازی", "رساندن کاربر جدید به اولین اقدام مهم"),
    "conversion": ("فروش و تبدیل", "تبدیل مخاطب به خریدار"),
    "retention": ("نگهداشت", "حفظ کاربران و مشترکان فعال"),
    "winback": ("بازگشت مشتری", "بازگرداندن کاربران و مشتریان ازدست‌رفته"),
    "loyalty": ("وفاداری", "پاداش و افزایش خرید کاربران وفادار"),
    "referral": ("معرفی دوستان", "رشد ارجاعی و دهان‌به‌دهان"),
    "seasonal": ("مناسبتی", "کمپین‌های مناسبتی و محدود به زمان"),
    "vip_upgrade": ("ارتقای VIP", "فروش یا تمدید پلن‌های خصوصی"),
    "announcement": ("اطلاع‌رسانی", "اعلان محصول، قابلیت یا رویداد مهم"),
}

CAMPAIGN_AUDIENCES: dict[str, str] = {
    "all": "همه کاربران",
    "new_user": "کاربران جدید",
    "active_user": "کاربران فعال",
    "inactive_user": "کاربران غیرفعال",
    "vip_active": "VIP فعال",
    "renewal_due": "VIP رو به پایان",
    "vip_expired": "VIP منقضی",
    "never_vip": "بدون سابقه VIP",
    "abandoned_checkout": "خرید نیمه‌تمام",
    "high_value": "مشتریان ارزشمند",
    "loyal_buyer": "مشتریان وفادار",
    "churned_customer": "مشتریان ازدست‌رفته",
}

DELIVERY_CHANNELS = {
    "draft",
    # Link-first campaigns are the supported creation path.  Legacy delivery
    # values remain readable for existing records and scheduled jobs.
    "link_bot",
    "link_channel",
    "link_both",
    "direct",
    "public",
    "private",
    "direct_public",
}
FINAL_CAMPAIGN_STATUSES = {"completed", "cancelled", "archived"}
MAX_CAMPAIGN_EVENTS = 100_000
DISPATCH_CLAIM_TTL_MINUTES = 15
SCHEDULE_CLAIM_TTL_MINUTES = 10


def _clean_name(value: Any) -> str:
    name = " ".join(str(value or "").strip().split())
    if not 3 <= len(name) <= 100:
        raise ValueError("نام کمپین باید بین ۳ تا ۱۰۰ نویسه باشد.")
    return name


def _campaign_id(db: dict[str, Any]) -> str:
    return f"CMP-{next_id(db, 'marketing_campaign'):06d}"


def campaign_dispatch_key(campaign: dict[str, Any]) -> str:
    """Return a stable key for one immutable campaign delivery version."""
    payload = {
        "id": str(campaign.get("id") or ""),
        "version": int(campaign.get("version", 1) or 1),
        "delivery": str(campaign.get("delivery") or "draft"),
        "audience": str(campaign.get("audience") or "all"),
        "message": str(campaign.get("message") or ""),
        "discount_code": str(campaign.get("discount_code") or ""),
    }
    digest = hashlib.sha256(
        json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()[:20]
    return f"{payload['id']}:v{payload['version']}:{digest}"


def _audience_digest(members: list[str]) -> str:
    payload = "\n".join(sorted({str(uid) for uid in members if str(uid).isdigit()}, key=int))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def freeze_campaign_audience(
    db: dict[str, Any],
    campaign_id: int | str,
    *,
    actor_id: int | str,
) -> dict[str, Any]:
    """Freeze the exact recipient cohort for one immutable campaign version."""
    row = campaign_by_id(db, campaign_id)
    if row is None:
        raise ValueError("Campaign not found.")
    dispatch_key = campaign_dispatch_key(row)
    snapshots = db.setdefault("campaign_audience_snapshots", {})
    existing = snapshots.get(dispatch_key)
    if isinstance(existing, dict):
        members = [str(uid) for uid in existing.get("members", []) if str(uid).isdigit()]
        if str(existing.get("sha256") or "") != _audience_digest(members):
            raise RuntimeError("Campaign audience snapshot integrity check failed.")
        return dict(existing)

    members = audience_members(db, str(row.get("audience") or "all"))
    members = sorted({str(uid) for uid in members if str(uid).isdigit()}, key=int)
    snapshot = {
        "dispatch_key": dispatch_key,
        "campaign_id": str(row.get("id") or ""),
        "campaign_version": int(row.get("version", 1) or 1),
        "audience": str(row.get("audience") or "all"),
        "members": members,
        "count": len(members),
        "sha256": _audience_digest(members),
        "frozen_at": utc_iso(),
        "frozen_by": str(actor_id or ""),
    }
    snapshots[dispatch_key] = snapshot
    row["audience_snapshot_key"] = dispatch_key
    row["audience_snapshot_count"] = len(members)
    row["audience_snapshot_sha256"] = snapshot["sha256"]
    row["audience_snapshot_at"] = snapshot["frozen_at"]
    record_campaign_event(
        db,
        row["id"],
        "audience_frozen",
        actor_id=actor_id,
        metadata={
            "dispatch_key": dispatch_key,
            "count": len(members),
            "sha256": snapshot["sha256"],
        },
    )
    return dict(snapshot)


def campaign_snapshot_members(
    db: dict[str, Any],
    campaign_id: int | str,
    dispatch_key: str,
) -> list[str]:
    """Return verified recipients and never recalculate a confirmed cohort."""
    row = campaign_by_id(db, campaign_id)
    if row is None:
        raise ValueError("Campaign not found.")
    snapshot = db.setdefault("campaign_audience_snapshots", {}).get(str(dispatch_key))
    if not isinstance(snapshot, dict):
        raise RuntimeError("Campaign audience snapshot is missing.")
    if str(snapshot.get("campaign_id") or "") != str(row.get("id") or ""):
        raise RuntimeError("Campaign audience snapshot belongs to another campaign.")
    members = [str(uid) for uid in snapshot.get("members", []) if str(uid).isdigit()]
    if str(snapshot.get("sha256") or "") != _audience_digest(members):
        raise RuntimeError("Campaign audience snapshot integrity check failed.")
    return sorted(set(members), key=int)


def campaign_by_id(db: dict[str, Any], campaign_id: int | str) -> dict[str, Any] | None:
    key = str(campaign_id or "").strip().upper()
    if key.isdigit():
        key = f"CMP-{int(key):06d}"
    row = db.setdefault("marketing_campaigns", {}).get(key)
    return row if isinstance(row, dict) else None


def record_campaign_event(
    db: dict[str, Any],
    campaign_id: int | str,
    event_type: str,
    *,
    actor_id: int | str = "",
    user_id: int | str = "",
    detail: str = "",
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    campaign = campaign_by_id(db, campaign_id)
    if campaign is None:
        raise ValueError("کمپین پیدا نشد.")
    row = {
        "id": next_id(db, "campaign_event"),
        "campaign_id": campaign["id"],
        "type": str(event_type or "event")[:64],
        "operation_id": operation_id("campaign:"+str(campaign_id)),
        "actor_id": str(actor_id or ""),
        "user_id": str(user_id or ""),
        "detail": str(detail or "")[:1000],
        "metadata": dict(metadata or {}),
        "created_at": utc_iso(),
    }
    events = db.setdefault("campaign_events", [])
    events.append(row)
    db["campaign_events"] = events[-MAX_CAMPAIGN_EVENTS:]
    campaign["updated_at"] = row["created_at"]
    return row


def create_marketing_campaign(
    db: dict[str, Any],
    *,
    name: str,
    category: str,
    audience: str,
    message: str,
    delivery: str,
    created_by: int | str,
    objective: str = "",
    tracking: dict[str, Any] | None = None,
) -> dict[str, Any]:
    clean_category = str(category or "").strip().lower()
    if clean_category not in CAMPAIGN_CATEGORIES:
        raise ValueError("دسته‌بندی کمپین معتبر نیست.")
    clean_audience = str(audience or "").strip().lower()
    if clean_audience not in CAMPAIGN_AUDIENCES:
        raise ValueError("گروه مخاطب کمپین معتبر نیست.")
    clean_delivery = str(delivery or "").strip().lower()
    if clean_delivery not in DELIVERY_CHANNELS:
        raise ValueError("مسیر انتشار کمپین معتبر نیست.")
    clean_message = str(message or "").strip()
    if not 3 <= len(clean_message) <= 3500:
        raise ValueError("متن کمپین باید بین ۳ تا ۳۵۰۰ نویسه باشد.")
    campaign_id = _campaign_id(db)
    now = utc_iso()
    default_objective = CAMPAIGN_CATEGORIES[clean_category][1]
    row = {
        "id": campaign_id,
        "name": _clean_name(name),
        "category": clean_category,
        "objective": str(objective or default_objective).strip()[:500],
        "audience": clean_audience,
        "message": clean_message,
        "delivery": clean_delivery,
        "status": "draft",
        "discount_code": "",
        "broadcast_job_ids": [],
        "channel_message_ids": {},
        "tracking_link_ids": [],
        "scheduled_for": None,
        "schedule_status": "not_scheduled",
        "schedule_priority": 3,
        "schedule_attempts": 0,
        "schedule_max_attempts": 5,
        "schedule_next_attempt_at": None,
        "schedule_claimed_at": None,
        "schedule_last_error": "",
        "started_at": None,
        "ended_at": None,
        "created_at": now,
        "created_by": str(created_by),
        "updated_at": now,
        "version": 1,
        "dispatch_claims": {},
        "dispatch_receipts": {},
        "touch_index": {},
        "tracking": {
            "source": str((tracking or {}).get("source") or "direct").strip().lower()[:100],
            "medium": str((tracking or {}).get("medium") or "telegram").strip().lower()[:80],
            "creative": str((tracking or {}).get("creative") or "default").strip().lower()[:120],
            "advertiser": str((tracking or {}).get("advertiser") or "").strip()[:100],
            "budget": max(0, int((tracking or {}).get("budget", 0) or 0)),
        },
        "bot_tracking_link": "",
        "channel_tracking_link": "",
        "previewed_at": None,
        "confirmed_at": None,
        "confirmed_by": None,
        "audience_snapshot_key": "",
        "audience_snapshot_count": 0,
        "audience_snapshot_sha256": "",
        "audience_snapshot_at": None,
    }
    initial_audience = audience_members(db, clean_audience)
    quality_warnings: list[str] = []
    if not initial_audience:
        quality_warnings.append("AUDIENCE_EMPTY_AT_CREATION")
    if clean_delivery.startswith("link_") and str(row["tracking"].get("source") or "") == "direct":
        quality_warnings.append("TRACKING_SOURCE_NOT_CUSTOMIZED")
    if len(clean_message) < 40:
        quality_warnings.append("MESSAGE_TOO_SHORT_FOR_CONTEXT")
    row["creation_snapshot"] = {
        "audience_estimate": len(initial_audience),
        "message_sha256": hashlib.sha256(clean_message.encode("utf-8")).hexdigest(),
        "tracking_ready": not clean_delivery.startswith("link_") or not quality_warnings,
        "quality": "ready" if not quality_warnings else "review",
        "warnings": quality_warnings,
        "created_at": now,
    }
    db.setdefault("marketing_campaigns", {})[campaign_id] = row
    record_campaign_event(db, campaign_id, "created", actor_id=created_by)
    return row


def activate_link_campaign(
    db: dict[str, Any],
    campaign_id: int | str,
    *,
    actor_id: int | str,
    bot_link: str = "",
    channel_link: str = "",
    channel_link_id: int | str = "",
) -> dict[str, Any]:
    row = campaign_by_id(db, campaign_id)
    if row is None:
        raise ValueError("کمپین پیدا نشد.")
    if str(row.get("delivery") or "") not in {"link_bot", "link_channel", "link_both"}:
        raise ValueError("این کمپین لینک‌محور نیست.")
    row["bot_tracking_link"] = str(bot_link or "")[:500]
    row["channel_tracking_link"] = str(channel_link or "")[:500]
    if channel_link_id:
        row.setdefault("tracking_link_ids", []).append(str(channel_link_id))
        row["tracking_link_ids"] = list(dict.fromkeys(row["tracking_link_ids"]))[-100:]
    row["status"] = "active"
    row["started_at"] = row.get("started_at") or utc_iso()
    row["updated_at"] = utc_iso()
    record_campaign_event(
        db,
        row["id"],
        "link_campaign_activated",
        actor_id=actor_id,
        metadata={
            "bot_link": bool(bot_link),
            "channel_link": bool(channel_link),
            "channel_link_id": str(channel_link_id or ""),
        },
    )
    return row


def attach_campaign_discount(
    db: dict[str, Any],
    campaign_id: int | str,
    code: str,
    *,
    actor_id: int | str,
) -> dict[str, Any]:
    campaign = campaign_by_id(db, campaign_id)
    if campaign is None:
        raise ValueError("کمپین پیدا نشد.")
    clean_code = str(code or "").strip().upper()
    discount = db.setdefault("discount_codes", {}).get(clean_code)
    if not isinstance(discount, dict):
        raise ValueError("کد تخفیف پیدا نشد.")
    discount["campaign_id"] = campaign["id"]
    discount["campaign_name"] = campaign["name"]
    discount["updated_at"] = utc_iso()
    campaign["discount_code"] = clean_code
    campaign["version"] = int(campaign.get("version", 1) or 1) + 1
    record_campaign_event(
        db,
        campaign["id"],
        "discount_attached",
        actor_id=actor_id,
        detail=clean_code,
    )
    return campaign


def audience_members(db: dict[str, Any], audience: str) -> list[str]:
    clean = str(audience or "all").strip().lower()
    if clean == "all":
        return sorted(
            {str(uid) for uid in db.get("users", {}) if str(uid).isdigit()},
            key=int,
        )
    if clean not in CAMPAIGN_AUDIENCES:
        raise ValueError("گروه مخاطب کمپین معتبر نیست.")
    return list(crm_segment_snapshot(db).get(clean, []))


def campaign_delivery_text(db: dict[str, Any], campaign_id: int | str) -> str:
    row = campaign_by_id(db, campaign_id)
    if row is None:
        raise ValueError("کمپین پیدا نشد.")
    parts = [str(row.get("message") or "").strip()]
    code = str(row.get("discount_code") or "").strip().upper()
    discount = db.get("discount_codes", {}).get(code) if code else None
    if isinstance(discount, dict):
        parts.extend(
            [
                "",
                f"🎁 کد تخفیف: {code}",
                f"💯 میزان تخفیف: {int(discount.get('percent', 0) or 0)}٪",
            ]
        )
        expiry = parse_dt(discount.get("expires_at"))
        if expiry:
            parts.append(f"⏳ اعتبار تا: {expiry.astimezone(UTC).strftime('%Y-%m-%d %H:%M UTC')}")
    parts.append("")
    parts.append("SENTINEL • Protect • Analyze • Execute")
    return "\n".join(parts)[:4096]


def campaign_preview(db: dict[str, Any], campaign_id: int | str) -> dict[str, Any]:
    """Build a side-effect-free preview and record that an admin inspected it."""
    row = campaign_by_id(db, campaign_id)
    if row is None:
        raise ValueError("کمپین پیدا نشد.")
    row["previewed_at"] = utc_iso()
    row["updated_at"] = row["previewed_at"]
    return {
        "campaign": dict(row),
        "delivery_text": campaign_delivery_text(db, row["id"]),
        "dispatch_key": campaign_dispatch_key(row),
        "audience_size": len(audience_members(db, str(row.get("audience") or "all"))),
    }


def claim_campaign_dispatch(
    db: dict[str, Any],
    campaign_id: int | str,
    *,
    actor_id: int | str,
) -> dict[str, Any]:
    """Claim one campaign version so repeated taps cannot enqueue it twice."""
    row = campaign_by_id(db, campaign_id)
    if row is None:
        raise ValueError("کمپین پیدا نشد.")
    if str(row.get("delivery") or "draft") == "draft":
        raise ValueError("مسیر انتشار کمپین هنوز روی پیش‌نویس است.")
    if not row.get("previewed_at"):
        raise ValueError("کمپین باید پیش از انتشار بازبینی شود.")
    key = campaign_dispatch_key(row)
    freeze_campaign_audience(db, row["id"], actor_id=actor_id)
    claims = row.setdefault("dispatch_claims", {})
    current = claims.get(key) if isinstance(claims.get(key), dict) else {}
    status = str(current.get("status") or "")
    if status == "uncertain":
        return {"claimed":False,"reason":"uncertain_review_required","key":key,"claim":dict(current)}
    if status == "completed":
        return {"claimed": False, "reason": "already_dispatched", "key": key, "claim": dict(current)}
    claimed_at = parse_dt(current.get("claimed_at"))
    if (
        status == "in_progress"
        and claimed_at
        and claimed_at + timedelta(minutes=DISPATCH_CLAIM_TTL_MINUTES) > utc_now()
    ):
        return {"claimed": False, "reason": "in_progress", "key": key, "claim": dict(current)}
    if status == 'in_progress' and current.get('delivery_started_channels'):
        current.update(status='uncertain',errors=['DELIVERY_RECEIPT_MISSING'])
        return {'claimed':False,'reason':'uncertain_review_required','key':key,'claim':dict(current)}
    now = utc_iso()
    previous_result = dict(current.get("result") or current.get('previous_result') or {})
    claim = {
        "key": key,
        "token": uuid4().hex,
        "operation_id": operation_id("campaign:"+str(campaign_id)),
        "status": "in_progress",
        "claimed_at": now,
        "claimed_by": str(actor_id),
        "completed_at": None,
        "errors": [],
        "retry_count": int(current.get("retry_count", 0) or 0) + (1 if status in {"partial", "failed"} else 0),
        "previous_result": previous_result,
    }
    claims[key] = claim
    row["confirmed_at"] = now
    row["confirmed_by"] = str(actor_id)
    row["updated_at"] = now
    record_campaign_event(
        db,
        row["id"],
        "dispatch_claimed",
        actor_id=actor_id,
        metadata={"dispatch_key": key},
    )
    return {
        "claimed": True,
        "reason": "retry" if status in {"partial", "failed"} else "claimed",
        "key": key,
        "claim": dict(claim),
        "previous_result": previous_result,
    }


def complete_campaign_dispatch(
    db: dict[str, Any],
    campaign_id: int | str,
    dispatch_key: str,
    *,
    actor_id: int | str,
    results: dict[str, Any],
    claim_token: str | None = None,
) -> dict[str, Any]:
    row = campaign_by_id(db, campaign_id)
    if row is None:
        raise ValueError("کمپین پیدا نشد.")
    claims = row.setdefault("dispatch_claims", {})
    claim = claims.get(str(dispatch_key))
    if not isinstance(claim, dict):
        raise ValueError("رزرو انتشار کمپین پیدا نشد.")
    if claim_token is not None and (claim.get('token')!=claim_token or claim.get('status')!='in_progress'):
        return {**claim,'stale_result_ignored':True}
    errors = [str(item)[:300] for item in results.get("errors", [])]
    delivered = bool(results.get("direct_job") or results.get("channels"))
    outstanding=set(claim.get('delivery_started_channels') or [])-set(results.get('channels') or {})
    if results.get('direct_job'):outstanding.discard('direct')
    uncertain=sorted(set(results.get('uncertain_channels') or [])|outstanding)
    claim["status"] = "uncertain" if uncertain else "partial" if delivered and errors else "completed" if delivered else "failed"
    claim["completed_at"] = utc_iso()
    claim["errors"] = errors
    claim["result"] = {
        "direct_job": str(results.get("direct_job") or ""),
        "uncertain_channels": uncertain,
        "channels": dict(results.get("channels") or {}),
    }
    row.setdefault("dispatch_receipts", {})[str(dispatch_key)] = dict(claim["result"])
    row["updated_at"] = claim["completed_at"]
    record_campaign_event(
        db,
        row["id"],
        f"dispatch_{claim['status']}",
        actor_id=actor_id,
        metadata={"dispatch_key": dispatch_key, "errors": errors},
    )
    return dict(claim)


def campaign_delivery_checkpoint(db,campaign_id,dispatch_key,token,channel,*,message_id=None,job_id=None):
    row=campaign_by_id(db,campaign_id)
    claim=(row or {}).get('dispatch_claims',{}).get(dispatch_key,{})
    if claim.get('token')!=token or claim.get('status')!='in_progress':
        raise ValueError('CAMPAIGN_DISPATCH_LEASE_CHANGED')
    if row.get('status') in {'cancelled','paused','archived'}:
        raise ValueError('CAMPAIGN_DISPATCH_STOPPED')
    started=claim.setdefault('delivery_started_channels',[])
    result=claim.setdefault('result',dict(claim.get('previous_result') or {}))
    if message_id is not None:
        result.setdefault('channels',{})[channel]=message_id
        if channel in started:started.remove(channel)
    elif job_id is not None:
        result['direct_job']=job_id
        if channel in started:started.remove(channel)
    elif channel not in started:
        started.append(channel)
    return True


def mark_campaign_dispatched(
    db: dict[str, Any],
    campaign_id: int | str,
    *,
    actor_id: int | str,
    broadcast_job_id: str = "",
    channel: str = "",
    message_id: int | str | None = None,
) -> dict[str, Any]:
    row = campaign_by_id(db, campaign_id)
    if row is None:
        raise ValueError("کمپین پیدا نشد.")
    if broadcast_job_id and broadcast_job_id not in row.setdefault("broadcast_job_ids", []):
        row["broadcast_job_ids"].append(str(broadcast_job_id))
    if channel and message_id is not None:
        row.setdefault("channel_message_ids", {})[str(channel)] = str(message_id)
    if row.get("status")!="scheduled" or row.get("schedule_status")!="processing":
        row["status"] = "active"
    row["started_at"] = row.get("started_at") or utc_iso()
    row["updated_at"] = utc_iso()
    record_campaign_event(
        db,
        row["id"],
        "dispatched",
        actor_id=actor_id,
        metadata={
            "broadcast_job_id": str(broadcast_job_id or ""),
            "channel": str(channel or ""),
            "message_id": str(message_id or ""),
        },
    )
    return row


def set_campaign_status(
    db: dict[str, Any],
    campaign_id: int | str,
    status: str,
    *,
    actor_id: int | str,
) -> dict[str, Any]:
    row = campaign_by_id(db, campaign_id)
    if row is None:
        raise ValueError("کمپین پیدا نشد.")
    clean = str(status or "").strip().lower()
    if clean not in {"draft", "scheduled", "active", "paused", "completed", "cancelled", "archived"}:
        raise ValueError("وضعیت کمپین معتبر نیست.")
    if row.get("status") in FINAL_CAMPAIGN_STATUSES and clean == "active":
        raise ValueError("کمپین بسته‌شده را نمی‌توان بدون ساخت نسخه جدید فعال کرد.")
    row["status"] = clean
    row["updated_at"] = utc_iso()
    if clean in FINAL_CAMPAIGN_STATUSES:
        row["ended_at"] = row.get("ended_at") or utc_iso()
    record_campaign_event(db, row["id"], f"status:{clean}", actor_id=actor_id)
    return row


def schedule_campaign(
    db: dict[str, Any],
    campaign_id: int | str,
    scheduled_for: Any,
    *,
    actor_id: int | str,
    priority: int = 3,
    max_attempts: int = 5,
) -> dict[str, Any]:
    row = campaign_by_id(db, campaign_id)
    if row is None:
        raise ValueError("کمپین پیدا نشد.")
    if str(row.get("delivery") or "draft") == "draft":
        raise ValueError("پیش از زمان‌بندی، مسیر انتشار کمپین را انتخاب کنید.")
    if str(row.get("status") or "draft") in FINAL_CAMPAIGN_STATUSES:
        raise ValueError("کمپین بسته‌شده را نمی‌توان زمان‌بندی کرد.")
    when = (
        scheduled_for.astimezone(UTC)
        if isinstance(scheduled_for, datetime) and scheduled_for.tzinfo is not None
        else parse_dt(scheduled_for)
    )
    if when is None:
        raise ValueError("زمان انتشار نامعتبر است.")
    if when <= utc_now() + timedelta(seconds=30):
        raise ValueError("زمان انتشار باید حداقل ۳۰ ثانیه بعد باشد.")
    if not row.get("previewed_at"):
        campaign_preview(db, row["id"])
    snapshot = freeze_campaign_audience(db, row["id"], actor_id=actor_id)
    row.update(
        {
            "status": "scheduled",
            "scheduled_for": utc_iso(when),
            "schedule_status": "waiting",
            "schedule_priority": max(1, min(int(priority), 5)),
            "schedule_attempts": 0,
            "schedule_max_attempts": max(1, min(int(max_attempts), 10)),
            "schedule_next_attempt_at": utc_iso(when),
            "schedule_claimed_at": None,
            "schedule_last_error": "",
            "audience_snapshot_key": snapshot["dispatch_key"],
            "audience_snapshot_count": snapshot["count"],
            "audience_snapshot_sha256": snapshot["sha256"],
            "audience_snapshot_at": snapshot["frozen_at"],
            "updated_at": utc_iso(),
        }
    )
    record_campaign_event(
        db,
        row["id"],
        "scheduled",
        actor_id=actor_id,
        metadata={
            "scheduled_for": row["scheduled_for"],
            "priority": row["schedule_priority"],
        },
    )
    return row


def claim_due_campaigns(db: dict[str, Any], *, limit: int = 10) -> list[dict[str, Any]]:
    now = utc_now()
    candidates: list[dict[str, Any]] = []
    for row in db.setdefault("marketing_campaigns", {}).values():
        if not isinstance(row, dict) or str(row.get("status") or "") != "scheduled":
            continue
        due = parse_dt(row.get("schedule_next_attempt_at") or row.get("scheduled_for"))
        if due is None or due > now:
            continue
        attempts = int(row.get("schedule_attempts", 0) or 0)
        maximum = max(1, int(row.get("schedule_max_attempts", 5) or 5))
        if attempts >= maximum:
            row["schedule_status"] = "dead_letter"
            continue
        claimed_at = parse_dt(row.get("schedule_claimed_at"))
        if (
            str(row.get("schedule_status") or "") == "processing"
            and claimed_at
            and claimed_at + timedelta(minutes=SCHEDULE_CLAIM_TTL_MINUTES) > now
        ):
            continue
        candidates.append(row)
    candidates.sort(
        key=lambda row: (
            -int(row.get("schedule_priority", 3) or 3),
            str(row.get("schedule_next_attempt_at") or row.get("scheduled_for") or ""),
        )
    )
    claimed: list[dict[str, Any]] = []
    for row in candidates[: max(1, min(int(limit), 50))]:
        row["schedule_status"] = "processing"
        row["schedule_claimed_at"] = utc_iso(now)
        row["schedule_attempts"] = int(row.get("schedule_attempts", 0) or 0) + 1
        row["updated_at"] = utc_iso(now)
        claimed.append(
            {
                "campaign_id": str(row.get("id") or ""),
                "actor_id": str(row.get("created_by") or ""),
                "attempt": int(row["schedule_attempts"]),
                "version": int(row.get("version", 1) or 1),
                "claimed_at": row["schedule_claimed_at"],
            }
        )
    return claimed


def mark_scheduled_campaign_result(
    db: dict[str, Any],
    campaign_id: int | str,
    *,
    success: bool,
    error: str = "",
    expected_attempt: int | None = None,
    expected_version: int | None = None,
    expected_claimed_at: str | None = None,
) -> dict[str, Any]:
    row = campaign_by_id(db, campaign_id)
    if row is None:
        raise ValueError("کمپین پیدا نشد.")
    # A timed-out worker may return after cancellation, a reschedule or another
    # worker's lease. Only the current processing claim may change this row.
    if row.get("status") != "scheduled" or row.get("schedule_status") != "processing":
        return row
    if expected_attempt is not None and int(row.get("schedule_attempts", 0) or 0) != expected_attempt:
        return row
    if expected_version is not None and int(row.get("version", 1) or 1) != expected_version:
        return row
    if expected_claimed_at is not None and row.get("schedule_claimed_at") != expected_claimed_at:
        return row
    row["schedule_claimed_at"] = None
    row["updated_at"] = utc_iso()
    if success:
        row["schedule_status"] = "completed"
        row["schedule_next_attempt_at"] = None
        row["schedule_last_error"] = ""
        row["status"] = "active"
        record_campaign_event(db, row["id"], "scheduled_dispatch_completed")
        return row
    attempts = int(row.get("schedule_attempts", 0) or 0)
    maximum = max(1, int(row.get("schedule_max_attempts", 5) or 5))
    row["schedule_last_error"] = str(error or "")[:500]
    row["status"] = "scheduled"
    if attempts >= maximum:
        row["schedule_status"] = "dead_letter"
        row["schedule_next_attempt_at"] = None
        record_campaign_event(
            db,
            row["id"],
            "scheduled_dispatch_dead_letter",
            detail=row["schedule_last_error"],
        )
    else:
        delay_minutes = min(120, 5 * (2 ** max(0, attempts - 1)))
        row["schedule_status"] = "retry"
        row["schedule_next_attempt_at"] = utc_iso(utc_now() + timedelta(minutes=delay_minutes))
        record_campaign_event(
            db,
            row["id"],
            "scheduled_dispatch_retry",
            detail=row["schedule_last_error"],
            metadata={"retry_in_minutes": delay_minutes},
        )
    return row


def set_campaign_delivery(
    db: dict[str, Any],
    campaign_id: int | str,
    delivery: str,
    *,
    actor_id: int | str,
) -> dict[str, Any]:
    row = campaign_by_id(db, campaign_id)
    if row is None:
        raise ValueError("کمپین پیدا نشد.")
    clean = str(delivery or "").strip().lower()
    if clean not in DELIVERY_CHANNELS:
        raise ValueError("مسیر انتشار کمپین معتبر نیست.")
    row["delivery"] = clean
    row["version"] = int(row.get("version", 1) or 1) + 1
    row["updated_at"] = utc_iso()
    record_campaign_event(
        db,
        row["id"],
        "delivery_changed",
        actor_id=actor_id,
        detail=clean,
    )
    return row


def record_campaign_touch(
    db: dict[str, Any],
    campaign_id: int | str,
    user_id: int | str,
    touch_type: str,
    *,
    metadata: dict[str, Any] | None = None,
) -> bool:
    row = campaign_by_id(db, campaign_id)
    if row is None:
        return False
    uid = str(user_id or "")
    if not uid.isdigit():
        return False
    touch_key = f"{str(touch_type)[:64]}:{uid}"
    touch_index = row.setdefault("touch_index", {})
    if touch_key in touch_index:
        return False
    touch_index[touch_key] = utc_iso()
    if len(touch_index) > 100_000:
        row["touch_index"] = dict(list(touch_index.items())[-80_000:])
    record_campaign_event(
        db,
        row["id"],
        touch_type,
        user_id=uid,
        metadata=metadata,
    )
    return True


def campaign_studio_summary(db: dict[str, Any]) -> dict[str, Any]:
    rows = [row for row in db.setdefault("marketing_campaigns", {}).values() if isinstance(row, dict)]
    statuses = Counter(str(row.get("status") or "draft") for row in rows)
    categories = Counter(str(row.get("category") or "unknown") for row in rows)
    return {
        "total": len(rows),
        "draft": statuses.get("draft", 0),
        "active": statuses.get("active", 0),
        "paused": statuses.get("paused", 0),
        "scheduled": statuses.get("scheduled", 0),
        "completed": statuses.get("completed", 0),
        "dead_letter": sum(
            1 for row in rows if str(row.get("schedule_status") or "") == "dead_letter"
        ),
        "categories": dict(categories),
        "latest": sorted(rows, key=lambda row: str(row.get("created_at") or ""), reverse=True)[:20],
    }


def marketing_campaign_report(db: dict[str, Any], campaign_id: int | str) -> dict[str, Any]:
    row = campaign_by_id(db, campaign_id)
    if row is None:
        raise ValueError("کمپین پیدا نشد.")
    events = [
        event
        for event in db.get("campaign_events", [])
        if isinstance(event, dict) and event.get("campaign_id") == row["id"]
    ]
    event_counts = Counter(str(event.get("type") or "") for event in events)
    touched_users = {
        str(event.get("user_id"))
        for event in events
        if event.get("user_id") and str(event.get("user_id")).isdigit()
    }
    broadcast_jobs = [
        job
        for job in db.get("broadcast_queue", [])
        if isinstance(job, dict) and str(job.get("id")) in set(row.get("broadcast_job_ids", []))
    ]
    sent = sum(int(job.get("sent", 0) or 0) for job in broadcast_jobs)
    failed = sum(int(job.get("failed", 0) or 0) for job in broadcast_jobs)
    blocked = sum(int(job.get("blocked", 0) or 0) for job in broadcast_jobs)
    links = [
        link
        for link in db.get("public_channel_links", [])
        if isinstance(link, dict) and str(link.get("campaign_id") or "") == row["id"]
    ]
    link_joins = sum(int(link.get("join_count", 0) or 0) for link in links)
    active_link_members = sum(int(link.get("active_members", 0) or 0) for link in links)
    discount_report: dict[str, Any] = {}
    if row.get("discount_code"):
        try:
            discount_report = discount_campaign_report(db, str(row["discount_code"]))
        except ValueError:
            discount_report = {}
    attribution = growth_link_lab(db, attribution_model="last_touch")
    attributed_links = [
        item
        for item in attribution.get("links", [])
        if isinstance(item, dict) and str(item.get("campaign_id") or "") == row["id"]
    ]
    attributed_orders = sum(int(item.get("approved_orders", 0) or 0) for item in attributed_links)
    attributed_revenue = sum(int(item.get("revenue", 0) or 0) for item in attributed_links)
    attributed_cost = sum(int(item.get("cost", 0) or 0) for item in attributed_links)
    link_audience = sum(int(item.get("unique_joins", 0) or 0) for item in attributed_links)
    discount_orders = int(discount_report.get("approved_orders", 0) or 0)
    discount_revenue = int(discount_report.get("revenue", 0) or 0)
    # Attribution links are the primary source because they preserve the
    # campaign identity. A discount-code report is used only when no attributed
    # order exists; summing both would double count the same purchase.
    conversions = attributed_orders if attributed_orders else discount_orders
    revenue = attributed_revenue if attributed_orders else discount_revenue
    conversion_source = "attribution_links" if attributed_orders else ("discount_code" if discount_orders else "none")
    dynamic_audience = len(audience_members(db, str(row.get("audience") or "all")))
    frozen_audience = max(0, int(row.get("audience_snapshot_count", 0) or 0))
    audience_size = frozen_audience or dynamic_audience
    reached = max(sent, link_audience, len(touched_users))
    denominator = max(1, audience_size or reached)
    attempted = sent + failed + blocked
    event_types = {
        key: int(value)
        for key, value in event_counts.items()
        if key in {"view", "click", "join", "checkout", "purchase", "renewal", "unsubscribe"}
    }
    anomalies: list[str] = []
    if conversions > denominator:
        anomalies.append("CONVERSIONS_EXCEED_AUDIENCE")
    if sent > denominator and frozen_audience:
        anomalies.append("SENT_EXCEEDS_FROZEN_AUDIENCE")
    if failed or blocked:
        anomalies.append("DELIVERY_ERRORS_PRESENT")
    snapshot_verified = bool(
        row.get("audience_snapshot_key")
        and frozen_audience >= 0
        and len(str(row.get("audience_snapshot_sha256") or "")) == 64
    )
    measurement_quality = "high" if snapshot_verified and conversion_source == "attribution_links" else (
        "medium" if snapshot_verified or conversion_source != "none" else "limited"
    )
    return {
        "campaign": dict(row),
        "audience_size": audience_size,
        "dynamic_audience_size": dynamic_audience,
        "frozen_audience_size": frozen_audience,
        "audience_snapshot_verified": snapshot_verified,
        "sent": sent,
        "failed": failed,
        "blocked": blocked,
        "attempted": attempted,
        "delivery_success_rate": round(sent / max(1, attempted) * 100, 2),
        "touches": len(touched_users),
        "reached": reached,
        "channel_links": len(links),
        "channel_joins": link_joins,
        "tracking_links": len(attributed_links),
        "tracked_visits": link_audience,
        "active_attributed_members": active_link_members,
        "approved_orders": conversions,
        "revenue": revenue,
        "cost": attributed_cost,
        "cac": round(attributed_cost / max(1, conversions), 2) if attributed_cost else 0,
        "roas": round(revenue / attributed_cost, 2) if attributed_cost else 0,
        "roi": round((revenue - attributed_cost) / attributed_cost * 100, 2) if attributed_cost else 0,
        "discount_total": int(discount_report.get("discount_total", 0) or 0),
        "conversion_rate": round(conversions / denominator * 100, 2),
        "event_counts": dict(event_counts),
        "funnel": {
            "eligible": audience_size,
            "reached": reached,
            "visits": link_audience,
            "conversions": conversions,
            "reach_rate": round(reached / denominator * 100, 2),
            "visit_rate": round(link_audience / max(1, reached) * 100, 2),
            "conversion_rate": round(conversions / denominator * 100, 2),
            "events": event_types,
        },
        "measurement": {
            "quality": measurement_quality,
            "conversion_source": conversion_source,
            "attribution_model": "last_touch",
            "deduplicated_users": len(touched_users),
            "anomalies": anomalies,
        },
        "tracking": dict(row.get("tracking") or {}),
        "attributed_links": attributed_links,
    }
