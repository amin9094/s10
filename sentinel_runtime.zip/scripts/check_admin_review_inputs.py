#!/usr/bin/env python3
"""Real, read-only scan using the admin proposal path; never Telegram/orders."""
import argparse
import asyncio
import json
import sys
import time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))

async def inspect(symbols,timeframes):
    from core.http_client import close_http_client
    from services.admin_review_market_service import review_monitor,analyze_admin_review,check_review_before_entry
    monitor=review_monitor();monitor.start();rows=[]
    try:
        deadline=asyncio.get_running_loop().time()+25
        while asyncio.get_running_loop().time()<deadline and (monitor.failure or any(s not in monitor.latest for s in symbols)):
            await asyncio.sleep(.25)
        semaphore=asyncio.Semaphore(2)
        async def one(symbol,timeframe):
            async with semaphore:
                try:
                    async with asyncio.timeout(25):result=await analyze_admin_review(symbol,timeframe)
                    drafts=[r for r in result['results'] if r.get('draft_plan')];checks=[]
                    for row in drafts:
                        try:checks.append({'draft_hash':row['draft_hash'],'check':await check_review_before_entry(row)})
                        except Exception:checks.append({'draft_hash':row['draft_hash'],'state':'NO_LONGER_ELIGIBLE'})
                    return {'symbol':symbol,'timeframe':timeframe,'state':'ANALYZED','drafts':drafts,'checks':checks,
                            'no_setup_is_a_valid_result':True}
                except Exception:
                    return {'symbol':symbol,'timeframe':timeframe,'state':'SOURCE_OR_STREAM_UNAVAILABLE'}
        rows=await asyncio.gather(*(one(s,t) for s in symbols for t in timeframes))
        return {'kind':'REAL_READ_ONLY_ADMIN_PROPOSAL_AUDIT','markets':rows,'observed_ms':int(time.time()*1000),
                'monitored_symbols':sorted(monitor.latest),'all_requested_analyzed':all(r['state']=='ANALYZED' for r in rows),
                'messages_sent':0,'orders_sent':0,'actual_telegram_delivery_tested':False,'native_execution_qualified':False}
    finally:
        await monitor.close();await close_http_client()


def main():
    from services.keyless_market_data_service import supported_symbols
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--symbols',nargs='+',choices=sorted(supported_symbols()),default=sorted(supported_symbols()))
    parser.add_argument('--timeframes',nargs='+',choices=['5m','1h'],default=['5m','1h'])
    args=parser.parse_args();report=asyncio.run(inspect(args.symbols,args.timeframes))
    print(json.dumps(report,ensure_ascii=False,indent=2))
    return 0 if report['all_requested_analyzed'] else 2

if __name__=='__main__':raise SystemExit(main())
