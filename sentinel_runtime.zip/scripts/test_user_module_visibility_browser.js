/* Real DOM visibility, synthetic flags, zero external sessions/messages. */
const fs=require('fs'),path=require('path'),{chromium}=require('playwright');
const root=path.resolve(__dirname,'..');
async function run(){
 const browser=await chromium.launch({headless:true,executablePath:process.env.SENTINEL_TEST_BROWSER_PATH,args:['--no-sandbox']});
 const page=await browser.newPage({viewport:{width:412,height:915}}),errors=[];page.on('pageerror',e=>errors.push(e.message));
 const core=fs.readFileSync(path.join(root,'webapp/src/core.js'),'utf8'),hub=fs.readFileSync(path.join(root,'webapp/src/user-hub.js'),'utf8');
 const helpers=hub.slice(hub.indexOf('// One authoritative module switch'),hub.indexOf('function syncRewardBadges'));
 await page.setContent(`<html dir="rtl"><body><div id="menu"></div><nav><button data-page-target="risk">مربی ریسک</button><button data-open="support">پشتیبانی</button></nav><button data-trade-tab="coach">مربی ریسک</button><div id="later"></div><script>
 const state={lang:'fa',resources:{overview:{features:{risk_coach:{enabled:false},support:{enabled:false},notify:{enabled:false},language:{enabled:false},tools:{enabled:false}},account:{}}}};
 const $=s=>document.querySelector(s);function num(n){return String(n);}function esc(x){return String(x);}function icon(){return '';}function unreadRewardCount(){return 0;}
 ${core.match(/const FEATURE_KEY =[^\n]+\nfunction featureEnabled[^\n]+/)[0]}
 ${helpers}
 document.querySelector('#menu').innerHTML=userMenuHtml();
 window.flags=state.resources.overview.features;window.refresh=syncUserModuleVisibility;
 </script></body></html>`);
 await page.waitForTimeout(30);
 for(const selector of ['[data-menu-id="risk"]','[data-menu-id="support"]','[data-menu-id="notifications"]','[data-menu-id="language"]','[data-menu-id="tools"]'])if(await page.locator(selector).count())throw Error('Disabled catalog entry remains '+selector);
 for(const selector of ['nav [data-page-target="risk"]','[data-trade-tab="coach"]','nav [data-open="support"]'])if(await page.locator(selector).isVisible())throw Error('Disabled shortcut remains '+selector+' '+JSON.stringify(await page.evaluate(()=>({off:featureEnabled('risk'),html:document.querySelector('nav').outerHTML,errors:window.testErrors})))+' errors='+errors.join('|'));
 if(!await page.locator('[data-menu-id="signals"]').isVisible())throw Error('Unrelated enabled feature hidden');
 await page.evaluate(()=>document.querySelector('#later').innerHTML='<button data-open="support">پشتیبانی</button>');await page.waitForTimeout(30);
 if(await page.locator('#later button').isVisible())throw Error('Late-rendered disabled entry remains');
 await page.evaluate(()=>{flags.support.enabled=true;refresh();});if(!await page.locator('#later button').isVisible())throw Error('Reenabled shortcut remains hidden');
 if(errors.length)throw Error(errors.join('\n'));
 console.log(JSON.stringify({passed:true,synthetic:true,checks:['flat_catalog','disabled_modules_absent','disabled_shortcuts_hidden','coach_tab_hidden','late_render_filtered','reenabled_restored','unrelated_features_retained'],errors}));await browser.close();
}
run().catch(e=>{console.error(e);process.exitCode=1;});
