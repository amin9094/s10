"""One coverage scope for Docker, local release proof and finalization."""

CRITICAL_TARGETS = ['core/async_runtime.py', 'core/distributed_jobs.py', 'core/miniapp_server.py', 'core/rate_limit.py', 'core/runtime_watchdog.py', 'core/storage/engine.py', 'core/update_processor.py', 'modules/admin_command_os.py', 'modules/automation_event_bus.py', 'modules/automation_v2.py', 'modules/feature_flags.py', 'modules/gemini_ads.py', 'modules/market_scope.py', 'modules/operations_intelligence.py', 'modules/portfolio.py', 'modules/prices.py', 'modules/prop_rules_v2/engine.py', 'modules/provider_intelligence.py', 'modules/security_sentinel.py', 'modules/trading_coach.py', 'repositories/v2/commerce.py', 'repositories/v2/idempotency.py', 'repositories/v2/journal.py', 'repositories/v2/positions.py', 'repositories/v2/preferences.py', 'repositories/v2/signals.py', 'services/actions_v2/journal.py', 'services/actions_v2/preferences.py', 'services/ai_control_service.py', 'services/automation_v2_dispatcher.py', 'services/live_market_service.py', 'services/miniapp_action_service_v2.py', 'services/miniapp_read_service_v2.py', 'services/vip_entitlement_projection.py']

# Candle-only analysis and shared account credits are financial data boundaries.
CRITICAL_TARGETS += [
    "repositories/v2/provider_budget.py", "services/canonical_market_service.py",
    "services/strategy_analysis_service.py", "services/market_reference_service.py",
    "modules/strategies/observations.py", "modules/strategies/indicators/observer.py",
    "modules/strategies/order_block/observer.py", "modules/strategies/sweep_fvg/observer.py",
    "modules/strategies/fibonacci/observer.py",
    "services/iran_market_data_service.py",
    "services/keyless_market_data_service.py",
    "services/strategy_readiness_service.py",
    "services/iran_equity_service.py", "modules/iran_equities.py", "modules/iran_equity_intraday.py",
    "services/strategy_delivery_service.py", "services/strategy_quote_owner.py",
    "services/biquote_stream_check.py", "modules/admin_review_proposals.py",
    "services/admin_review_market_service.py", "services/admin_review_delivery_service.py",
    "repositories/v2/strategy_reviews.py", "repositories/v2/strategy_outbox.py",
    "modules/strategies/common.py", "modules/strategies/identity.py",
    "modules/strategies/indicators/engine.py", "modules/strategies/sweep_fvg/engine.py",
    "modules/strategies/order_block/engine.py", "modules/strategies/fibonacci/engine.py",
    "modules/strategies/fibonacci_pullback/engine.py", "repositories/v2/setup_proposals.py",
]

# Private signal publication and simulated account balances are durable boundaries.
CRITICAL_TARGETS += [
    "services/live_signal_service.py", "repositories/v2/live_signal_inbox.py",
    "repositories/v2/strategy_paper.py", "modules/strategy_paper.py",
    "bot_runtime/live_signal_desk.py",
    "core/bot_identity.py", "modules/goldbach_confirmation.py",
    "services/goldbach_settings_service.py",
    "modules/signal_plan_policy.py",
]

# Source revision acceptance and reminder ownership are durable admin boundaries.
CRITICAL_TARGETS += [
    "services/diagnostic_review_service.py", "services/desk_notification_service.py",
    "repositories/v2/desk_notifications.py",
]

# Market-scope enforcement and private Iranian equity routing are boundaries.
CRITICAL_TARGETS += [
    "modules/automated_market_scope.py", "repositories/v2/iran_equity_analyses.py",
    "services/iran_equity_desk_service.py", "bot_runtime/iran_equity_desk.py",
]

# Causal liquidity direction and exact signal presentation.
CRITICAL_TARGETS += ["modules/strategies/liquidity.py", "modules/strategy_signal_format.py"]

# Admin combinations, indicator votes and their immutable settings are financial boundaries.
CRITICAL_TARGETS += ["modules/custom_strategy.py", "modules/indicator_suite.py", "services/custom_strategy_service.py"]
CRITICAL_TARGETS += ["modules/signal_chart.py", "services/signal_chart_service.py"]

CRITICAL_TARGETS += ['modules/signal_execution.py']

# Privacy completion and exports cross the legacy/normalized ownership boundary.
CRITICAL_TARGETS += ["core/privacy_projection.py", "services/privacy_service.py", "modules/privacy.py"]

# Upgrade 70: financial reports, frozen research isolation, and publication
# assets must be included in the same coverage boundary as the live ledger.
CRITICAL_TARGETS += [
    'repositories/v2/paper_statistics.py', 'repositories/v2/paper_comparison.py',
    'repositories/v2/paper_equity.py', 'repositories/v2/research_cases.py',
    'modules/signal_price_contract.py', 'modules/strategy_replay.py',
    'modules/original_dmns_amd.py', 'services/poster_presets_service.py',
    'services/research_protocol_service.py', 'services/strategy_lab_service.py',
    'services/research_review_service.py', 'services/signal_workspace_service.py',
]

# Release 33: publication, Persian diagnostics, and explicit strategy paths.
CRITICAL_TARGETS += [
    "services/publication_state.py", "core/signal_commit_projection.py",
    "core/error_explanations.py", "services/signal_projection_service.py",
    "repositories/v2/strategy_paths.py", "services/strategy_paths_service.py",
    "services/signal_delivery_recovery.py", "bot_runtime/strategy_paths_panel.py",
]
