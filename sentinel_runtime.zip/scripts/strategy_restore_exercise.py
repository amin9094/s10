"""Offline strategy-ledger restore drill. The source is read only.

Pseudonymizes actor identifiers and removes operational free text in an
isolated copy. This is not a certificate of full customer anonymization.
Financial plans and frozen research inputs remain exact for reproducibility.
"""
import argparse,hashlib,hmac,json,secrets,tempfile
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:sys.path.insert(0,str(ROOT))
from scripts.strategy_backup import export_snapshot,restore_snapshot,TABLES
from core.storage.engine import DatabaseEngine
from repositories.v2.common import json_dump,json_load

ACTOR_FIELDS={'actor','owner','admin_id','user_id','claimed_by','reviewer','reset_by','created_by','admin','recipient'}
TEXT_FIELDS={'note','notes','text','message','comment','reason_text','email','username','first_name','last_name','phone'}
PROTECTED={'plan','draft_plan','base_plan','bundle','original_results','chart_snapshot'}
EXCLUDED={'s9_poster_assets','s9_poster_presets','s9_original_indicator_inputs'}


def financial_projection(engine):
    """Hash exact financial state without collecting all trade payloads."""
    digest=hashlib.sha256();count=0
    with engine.transaction(read_only=True,repeatable_read=True) as c:
        for table in ('s9_strategy_paper_runs','s9_strategy_paper_trades'):
            after=''
            while True:
                rows=c.execute(f'SELECT * FROM {table} WHERE id>? ORDER BY id LIMIT 200',(after,)).fetchall()  # nosec B608 -- fixed table tuple
                for row in rows:
                    p=json_load(row['payload']);keys=(('starting_balance','balance','risk_percent','profile_id','risk_policy','cost_models','entries_enabled') if table.endswith('runs') else
                        ('plan','run_id','signal_id','state','risk_usd','quantity','fill_price','remaining','realized_usd','unrealized_usd','targets_hit','closed_ms','entered_ms'))
                    value={k:p.get(k) for k in keys};identity={k:row.get(k) for k in ('id','engine','active','run_id','signal_id','state')}
                    digest.update(json_dump({'table':table,'identity':identity,'value':value}).encode());count+=1
                if len(rows)<200:break
                after=rows[-1]['id']
    return {'sha256':digest.hexdigest(),'records':count}


def exercise(source):
    before=financial_projection(source);salt=secrets.token_bytes(32);redacted=0
    def alias(value):return 'actor_'+hmac.new(salt,str(value).encode(),hashlib.sha256).hexdigest()[:20]
    def redact(value):
        nonlocal redacted
        if isinstance(value,list):return [redact(v) for v in value]
        if not isinstance(value,dict):return value
        result={}
        for key,v in value.items():
            if key in PROTECTED:result[key]=v
            elif key in ACTOR_FIELDS and v is not None:result[key]=alias(v);redacted+=1
            elif key in TEXT_FIELDS:result[key]='[REMOVED_IN_RESTORE_DRILL]';redacted+=1
            else:result[key]=redact(v)
        return result
    with tempfile.TemporaryDirectory(prefix='sentinel-restore-drill-') as folder:
        path=Path(folder);raw=path/'source.zip';sanitized=path/'pseudonymized.zip'
        export_snapshot(source,raw,include_quotes=False)
        first=DatabaseEngine(database_url='',sqlite_path=path/'first.sqlite3');second=DatabaseEngine(database_url='',sqlite_path=path/'second.sqlite3')
        try:
            first.ensure_schema();second.ensure_schema();restore_snapshot(raw,first)
            with first.transaction() as c:
                for table in TABLES:
                    if table in EXCLUDED:
                        c.execute(f'DELETE FROM {table}')  # nosec B608 -- schema whitelist
                        continue
                    after=0
                    while True:
                        rows=c.execute(f'SELECT rowid AS drill_rowid,* FROM {table} WHERE rowid>? ORDER BY rowid LIMIT 200',(after,)).fetchall()  # nosec B608 -- isolated SQLite copy
                        for row in rows:
                            change={}
                            for key,v in row.items():
                                if key in ACTOR_FIELDS and v is not None:change[key]=alias(v);redacted+=1
                                elif key=='payload':change[key]=json_dump(redact(json_load(v)))
                            if change:
                                c.execute(f'UPDATE {table} SET '+','.join(k+'=?' for k in change)+' WHERE rowid=?',tuple(change.values())+(row['drill_rowid'],))  # nosec B608 -- schema-owned identifiers
                        if len(rows)<200:break
                        after=rows[-1]['drill_rowid']
            intermediate=financial_projection(first)
            if intermediate!=before:raise ValueError('PSEUDONYMIZATION_CHANGED_FINANCIAL_STATE')
            export_snapshot(first,sanitized,include_quotes=False);restore_snapshot(sanitized,second)
            if financial_projection(second)!=before:raise ValueError('RESTORE_FINANCIAL_PARITY_FAILED')
        finally:first.close();second.close()
    if financial_projection(source)!=before:raise ValueError('SOURCE_FINANCIAL_STATE_CHANGED_DURING_DRILL')
    return {'state':'STRATEGY_LEDGER_RESTORE_VERIFIED','financial_projection':before,'pseudonymized_fields':redacted,
            'source_written':False,'quotes_included':False,'quotes_continuity_not_assumed':True,
            'scope':'STRATEGY_FINANCIAL_PARITY_AND_OPERATIONAL_METADATA_ONLY',
            'full_customer_anonymization_certified':False,'temporary_copies_destroyed':True}


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',required=True);args=parser.parse_args()
    from core.storage.engine import normalized_engine
    result=exercise(normalized_engine());Path(args.output).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')


if __name__=='__main__':main()
