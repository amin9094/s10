#!/usr/bin/env python3
"""Single safe operator CLI for SENTINEL maintenance and releases.

This wrapper intentionally does not deploy or execute arbitrary shell input. It
only composes existing repository-owned quality/release commands so the same
validated path is used locally, in CI, and on Railway build workers.
"""
from __future__ import annotations

import argparse
import json
import subprocess  # nosec B404 -- fixed repository-owned commands only
import sys
from pathlib import Path
from typing import Iterable

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
PYTHON = sys.executable
DEFAULT_DIST = ROOT / "dist"


def _run(args: list[str], *, label: str, check: bool = True) -> int:
    print(f"\n==> {label}")
    print("$ " + " ".join(args))
    result = subprocess.run(args, cwd=ROOT, check=False)  # nosec B603
    if check and result.returncode != 0:
        raise RuntimeError(f"{label} failed with exit code {result.returncode}")
    return int(result.returncode)


def doctor_commands() -> list[tuple[str, list[str]]]:
    return [
        ("Compile", [PYTHON, "-m", "compileall", "-q", "main.py", "bot.py", "config.py", "core", "modules", "services", "repositories", "handlers", "jobs", "bot_runtime"]),
        ("Security audit", [PYTHON, "scripts/security_audit_verify.py"]),
        ("Dependency boundaries", [PYTHON, "scripts/dependency_boundary_check.py"]),
        ("Circular imports", [PYTHON, "scripts/circular_import_check.py"]),
    ]


def test_commands() -> list[tuple[str, list[str]]]:
    return [("Pytest", [PYTHON, "-m", "pytest", "-q"])]


def release_commands(*, output: Path, evidence: Path, production: bool = False) -> list[tuple[str, list[str]]]:
    quality = [PYTHON, "scripts/quality_gate.py", "--full-suite", "--release-channel", "production" if production else "candidate"]
    if production:
        quality.append("--enforce-production-thresholds")
    build = [PYTHON, "scripts/build_release.py", "--outer", str(output), "--evidence", str(evidence)]
    gate = [PYTHON, "scripts/release_gate.py"]
    if production:
        build.append("--production")
        gate.append("--production")
    return [("Quality gate", quality), ("Build release", build), ("Release gate", gate)]


def _run_many(commands: Iterable[tuple[str, list[str]]]) -> None:
    for label, command in commands:
        _run(command, label=label)


def main() -> int:
    parser = argparse.ArgumentParser(prog="sentinelctl", description="SENTINEL operator and release CLI")
    sub = parser.add_subparsers(dest="command", required=True)
    doctor = sub.add_parser("doctor", help="Run fast local health and architecture checks")
    doctor.add_argument("--strict-env", action="store_true", help="also require deployment secrets/configuration to pass preflight")
    sub.add_parser("test", help="Run the complete pytest suite")

    build = sub.add_parser("build", help="Build an archive from an already-current QUALITY_PROOF")
    build.add_argument("--output", type=Path, default=DEFAULT_DIST / "SENTINEL.zip")
    build.add_argument("--evidence", type=Path, default=DEFAULT_DIST / "SENTINEL_QUALITY_EVIDENCE.zip")

    release = sub.add_parser("release", help="Quality-test, build and verify one candidate in sequence")
    release.add_argument("--output", type=Path, default=DEFAULT_DIST / "SENTINEL.zip")
    release.add_argument("--evidence", type=Path, default=DEFAULT_DIST / "SENTINEL_QUALITY_EVIDENCE.zip")
    release.add_argument("--production", action="store_true")

    sub.add_parser("config", help="Print a secret-safe grouped configuration readiness report")

    verify = sub.add_parser("verify", help="Verify local artifact or a deployed HTTPS endpoint")
    verify.add_argument("--base-url", default="")
    verify.add_argument("--allow-not-ready", action="store_true")

    args = parser.parse_args()
    DEFAULT_DIST.mkdir(parents=True, exist_ok=True)

    if args.command == "doctor":
        _run_many(doctor_commands())
        preflight_rc = _run([PYTHON, "scripts/preflight.py", "--offline"], label="Environment preflight", check=bool(args.strict_env))
        if preflight_rc != 0 and not args.strict_env:
            print("WARNING: deployment environment is incomplete here; code doctor checks still passed.")
    elif args.command == "test":
        _run_many(test_commands())
    elif args.command == "config":
        from modules.config_wizard import config_wizard_snapshot
        import os
        print(json.dumps(config_wizard_snapshot(os.environ), ensure_ascii=False, indent=2))
    elif args.command == "build":
        _run([PYTHON, "scripts/build_release.py", "--outer", str(args.output), "--evidence", str(args.evidence)], label="Build release")
        _run([PYTHON, "scripts/release_gate.py"], label="Release gate")
    elif args.command == "release":
        _run_many(doctor_commands())
        _run([PYTHON, "scripts/preflight.py", "--offline"], label="Environment preflight", check=bool(args.production))
        _run_many(release_commands(output=args.output, evidence=args.evidence, production=bool(args.production)))
    elif args.command == "verify":
        if args.base_url:
            command = [PYTHON, "scripts/postdeploy_smoke.py", "--base-url", str(args.base_url)]
            if args.allow_not_ready:
                command.append("--allow-not-ready")
            _run(command, label="Post-deploy smoke")
        else:
            _run([PYTHON, "scripts/release_gate.py"], label="Local release gate")
    else:  # pragma: no cover
        raise RuntimeError("unknown command")

    version = (ROOT / "VERSION").read_text(encoding="utf-8").strip()
    print(json.dumps({"ok": True, "command": args.command, "version": version}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"sentinelctl failed: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc
