#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import ProxyHandler, Request, build_opener

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from config import SETTINGS  # noqa: E402
from core.heartbeat import heartbeat_age_seconds, process_is_alive, read_heartbeat  # noqa: E402


def _http_liveness(host: str, port: int, timeout: float) -> None:
    if port <= 0:
        raise RuntimeError("HTTP health port is not configured")
    safe_host = "127.0.0.1" if host in {"0.0.0.0", "::", ""} else host  # nosec B104
    if ":" in safe_host and not safe_host.startswith("["):
        safe_host = f"[{safe_host}]"
    request = Request(
        f"http://{safe_host}:{port}/readyz",
        method="GET",
        headers={"Host": "healthcheck.railway.app", "User-Agent": "sentinel-container-health/1"},
    )
    # Container-local probes must never be routed through an outbound proxy.
    opener = build_opener(ProxyHandler({}))
    try:
        response = opener.open(request, timeout=max(1.0, timeout))  # nosec B310
    except HTTPError as exc:
        try:
            payload = json.loads(exc.read(4096))
            failed = [str(name) for name, healthy in payload.get("checks", {}).items() if not healthy]
        except (ValueError, AttributeError, TypeError):
            failed = []
        finally:
            exc.close()
        detail = ", ".join(failed) or "readiness response unavailable"
        raise RuntimeError(f"HTTP readiness returned {exc.code}; failing checks: {detail}") from exc
    with response:
        status = int(getattr(response, "status", 0) or 0)
        if status != 200:
            raise RuntimeError(f"HTTP readiness returned status {status}")
        response.read(4096)


def _runtime_health(max_age: int) -> None:
    data = read_heartbeat(SETTINGS.heartbeat_file)
    age = heartbeat_age_seconds(SETTINGS.heartbeat_file)
    if data.get("status") != "running":
        raise RuntimeError(f"bot status is {data.get('status')!r}")
    if age > max(1, max_age):
        raise RuntimeError(f"heartbeat is stale ({age:.1f}s)")
    pid = int(data.get("pid", 0) or 0)
    if not process_is_alive(pid):
        raise RuntimeError("bot process is not alive")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=("http", "runtime"), default="http")
    parser.add_argument("--max-age", type=int, default=SETTINGS.heartbeat_max_age_seconds)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=SETTINGS.health_port)
    parser.add_argument("--timeout", type=float, default=5.0)
    args = parser.parse_args(argv)
    try:
        if args.mode == "runtime":
            _runtime_health(args.max_age)
        else:
            _http_liveness(args.host, args.port, args.timeout)
    except Exception as exc:
        print(f"UNHEALTHY: {exc}", file=sys.stderr)
        return 1
    print(f"HEALTHY mode={args.mode}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
