"""Restore/verify a complete backup into a NEW isolated directory only."""
import argparse
import json
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:sys.path.insert(0,str(ROOT))


def main():
    from config import SETTINGS
    from core.full_backup import activate_restored_paths,restore_complete_backup
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('backup',type=Path)
    parser.add_argument('--destination',required=True,type=Path)
    parser.add_argument('--postgres-url',default='')
    parser.add_argument('--rebind-paths',action='store_true')
    args=parser.parse_args()
    result=restore_complete_backup(args.backup,args.destination,encryption_key=SETTINGS.backup_encryption_key,
                                  previous_keys=SETTINGS.backup_previous_keys,postgres_url=args.postgres_url)
    if args.rebind_paths:result['activation']=activate_restored_paths(args.destination,postgres_url=args.postgres_url)
    print(json.dumps(result,ensure_ascii=False))


if __name__=='__main__':main()
